// file: lib/drakoridMap.ts
import * as cheerio from 'cheerio';
export interface SliderItem {
    id: string;
    url: string;
    imageUrl: string;
}

export function mapSliderData(htmlString: string): SliderItem[] {
    const results: SliderItem[] = [];

    // Regex untuk mencari pola: <a href="URL"><img src="IMAGE_URL"
    const regex = /<a\s+href=["']([^"']+)["'][^>]*>\s*<img\s+src=["']([^"']+)["']/gi;
    let match;

    // Looping semua hasil yang cocok dengan Regex di dalam string HTML
    while ((match = regex.exec(htmlString)) !== null) {
        const fullUrl = match[1];      // Contoh: https://drakorid.co/go/4869
        const fullImageUrl = match[2]; // Contoh: https://convert.d-cdn.me/.../1.jpg

        // Opsional: Ekstrak ID dari URL (ngambil angka "4869" dari "/go/4869")
        const idMatch = fullUrl.match(/\/go\/(\d+)/);
        const id = idMatch ? idMatch[1] : "";

        results.push({
            id: id,
            url: fullUrl,
            imageUrl: fullImageUrl
        });
    }

    return results;
}

export interface OngoingItem {
    id: string;
    url: string;
    imageUrl: string;
    episode: string;
    title: string;
}

export function mapOngoingData(htmlString: string): OngoingItem[] {
    const $ = cheerio.load(htmlString);
    const results: OngoingItem[] = [];

    $('.movie-list-card').each((i, el) => {
        const link = $(el).find('a').attr('href') || "";
        const img = $(el).find('img');
        const imageUrl = img.attr('src') || "";

        // Ambil Episode
        let ep = $(el).find('.badge').text().trim();
        if (!ep) {
            ep = $(el).find('.top-right span').text().trim();
        }

        // Ambil Judul
        let title = $(el).find('[data-original-title]').attr('data-original-title');

        if (!title) {
            title = $(el).find('.card-title, h5, .movie-list-card__title').text().trim();
        }

        if (!title) {
            const altText = img.attr('alt')?.trim();
            title = (altText && altText.toLowerCase() !== 'image') ? altText : "Unknown Title";
        }

        // 🔥 BERSIHKAN JUDUL: Hapus teks "Episode XX" dari manapun sumber judulnya didapat
        title = title.replace(/\s*Episode\s+\d+.*$/i, '').trim();

        // Ambil ID dari URL
        const idMatch = link.match(/\/nonton\/([^\/]+)/);
        const id = idMatch ? idMatch[1] : "";

        if (id) {
            results.push({
                id: id,
                url: link,
                imageUrl: imageUrl,
                episode: ep,
                title: title
            });
        }
    });

    return results;
}

export interface TrendingItem {
    rank: number;
    id: string;
    url: string;
    imageUrl: string;
    title: string;
}

export interface AllTrendingData {
    hari_ini: TrendingItem[];
    minggu_ini: TrendingItem[];
    bulan_ini: TrendingItem[];
}

// Tambahkan parameter $ (CheerioAPI)
function parsePane(paneElement: any, $: cheerio.CheerioAPI): TrendingItem[] {
    const results: TrendingItem[] = [];

    paneElement.find('.trending-card').each((_: number, el: any) => {
        // Sekarang $ sudah dikenal karena dikirim dari luar
        const card = $(el);
        const rank = parseInt(card.find('.trending-rank').text().trim()) || 0;
        const link = card.find('a.trending-card__title').attr('href') || "";
        const img = card.find('img').attr('src') || "";
        const title = card.find('.trending-card__title').text().trim();

        const idMatch = link.match(/\/nonton\/([^\/]+)/);
        const id = idMatch ? idMatch[1] : "";

        if (id) {
            results.push({ rank, id, url: link, imageUrl: img, title });
        }
    });

    return results.sort((a, b) => a.rank - b.rank);
}

// Update fungsi utamanya
export function mapAllTrendingData(htmlString: string): AllTrendingData {
    const $: cheerio.CheerioAPI = cheerio.load(htmlString);

    return {
        // Kirim $ ke fungsi
        hari_ini: parsePane($('#trending-pane-today'), $),
        minggu_ini: parsePane($('#trending-pane-week'), $),
        bulan_ini: parsePane($('#trending-pane-month'), $)
    };
}

// Terbaru Mapping
export interface TerbaruItem {
    id: string;
    url: string;
    imageUrl: string;
    title: string;
}

export function mapTerbaruData(htmlString: string): TerbaruItem[] {
    const $: cheerio.CheerioAPI = cheerio.load(htmlString);
    const results: TerbaruItem[] = [];

    // 1. UPDATE: Batasi di #appCapsule, lalu targetkan .movie-list-card
    $('#appCapsule .movie-list-card').each((_, el) => {
        const card = $(el);
        const link = card.find('a').attr('href') || "";
        const img = card.find('img');

        // Coba cari judul dari 3 sumber dengan prioritas:
        // 1. Atribut data-original-title (paling akurat untuk judul lengkap)
        // 2. Teks dari elemen title (.movie-list-card__title / h5)
        // 3. Alt dari tag img (cadangan)
        let title = card.find('[data-original-title]').attr('data-original-title');

        if (!title) {
            title = card.find('.movie-list-card__title, h5').text().trim();
        }

        if (!title) {
            title = img.attr('alt') || "No Title";
        }

        const imageUrl = img.attr('src') || "";

        // Ambil ID/Slug dari URL (contoh: /nonton/the-ugly-2025/ -> the-ugly-2025)
        const idMatch = link.match(/\/nonton\/([^\/]+)/);
        const id = idMatch ? idMatch[1] : "";

        // Push ke array hanya jika data yang krusial ditemukan
        if (id && link) {
            results.push({
                id: id,
                url: link,
                imageUrl: imageUrl,
                title: title.trim() // Bersihkan spasi berlebih
            });
        }
    });

    return results;
}
// Item Kategori (untuk endpoint /kategori)
export interface KategoriItem {
    id: string;
    url: string;
    title: string;
    count: number;
}

export function mapKategoriData(htmlString: string): KategoriItem[] {
    const $: cheerio.CheerioAPI = cheerio.load(htmlString);
    const results: KategoriItem[] = [];

    // Langsung target ke elemen listview-nya
    $('.listview.image-listview a').each((_, el) => {
        const item = $(el);
        const link = item.attr('href') || "";

        // Mengambil title dari div class="in" dan membersihkan teks dari tag span (badge)
        const inDiv = item.find('.in');
        const count = parseInt(inDiv.find('.badge').text().trim()) || 0;

        // Ambil title: clone div, hapus badge, ambil teks yang tersisa
        const titleClone = inDiv.clone();
        titleClone.find('.badge').remove();
        const title = titleClone.text().trim();

        // Ekstrak ID dari URL
        const idMatch = link.match(/\/kategori\/([^\/]+)/);
        const id = idMatch ? idMatch[1] : "";

        if (id && title) {
            results.push({
                id: id,
                url: link,
                title: title,
                count: count
            });
        }
    });

    return results;
}

// Episode & Detail Drama Mapping

export interface EpisodeItem {
    episode: string;
    number: number;
}

export interface DetailDramaItem {
    id: string;       // ID angka (buat API episode)
    slug: string;        // ID slug
    title: string;
    poster: string;
    synopsis: string;
    details: Record<string, string>;
    cast: { name: string; url: string; role: string }[];
    episodes: EpisodeItem[];
}

// file: lib/drakoridMap.ts

export function mapEpisodeData(htmlString: string): EpisodeItem[] {
    const $ = cheerio.load(htmlString);
    const episodes: EpisodeItem[] = [];

    // 1. Cari elemen daftar episode di dalam modal
    const epButtons = $('.episode-pick-num');

    // 2. Jika ada tombol episode, kita parse
    if (epButtons.length > 0) {
        epButtons.each((_, el) => {
            const epNum = $(el).attr('data-episode');
            const parsedNum = parseInt(epNum || "0", 10);

            if (parsedNum > 0 && !episodes.some(ep => ep.number === parsedNum)) {
                episodes.push({
                    episode: `Episode ${parsedNum}`,
                    number: parsedNum
                });
            }
        });
    }
    // 3. JIKA EPISODE KOSONG (KEMUNGKINAN FILM)
    else {
        // Logika tambahan: cek apakah ada tombol "Tonton Episode 1"
        // Jika ada tombol nonton, anggap ini film 1 episode
        const btnTonton = $('#btnTonton');
        if (btnTonton.length > 0) {
            episodes.push({
                episode: "Episode 1",
                number: 1
            });
        }
    }

    return episodes.sort((a, b) => a.number - b.number);
}

export function mapDetailDramaData(htmlString: string, slug: string): DetailDramaItem {
    const $ = cheerio.load(htmlString);

    // 1. Ekstrak Detail (Membaca baris teks di dalam <p> yang berisi "Details")
    const details: Record<string, string> = {};
    const detailsP = $('p').filter((_, el) => $(el).text().includes('Details'));

    if (detailsP.length > 0) {
        const detailsHtml = detailsP.html() || "";
        // Pisahkan baris berdasarkan tag <br>
        const lines = detailsHtml.split(/<br\s*\/?>/i);

        lines.forEach(line => {
            // Bersihkan sisa-sisa tag HTML (seperti tag <img> di baris awal jika ada)
            const cleanLine = $('<div>').html(line).text().trim();
            if (cleanLine.includes(':')) {
                const [key, ...val] = cleanLine.split(':');
                const cleanKey = key.replace(/[^\w\s]/gi, '').trim();

                // Jangan masukkan tulisan "Details" sebagai key
                if (cleanKey && cleanKey.toLowerCase() !== 'details') {
                    details[cleanKey] = val.join(':').trim();
                }
            }
        });
    }

    // 2. Ekstrak Sinopsis (Menggabungkan paragraf setelah teks "Sinopsis")
    let synopsisParts: string[] = [];
    const synopsisStartP = $('p').filter((_, el) => $(el).text().startsWith('Sinopsis'));

    if (synopsisStartP.length > 0) {
        // Ambil teks paragraf pertama tanpa kata "Sinopsis"
        synopsisParts.push(synopsisStartP.text().replace(/^Sinopsis\s*/i, '').trim());

        // Ambil paragraf setelahnya jika sinopsisnya panjang (berhenti jika bertemu info lain)
        let nextEl = synopsisStartP.next();
        // Tambahkan ?. setelah .prop('tagName')
        while (nextEl.length > 0 && nextEl.prop('tagName')?.toLowerCase() === 'p') {
            const text = nextEl.text().trim();
            if (text.includes('Additional Cast Members') || text.includes('Details')) break;
            if (text) synopsisParts.push(text);
            nextEl = nextEl.next();
        }
    }
    const synopsis = synopsisParts.join(' ').trim();

    // 3. Ekstrak Cast (Aktor Utama dari Table & Aktor Tambahan dari List)
    const cast: { name: string; url: string; role: string }[] = [];

    // Bagian A: Ambil dari Table (Pemeran Utama)
    $('#deskripsi table').each((_, tableEl) => {
        const rows = $(tableEl).find('tr');
        let nameRowIdx = -1;

        // Cari baris index ke berapa yang berisi nama/link aktor (bukan baris foto)
        rows.each((i, row) => {
            if ($(row).find('a').text().trim() !== '' && $(row).find('img').length === 0) {
                nameRowIdx = i;
            }
        });

        // Jika baris nama ketemu, baris tepat di bawahnya (nameRowIdx + 1) adalah baris Role/Peran
        if (nameRowIdx !== -1 && nameRowIdx + 1 < rows.length) {
            const nameTds = $(rows[nameRowIdx]).find('td');
            const roleTds = $(rows[nameRowIdx + 1]).find('td');

            nameTds.each((j, td) => {
                const link = $(td).find('a');
                if (link.length > 0) {
                    const name = link.text().trim();
                    const url = link.attr('href') || "";
                    const role = $(roleTds[j]).text().trim();
                    if (name) {
                        cast.push({ name, url, role });
                    }
                }
            });
        }
    });

    // Bagian B: Ambil dari <ul> (Additional Cast Members jika ada)
    $('#deskripsi ul li').each((_, liEl) => {
        const li = $(liEl);
        const link = li.find('a');
        if (link.length > 0 && li.text().includes('-')) {
            const name = link.text().trim();
            const url = link.attr('href') || "";
            // Pisahkan teks berdasarkan tanda '-' untuk mengambil nama perannya
            const role = li.text().split('-')[1]?.trim() || "";
            if (name) {
                cast.push({ name, url, role });
            }
        }
    });

    return {
        id: slug,
        slug: slug,
        title: $('h3.title').text().trim(),
        poster: $('.poster-img').attr('src') || "",
        synopsis,
        details,
        cast,
        episodes: typeof mapEpisodeData === 'function' ? mapEpisodeData(htmlString) : []
    };
}

// Play Data Mapping

export interface PlayResponse {
    id: string;
    episode: number;
    quality: number;
    format: string;
    vid_url: string;
    vid_url_proxy: string;
}

export function mapPlayData(slug: string, episode: number, quality: number, streamUrl: string): PlayResponse {
    const dramaId = slug;

    // 1. Deteksi format otomatis dari streamUrl
    let videoFormat = "UNKNOWN";
    const lowerUrl = streamUrl.toLowerCase();

    if (lowerUrl.includes('.m3u8')) {
        videoFormat = "HLS";
    } else if (lowerUrl.includes('.mp4')) {
        videoFormat = "MP4";
    } else if (lowerUrl.includes('.mkv')) {
        videoFormat = "MKV";
    }

    return {
        id: slug,
        episode: episode,
        quality: quality,
        format: videoFormat, // 2. Masukkan format otomatis di sini
        vid_url: streamUrl,
        vid_url_proxy: streamUrl, // proxy-nya udah disesuaikan sesuai kodemu
    };
}

export interface SearchDramaItem {
    id: string;          // Slug / ID unik drama
    slug: string;        // URL path slug (misal: perfect-and-casual-2020)
    title: string;       // Judul lengkap dari data-original-title
    poster: string;      // URL gambar poster
}

export interface SearchDramaResponse {
    results: SearchDramaItem[];
    pagination: {
        currentPage: number;
        nextPageUrl: string | null;
        hasNextPage: boolean;
    };
}

export function mapSearchDramaData(htmlString: string): SearchDramaResponse {
    const $ = cheerio.load(htmlString);
    const results: SearchDramaItem[] = [];

    // 1. Ekstrak data list drama dari grid card
    // UPDATE: Selector dibatasi di #appCapsule dan target class baru .movie-list-card
    $('#appCapsule .movie-list-card').each((_, cardEl) => {
        const card = $(cardEl);

        // Ambil elemen <a> yang membungkus gambar (biar gak salah ambil <a> lain)
        const anchor = card.find('a.movie-list-card__media');
        // Kalau gak nemu, fallback ke <a> pertama
        const finalAnchor = anchor.length > 0 ? anchor : card.find('a').first();

        const img = card.find('img');

        // Ambil URL link dan ekstrak slug-nya
        const fullUrl = finalAnchor.attr('href') || "";
        const slugMatch = fullUrl.match(/\/(?:nonton|film)\/([^\/]+)/);
        const slug = slugMatch ? slugMatch[1] : fullUrl.split('/').filter(Boolean).pop() || "";

        // Cari judul (Prioritas: data-original-title -> teks H5 -> alt gambar)
        let title = card.find('[data-original-title]').attr('data-original-title');

        if (!title) {
            title = card.find('.movie-list-card__title, h5').text().trim();
        }

        if (!title) {
            title = img.attr('alt') || "No Title";
        }

        const poster = img.attr('src') || "";

        if (title && slug) {
            results.push({
                id: slug,
                slug: slug,
                title: title.trim(),
                poster: poster
            });
        }
    });

    // 2. Ekstrak data Paginasi
    const paginationEl = $('.pagination');
    const inputPageValue = $('#goToPage').attr('value') || "1";
    const currentPage = parseInt(inputPageValue, 10) || 1;

    // Cari tombol "Next" di list pagination
    const nextAnchor = paginationEl.find('a:contains("Next")');
    let nextPageUrl: string | null = null;
    let hasNextPage = false;

    if (nextAnchor.length > 0) {
        nextPageUrl = nextAnchor.attr('href') || null;
        if (nextPageUrl && nextPageUrl !== '#') {
            hasNextPage = true;
        }
    }

    return {
        results,
        pagination: {
            currentPage,
            nextPageUrl,
            hasNextPage
        }
    };
}