// file: lib/osint.ts
import fs from 'fs';
import path from 'path';

const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || "";
const SESSION_FILE = path.join(process.cwd(), 'supabase_session.json');

let currentSessionData: any = null;
let refreshPromise: Promise<any> | null = null; // Gembok Anti-Double Fire

// ==========================================
// 1. FILE SYSTEM HANDLER
// ==========================================
function getSavedSession() {
    if (fs.existsSync(SESSION_FILE)) {
        try {
            const fileData = fs.readFileSync(SESSION_FILE, 'utf-8');
            return JSON.parse(fileData);
        } catch (e) {
            console.error("Gagal baca file session lama");
        }
    }
    return null;
}

function saveSession(data: any) {
    fs.writeFileSync(SESSION_FILE, JSON.stringify(data, null, 2), 'utf-8');
    currentSessionData = data;
}

// ==========================================
// 2. ENGINE AUTHENTICATION (DENGAN GEMBOK)
// ==========================================
async function refreshSupabaseToken() {
    if (refreshPromise) {
        console.log("[OSINT Core] Menunggu antrean refresh token...");
        return refreshPromise;
    }

    refreshPromise = (async () => {
        console.log("[OSINT Core] Refreshing Supabase Token...");
        try {
            const savedSession = getSavedSession();
            const tokenToUse = savedSession?.refresh_token || process.env.SUPABASE_REFRESH_TOKEN;

            const res = await fetch("https://wyekhfprohbamihiznsu.supabase.co/auth/v1/token?grant_type=refresh_token", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json;charset=UTF-8",
                    "apikey": SUPABASE_ANON_KEY,
                    "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
                },
                body: JSON.stringify({ refresh_token: tokenToUse })
            });

            if (!res.ok) {
                const errText = await res.text();
                throw new Error(`Gagal refresh token. Response: ${errText}`);
            }

            const data = await res.json();
            saveSession(data);
            return data;
        } finally {
            refreshPromise = null;
        }
    })();

    return refreshPromise;
}

function generateSupabaseCookie(sessionData: any): string {
    const jsonString = JSON.stringify(sessionData);
    const base64Data = Buffer.from(jsonString).toString('base64');
    const fullCookieStr = `base64-${base64Data}`;

    const chunk0 = fullCookieStr.slice(0, 3000);
    const chunk1 = fullCookieStr.slice(3000);

    let cookie = `sb-wyekhfprohbamihiznsu-auth-token.0=${chunk0};`;
    if (chunk1) {
        cookie += ` sb-wyekhfprohbamihiznsu-auth-token.1=${chunk1};`;
    }
    return cookie;
}

// ==========================================
// 3. THE ULTIMATE FETCH ENGINE
// ==========================================
interface OsintParams {
    path: string;
    payloadArray: any[];
    actionHash: string;
    isRetry?: boolean;
}

export async function fetchOsint(params: OsintParams): Promise<any> {
    const { path, payloadArray, actionHash, isRetry = false } = params;

    if (!currentSessionData) {
        currentSessionData = getSavedSession();
        if (!currentSessionData) {
            await refreshSupabaseToken();
        }
    }

    const cookieHeader = generateSupabaseCookie(currentSessionData);
    const targetUrl = `https://blackbird.mom${path}`;
    const payloadStr = JSON.stringify(payloadArray);

    let res;
    try {
        // Tembak pakai Stealth Headers (Bypass Cloudflare/Bot Protection)
        res = await fetch(targetUrl, {
            method: "POST",
            headers: {
                "Accept": "text/x-component",
                "Content-Type": "text/plain;charset=UTF-8",
                "Cookie": cookieHeader,
                "Origin": "https://blackbird.mom",
                "Referer": targetUrl,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
                "next-action": actionHash,
                "Connection": "keep-alive",
                "Accept-Encoding": "gzip, deflate, br",
                "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "same-origin"
            },
            body: payloadStr
        });
    } catch (error: any) {
        if (error.code === 'ECONNRESET' || error.message.includes('fetch failed')) {
            if (!isRetry) {
                console.log("[OSINT Core] Koneksi diputus target. Mode Reconnect aktif...");
                await new Promise(resolve => setTimeout(resolve, 1500));
                return fetchOsint({ ...params, isRetry: true });
            } else {
                throw new Error("Koneksi gagal total. Server target mungkin down.");
            }
        }
        throw error;
    }

    // Ambil text balasan
    const responseText = await res.text();

    // Deteksi Error Token Basi
    const isNextJsRedirect = responseText.includes("NEXT_REDIRECT") || responseText.includes("Unauthorized");
    const isHttpError = res.status === 401 || res.status === 403 || res.redirected;

    if (isHttpError || isNextJsRedirect) {
        if (!isRetry) {
            console.log(`[OSINT Core] Token kadaluarsa. Memulai proses Auto-Refresh...`);
            await refreshSupabaseToken();
            return fetchOsint({ ...params, isRetry: true });
        } else {
            throw new Error(`Akses ditolak total. Silakan cek sisa Limit / Kuota di akun Supabase lu.`);
        }
    }

    // FILTER PEMBERSIH RSC PAYLOAD V2
    try {
        return JSON.parse(responseText);
    } catch {
        try {
            const lines = responseText.split('\n');
            for (const line of lines) {
                if (/^\d+:/.test(line)) {
                    const possibleJson = line.replace(/^\d+:/, '').trim();
                    try {
                        const parsed = JSON.parse(possibleJson);
                        // 🔴 UPDATE: Sekarang nangkep yg ada "success", "data", ATAU "error" 🔴
                        // Jadi ini (biar lebih strict):
                        if (parsed.hasOwnProperty('success') || parsed.hasOwnProperty('data') || parsed.hasOwnProperty('error')) {
                            return parsed;
                        }
                    } catch (e) {
                        continue;
                    }
                }
            }

            // Fallback (Cari "success" atau "error")
            const successIdx = responseText.indexOf('{"success"');
            const errorIdx = responseText.indexOf('{"error"');
            const startIdx = successIdx !== -1 ? successIdx : errorIdx;

            if (startIdx !== -1) {
                const endIdx = responseText.lastIndexOf('}');
                const cleanJsonStr = responseText.substring(startIdx, endIdx + 1);
                return JSON.parse(cleanJsonStr);
            }
        } catch (extractError) {
            console.error("[OSINT Core] Gagal menyaring data mentah RSC.");
        }
        return responseText;
    }
}