import https from "node:https";
import { URL } from "node:url";
import { HttpsProxyAgent } from 'https-proxy-agent';

// ==========================================
// 🚀 BASE URL HBO MAX
// ==========================================
export const HBO_CONTENT_BASE = "https://default.any-emea.prd.api.hbomax.com";
export const HBO_AUTH_BASE = "https://default.beam-emea.prd.api.hbomax.com";
export const HBO_PLAYBACK_BASE = "https://default.any-any.prd.api.hbomax.com";

const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL_FILMBOX || '';

// ==========================================
// HELPER: SANITIZE STATUS UNTUK NGINX
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 500;
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400;
    }
    return status;
}

export async function fetchUpstream(
    urlStr: string,
    method: string = 'GET',
    body?: any,
    customHeaders?: Record<string, string>,
    useProxyOverride?: boolean,
    maxRetries: number = 3
) {
    const u = new URL(urlStr);
    const shouldProxy = useProxyOverride !== undefined ? useProxyOverride : USE_PROXY;
    const agent = (shouldProxy && PROXY_URL) ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    const headers: Record<string, string> = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'origin': 'https://play.hbomax.com',
        'referer': 'https://play.hbomax.com/',
        'sec-ch-ua': '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',

        'x-disco-client': 'WEB:NT 10.0:hbomax:7.10.0',
        'x-disco-params': 'realm=bolt,bid=beam,features=ar',
        'x-device-info': 'hbomax/7.10.0 (desktop/desktop; Windows/NT 10.0; a4647383-ccb5-4163-9239-d5afde4d0dbd/da0cdd94-5a39-42ef-aa68-54cbc1b852c3)',
        'x-wbd-preferred-language': 'en-US,en',
        'x-wbd-time-zone': 'Asia/Jakarta',
        'x-wbd-device-consent': 'gpc=0',

        ...customHeaders
    };

    if (!headers['Host'] && !headers['host']) headers['Host'] = u.hostname;
    if (method === 'POST' && !headers['content-type']) headers['content-type'] = 'application/json';

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await new Promise<any>((resolve, reject) => {
                const options: https.RequestOptions = {
                    hostname: u.hostname,
                    port: u.port || 443,
                    path: u.pathname + u.search,
                    method,
                    headers,
                    agent: agent as any,
                    timeout: 15000,
                    rejectUnauthorized: false
                };

                const req = https.request(options, (res) => {
                    let data = "";
                    res.setEncoding('utf8');
                    res.on("data", (chunk) => (data += chunk));
                    res.on("end", () => {
                        const rawData = data.trim();

                        const isHtml = rawData.toLowerCase().startsWith("<!doctype") || rawData.toLowerCase().startsWith("<html");
                        if (isHtml || rawData.includes("incapsula") || rawData.includes("cloudflare")) {
                            reject({
                                isCustomError: true,
                                status: res.statusCode,
                                message: "Kena blokir WAF / Response berupa HTML",
                                rawData: rawData
                            });
                            return;
                        }

                        try {
                            const parsed = JSON.parse(rawData || "{}");
                            if (parsed.errors && Array.isArray(parsed.errors)) {
                                const hboErrorMsg = parsed.errors[0]?.title || parsed.errors[0]?.detail || JSON.stringify(parsed.errors[0]);
                                reject({
                                    isCustomError: true,
                                    status: res.statusCode,
                                    message: `HBO API Error: ${hboErrorMsg}`,
                                    rawData: parsed
                                });
                                return;
                            }
                            resolve(parsed);
                        } catch (err) {
                            reject({
                                isCustomError: true,
                                status: res.statusCode,
                                message: "Gagal parse response JSON",
                                rawData: rawData
                            });
                        }
                    });
                });

                req.on("error", (err: any) => {
                    reject({
                        isCustomError: true,
                        status: 500,
                        message: `Koneksi Error: ${err.message || err.code}`,
                        code: err.code || 'UNKNOWN',
                        rawData: null
                    });
                });

                req.on("timeout", () => {
                    req.destroy(new Error("Request Timeout dari Sistem"));
                });

                if (body) {
                    req.write(typeof body === 'string' ? body : JSON.stringify(body));
                }

                req.end();
            });

        } catch (error: any) {
            console.warn(`[HBO Upstream Attempt ${attempt}/${maxRetries} Failed]:`, error.message || error);
            if (attempt === maxRetries) {
                throw error;
            }
            await new Promise(res => setTimeout(res, 500));
        }
    }
}

export async function hboProxy(
    req: Request,
    path: string,
    method: 'GET' | 'POST' = 'GET',
    query: Record<string, any> = {},
    body?: any,
    useProxyOverride?: boolean
) {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined) sp.set(k, String(v));
    }

    const queryString = sp.toString()
        .replace(/%5B/g, '[')
        .replace(/%5D/g, ']')
        .replace(/%2C/g, ',');

    let baseUrl = HBO_CONTENT_BASE;
    let hostHeader = 'default.any-emea.prd.api.hbomax.com';

    if (path.includes('/users/') || path.includes('/auth/')) {
        baseUrl = HBO_AUTH_BASE;
        hostHeader = 'default.beam-emea.prd.api.hbomax.com';
    } else if (path.includes('/playback/')) {
        baseUrl = HBO_PLAYBACK_BASE;
        hostHeader = 'default.any-any.prd.api.hbomax.com';
    }

    const url = `${baseUrl}${path}${queryString ? '?' + queryString : ''}`;
    const customHeaders: Record<string, string> = {
        'Host': hostHeader
    };

    if (baseUrl === HBO_AUTH_BASE) {
        customHeaders['Origin'] = 'https://auth.hbomax.com';
        customHeaders['Referer'] = 'https://auth.hbomax.com/';
    }

    const hboCookie = process.env.HBO_COOKIE || req.headers.get('cookie');
    const hboSessionState = process.env.HBO_SESSION_STATE || req.headers.get('x-wbd-session-state');

    if (hboCookie) customHeaders['Cookie'] = hboCookie;
    if (hboSessionState) customHeaders['x-wbd-session-state'] = hboSessionState;

    try {
        const json = await fetchUpstream(url, method, body, customHeaders, useProxyOverride);

        return new Response(JSON.stringify(json), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        const isCustom = e.isCustomError;
        const originalStatus = e.status || 502;
        const safeStatus = sanitizeStatus(originalStatus);

        return new Response(
            JSON.stringify({
                code: originalStatus,
                message: e.message || "Internal Proxy Error",
                data: isCustom ? e.rawData : null
            }),
            {
                status: safeStatus,
                headers: { 'Content-Type': 'application/json' }
            }
        );
    }
}