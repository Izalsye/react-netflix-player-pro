// /lib/hbo/authService.ts

export async function getFreshHboSession(masterCookie: string) {
    try {
        const userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36';

        // ==========================================
        // 1. Ambil Token Session Baru (JWT st=...)
        // ==========================================
        const tokenRes = await fetch("https://default.any-any.prd.api.hbomax.com/v2_token?realm=bolt", {
            method: 'GET',
            headers: {
                'Cookie': masterCookie,
                'User-Agent': userAgent,
                'Accept': '*/*'
            }
        });

        // Ekstrak set-cookie dari response headers untuk mendapatkan 'st=...'
        const setCookieHeader = tokenRes.headers.get('set-cookie') || '';
        const stCookie = setCookieHeader.split(';').find(c => c.includes('st=')) || '';

        if (!stCookie) throw new Error("Gagal mendapatkan st cookie dari v2_token");

        // Gabungkan master cookie dengan session cookie yang baru
        const activeCookie = `${masterCookie}; ${stCookie}`;

        // ==========================================
        // 2. Tembak Bootstrap untuk pancing Session State
        // ==========================================
        const bootstrapRes = await fetch("https://default.any-any.prd.api.hbomax.com/session-context/headwaiter/v1/bootstrap", {
            method: 'POST',
            headers: {
                'Cookie': activeCookie,
                'Content-Type': 'application/json',
                'User-Agent': userAgent,
                'Origin': 'https://play.hbomax.com',
                'Referer': 'https://play.hbomax.com/',
                'x-disco-client': 'WEB:NT 10.0:hbomax:7.10.0',
                'x-disco-params': 'realm=bolt,bid=beam,features=ar'
            },
            body: JSON.stringify({}) // Payload asli dari kodemu cuma {} (Content-Length: 2)
        });

        // ==========================================
        // 3. Tangkap Session State dari Headers
        // ==========================================
        const newSessionState = bootstrapRes.headers.get('x-wbd-session-state');

        if (!newSessionState) {
            throw new Error("Header x-wbd-session-state tidak dikembalikan oleh server");
        }

        return {
            success: true,
            activeCookie: activeCookie,
            sessionState: newSessionState
        };

    } catch (error: any) {
        console.error("[HBO Auth] Auto-Refresh Error:", error.message);
        return { success: false, error: error.message };
    }
}