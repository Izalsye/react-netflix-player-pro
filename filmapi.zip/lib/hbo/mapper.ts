// /lib/hbo/mapper.ts

// ==========================================
// 1. INTERFACES
// ==========================================
export interface HboImage {
    id: string;
    kind: string;
    url: string;
    width: number;
    height: number;
}

export interface HboMediaItem {
    id: string;
    targetType: string;
    title: string;
    description?: string;
    images: HboImage[];
    badges: string[];
    routeId?: string;
    routeUrl?: string;
    seasonNumber?: number;  // 🔥 Berfungsi buat nampilin urutan di UI
    episodeNumber?: number; // 🔥 Berfungsi buat nampilin urutan di UI
}

export interface HboCollection {
    id: string;
    title: string;
    alias: string;
    uiType: string;
    loadType: string; // 'manual' | 'automatic'
    items: HboMediaItem[];
}

export interface HboHomeData {
    id: string;
    tab_content: HboCollection[];
    content_sections: HboCollection[];
    category: HboCollection[];
}

export interface ApiResponse<T> {
    code: number;
    message: string;
    data: T;
}

export interface HboSeason {
    id: string;
    name: string;
    seasonNumber: number;
    description: string;
    episodeCount: number;
    episodes: HboMediaItem[]; // 🔥 Episode nyarang di sini
}

export interface HboShowDetail {
    id: string;
    targetType: string;
    title: string;
    originalTitle: string;
    description: string;
    images: HboImage[];
    genres: string[];
    cast: string[];
    director: string[];
    seasons: HboSeason[]; // 🔥 Seasons udah lengkap sama isinya
    collections: HboCollection[];
}

export interface HboSubtitle {
    language: string;
    displayName: string;
    format: string;
    type: string;
}

export interface HboPlayData {
    streamUrl: string;
    fallbackUrl?: string;
    drm: {
        type: string;
        licenseUrl: string;
    } | null;
    subtitles: HboSubtitle[]; // Daftar subtitle yang tersedia di dalam MPD
    duration: number;
}

// ==========================================
// 2. MAIN MAPPER CLASS
// ==========================================
export class HboDataMapper {

    private static buildDictionary(includedArray: any[] = []): Record<string, any> {
        const dict: Record<string, any> = {};
        for (const item of includedArray) {
            if (item.type && item.id) dict[`${item.type}:${item.id}`] = item;
        }
        return dict;
    }

    private static mapImages(imageRefs: any[] = [], dict: Record<string, any>): HboImage[] {
        if (!Array.isArray(imageRefs)) return [];
        return imageRefs.map((ref: any) => {
            const imgData = dict[`${ref.type}:${ref.id}`];
            if (!imgData) return null;
            return {
                id: imgData.id,
                kind: imgData.attributes?.kind || 'default',
                url: imgData.attributes?.src || '',
                width: imgData.attributes?.width || 0,
                height: imgData.attributes?.height || 0,
            };
        }).filter(Boolean) as HboImage[];
    }

    private static mapMediaItem(collectionItemRef: any, dict: Record<string, any>): HboMediaItem | null {
        const collItem = dict[`${collectionItemRef.type}:${collectionItemRef.id}`];
        if (!collItem) return null;

        // Sapu jagat semua kemungkinan tipe aset yang dipakai HBO Max
        const contentTypes = [
            'show', 'movie', 'video', 'episode', 'link',
            'channel', 'taxonomyNode', 'page', 'collection',
            'brand', 'franchise', 'customAsset'
        ];

        let targetRef = null;
        for (const cType of contentTypes) {
            if (collItem.relationships?.[cType]?.data) {
                const refData = collItem.relationships[cType].data;
                targetRef = Array.isArray(refData) ? refData[0] : refData;
                break;
            }
        }

        if (!targetRef) return null;

        const targetData = dict[`${targetRef.type}:${targetRef.id}`];
        if (!targetData) return null;

        const title = targetData.attributes?.title || targetData.attributes?.name || targetData.attributes?.alias || 'Unknown Title';
        const imageRefs = targetData.relationships?.images?.data || [];

        const badgeRefs = collItem.relationships?.badges?.data || collItem.relationships?.overlays?.data || [];
        const badges = badgeRefs.map((b: any) => dict[`${b.type}:${b.id}`]?.attributes?.label || dict[`${b.type}:${b.id}`]?.attributes?.displayText || '').filter(Boolean);

        let routeId = targetRef.type === 'collection' ? targetData.id : '';
        let routeUrl = '';

        const routeRefs = targetData.relationships?.routes?.data || targetData.relationships?.linkedContentRoutes?.data;

        if (routeRefs && (Array.isArray(routeRefs) ? routeRefs.length > 0 : true)) {
            const rRef = Array.isArray(routeRefs) ? routeRefs[0] : routeRefs;
            const routeObj = dict[`${rRef.type}:${rRef.id}`];
            if (routeObj && routeObj.attributes) {
                routeId = routeObj.id;
                routeUrl = routeObj.attributes.url || '';
            }
        }

        // 🔥 Ekstrak data Season & Episode Number kalau ada
        const seasonNumber = targetData.attributes?.seasonNumber;
        const episodeNumber = targetData.attributes?.episodeNumber;

        return {
            id: targetData.id,
            targetType: targetRef.type,
            title: title,
            description: targetData.attributes?.description || targetData.attributes?.longDescription || '',
            images: this.mapImages(imageRefs, dict),
            badges: badges,
            routeId: routeId,
            routeUrl: routeUrl,
            ...(seasonNumber !== undefined && { seasonNumber }),
            ...(episodeNumber !== undefined && { episodeNumber })
        };
    }

    private static extractAllCollections(startRefs: any[], dict: Record<string, any>): any[] {
        const visited = new Set<string>();
        const collections: any[] = [];

        const scan = (itemRef: any) => {
            if (!itemRef || !itemRef.type || !itemRef.id) return;
            const refKey = `${itemRef.type}:${itemRef.id}`;

            if (visited.has(refKey)) return;
            visited.add(refKey);

            if (itemRef.type === 'collection') collections.push(itemRef);

            const item = dict[refKey];
            if (!item || !item.relationships) return;

            const rels = item.relationships;
            const targets = [
                rels.collection?.data,
                rels.container?.data,
                rels.tabs?.data,
                rels.page?.data,
                rels.items?.data
            ];

            for (const target of targets) {
                if (!target) continue;
                if (Array.isArray(target)) target.forEach(t => scan(t));
                else scan(target);
            }
        };

        startRefs.forEach(ref => scan(ref));
        return collections;
    }

    private static determineUiType(componentId: string, alias: string): string {
        if (alias.includes('hero')) return 'hero-banner';
        if (componentId === 'tab-group' || alias.includes('tab-group')) return 'category-group';
        if (componentId === 'tab' || alias.includes('tab-')) return 'category-tab';
        if (componentId === '1-1' || alias.includes('genre')) return 'grid-links';
        return 'carousel';
    }

    // --- 🚀 PUBLIC MAPPERS ---

    public static mapHomepage(rawResponse: any): ApiResponse<HboHomeData> | null {
        if (!rawResponse || !rawResponse.data) return null;

        const dict = this.buildDictionary(rawResponse.included || []);
        const pageRef = rawResponse.data.relationships?.target?.data;
        if (!pageRef || pageRef.type !== 'page') return null;

        const pageData = dict[`${pageRef.type}:${pageRef.id}`];
        if (!pageData) return null;

        const pageItemRefs = pageData.relationships?.items?.data || [];
        const allCollectionRefs = this.extractAllCollections(pageItemRefs, dict);

        const result: HboHomeData = {
            id: pageData.id,
            tab_content: [],
            content_sections: [],
            category: []
        };

        for (const collectionRef of allCollectionRefs) {
            const collectionData = dict[`${collectionRef.type}:${collectionRef.id}`];
            const componentId = collectionData?.attributes?.component?.id || '';
            const alias = collectionData?.attributes?.alias || '';

            const mappedItems: HboMediaItem[] = [];
            if (collectionData) {
                const collectionItemRefs = collectionData.relationships?.items?.data || [];
                for (const ciRef of collectionItemRefs) {
                    const mappedMedia = this.mapMediaItem(ciRef, dict);
                    if (mappedMedia) mappedItems.push(mappedMedia);
                }
            }

            const uiType = this.determineUiType(componentId, alias);
            const loadType = mappedItems.length === 0 ? 'manual' : 'automatic';
            const isTabComp = uiType === 'category-tab' || uiType === 'category-group';

            if (mappedItems.length > 0 || isTabComp) {
                const collectionObj: HboCollection = {
                    id: collectionRef.id,
                    title: collectionData?.attributes?.title || collectionData?.attributes?.name || 'Untitled Section',
                    alias: alias,
                    uiType: uiType,
                    loadType: loadType,
                    items: mappedItems,
                };

                if (isTabComp) {
                    result.tab_content.push(collectionObj);
                } else if (uiType === 'grid-links' || alias.includes('a-z') || alias.includes('genre')) {
                    result.category.push(collectionObj);
                } else {
                    result.content_sections.push(collectionObj);
                }
            }
        }

        return {
            code: 0,
            message: "ok",
            data: result
        };
    }

    public static mapSeriesPage(rawResponse: any): ApiResponse<HboHomeData> | null {
        return this.mapHomepage(rawResponse);
    }

    public static mapSingleCollection(rawResponse: any): ApiResponse<HboCollection> | null {
        if (!rawResponse || !rawResponse.data) return null;

        const collectionData = rawResponse.data;
        const dict = this.buildDictionary(rawResponse.included || []);

        const componentId = collectionData?.attributes?.component?.id || '';
        const alias = collectionData?.attributes?.alias || '';

        const collectionItemRefs = collectionData.relationships?.items?.data || [];
        const mappedItems: HboMediaItem[] = [];

        for (const ciRef of collectionItemRefs) {
            const mappedMedia = this.mapMediaItem(ciRef, dict);
            if (mappedMedia) mappedItems.push(mappedMedia);
        }

        const loadType = mappedItems.length === 0 ? 'manual' : 'automatic';

        const result: HboCollection = {
            id: collectionData.id,
            title: collectionData.attributes?.title || collectionData.attributes?.name || 'Untitled Section',
            alias: alias,
            uiType: this.determineUiType(componentId, alias),
            loadType: loadType,
            items: mappedItems,
        };

        return {
            code: 0,
            message: "ok",
            data: result
        };
    }

    public static mapDetailPage(rawResponse: any, requestedId?: string): ApiResponse<HboShowDetail> | null {
        if (!rawResponse || !rawResponse.data) return null;

        const dict = this.buildDictionary(rawResponse.included || []);
        let showData: any = null;

        // 1. CARI TARGET KONTEN UTAMA (STRATEGI SAPU JAGAT)
        if (requestedId) {
            showData = dict[`show:${requestedId}`] || dict[`movie:${requestedId}`] || dict[`video:${requestedId}`];
        }

        if (!showData) {
            const pageRef = rawResponse.data.relationships?.target?.data;
            if (pageRef && pageRef.type === 'page') {
                const pageData = dict[`${pageRef.type}:${pageRef.id}`];

                let contentRef = pageData?.relationships?.primaryContent?.data;
                if (!contentRef && pageData?.meta?.analytics?.pageContentId) {
                    contentRef = {
                        id: pageData.meta.analytics.pageContentId,
                        type: pageData.meta.analytics.pageContentIdType || 'show'
                    };
                }
                if (contentRef) showData = dict[`${contentRef.type}:${contentRef.id}`];
            }
        }

        if (!showData) {
            const fallbackKey = Object.keys(dict).find(k => k.startsWith('show:') || k.startsWith('movie:'));
            if (fallbackKey) showData = dict[fallbackKey];
        }

        // 2. MAPPING METADATA (Genre, Cast, Director) & SETUP SEASONS
        let genres: string[] = [];
        let cast: string[] = [];
        let director: string[] = [];
        const seasonMap = new Map<string, HboSeason>();

        if (showData) {
            const genreRefs = showData.relationships?.txGenres?.data || [];
            genres = genreRefs.map((g: any) => dict[`${g.type}:${g.id}`]?.attributes?.name).filter(Boolean);

            const creditGroupRefs = showData.relationships?.creditGroups?.data || [];
            for (const cgRef of creditGroupRefs) {
                const cgData = dict[`${cgRef.type}:${cgRef.id}`];
                if (!cgData) continue;

                const roleName = cgData.attributes?.name?.toLowerCase() || '';
                const creditRefs = cgData.relationships?.credits?.data || [];
                const people = creditRefs.map((c: any) => {
                    const personRef = dict[`${c.type}:${c.id}`]?.relationships?.person?.data;
                    return personRef ? dict[`${personRef.type}:${personRef.id}`]?.attributes?.fullName : null;
                }).filter(Boolean);

                if (roleName.includes('menampilkan') || roleName.includes('starring') || roleName.includes('cast')) {
                    cast.push(...people);
                } else if (roleName.includes('sutradara') || roleName.includes('director')) {
                    director.push(...people);
                }
            }

            // Setup kerangka Seasons
            const seasonRefs = showData.relationships?.seasons?.data || [];
            seasonRefs.forEach((sRef: any) => {
                const sData = dict[`${sRef.type}:${sRef.id}`];
                if (sData) {
                    const seasonObj: HboSeason = {
                        id: sData.id,
                        name: sData.attributes?.name || `Season ${sData.attributes?.seasonNumber || 1}`,
                        seasonNumber: sData.attributes?.seasonNumber || 1,
                        description: sData.attributes?.longDescription || sData.attributes?.description || '',
                        episodeCount: sData.attributes?.videoCountByType?.EPISODE || 0,
                        episodes: [] // Wadah buat dimasukin episode
                    };
                    seasonMap.set(seasonObj.id, seasonObj);
                }
            });
        }

        // =========================================================================
        // 🔥 FIX: 3. SAPU SEMUA EPISODE DARI DICTIONARY (MAPPING LANGSUNG)
        // =========================================================================
        Object.values(dict).forEach((item: any) => {
            if (item.type === 'video' && item.attributes?.videoType === 'EPISODE') {
                const belongsToShow = item.relationships?.show?.data?.id === showData?.id;

                if (belongsToShow || !showData) {
                    const seasonId = item.relationships?.season?.data?.id;
                    if (seasonId && seasonMap.has(seasonId)) {

                        // Ekstrak properti episode secara manual biar nggak lari ke "Show"
                        const imageRefs = item.relationships?.images?.data || [];
                        const badgeRefs = item.relationships?.badges?.data || item.relationships?.overlays?.data || [];
                        const badges = badgeRefs.map((b: any) => dict[`${b.type}:${b.id}`]?.attributes?.label || dict[`${b.type}:${b.id}`]?.attributes?.displayText || '').filter(Boolean);

                        let routeId = '';
                        let routeUrl = '';
                        const routeRefs = item.relationships?.routes?.data || [];
                        if (routeRefs.length > 0) {
                            const routeObj = dict[`${routeRefs[0].type}:${routeRefs[0].id}`];
                            if (routeObj && routeObj.attributes) {
                                routeId = routeObj.id;
                                routeUrl = routeObj.attributes?.url || '';
                            }
                        }

                        const mappedEps: HboMediaItem = {
                            id: item.id,
                            targetType: item.type,
                            title: item.attributes?.name || item.attributes?.title || `Episode ${item.attributes?.episodeNumber}`,
                            description: item.attributes?.longDescription || item.attributes?.description || '',
                            images: this.mapImages(imageRefs, dict),
                            badges: badges,
                            routeId: routeId,
                            routeUrl: routeUrl,
                            seasonNumber: item.attributes?.seasonNumber,
                            episodeNumber: item.attributes?.episodeNumber
                        };

                        seasonMap.get(seasonId)!.episodes.push(mappedEps);
                    }
                }
            }
        });

        // Urutkan Seasons dan Episodes berdasarkan angkanya
        const seasons = Array.from(seasonMap.values()).sort((a, b) => a.seasonNumber - b.seasonNumber);
        seasons.forEach(season => {
            season.episodes.sort((a, b) => (a.episodeNumber || 0) - (b.episodeNumber || 0));
        });

        // =========================================================================
        // 🔥 FIX MOVIE: JIKA SEASONS KOSONG, BUATKAN DUMMY SEASON 1 EPISODE 1 
        // =========================================================================
        if (seasons.length === 0 && showData) {
            // Cari ID Video Playable-nya (Biar tombol play bisa nyala)
            let moviePlayId = requestedId || showData.id;

            // Coba ambil dari relasi showData langsung
            if (showData.relationships?.activeVideoForShow?.data?.id) {
                moviePlayId = showData.relationships.activeVideoForShow.data.id;
            } else {
                // Kalau disembunyiin di collectionItem (Khas HBO Max)
                const colItem = Object.values(dict).find((item: any) =>
                    item.type === 'collectionItem' &&
                    item.relationships?.activeVideoForShow?.data?.id
                );
                if (colItem) {
                    moviePlayId = colItem.relationships.activeVideoForShow.data.id;
                }
            }

            const dummyMovieEps: HboMediaItem = {
                id: moviePlayId, // 🔥 PENTING: Pakai Play ID asli!
                targetType: 'video',
                title: showData.attributes?.name || showData.attributes?.title || 'Watch Movie',
                description: showData.attributes?.longDescription || showData.attributes?.description || '',
                images: this.mapImages(showData.relationships?.images?.data || [], dict),
                badges: [],
                routeId: '',
                routeUrl: '',
                seasonNumber: 1,
                episodeNumber: 1
            };

            seasons.push({
                id: 'season-1-movie',
                name: 'Movie',
                seasonNumber: 1,
                description: '',
                episodeCount: 1,
                episodes: [dummyMovieEps]
            });
        }

        // 4. MAPPING COLLECTIONS LAIN (Kecuali tab Episode biar gak double)
        const pageItemRefs = rawResponse.data.relationships?.target?.data ?
            dict[`page:${rawResponse.data.relationships.target.data.id}`]?.relationships?.items?.data || [] : [];

        const allCollectionRefs = this.extractAllCollections(pageItemRefs, dict);
        const mappedCollections: HboCollection[] = [];

        for (const collectionRef of allCollectionRefs) {
            const collectionData = dict[`${collectionRef.type}:${collectionRef.id}`];
            const componentId = collectionData?.attributes?.component?.id || '';
            const alias = collectionData?.attributes?.alias || '';

            const mappedItems: HboMediaItem[] = [];
            if (collectionData) {
                const collectionItemRefs = collectionData.relationships?.items?.data || [];
                for (const ciRef of collectionItemRefs) {
                    const mappedMedia = this.mapMediaItem(ciRef, dict);
                    if (mappedMedia) mappedItems.push(mappedMedia);
                }
            }

            const uiType = this.determineUiType(componentId, alias);
            const loadType = mappedItems.length === 0 ? 'manual' : 'automatic';

            // Jangan masukin Tab/Collection yang alias-nya mengandung "episodes" ke root collections
            if (!alias.includes('episodes') && (mappedItems.length > 0 || uiType === 'category-tab' || uiType === 'category-group')) {
                mappedCollections.push({
                    id: collectionRef.id,
                    title: collectionData?.attributes?.title || collectionData?.attributes?.name || 'Untitled Section',
                    alias: alias,
                    uiType: uiType,
                    loadType: loadType,
                    items: mappedItems,
                });
            }
        }

        const result: HboShowDetail = {
            id: showData?.id || requestedId || '',
            targetType: showData?.type || 'unknown',
            title: showData?.attributes?.name || showData?.attributes?.title || 'Unknown Title',
            originalTitle: showData?.attributes?.originalName || '',
            description: showData?.attributes?.longDescription || showData?.attributes?.description || '',
            images: this.mapImages(showData?.relationships?.images?.data || [], dict),
            genres,
            cast,
            director,
            seasons: seasons,
            collections: mappedCollections
        };

        return {
            code: 0,
            message: "ok",
            data: result
        };
    }

    public static mapPlaybackData(rawResponse: any): ApiResponse<HboPlayData> | null {
        // Cek kalau format JSON HBO beda
        if (!rawResponse || (!rawResponse.manifest && !rawResponse.fallback?.manifest)) {
            console.error("[HBO Mapper] Playback manifest not found in response:", JSON.stringify(rawResponse).substring(0, 200));
            return null;
        }

        // Ambil URL manifest (DASH MPD)
        const manifestUrl = rawResponse.manifest?.url || rawResponse.fallback?.manifest?.url || '';

        let drm = null;
        // Ambil URL License Widevine
        if (rawResponse.drm?.schemes?.widevine) {
            drm = {
                type: 'widevine',
                licenseUrl: rawResponse.drm.schemes.widevine.licenseUrl
            };
        }

        // Cari data metadata video (Buat ambil subtitle & durasi)
        let mainVideo = null;
        if (rawResponse.videos && Array.isArray(rawResponse.videos)) {
            mainVideo = rawResponse.videos.find((v: any) => v.type === 'main') || rawResponse.videos[0];
        } else if (rawResponse.fallback?.videos && Array.isArray(rawResponse.fallback.videos)) {
            mainVideo = rawResponse.fallback.videos.find((v: any) => v.type === 'main') || rawResponse.fallback.videos[0];
        }

        // Ekstrak Subtitle
        const subtitles = mainVideo?.textTracks?.map((t: any) => ({
            language: t.language,
            displayName: t.displayName,
            format: t.format,
            type: t.type
        })) || [];

        return {
            code: 0,
            message: "ok",
            data: {
                streamUrl: manifestUrl,
                drm: drm,
                subtitles: subtitles,
                duration: mainVideo?.duration || 0
            }
        };
    }
}