import { NextRequest } from 'next/server';
import crypto from 'crypto';
import prisma from '../prisma/prisma';
import { recordHit } from './stats';

function hashKey(apiKey: string) {
    return crypto.createHash('sha256').update(apiKey).digest('hex');
}

// 🎯 Tambahin parameter "isInternal = false"
export async function validateApiKey(req: NextRequest, providerPath: string, isInternal: boolean = false) {
    const apiKey = req.headers.get('x-api-key');

    if (!apiKey) {
        return { isValid: false, status: 401, message: "Missing x-api-key" };
    }

    const hashed = hashKey(apiKey);

    // 1. Cari user
    const keyData = await prisma.apiKey.findFirst({
        where: {
            OR: [
                { hashedKey: hashed },
                { rawKey: apiKey },
                { hashedKey: apiKey }
            ]
        },
        include: { user: true }
    });

    if (!keyData || !keyData.user) {
        return { isValid: false, status: 401, message: "Invalid API Key" };
    }

    const user = keyData.user;
    let activeRole = user.role;

    // 2. Cek Expiry VIP
    if (activeRole === 'VIP' && user.subEndsAt) {
        const now = new Date();
        if (now > user.subEndsAt) {
            activeRole = 'FREE';
            await prisma.user.update({ where: { id: user.id }, data: { role: 'FREE' } });
        }
    }

    // 🔥 FIX: JALUR BYPASS UNTUK ENDPOINT INTERNAL 🔥
    // Kalau isInternal = true, kita lolosin aja. Gak usah ngecek batas provider dan potong kuota.
    if (isInternal) {
        return { isValid: true, status: 200, message: "OK" };
    }

    // 3. Batasan Provider (Cuma berlaku buat API streaming)
    if (activeRole === 'FREE') {
        const providerName = providerPath.toLowerCase();
        const freeProviders = ['drakorid', 'filmbox', 'mangaku'];
        const isAllowed = freeProviders.some(fp => providerName.includes(fp));
        if (!isAllowed) {
            return {
                isValid: false,
                status: 403,
                message: `Free users can only access: ${freeProviders.join(', ')}. Upgrade to VIP.`
            };
        }
    }

    // 4. Kuota Harian
    const today = new Date();
    today.setUTCHours(0, 0, 0, 0);

    let usage = await prisma.dailyUsage.findUnique({
        where: { userId_date: { userId: user.id, date: today } }
    });

    if (!usage) {
        usage = await prisma.dailyUsage.create({
            data: { userId: user.id, date: today, count: 0 }
        });
    }

    const maxRequests = activeRole === 'VIP' ? 1000000 : 600;

    if (usage.count >= maxRequests) {
        return {
            isValid: false,
            status: 429,
            message: `Rate limit exceeded. Your plan (${activeRole}) allows ${maxRequests} requests/day.`
        };
    }

    // 5. Tambah kuota +1 & CATAT HIT (JALAN DI BACKGROUND)
    prisma.dailyUsage.update({
        where: { id: usage.id },
        data: { count: usage.count + 1 }
    }).catch((err: any) => console.error("Gagal update kuota harian:", err.message));
    recordHit(req, `apiKey:${apiKey}`, providerPath, req.method);

    // Langsung loloskan user tanpa harus menunggu database selesai menulis
    return { isValid: true, status: 200, message: "OK" };
}

// Pastikan ada kata 'export' di depannya
export async function upsertApiKey(userId: string, label: string = 'Default Key') {
    const rawKey = `indocast_${crypto.randomBytes(24).toString('hex')}`;
    const hashedKey = crypto.createHash('sha256').update(rawKey).digest('hex');

    // Upsert: Kalau udah ada di-update, kalau belum ada di-create
    const apiKey = await prisma.apiKey.upsert({
        where: { userId },
        update: {
            rawKey,
            hashedKey,
        },
        create: {
            userId,
            rawKey,
            hashedKey,
            label,
        }
    });

    return { rawKey, apiKey };
}