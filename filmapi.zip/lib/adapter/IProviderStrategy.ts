import { PreviewFeed, PreviewDetail } from './types';

export interface FeedRequestConfig {
    baseEndpointId: string;
    gridEndpointId: string | null;
    params: Record<string, string>;
}

export interface DetailRequestConfig {
    endpointId: string;
    params: Record<string, string>;
}

export interface PlayRequestConfig {
    endpointId: string;
    params: Record<string, string>;
    method?: string; // <-- Tambahin ini
}

export interface IProviderStrategy {
    // 👇 Ubah 'page: number' menjadi 'pageParam?: number | string'
    getFeedRequest(menuId: string, lang: string, pageParam?: number | string): FeedRequestConfig;

    // 2. Normalisasi response Feed API ke format Frontend
    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed;

    // 3. Menentukan endpoint & parameter untuk Detail
    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig;

    // 4. Normalisasi response Detail API ke format Frontend
    normalizeDetail(rawData: any): PreviewDetail | null;

    // 5. Menentukan endpoint & parameter untuk Video Player
    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig;
}