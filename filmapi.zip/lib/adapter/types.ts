export interface PreviewMedia {
    id: string | number;
    title: string;
    posterUrl: string;
    type?: 'movie' | 'series' | 'anime';
    rating?: string;
    year?: string | number;
    slug?: string;
    badge?: string;
    statusText?: string;
}

export interface PreviewSection {
    title: string;
    items: PreviewMedia[];
    isGrid?: boolean;
}

export interface PreviewMenu {
    id: string;
    label: string;
    isActive?: boolean;
}

export interface PreviewFeed {
    menus: PreviewMenu[];
    banners: PreviewMedia[];
    sections: PreviewSection[];
    hasMore?: boolean;
    // 👇 Tambahin baris ini bre buat nyimpen token halaman berikutnya
    nextPageContext?: string;
}

export interface PreviewDetail extends PreviewMedia {
    description?: string;
    genres?: string;
    country?: string;
    trailerUrl?: string;
    seasonsList?: any[];
}