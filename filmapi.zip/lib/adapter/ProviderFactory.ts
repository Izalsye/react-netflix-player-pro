import { IProviderStrategy } from './IProviderStrategy';
import { FilmboxAdapter } from './providers/FilmboxAdapter';
import { HboAdapter } from './providers/HboAdapter';
import { IdlixAdapter } from './providers/IdlixAdapter';
import { IqiyiAdapter } from './providers/IqiyiAdapter';
import { VidioAdapter } from './providers/VidioAdapter';
import { ViuAdapter } from './providers/ViuAdapter';
import { WeTVAdapter } from './providers/WeTVAdapter';

export class ProviderFactory {
    static getAdapter(providerId: string): IProviderStrategy {
        const id = providerId.toLowerCase();

        switch (id) {
            case 'filmbox':
                return new FilmboxAdapter();
            case 'wetv':
                return new WeTVAdapter();
            case 'hbo':
                return new HboAdapter();
            case 'viu':
                return new ViuAdapter();
            case 'vidio':
                return new VidioAdapter();
            case 'iqiyi':
                return new IqiyiAdapter();
            case 'idlix':
                return new IdlixAdapter();
            // Nanti kalau ada provider ke-3, ke-4 dst, tinggal tambahin di sini bre
            // case 'netflix':
            //     return new NetflixAdapter();
            default:
                throw new Error(`Adapter untuk provider '${providerId}' belum tersedia.`);
        }
    }
}