import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export class VidioAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        // Sesuaikan nama endpointId dengan konfigurasi array `endpoints` lu
        let baseEndpointId = 'home';

        // Routing menu ke endpointId yang benar
        if (menuId === 'series') baseEndpointId = 'series';
        else if (menuId === 'movies' || menuId === 'movie') baseEndpointId = 'movies';
        else if (menuId === 'channels' || menuId === 'Channel-TV') baseEndpointId = 'Channel-TV';

        return {
            baseEndpointId,
            gridEndpointId: null,
            params: {
                page: String(page), // Convert number ke string
                size: '10'          // Pake kutip biar jadi string
            }
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false };
        const data = baseRaw;

        if (!data || !data.success) return feed;

        // 1. Setup Navbar Menus (Sesuai dengan key endpoint yang dilooping di menuId)
        feed.menus = [
            { id: 'home', label: 'Home' },
            { id: 'series', label: 'Series' },
            { id: 'movies', label: 'Movies' },
            { id: 'Channel-TV', label: 'TV Channels' }
        ];

        // 2. Set pagination load more (Gunakan fallback deteksi jumlah section)
        feed.hasMore = data.nextPage !== undefined
            ? !!data.nextPage
            : (Array.isArray(data.sections) && data.sections.length > 0);

        // Helper mapper untuk meratakan data item dari Vidio
        const mapVidioItem = (item: any): PreviewMedia | null => {
            if (!item.id) return null;
            return {
                id: String(item.id),
                title: item.title || item.name || 'Tanpa Judul',
                posterUrl: item.coverUrl || item.image || '',
                // 🔥 Kita simpan raw 'type' (livestreaming_schedule, content_profile, dll) di slug buat diconvert pas request Detail/Play
                slug: item.type || 'content_profile',
                type: item.type?.includes('livestreaming') || item.type === 'category' ? 'series' : 'movie',
                badge: item.contentRating || undefined,
                statusText: item.altTitle || ''
            };
        };

        // 3. Handle data dari endpoint TV Channels (Strukturnya: data.data)
        if (data.total && Array.isArray(data.data)) {
            data.data.forEach((group: any) => {
                const validItems = group.data?.map(mapVidioItem).filter(Boolean) as PreviewMedia[];
                if (validItems && validItems.length > 0) {
                    feed.sections.push({
                        title: group.name,
                        items: validItems,
                        isGrid: false,
                        // @ts-ignore - Nyelipin variation khusus UI Vidio
                        variation: 'landscape_horizontal'
                    });
                }
            });
            // Endpoint channel biasanya langsung load semua, nggak pakai infinite scroll
            feed.hasMore = false;
            return feed;
        }

        // 4. Handle data dari endpoint Home / Series / Movie (Strukturnya: data.sections)
        if (Array.isArray(data.sections)) {
            data.sections.forEach((sec: any) => {
                if (!Array.isArray(sec.items) || sec.items.length === 0) return;

                const validItems = sec.items.map(mapVidioItem).filter(Boolean) as PreviewMedia[];

                // Pisahin section 'headline' untuk dimasukin ke atas (Hero Banners)
                if (sec.variation === 'headline') {
                    feed.banners.push(...validItems);
                } else {
                    feed.sections.push({
                        title: sec.title || 'Lainnya',
                        items: validItems,
                        isGrid: false,
                        // @ts-ignore - Nyelipin variation buat trigger custom CSS di PreviewSection.tsx lu
                        variation: sec.variation
                    });
                }
            });
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        // 🔥 MAPPING TIPE UNTUK DETAIL 🔥
        // Kalau type bawaan feed itu "livestreaming_schedule", kita paksa jadi "livestreaming" biar API gak bingung.
        let typeParam = slug || 'content_profile';
        if (typeParam === 'livestreaming_schedule') {
            typeParam = 'livestreaming';
        }

        return {
            endpointId: 'detail',
            params: {
                id: id,
                type: typeParam
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        // Karena kadang detail juga bisa ngerespon array jika tipe 'video' langsung, kita pastiin handle objek aslinya
        const info = rawData;
        if (!info || !info.success) return null;

        let seasonsList: any[] = [];

        // Parsing daftar season dan episode
        if (Array.isArray(info.seasons)) {
            info.seasons.forEach((season: any) => {
                if (Array.isArray(season.episodes) && season.episodes.length > 0) {
                    seasonsList.push({
                        season_number: seasonsList.length + 1,
                        season_name: season.name || `Season ${seasonsList.length + 1}`,
                        episodes: season.episodes.map((ep: any) => ({
                            id: String(ep.id),
                            title: ep.title || 'Episode',
                            thumbnail: ep.coverUrl || '',
                            // Kasih badge Premium jika isPremier true
                            badge: ep.isPremier ? 'Premium' : '',
                            description: ep.description || ''
                        }))
                    });
                }
            });
        }

        // Handle ekstrak genre
        const genresStr = Array.isArray(info.genres)
            ? info.genres.map((g: any) => g.name).join(', ')
            : '';

        // Handle tahun rilis
        const releaseYear = info.releaseDate ? info.releaseDate.substring(0, 4) : '';

        return {
            id: String(info.id),
            title: info.title || 'Tanpa Judul',
            // Gambar prioritas: landscape (biar lebar) > portrait
            posterUrl: info.coverLandscape || info.coverPortrait || '',
            type: seasonsList.length > 0 ? 'series' : 'movie',
            rating: info.contentRating || '',
            year: releaseYear,
            // 🔥 Tetap simpan tipe mentah untuk proses di fungsi Play
            slug: info.type || 'video',
            description: info.description || '',
            genres: genresStr,
            country: info.country || '',
            trailerUrl: info.trailerUrl || '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        // 🔥 MAPPING TIPE UNTUK PLAY 🔥
        let playType = detail.slug || 'video';

        // 1. Content Profile itu tipe wadah film/series, kalau di-play pastinya butuh format "video"
        if (playType === 'content_profile') playType = 'video';

        // 2. Apapun embel-embel livestreaming (jadwal, on-air), tipenya wajib "livestreaming"
        if (playType.includes('livestreaming')) playType = 'livestreaming';

        // 3. Pengecualian: Kalau kita lagi milih episode tertentu dalam series (id vidio tidak sama dgn id parent)
        // Maka tipe konten otomatis berubah menjadi "video" VOD.
        if (vid && vid !== detail.id) {
            playType = 'video';
        }

        return {
            endpointId: 'vidio-play',
            params: {
                id: String(vid || detail.id),
                type: playType
            }
        };
    }
}