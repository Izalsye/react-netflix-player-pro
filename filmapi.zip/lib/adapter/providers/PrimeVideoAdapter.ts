import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export interface ExtendedPreviewMedia extends PreviewMedia {
    bannerLayers?: { background?: string; cover?: string; title?: string; };
}

export class PrimeVideoAdapter implements IProviderStrategy {

    // 1. MAPPING REQUEST UNTUK HALAMAN DEPAN (HOME, MOVIE, TV, SEARCH)
    getFeedRequest(menuId: string, lang: string, pageParam?: number | string): FeedRequestConfig {
        let baseEndpointId = 'primevideo-home'; // Default ke Home
        const params: Record<string, string> = {};

        // Penentuan Endpoint berdasarkan menuId
        if (menuId === 'movie') {
            baseEndpointId = 'primevideo-movie';
        } else if (menuId === 'tv') {
            baseEndpointId = 'primevideo-tv';
        } else if (menuId.startsWith('search')) {
            baseEndpointId = 'primevideo-search';
            if (menuId.includes('?')) {
                const searchParams = new URLSearchParams(menuId.split('?')[1]);
                searchParams.forEach((val, key) => { params[key] = val; });
            }
        }

        // Kalau ada parameter halaman (jaga-jaga kalau Prime Video mendukung paginasi)
        if (typeof pageParam !== 'undefined' && pageParam !== null) {
            params['page'] = String(pageParam);
        }

        return { baseEndpointId, gridEndpointId: null, params };
    }

    // 2. PARSING & NORMALISASI JSON HALAMAN DEPAN
    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = {
            // Karena dari JSON tidak ada list Menu, kita hardcode menu dasar Prime Video
            menus: [
                { id: 'home', label: 'Home' },
                { id: 'movie', label: 'Movies' },
                { id: 'tv', label: 'TV Shows' }
            ],
            banners: [],
            sections: [],
            hasMore: false,
            nextPageContext: undefined
        };

        // Fungsi Helper untuk standarisasi format item
        const mapPrimeItem = (item: any): ExtendedPreviewMedia | null => {
            if (!item.id && !item.targetid) return null;
            return {
                id: item.id || item.targetid,
                title: item.title || 'Tanpa Judul',
                posterUrl: item.portraitThumbnail || item.thumbnail || '',
                type: item.type === 'movie' ? 'movie' : 'series',
                rating: item.maturityRating ? `${item.maturityRating}+` : undefined,
                slug: item.id || item.targetid,
                badge: item.premiumLabel || (item.isPremium ? 'Premium' : 'Free'),
                bannerLayers: { background: item.thumbnail || item.portraitThumbnail || '' }
            };
        };

        // Ambil Banners
        if (baseRaw?.banners && Array.isArray(baseRaw.banners)) {
            feed.banners = baseRaw.banners.map(mapPrimeItem).filter(Boolean) as ExtendedPreviewMedia[];
        }

        // Ambil Sections / Rows
        if (baseRaw?.sections && Array.isArray(baseRaw.sections)) {
            baseRaw.sections.forEach((sec: any) => {
                if (sec.items && Array.isArray(sec.items)) {
                    const validItems = sec.items.map(mapPrimeItem).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        feed.sections.push({
                            title: sec.sectionName || 'Rekomendasi',
                            items: validItems,
                            isGrid: false // Prime video defaultnya carousell horizontal
                        });
                    }
                }
            });
        }

        return feed;
    }

    // 3. MAPPING REQUEST UNTUK HALAMAN DETAIL
    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return { endpointId: 'primevideo-detail', params: { id: id } };
    }

    // 4. PARSING & NORMALISASI JSON DETAIL + EPISODE
    normalizeDetail(rawData: any): PreviewDetail | null {
        const data = rawData?.data;
        if (!data) return null;

        let seasonsList = [];

        // Parsing daftar Season dan Episode
        if (data.seasons && Array.isArray(data.seasons)) {
            seasonsList = data.seasons.map((season: any) => ({
                season_number: season.seasonNumber,
                season_name: season.title || `Season ${season.seasonNumber}`,
                episodes: (season.episodes || []).map((ep: any) => ({
                    // 🔥 TRIK MVVM: Gabungkan ID dan shortid jadi satu string pakai pemisah "||"
                    id: ep.shortid ? `${ep.id}||${ep.shortid}` : ep.id,
                    title: ep.title || `Episode ${ep.episodeNumber}`,
                    thumbnail: ep.image || '',
                    badge: ep.shortid ? 'READY' : ''
                }))
            }));
        }

        // Tangani Movie (kalau data root-nya punya shortid)
        const mainId = data.shortid ? `${data.id}||${data.shortid}` : data.id;

        return {
            id: mainId,
            title: data.title || 'Tanpa Judul',
            posterUrl: data.cover?.potrait || data.banner || '',
            type: (data.seasons && data.seasons.length > 0) ? 'series' : 'movie',
            rating: data.voteAverage ? data.voteAverage.toString() : '',
            year: data.releaseYear ? data.releaseYear.toString() : '',
            slug: data.slug || data.id,
            description: data.overview || '',
            genres: Array.isArray(data.genres) ? data.genres.join(', ') : '',
            country: '',
            trailerUrl: '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    // 5. MAPPING REQUEST UNTUK MENDAPATKAN URL PLAYBACK
    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        const params: Record<string, string> = {};

        // Ambil raw ID (vid dari episode yang diklik, atau detail.id kalau itu Movie)
        const targetRawId = vid || detail.id.toString();

        // 🔥 BONGKAR GABUNGAN ID DAN SHORTID 🔥
        let actualId = targetRawId;
        let shortId = "";

        if (targetRawId.includes('||')) {
            const parts = targetRawId.split('||');
            actualId = parts[0];
            shortId = parts[1];
        }

        // Set parameter sesuai kebutuhan endpoint primevideo-play
        params['id'] = actualId;

        if (shortId) {
            params['shortid'] = shortId;
        }

        return { endpointId: 'primevideo-play', params, method: 'POST' };
    }
}