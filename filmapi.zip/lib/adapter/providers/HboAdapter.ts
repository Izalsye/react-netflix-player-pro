import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia, PreviewMenu } from '../types';

export class HboAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        // Mapping menuId dari UI ke ID endpoint di config lu
        let baseEndpointId = 'hbo-home'; // Default ke home

        if (menuId === 'series' || menuId === 'hbo-series') {
            baseEndpointId = 'hbo-series';
        } else if (menuId === 'movies' || menuId === 'hbo-movies') {
            baseEndpointId = 'hbo-movies';
        } else if (menuId && menuId !== 'home' && menuId !== 'index') {
            // Kalau ada menu lain (misal explore), lempar ID-nya langsung
            baseEndpointId = menuId;
        }

        return {
            baseEndpointId,
            gridEndpointId: null,
            params: { lang }
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false };
        const data = baseRaw?.data || baseRaw;

        if (!data) return feed;

        // Helper untuk ekstrak gambar berdasarkan 'kind' dari HBO
        const getImageUrl = (images: any[], kinds: string[]): string => {
            if (!Array.isArray(images)) return '';
            const img = images.find(i => kinds.includes(i.kind));
            return img ? img.url : images[0]?.url || '';
        };

        // Mapper untuk satu item HBO ke PreviewMedia
        const mapHboItem = (item: any, isBanner: boolean = false): PreviewMedia | null => {
            if (!item.id && !item.title) return null;

            // Kalau banner, cari gambar wide. Kalau biasa, cari poster vertikal.
            const kinds = isBanner ? ['default-wide', 'centered-background'] : ['poster-with-logo', 'cover-artwork'];

            return {
                id: String(item.id), // Udah dibungkus String biar TS nggak rewel
                title: item.title || 'Tanpa Judul',
                posterUrl: getImageUrl(item.images, kinds),
                type: item.targetType === 'movie' ? 'movie' : 'series',
                rating: undefined, // HBO jarang ngasih rating di feed awal
                slug: String(item.id),
                badge: item.badges && item.badges.length > 0 ? item.badges[0] : undefined,
                statusText: item.description || ''
            };
        };

        const processSections = (sections: any[]) => {
            if (!Array.isArray(sections)) return;

            sections.forEach((section: any) => {
                if (!section.items || !Array.isArray(section.items)) return;

                if (section.uiType === 'hero-banner') {
                    // Masuk ke Header/Banner slider
                    const validBanners = section.items.map((i: any) => mapHboItem(i, true)).filter(Boolean) as PreviewMedia[];
                    feed.banners.push(...validBanners);
                } else if (['carousel', 'category-tab', 'category-group', 'grid-links'].includes(section.uiType)) {
                    // Masuk ke section list horizontal / grid bawahnya
                    const validItems = section.items.map((i: any) => mapHboItem(i, false)).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        feed.sections.push({
                            title: section.title || 'Lainnya',
                            items: validItems,
                            isGrid: section.uiType === 'grid-links' // Kalau grid-links biarin isGrid true
                        });
                    }
                }
            });
        };

        // 🔥 Cuma ambil data dari content_sections sesuai request lu bre 🔥
        processSections(data.content_sections);

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return {
            endpointId: 'hbo-detail', // <-- Harus sama persis kayak di config lu
            params: {
                id: String(id || slug),
                lang: lang
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const info = rawData?.data || rawData;
        if (!info || !info.id) return null;

        const getImageUrl = (images: any[], kinds: string[]): string => {
            if (!Array.isArray(images)) return '';
            const img = images.find(i => kinds.includes(i.kind));
            return img ? img.url : images[0]?.url || '';
        };

        let seasonsList: any[] = [];

        // HBO nyimpen episode di dalam array `seasons`
        if (info.seasons && Array.isArray(info.seasons)) {
            info.seasons.forEach((season: any) => {
                if (season.episodes && Array.isArray(season.episodes)) {
                    seasonsList.push({
                        season_number: season.seasonNumber || 1,
                        season_name: season.name || `Season ${season.seasonNumber || 1}`,
                        episodes: season.episodes.map((ep: any, index: number) => ({
                            id: String(ep.id || index),
                            title: ep.title || `Episode ${ep.episodeNumber || index + 1}`,
                            badge: ep.badges && ep.badges.length > 0 ? ep.badges[0] : '',
                            thumbnail: getImageUrl(ep.images, ['default', 'default-wide', 'still-frame'])
                        }))
                    });
                }
            });
        }

        // Ekstrak genres. HBO kadang bentuknya array of strings langsung, kadang array of objects.
        let genresStr = '';
        if (Array.isArray(info.genres)) {
            genresStr = typeof info.genres[0] === 'string'
                ? info.genres.join(', ')
                : info.genres.map((g: any) => g.name || g).join(', ');
        }

        return {
            id: String(info.id),
            title: info.title || 'Tanpa Judul',
            posterUrl: getImageUrl(info.images, ['poster-with-logo', 'cover-artwork', 'cover-artwork-square']),
            type: info.targetType === 'movie' || info.type === 'movie' ? 'movie' : 'series',
            rating: info.rating || '',
            year: info.releaseYear?.toString() || info.year?.toString() || '',
            slug: String(info.id),
            description: info.description || info.summary || '',
            genres: genresStr,
            country: info.country || '',
            trailerUrl: info.trailerUrl || '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        return {
            endpointId: 'hbo-play', // <-- Ini udah bener sama kayak config lu
            params: {
                id: String(vid || detail.id),
                lang: lang
            }
        };
    }
}