import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export class IdlixAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        const [baseMenu, queryString] = menuId.split('?');
        const urlParams = new URLSearchParams(queryString || '');

        // Wajib strict string semua
        const params: Record<string, string> = { page: String(page) };
        urlParams.forEach((value, key) => {
            params[key] = value;
        });

        if (baseMenu === 'movie') {
            return {
                baseEndpointId: 'movies',
                gridEndpointId: null,
                params: { limit: '36', sort: 'releaseDate', ...params }
            };
        } else if (baseMenu === 'series') {
            return {
                baseEndpointId: 'series',
                gridEndpointId: null,
                params: { limit: '36', sort: 'releaseDate', ...params }
            };
        } else if (['netflix', 'hbo', 'prime-video', 'disney-plus', 'apple-tv-plus'].includes(baseMenu)) {
            return {
                baseEndpointId: 'network',
                gridEndpointId: null,
                params: { network: baseMenu, limit: '36', sort: 'latest', ...params }
            };
        }

        return {
            baseEndpointId: 'home',
            gridEndpointId: null,
            params: {}
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false };
        if (!baseRaw) return feed;

        // 1. Setup Navbar Menus
        feed.menus = [
            { id: 'home', label: 'Home' },
            { id: 'movie', label: 'Movies' },
            { id: 'series', label: 'Series' },
            { id: 'netflix', label: 'Netflix (Network)' },
            { id: 'hbo', label: 'HBO (Network)' },
            { id: 'disney-plus', label: 'Disney+ (Network)' }
        ];

        // Helper untuk ekstrak item
        const mapItem = (item: any): PreviewMedia | null => {
            if (!item.id) return null;

            const isMovie = item.contentType === 'movie';
            const reqType = isMovie ? 'movies' : 'series';
            const playType = isMovie ? 'movie' : 'series';

            return {
                id: String(item.id),
                title: item.title || 'Tanpa Judul',
                posterUrl: item.posterPath || '',
                type: isMovie ? 'movie' : 'series',
                slug: `${reqType}:::${playType}:::${item.slug}`,
                rating: item.voteAverage ? String(item.voteAverage) : undefined,
                statusText: item.releaseDate ? item.releaseDate.substring(0, 4) : undefined,
            };
        };

        // 2. Handle HOME Endpoint
        if (Array.isArray(baseRaw.sliderItems)) {
            feed.banners = baseRaw.sliderItems.map(mapItem).filter(Boolean) as PreviewMedia[];
        }

        if (Array.isArray(baseRaw.sections)) {
            baseRaw.sections.forEach((sec: any) => {
                if (Array.isArray(sec.items) && sec.items.length > 0) {
                    feed.sections.push({
                        title: sec.title || 'Rekomendasi',
                        items: sec.items.map(mapItem).filter(Boolean) as PreviewMedia[],
                        isGrid: sec.type === 'latest_movies' || sec.type === 'latest_series'
                    });
                }
            });
        }

        // 3. Handle MOVIE, SERIES, NETWORK Endpoints
        // 🔥 FIX: Ambil dari baseRaw.items (Movies/Series) atau baseRaw.data (Network)
        const gridItems = baseRaw.items || (Array.isArray(baseRaw.data) ? baseRaw.data : undefined);

        if (Array.isArray(gridItems)) {
            feed.sections.push({
                title: baseRaw.networkName ? `Network: ${baseRaw.networkName.toUpperCase()}` : 'Katalog Pilihan',
                items: gridItems.map(mapItem).filter(Boolean) as PreviewMedia[],
                isGrid: true
            });

            // Set hasMore untuk infinite scroll
            if (baseRaw.pagination) {
                feed.hasMore = baseRaw.pagination.page < baseRaw.pagination.totalPages;
            }
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        const [reqType, playType, realSlug] = slug.split(':::');

        return {
            endpointId: 'detail',
            params: {
                // Pastikan jadi string
                slug: String(realSlug || slug),
                type: String(reqType || 'movies')
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const info = rawData?.data || rawData;
        if (!info || !info.id) return null;

        let seasonsList: any[] = [];
        const isMovie = info.contentType === 'movie';
        const playType = isMovie ? 'movie' : 'series';

        // Base URL untuk TMDB fallback
        const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';

        // Parsing Seasons & Episodes
        if (Array.isArray(info.seasons) && info.seasons.length > 0) {
            seasonsList = info.seasons.map((season: any) => ({
                season_number: season.seasonNumber,
                season_name: season.title || `Season ${season.seasonNumber}`,
                episodes: (season.episodes || []).map((ep: any) => {

                    // 🔥 FIX: Smart Formatting Judul biar gak double "Episode 9: Episode 9"
                    let epTitle = `Episode ${ep.episodeNumber}`;
                    if (ep.title) {
                        const titleClean = ep.title.trim();
                        const titleLower = titleClean.toLowerCase();
                        const prefixLower = `episode ${ep.episodeNumber}`.toLowerCase();

                        // Kalau judulnya cuma "Episode 9" atau berawalan "Episode 9", pake aslinya aja
                        if (titleLower === prefixLower || titleLower.startsWith(`${prefixLower}:`) || titleLower.startsWith(`${prefixLower} -`)) {
                            epTitle = titleClean;
                        } else {
                            // Kalau ada judul aslinya (misal "The Call"), baru digabung
                            epTitle = `Episode ${ep.episodeNumber}: ${titleClean}`;
                        }
                    }

                    // Ambil thumbnail episode, fallback ke backdrop/poster
                    let epThumb = ep.thumbnail || ep.stillPath || '';
                    if (epThumb && !epThumb.startsWith('http')) {
                        epThumb = `${TMDB_IMAGE_BASE}${epThumb}`;
                    } else if (!epThumb) {
                        epThumb = info.backdropPath || info.posterPath || '';
                    }

                    return {
                        id: `${playType}:::${ep.id}`,
                        title: epTitle,
                        thumbnail: epThumb
                    };
                })
            }));
        } else if (isMovie) {
            // Fallback buat Movie biar player jalan
            seasonsList.push({
                season_number: 1,
                season_name: 'Movie',
                episodes: [{
                    id: `${playType}:::${info.id}`,
                    title: info.title || 'Full Movie',
                    thumbnail: info.backdropPath || info.posterPath || ''
                }]
            });
        }

        return {
            id: String(info.id),
            title: info.title || 'Tanpa Judul',
            posterUrl: info.posterPath || '',
            type: isMovie ? 'movie' : 'series',
            rating: info.voteAverage ? String(info.voteAverage) : '',
            year: info.releaseDate ? info.releaseDate.substring(0, 4) : '',
            slug: String(info.slug || info.id),
            description: info.overview || '',
            genres: Array.isArray(info.genres) ? info.genres.join(', ') : '',
            country: info.country || '',
            trailerUrl: info.trailerUrl || '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        // Handle undefined vid aman pakai fallback string kosong
        const safeVid = vid || '';
        const [playType, realVidId] = safeVid.split(':::');

        return {
            endpointId: 'idlix-getplay',
            params: {
                // Wajib dibungkus String() semua buat menuhin Record<string, string>
                slug: String(detail.slug || ''),
                id: String(realVidId || safeVid),
                type: String(playType || (detail.type === 'movie' ? 'movie' : 'series'))
            }
        };
    }
}