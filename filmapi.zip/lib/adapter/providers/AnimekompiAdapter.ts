import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export interface ExtendedPreviewMedia extends PreviewMedia {
    bannerLayers?: { background?: string; cover?: string; title?: string; };
}

export class AnimekompiAdapter implements IProviderStrategy {

    // 1. MAPPING REQUEST UNTUK HALAMAN DEPAN & GENRE
    getFeedRequest(menuId: string, lang: string, pageParam?: number | string): FeedRequestConfig {
        const params: Record<string, string> = {};
        const page = pageParam ? String(pageParam) : '1';

        // Tentukan endpoint berdasarkan menuId
        if (menuId === 'home') {
            params['page'] = page;
            return { baseEndpointId: 'home', gridEndpointId: null, params };
        }
        else if (menuId === 'schedule') {
            return { baseEndpointId: 'schedule', gridEndpointId: null, params: {} };
        }
        else {
            // Jika bukan home/schedule, asumsikan itu adalah genre (misal: 'romance', 'action')
            params['genre'] = menuId;
            params['page'] = page;
            return { baseEndpointId: 'genre-detail', gridEndpointId: null, params };
        }
    }

    // 2. PARSING & NORMALISASI JSON FEED
    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = {
            menus: [
                { id: 'home', label: 'Home' },
                { id: 'schedule', label: 'Jadwal Tayang' },
                { id: 'action', label: 'Action' },
                { id: 'romance', label: 'Romance' },
                { id: 'comedy', label: 'Comedy' },
                { id: 'adventure', label: 'Adventure' },
                { id: 'fantasy', label: 'Fantasy' },
                { id: 'isekai', label: 'Isekai' },
                { id: 'school', label: 'School' },
                { id: 'sci-fi', label: 'Sci-Fi' },
                { id: 'shounen', label: 'Shounen' },
                { id: 'slice-of-life', label: 'Slice of Life' }
                // Silakan tambahkan genre lain secara manual di sini jika butuh shortcut
            ],
            banners: [],
            sections: [],
            hasMore: false,
            nextPageContext: undefined
        };

        const data = baseRaw?.data;
        if (!data) return feed;

        // Fungsi mapper standar untuk item Animekompi
        const mapItem = (item: any): ExtendedPreviewMedia => ({
            id: item.path,
            title: item.title || 'Tanpa Judul',
            posterUrl: item.cover_url || '',
            type: 'series', // Mayoritas serial anime
            slug: item.path,
            badge: item.episode || item.status_or_episode || item.status || '',
            rating: item.rating ? item.rating.toString() : undefined,
            bannerLayers: { background: item.cover_url || '' }
        });

        // A. Handle Response HOME
        if (data.sliders || data.trending_today || data.latest_updates) {
            if (data.sliders) {
                feed.banners = data.sliders.map(mapItem) as ExtendedPreviewMedia[];
            }
            if (data.trending_today && data.trending_today.length > 0) {
                feed.sections.push({ title: 'Trending Hari Ini', items: data.trending_today.map(mapItem), isGrid: false });
            }
            if (data.latest_updates && data.latest_updates.length > 0) {
                // Pakai mode grid untuk update terbaru karena jumlahnya banyak
                feed.sections.push({ title: 'Update Terbaru', items: data.latest_updates.map(mapItem), isGrid: true });
            }
        }
        // B. Handle Response SCHEDULE (Jadwal Tayang)
        else if (Array.isArray(data)) {
            data.forEach((dayData: any) => {
                if (dayData.animes && dayData.animes.length > 0) {
                    feed.sections.push({
                        title: `Jadwal ${dayData.day}`,
                        items: dayData.animes.map(mapItem),
                        isGrid: false
                    });
                }
            });
        }
        // C. Handle Response GENRE DETAIL
        else if (data.animes && Array.isArray(data.animes)) {
            feed.sections.push({
                title: `Genre: ${data.genre_name || 'Daftar Anime'}`,
                items: data.animes.map(mapItem),
                isGrid: true
            });
            feed.hasMore = data.has_next_page || false;
            feed.nextPageContext = data.current_page ? (data.current_page + 1) : undefined;
        }

        return feed;
    }

    // 3. MAPPING REQUEST UNTUK HALAMAN DETAIL
    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        // Parameternya menggunakan 'path' berdasarkan JSON lu
        return { endpointId: 'detail', params: { path: id || slug } };
    }

    // 4. PARSING & NORMALISASI JSON DETAIL + EPISODE
    normalizeDetail(rawData: any): PreviewDetail | null {
        const data = rawData?.data;
        if (!data) return null;

        // 🔥 FIX: Definisikan tipe array-nya di sini secara eksplisit 🔥
        let episodes: any[] = [];

        if (data.episode_list && Array.isArray(data.episode_list)) {
            // Karena web anime biasanya ngurutin episode dari yang terbaru (Z-A), 
            // Kita reverse() biar di Player urutannya dari Episode 1 (A-Z)
            const reversedList = [...data.episode_list].reverse();

            episodes = reversedList.map((ep: any) => ({
                id: ep.episode_id,
                title: ep.title || `Episode ${ep.episode_number}`,
                thumbnail: '',
                badge: ep.release_date || ''
            }));
        }

        return {
            id: data.title,
            title: data.title || 'Tanpa Judul',
            posterUrl: data.cover_url || '',
            type: data.type?.toLowerCase() === 'movie' ? 'movie' : 'series',
            rating: data.rating ? data.rating.toString() : '',
            year: data.release_date || data.season || '',
            slug: data.title,
            description: data.synopsis || '',
            genres: Array.isArray(data.genres) ? data.genres.join(', ') : '',
            country: 'Japan',
            seasonsList: episodes.length > 0 ? [{ season_number: 1, season_name: 'Semua Episode', episodes: episodes }] : undefined
        };
    }
    // 5. MAPPING REQUEST UNTUK MENDAPATKAN URL PLAYBACK
    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        // 'vid' di sini adalah episode_id (misal: "a-day-before-us-2-episode-01")
        return {
            endpointId: 'animekompi-play',
            params: { episode_id: vid || '' },
            method: 'GET'
        };
    }
}