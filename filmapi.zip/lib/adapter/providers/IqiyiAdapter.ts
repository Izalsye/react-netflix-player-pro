import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export interface ExtendedPreviewMedia extends PreviewMedia {
    bannerLayers?: { background?: string; cover?: string; title?: string; };
}

export class IqiyiAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, pageParam?: number | string): FeedRequestConfig {
        // 1. Daftar menu/endpoint yang valid sesuai konfigurasi API kamu
        const validMenus = ['home', 'trending', 'drama', 'kdrama', 'movie', 'anime', 'variety'];

        // 2. Default fallback ke 'home' jika menuId tidak dikenali
        const baseEndpointId = validMenus.includes(menuId) ? menuId : 'home';

        // 3. Set parameter query
        const params: Record<string, string> = {
            lang: lang || 'id_id',
            page: String(pageParam || 1)
        };

        return {
            baseEndpointId,
            gridEndpointId: null,
            params
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false, nextPageContext: undefined };

        const data = baseRaw?.data || baseRaw;
        if (!data) return feed;

        // 1. Setup Navbar Menus (Bisa statis atau dinamis dari API)
        feed.menus = [
            { id: 'home', label: 'Rekomendasi' },
            { id: 'trending', label: 'Top Peringkat' },
            { id: 'drama', label: 'Drama' },
            { id: 'kdrama', label: 'K-Drama' },
            { id: 'movie', label: 'Film' },
            { id: 'anime', label: 'Anime' },
            { id: 'variety', label: 'Variety Show' }
        ];

        // 2. Helper Map Item
        const mapIqiyiItem = (item: any): ExtendedPreviewMedia | null => {
            const mediaId = item.pathdetail || item.slug || item.id;
            if (!mediaId) return null;

            const poster = item.cover?.potrait || item.banner?.background || item.coverHorizontal || item.coverVertical || '';

            return {
                id: String(mediaId),
                title: item.title || 'Tanpa Judul',
                posterUrl: poster,
                type: item.contentType === 'movie' ? 'movie' : 'series',
                slug: String(mediaId),
                rating: item.voteAverage && item.voteAverage !== "0" ? String(item.voteAverage) : undefined,
                statusText: item.numberOfEpisodes ? `${item.numberOfEpisodes} Episode` : undefined,
                bannerLayers: item.banner ? {
                    background: item.banner.background,
                    cover: item.banner.cover,
                    title: item.banner.title
                } : undefined
            };
        };

        // 3. Handle Banners (Hero Slider)
        if (Array.isArray(data.sliderItems)) {
            feed.banners = data.sliderItems.map(mapIqiyiItem).filter(Boolean) as ExtendedPreviewMedia[];
        }

        // 4. Handle Sections (Home & Kategori)
        if (Array.isArray(data.sections)) {
            data.sections.forEach((sec: any) => {
                if (Array.isArray(sec.items) && sec.items.length > 0) {
                    const validItems = sec.items.map(mapIqiyiItem).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        feed.sections.push({
                            title: sec.title || 'Rekomendasi',
                            items: validItems,
                            isGrid: sec.type === 'grid' || false
                        });
                    }
                }
            });
        }

        // 5. Handle Array Lempengan (Biasanya untuk response Pagination / Page 2 ke atas)
        const exploreItems = data.items || (Array.isArray(data) ? data : null);
        if (exploreItems && Array.isArray(exploreItems) && feed.sections.length === 0) {
            const validItems = exploreItems.map(mapIqiyiItem).filter(Boolean) as PreviewMedia[];
            if (validItems.length > 0) {
                feed.sections.push({
                    title: 'Katalog',
                    items: validItems,
                    isGrid: true
                });
            }
        }

        // 6. Handle Pagination HasMore
        // Cek property hasMore, has_next, atau next_page dari JSON iQIYI
        const hasMoreData = data.hasMore === 1 || data.hasMore === true || data.has_next === 1 || data.hasNextPage === true;
        if (hasMoreData) {
            feed.hasMore = true;
            // Jika API iQIYI ngirim token halaman selanjutnya, masukkan ke nextPageContext. 
            // Jika tidak ada, UI biasanya akan auto-increment parameter `page` sebagai angka.
            feed.nextPageContext = data.next_page || data.nextPageContext || undefined;
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return {
            endpointId: 'detail',
            params: {
                pathplay: String(slug || id),
                lang: lang || 'id_id'
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const info = rawData?.data || rawData;
        if (!info || !info.id) return null;

        let seasonsList: any[] = [];

        if (Array.isArray(info.seasons) && info.seasons.length > 0) {
            seasonsList = info.seasons.map((season: any) => ({
                season_number: season.seasonNumber,
                season_name: season.title || `Season ${season.seasonNumber}`,
                episodes: (season.episodes || []).map((ep: any) => ({
                    id: String(ep.slug || ep.id),
                    title: ep.title || `Episode ${ep.episodeNumber}`,
                    thumbnail: info.cover?.landscape || ''
                }))
            }));
        } else if (info.contentType === 'movie' || info.type === 'movie') {
            seasonsList.push({
                season_number: 1,
                season_name: 'Movie',
                episodes: [{
                    id: String(info.slug || info.id),
                    title: info.title,
                    thumbnail: info.cover?.landscape || ''
                }]
            });
        }

        return {
            id: String(info.id),
            title: info.title || 'Tanpa Judul',
            posterUrl: info.cover?.potrait || info.coverVertical || '',
            type: info.contentType === 'movie' || info.type === 'movie' ? 'movie' : 'series',
            rating: info.voteAverage && info.voteAverage !== "0" ? String(info.voteAverage) : '',
            year: info.releaseDate ? String(info.releaseDate).substring(0, 4) : '',
            slug: String(info.slug || info.id),
            description: info.overview || info.description || '',
            genres: Array.isArray(info.genres) ? info.genres.join(', ') : (info.genres || ''),
            country: info.country || info.region || '',
            trailerUrl: info.trailerUrl || '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        return {
            endpointId: 'playurl',
            params: {
                slug: String(vid || detail.slug || detail.id),
                lang: lang || 'id_id'
            }
        };
    }
}