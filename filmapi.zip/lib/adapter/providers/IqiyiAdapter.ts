import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export class IqiyiAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        // 1. Handle Routing: Cuma ada Home dan Trending
        let endpointId = 'home'; // default dari config lu

        if (menuId === 'trending') {
            endpointId = 'trending';
        } else {
            endpointId = 'home';
        }

        return {
            baseEndpointId: endpointId,
            gridEndpointId: null,
            params: {} // iQIYI endpoint home/trending lu di config gak butuh param page/lang
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false };
        // Asumsi struktur data ada di baseRaw.data atau langsung di baseRaw
        const data = baseRaw?.data || baseRaw;

        if (!data) return feed;

        // 2. Setup Navbar Menus
        feed.menus = [
            { id: 'home', label: 'Home' },
            { id: 'trending', label: 'Populer / Trending' }
        ];

        // Helper untuk ekstrak item iQIYI ke standar UI
        const mapIqiyiItem = (item: any): PreviewMedia | null => {
            const mediaId = item.pathdetail || item.slug || item.id;
            if (!mediaId) return null;

            // Prioritas Cover: Portrait -> Background Banner -> Fallback string kosong
            const poster = item.cover?.potrait || item.banner?.background || '';

            return {
                id: String(mediaId),
                title: item.title || 'Tanpa Judul',
                posterUrl: poster,
                type: item.contentType === 'movie' ? 'movie' : 'series',
                slug: String(mediaId),
                rating: item.voteAverage ? String(item.voteAverage) : undefined,
                // Format episode jika ada
                statusText: item.numberOfEpisodes ? `${item.numberOfEpisodes} Episode` : undefined,

                // EXTRA: Lempar data layer banner murni ke UI biar bisa di-styling parallax/tumpuk
                ...(item.banner && {
                    bannerLayers: {
                        background: item.banner.background,
                        cover: item.banner.cover,
                        title: item.banner.title
                    }
                }) as any // Cast as any kalau interface PreviewMedia lu belum support bannerLayers
            };
        };

        // 3. Handle Banners (Hero Slider)
        if (Array.isArray(data.sliderItems)) {
            feed.banners = data.sliderItems.map(mapIqiyiItem).filter(Boolean) as PreviewMedia[];
        }

        // 4. Handle Sections (Home & Trending sama-sama pakai format sections)
        if (Array.isArray(data.sections)) {
            data.sections.forEach((sec: any) => {
                if (Array.isArray(sec.items) && sec.items.length > 0) {
                    const validItems = sec.items.map(mapIqiyiItem).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        feed.sections.push({
                            title: sec.title || 'Rekomendasi',
                            items: validItems,
                            isGrid: sec.type === 'grid' // Kalau sewaktu-waktu ada tipe grid
                        });
                    }
                }
            });
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return {
            endpointId: 'detail', // Sesuai ID di config Iqiyi
            params: {
                // iQIYI pakai 'pathplay' atau 'slug' buat get detail
                pathplay: String(slug || id),
                lang: lang || 'id_id'
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        // Handle root payload
        const info = rawData?.data || rawData;
        if (!info || !info.id) return null;

        let seasonsList: any[] = [];

        // Parsing Seasons & Episodes
        if (Array.isArray(info.seasons) && info.seasons.length > 0) {
            seasonsList = info.seasons.map((season: any) => ({
                season_number: season.seasonNumber,
                season_name: season.title || `Season ${season.seasonNumber}`,
                episodes: (season.episodes || []).map((ep: any) => ({
                    // KUNCI: Kita pakai ep.slug sebagai ID, karena endpoint playurl butuh slug ini
                    id: String(ep.slug),
                    title: ep.title || `Episode ${ep.episodeNumber}`,
                    // Kalau ep gak punya thumbnail, fallback ke cover landscape filmnya
                    thumbnail: info.cover?.landscape || ''
                }))
            }));
        } else if (info.contentType === 'movie') {
            // Kalau Movie, buatin 1 dummy episode biar play button tetep jalan
            seasonsList.push({
                season_number: 1,
                season_name: 'Movie',
                episodes: [{
                    id: String(info.slug || info.id),
                    title: info.title,
                    thumbnail: info.cover?.landscape || ''
                }]
            });
        }

        return {
            id: String(info.id),
            title: info.title || 'Tanpa Judul',
            posterUrl: info.cover?.potrait || '',
            type: info.contentType === 'movie' ? 'movie' : 'series',
            rating: info.voteAverage ? String(info.voteAverage) : '',
            year: info.releaseDate ? info.releaseDate.substring(0, 4) : '',
            slug: String(info.slug || info.id),
            description: info.overview || '',
            genres: Array.isArray(info.genres) ? info.genres.join(', ') : '',
            country: '',
            trailerUrl: '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        return {
            endpointId: 'playurl', // Sesuai ID di config Iqiyi
            params: {
                // vid ini didapat dari episode.id di fungsi normalizeDetail di atas (yang mana isinya adalah ep.slug)
                slug: String(vid),
                lang: lang || 'id_id'
            }
        };
    }
}