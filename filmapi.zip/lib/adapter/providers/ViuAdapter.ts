import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia, PreviewMenu } from '../types';

export class ViuAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        let baseEndpointId = '';
        let params: any = { lang };

        // 1. Handle Routing: Beda menuId, beda endpoint yang ditembak
        if (!menuId || menuId === 'home' || menuId === 'index') {
            baseEndpointId = 'viu-home';
            params.country = 'ID'; // Default country dari config lu
        } else {
            baseEndpointId = 'viu-category';
            params.category_id = menuId;

            // Pagination khusus buat category
            const limit = 44;
            params.length = limit;
            params.offset = (page - 1) * limit;
        }

        return {
            baseEndpointId,
            gridEndpointId: null,
            params
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false };
        const data = baseRaw;

        if (!data || data.status !== 'success') return feed;

        // 2. Setup Navbar Menus (Sesuai response /api/viu/categories lu)
        feed.menus = [
            { id: 'home', label: 'Home' },
            { id: '571', label: 'Viu Original' },
            { id: '549', label: 'Drama Korea' },
            { id: '550', label: 'Variety Show Korea' },
            { id: '553', label: 'Drama Cina' },
            { id: '552', label: 'Drama Thailand' },
            { id: '546', label: 'Dub Bahasa Indonesia' },
            { id: '551', label: 'Film Korea' },
            { id: '308', label: 'Film' },
            { id: '574', label: 'Anime' },
            { id: '548', label: 'Drama Indonesia' },
            { id: '557', label: 'Drama Turki' },
            { id: '573', label: 'Variety Show' },
            { id: '775', label: 'Drama Korea Romantis' }
        ];

        // Helper untuk ekstrak item ke standar UI
        const mapViuItem = (item: any): PreviewMedia | null => {
            const mediaId = item.seriesId ? item.seriesId : item.id;
            if (!mediaId) return null;

            return {
                id: String(mediaId),
                title: item.title || 'Tanpa Judul',
                // Prioritas: Portrait -> Thumbnail biasa -> ImageUrl (khusus banner home)
                posterUrl: item.portraitThumbnail || item.thumbnail || item.imageUrl || '',
                type: item.type === 'movie' ? 'movie' : 'series',
                slug: String(mediaId),
                badge: item.isPremium ? 'Premium' : undefined,
                // Hilangin "0 Episode" buat trailer/bundling
                statusText: item.episodeCount && item.episodeCount !== "0" ? `${item.episodeCount} Episode` : ''
            };
        };

        // 3. Handle Banners (Bisa dari 'banners' di Home atau 'heroSection' di Category)
        const rawBanners = data.banners || data.heroSection || [];
        if (Array.isArray(rawBanners)) {
            const validBanners = rawBanners.map(mapViuItem).filter(Boolean) as PreviewMedia[];

            // Khusus banner, kita paksa ambil gambar yang landscape/wide
            feed.banners = validBanners.map((b, i) => ({
                ...b,
                posterUrl: rawBanners[i].imageUrl || rawBanners[i].thumbnail || b.posterUrl
            }));
        }

        // 4. Handle Sections (Khusus dari endpoint viu-home)
        if (Array.isArray(data.sections)) {
            data.sections.forEach((sec: any) => {
                if (Array.isArray(sec.items) && sec.items.length > 0) {
                    const validItems = sec.items.map(mapViuItem).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        feed.sections.push({
                            title: sec.sectionName || 'Lainnya',
                            items: validItems,
                            isGrid: false // Biasanya home itu slider horizontal
                        });
                    }
                }
            });
            feed.hasMore = false; // Home biasanya gak pake infinite scroll pagination
        }

        // 5. Handle Series Grid (Khusus dari endpoint viu-category)
        if (Array.isArray(data.series) && data.series.length > 0) {
            const validItems = data.series.map(mapViuItem).filter(Boolean) as PreviewMedia[];
            if (validItems.length > 0) {
                feed.sections.push({
                    title: data.series[0]?.category?.name || 'Terbaru',
                    items: validItems,
                    isGrid: true // Kalau category page, tampilin bentuk Grid card
                });
                // Aktifin pagination kalo data nutup limit (44)
                feed.hasMore = validItems.length >= 44;
            }
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return {
            endpointId: 'viu-detail',
            params: {
                series_id: String(id || slug),
                lang: lang
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const payload = rawData?.data;
        if (!payload || payload.status !== 'success' || !payload.detail) return null;

        const info = payload.detail;
        let seasonsList: any[] = [];

        if (Array.isArray(payload.episodes) && payload.episodes.length > 0) {
            seasonsList.push({
                season_number: 1,
                season_name: 'Season 1',
                episodes: payload.episodes.map((ep: any) => ({
                    id: String(ep.id),
                    title: ep.name || `Episode ${ep.episodeNum}`,
                    thumbnail: ep.coverEpisode || info.thumbnail || ''
                }))
            });
        }

        return {
            id: String(info.seriesId || info.id),
            title: info.title || 'Tanpa Judul',
            posterUrl: info.thumbnail || '',
            type: info.type === 'movie' ? 'movie' : 'series',
            rating: '',
            year: '',
            slug: String(info.seriesId || info.id),
            description: info.synopsis || '',
            genres: info.category?.name || '',
            country: '',
            trailerUrl: '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        return {
            endpointId: 'viu-play',
            params: {
                product_id: String(vid),
                lang: lang
            }
        };
    }
}