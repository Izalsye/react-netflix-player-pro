import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia, PreviewMenu } from '../types';

export interface ExtendedPreviewMedia extends PreviewMedia {
    bannerLayers?: { background?: string; cover?: string; title?: string; };
}

export class WeTVAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, pageParam?: number | string): FeedRequestConfig {
        let baseEndpointId = 'home';
        const params: Record<string, string> = { lang };
        const isExplore = menuId.startsWith('explore');

        const extractExploreParams = (url: string) => {
            if (url.includes('?')) {
                const searchParams = new URLSearchParams(url.split('?')[1]);
                searchParams.forEach((val, key) => { params[key] = val; });
            }
        };

        if (typeof pageParam === 'string' && pageParam.length > 0) {
            baseEndpointId = isExplore ? 'explore' : 'channel';
            if (baseEndpointId === 'channel') {
                params['id'] = menuId;
            } else {
                extractExploreParams(menuId);
            }
            params['pageCtx'] = pageParam;
            return { baseEndpointId, gridEndpointId: null, params };
        }

        if (isExplore) {
            baseEndpointId = 'explore';
            extractExploreParams(menuId);
            return { baseEndpointId, gridEndpointId: null, params };
        }

        if (menuId !== 'home' && menuId !== 'index') {
            baseEndpointId = 'channel';
            params['id'] = menuId;
        }

        return { baseEndpointId, gridEndpointId: null, params };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = { menus: [], banners: [], sections: [], hasMore: false, nextPageContext: undefined };

        if (baseRaw?.menus && Array.isArray(baseRaw.menus)) {
            feed.menus = baseRaw.menus.map((m: any) => ({ id: m.id || m.name, label: m.name || m.title }));
            if (!feed.menus.find(m => m.id === 'explore')) {
                feed.menus.push({ id: 'explore', label: 'Eksplorasi' });
            }
        }

        const mapWeTVItem = (item: any): ExtendedPreviewMedia | null => {
            if (!item.id && !item.title) return null;
            return {
                id: item.id, title: item.title || 'Tanpa Judul',
                posterUrl: item.coverVertical || item.coverHorizontal || '',
                type: 'series', rating: item.score && item.score !== "0" ? item.score : undefined,
                slug: item.id, badge: item.badge, statusText: item.statusText,
                bannerLayers: { background: item.coverHorizontal || '' }
            };
        };

        if (baseRaw?.sections?.banners) feed.banners = baseRaw.sections.banners.map(mapWeTVItem).filter(Boolean) as ExtendedPreviewMedia[];

        if (baseRaw?.modules) {
            const carouselModule = baseRaw.modules.find((m: any) => m.moduleType === 'MODULE_TYPE_CAROUSEL');
            if (carouselModule && carouselModule.items) feed.banners = carouselModule.items.map(mapWeTVItem).filter(Boolean) as ExtendedPreviewMedia[];
        }

        if (baseRaw?.sections) {
            Object.keys(baseRaw.sections).forEach(key => {
                if (key !== 'banners' && Array.isArray(baseRaw.sections[key])) {
                    const validItems = baseRaw.sections[key].map(mapWeTVItem).filter(Boolean) as PreviewMedia[];
                    if (validItems.length > 0) {
                        let sectionTitle = key === 'wetvHot' ? 'WeTV Hot' : key === 'segeraTayang' ? 'Segera Tayang' : key === 'terbaru' ? 'Terbaru' : key;
                        feed.sections.push({ title: sectionTitle, items: validItems, isGrid: false });
                    }
                }
            });
        }

        if (baseRaw?.modules) {
            baseRaw.modules.forEach((mod: any) => {
                if (mod.moduleType === 'MODULE_TYPE_CAROUSEL') return;
                const validItems = (mod.items || []).map(mapWeTVItem).filter(Boolean) as PreviewMedia[];
                if (validItems.length > 0) feed.sections.push({ title: mod.moduleName || 'Rekomendasi', items: validItems, isGrid: false });
            });
        }

        // 🔥 FIX 1: JSON WeTV Naruh Items Langsung di luar (baseRaw.items)
        const exploreItems = baseRaw?.items || baseRaw?.data?.items;
        if (exploreItems && Array.isArray(exploreItems)) {
            const validItems = exploreItems.map(mapWeTVItem).filter(Boolean) as PreviewMedia[];
            if (validItems.length > 0) {
                // Sengaja title dikosongin biar nempel atas
                feed.sections.push({ title: 'Katalog Pilihan', items: validItems, isGrid: true });
            }
        }

        // 🔥 FIX 2: JSON WeTV Naruh Pagination di luar (baseRaw.pagination)
        const paginationObj = baseRaw?.pagination || baseRaw?.data?.pagination;
        
        if (paginationObj && paginationObj.hasNextPage) {
            feed.hasMore = true;
            feed.nextPageContext = paginationObj.nextPageContext;
        } else if (baseRaw?.hasNextPage) {
            feed.hasMore = true;
            feed.nextPageContext = baseRaw.nextPageContext;
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return { endpointId: 'detail', params: { cid: id || slug, lang: lang } };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const info = rawData?.series || rawData?.data?.series || rawData?.data || rawData;
        if (!info) return null;
        let seasonsList = [];
        const mapWeTVEpisode = (ep: any, index: number) => ({
            id: ep.vid || ep.id || String(index), title: ep.title || `Episode ${ep.episodeNumber || index + 1}`,
            badge: ep.badge || (ep.isFree === false ? 'VIP' : ''), thumbnail: ep.thumbnail || ''
        });

        const mainEpisodes = rawData?.episodes || rawData?.data?.episodes || [];
        if (mainEpisodes.length > 0) seasonsList.push({ season_number: 1, season_name: 'Episodes', episodes: mainEpisodes.map(mapWeTVEpisode) });
        const extras = rawData?.extras || rawData?.data?.extras || [];
        if (extras.length > 0) seasonsList.push({ season_number: 2, season_name: 'Extras', episodes: extras.map(mapWeTVEpisode) });
        const trailers = rawData?.trailers || rawData?.data?.trailers || [];
        if (trailers.length > 0) seasonsList.push({ season_number: 3, season_name: 'Trailers', episodes: trailers.map(mapWeTVEpisode) });

        return {
            id: info.id, title: info.title || 'Tanpa Judul',
            posterUrl: info.coverHorizontal || info.coverVertical || info.pic || '',
            type: info.episodeTotal === 1 || info.pageType === 'movie' ? 'movie' : 'series',
            rating: info.score && info.score !== "0" ? info.score.toString() : '',
            year: info.year || info.publishYear || '', slug: info.id, description: info.description || info.intro || '',
            genres: Array.isArray(info.genres) ? info.genres.join(', ') : (info.genres || info.category || ''),
            country: info.region || info.area || info.country || '', trailerUrl: info.trailerUrl || '',
            seasonsList: seasonsList.length > 0 ? seasonsList : undefined
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        const params: Record<string, string> = { cid: detail.id.toString(), defn: 'fhd', lang: lang };
        if (vid) params['vid'] = vid;
        else if (detail.type === 'movie') params['vid'] = detail.id.toString();
        return { endpointId: 'play', params };
    }
}