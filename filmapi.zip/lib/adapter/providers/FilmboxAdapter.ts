import { IProviderStrategy, FeedRequestConfig, DetailRequestConfig, PlayRequestConfig } from '../IProviderStrategy';
import { PreviewFeed, PreviewDetail, PreviewMedia } from '../types';

export class FilmboxAdapter implements IProviderStrategy {

    getFeedRequest(menuId: string, lang: string, page: number): FeedRequestConfig {
        let baseEndpointId = menuId;
        let gridEndpointId = null;

        // Logika routing endpoint khusus Filmbox
        if (menuId === 'home' || menuId === 'endpoints') {
            baseEndpointId = 'home';
            gridEndpointId = 'trending';
        } else if (menuId === '18plus') {
            baseEndpointId = '18plus-home';
            gridEndpointId = '18plus-trending';
        } else if (menuId === 'movie') {
            baseEndpointId = 'movie-home';
            gridEndpointId = 'movie-trending';
        }

        return {
            baseEndpointId,
            gridEndpointId,
            params: {} // Filmbox biasanya ga butuh param aneh-aneh di feed awal
        };
    }

    normalizeFeed(baseRaw: any, gridRaw?: any): PreviewFeed {
        const feed: PreviewFeed = {
            menus: [
                { id: 'home', label: 'Home' },
                { id: '18plus', label: '18+ Midnight' },
                { id: 'movie', label: 'Movie' }
            ],
            banners: [],
            sections: [],
            hasMore: false
        };

        const mapItem = (item: any): PreviewMedia | null => {
            if (!item.cover_url && !item.title) return null;
            return {
                id: item.subjectId,
                title: item.title || 'Tanpa Judul',
                posterUrl: item.cover_url || '',
                type: item.subjectType === 1 ? 'movie' : 'series',
                rating: item.rating ? item.rating.toString() : '',
                year: item.releaseDate ? item.releaseDate.split('-')[0] : '',
                slug: item.detailPath
            };
        };

        // 1. Ambil Banner & Section Slider dari API Home
        if (baseRaw?.data?.content_sections) {
            if (baseRaw.data.hero_banners) {
                feed.banners = baseRaw.data.hero_banners.map(mapItem).filter(Boolean) as PreviewMedia[];
            }
            baseRaw.data.content_sections.forEach((sec: any) => {
                const validItems = (sec.items || []).map(mapItem).filter(Boolean) as PreviewMedia[];
                if (validItems.length > 0) {
                    feed.sections.push({
                        title: sec.section_title || 'Rekomendasi',
                        items: validItems,
                        isGrid: false
                    });
                }
            });
        }

        // 2. Ambil Section Grid dari API Trending (jika ada)
        if (gridRaw?.data?.items) {
            const validGridItems = gridRaw.data.items.map(mapItem).filter(Boolean) as PreviewMedia[];
            if (validGridItems.length > 0) {
                feed.sections.push({
                    title: 'Trending Saat Ini',
                    items: validGridItems,
                    isGrid: true
                });
            }
            if (gridRaw?.data?.pager) {
                feed.hasMore = gridRaw.data.pager.hasMore;
            }
        }

        return feed;
    }

    getDetailRequest(id: string, slug: string, lang: string): DetailRequestConfig {
        return {
            endpointId: 'detail',
            params: {
                id: id || '',
                detailPath: slug || ''
            }
        };
    }

    normalizeDetail(rawData: any): PreviewDetail | null {
        const item = rawData?.data;
        if (!item) return null;

        return {
            id: item.subjectId,
            title: item.title || 'Tanpa Judul',
            posterUrl: item.cover_url || '',
            type: item.subjectType === 1 ? 'movie' : 'series',
            rating: item.rating ? item.rating.toString() : '',
            year: item.releaseDate ? item.releaseDate.split('-')[0] : '',
            slug: item.detailPath,
            description: item.description,
            genres: item.genre,
            country: item.country,
            trailerUrl: item.trailer_url,
            seasonsList: item.seasons_list
        };
    }

    getPlayRequest(detail: PreviewDetail, epNum: number, seasonNum: number, lang: string, vid?: string): PlayRequestConfig {
        return {
            endpointId: 'filmbox-getplay',
            params: {
                subjectId: detail.id.toString(),
                detailPath: detail.slug || '',
                se: seasonNum.toString(),
                ep: epNum.toString(),
                lang: lang === 'id' ? 'in_id' : 'en_us'
            }
        };
    }
}