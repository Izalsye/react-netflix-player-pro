import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

// Sesuaikan import generator sesi Prime lu nanti
// import { PrimeSessionGenerator } from './primeSessionGenerator';

const PRIME_API_BASE = process.env.PRIME_API_BASE || 'https://atv-ps-eu.primevideo.com';
const PRIME_WWW_BASE = process.env.PRIME_WWW_BASE || 'https://www.primevideo.com';
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// Default cookie hasil dump (Pastikan ngambil dari .env)
const DEFAULT_PRIME_COOKIE = process.env.PRIME_VIDEO_COOKIE || '';

const cache = new Map<string, { val: any, exp: number }>();

// 🚀 EKSTRAKTOR SESSION ID DARI COOKIE
function extractSessionId(cookieStr: string): string {
    const match = cookieStr.match(/session-id=([^;]+)/);
    return match ? match[1] : "355-6059488-6254463"; // Fallback ke sesi default
}

// 🚀 BUILDER HEADER KHUSUS PRIME VIDEO (UPDATED)
function buildPrimeHeaders(req: Request, targetHost: string, dynamicCookie: string): Record<string, string> {
    const incomingHeaders = Object.fromEntries(req.headers.entries());
    const clientCookie = dynamicCookie || incomingHeaders["cookie"] || DEFAULT_PRIME_COOKIE;
    const sessionId = extractSessionId(clientCookie);

    let safeAcceptEncoding = incomingHeaders["accept-encoding"] || "gzip, deflate, br";
    safeAcceptEncoding = safeAcceptEncoding.replace(/,?\s*zstd/gi, '').trim();
    if (safeAcceptEncoding.startsWith(',')) safeAcceptEncoding = safeAcceptEncoding.substring(1).trim();

    // 🔥 DETEKSI APAKAH INI KE API (atv-ps) ATAU KE WEB (www)
    const isApi = targetHost.includes('atv-ps');

    const headers: Record<string, string> = {
        "Accept": isApi ? "*/*" : "application/json",
        "Accept-Encoding": safeAcceptEncoding,
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Cookie": clientCookie,
        "Host": targetHost,
        // Referer selalu butuh trailing slash untuk Playback API
        "Referer": "https://www.primevideo.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Google Chrome";v="153", "Not_A Brand";v="8", "Chromium";v="153"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        // WAF Amazon sangat ketat soal ini: same-site untuk API, same-origin untuk WEB
        "Sec-Fetch-Site": isApi ? "same-site" : "same-origin",
    };

    // Tambahan spesifik tergantung target host
    if (isApi) {
        headers["Origin"] = "https://www.primevideo.com";
    } else {
        headers["x-purpose"] = "navigation";
        headers["x-requested-with"] = "WebAppSPA";
        headers["x-atv-session-id"] = sessionId;
        headers["x-request-priority"] = "NOTIFICATION";
        headers["x-retry-count"] = "0";
    }

    return headers;
}

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

// ============================================================================
// CORE HTTP GET
// ============================================================================
async function Get(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000, maxRedirects = 5) {
    let currentUrl = urlStr;

    for (let i = 0; i < maxRedirects; i++) {
        const u = new URL(currentUrl);
        const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

        const result = await new Promise<{ status: number; contentType: string; text: string; redirectUrl?: string }>((resolve, reject) => {
            const req = https.request(
                {
                    protocol: u.protocol,
                    hostname: u.hostname,
                    path: u.pathname + u.search,
                    method: "GET",
                    headers: {
                        ...headers,
                        "Host": u.hostname // Update host sesuai redirect target
                    },
                    agent: agent as any,
                    rejectUnauthorized: false,
                },
                (res) => {
                    // Tangkap Redirect HTTP (301, 302, 303, 307, 308)
                    if ([301, 302, 303, 307, 308].includes(res.statusCode || 0) && res.headers.location) {
                        let redirectLoc = res.headers.location;
                        if (redirectLoc.startsWith('/')) {
                            redirectLoc = `${u.protocol}//${u.hostname}${redirectLoc}`;
                        }
                        resolve({ status: res.statusCode || 0, contentType: "", text: "", redirectUrl: redirectLoc });
                        return;
                    }

                    const chunks: Buffer[] = [];
                    res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                    res.on("end", () => {
                        const buffer = Buffer.concat(chunks);
                        const encoding = res.headers["content-encoding"];
                        const text = decompressResponse(buffer, encoding);

                        resolve({
                            status: res.statusCode || 0,
                            contentType: res.headers["content-type"] || "application/json",
                            text: text,
                        });
                    });
                }
            );

            req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
            req.on("error", reject);
            req.end();
        });

        // Kalau ada instruksi redirect, lempar ulang looping ke URL baru
        if (result.redirectUrl) {
            currentUrl = result.redirectUrl;
            continue;
        }

        return result;
    }

    throw new Error("Too many redirects");
}

// ============================================================================
// EXPORT PROXY GET
// ============================================================================
export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    // Tambahin parameter opsional redirectCount buat mencegah infinite loop
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string>; redirectCount?: number } = { label: 'prime-get', redirectCount: 0 }
) {
    // 🛡️ BATESIN REDIRECT MAKSIMAL 3x BIAR GAK INFINITE LOOP!
    const currentRedirectCount = opts.redirectCount || 0;
    if (currentRedirectCount > 3) {
        console.error("🛑 Terlalu banyak JSON redirect! Menghentikan infinite loop.");
        if (opts.send === false) return { error: true, status: 508, message: "Loop Detected in Prime Video API" };
        return new Response(JSON.stringify({ error: true, message: "Loop Detected in Prime Video API" }), { status: 508, headers: { 'Content-Type': 'application/json' } });
    }
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    // 🚀 SMART ROUTING UNTUK PRIME VIDEO
    let upstreamUrl = path;
    let targetHost = "";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
        upstreamUrl = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
    } else {
        const base = (path.startsWith('/playback') || path.startsWith('/cdp')) ? PRIME_API_BASE : PRIME_WWW_BASE;
        const pathWithQuery = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
        upstreamUrl = `${base}${pathWithQuery}`;
        targetHost = new URL(base).hostname;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${upstreamUrl}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(
                typeof hit.val === 'string' ? hit.val : JSON.stringify(hit.val),
                { headers: { 'Content-Type': typeof hit.val === 'string' ? 'text/html' : 'application/json', 'x-cache': 'HIT' } }
            );
        }
    }

    const dynamicCookie = DEFAULT_PRIME_COOKIE;

    const headers = {
        ...buildPrimeHeaders(req, targetHost, dynamicCookie),
        ...opts.headers
    };

    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            if (status !== 200) {
                console.error(`[Prime ProxyGet Error] Upstream status is ${status}. Prime says: ${text.slice(0, 500)}`);
                return { error: true, status, message: "Upstream or Proxy failed" };
            }

            if (contentType.includes('text/html')) {
                if (cacheKey && opts.cacheTtlMs) cache.set(cacheKey, { val: text, exp: Date.now() + opts.cacheTtlMs });
                return text;
            }

            try {
                const parsedJSON = JSON.parse(text);

                // 🔥 TANGKAP JSON REDIRECT DENGAN SAFEGUARD
                if (parsedJSON && parsedJSON.redirect) {
                    console.log(`🔄 Menangkap JSON Redirect dari Amazon (${currentRedirectCount + 1}/3): ${parsedJSON.redirect}`);
                    const redirUrl = new URL(parsedJSON.redirect, PRIME_WWW_BASE);
                    const newQuery = Object.fromEntries(redirUrl.searchParams.entries());

                    // Terusin request dengan counter +1 biar aman dari infinite loop
                    return proxyGet(req, redirUrl.pathname, newQuery, { ...opts, redirectCount: currentRedirectCount + 1 });
                }

                if (cacheKey && opts.cacheTtlMs) cache.set(cacheKey, { val: parsedJSON, exp: Date.now() + opts.cacheTtlMs });
                return parsedJSON;
            } catch (parseError) {
                return text;
            }
        }

        return new Response(text, { status, headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        console.error(`[PrimeProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

// ============================================================================
// CORE HTTP POST (UPDATED)
// ============================================================================
async function Post(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

// ============================================================================
// EXPORT PROXY POST (UPDATED)
// ============================================================================
export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; send?: boolean; headers?: Record<string, string> } = { label: 'prime-post' }
) {
    // 🚀 SMART ROUTING UNTUK PRIME VIDEO
    let upstreamUrl = path;
    let targetHost = "";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        const base = (path.startsWith('/playback') || path.startsWith('/cdp')) ? PRIME_API_BASE : PRIME_WWW_BASE;
        upstreamUrl = `${base}${path}`;
        targetHost = new URL(base).hostname;
    }

    const dynamicCookie = DEFAULT_PRIME_COOKIE;

    // 🔥 FIX: Gabungkan header dengan aman, prioritaskan opts.headers
    const headers: Record<string, string> = {
        ...buildPrimeHeaders(req, targetHost, dynamicCookie)
    };

    if (opts.headers) {
        // Hapus Content-Type default kalau ada di opts, biar nggak dobel huruf besar/kecil
        if (opts.headers['Content-Type'] || opts.headers['content-type']) {
            delete headers['Content-Type'];
            delete headers['content-type'];
        }
        Object.assign(headers, opts.headers);
    }

    // Pastikan body di-stringify
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);

    // Tentukan final Content Type
    const reqContentType = headers["Content-Type"] || headers["content-type"] || "application/json";

    try {
        const { status, contentType, text } = await Post(upstreamUrl, headers, stringBody, reqContentType, 15_000);

        if (opts.send === false) {
            try { return { status, body: JSON.parse(text) }; } catch { return { status, body: text }; }
        }
        return new Response(text, { status, headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        console.error(`[PrimeProxyPost:${opts.label}] upstream failed`, { message: e?.message });
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}