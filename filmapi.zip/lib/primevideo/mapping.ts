import crypto from 'crypto';
import prisma from '@/prisma/prisma'; // ⚠️ SESUAIIN SAMA PATH FILE PRISMA LU YA BRE!

export class PrimeVideoMapper {
    /**
     * Helper untuk bikin slug (contoh: "Love Has Fireworks" -> "love-has-fireworks")
     */
    static slugify(text: string): string {
        if (!text) return "";
        return text.toString().toLowerCase()
            .replace(/\s+/g, '-')           // Ganti spasi dengan -
            .replace(/[^\w\-]+/g, '')       // Hapus karakter non-word
            .replace(/\-\-+/g, '-')         // Hapus multiple -
            .replace(/^-+/, '')             // Trim - dari awal
            .replace(/-+$/, '');            // Trim - dari akhir
    }

    /**
     * Mapper Utama untuk Detail & Episode List Prime Video
     */
    static async mapDetail(rawData: any, titleId: string) {
        // 1. Ekstrak Node State dari ATF (Above The Fold) & BTF (Below The Fold)
        const atfState = rawData?.body?.atf?.state || {};
        const btfState = rawData?.body?.btf?.state || {};

        // 2. Info Series/Movie biasanya ada di Header Detail (ATF)
        const headerDetails = atfState?.detail?.headerDetail || {};
        const fallbackDetails = atfState?.detail?.detail || {}; // Jaga-jaga kalau nyangkut di sini

        const seriesInternalId = Object.keys(headerDetails)[0] || Object.keys(fallbackDetails)[0] || titleId;
        const seriesData = headerDetails[seriesInternalId] || fallbackDetails[seriesInternalId] || {};

        // 3. Info Episode biasanya ada di BTF Detail
        const btfDetail = btfState?.detail?.detail || {};

        // Parsing Genres
        const genres = seriesData.genres?.map((g: any) => g.text) || [];

        // Kalkulasi Total Durasi
        let defaultRuntimeMinutes = 0;

        // 5. Mapping Episodes
        const episodes = [];
        for (const [epId, rawEpData] of Object.entries(btfDetail)) {
            const epData = rawEpData as any;

            // Kita cuma ambil tipe episode atau movie
            if (epData.titleType !== "episode" && epData.titleType !== "movie") continue;

            const rawEnvelope = this.extractEnvelope(rawData, epId);
            let shortEnvelopeId = null;

            // 🔥 LOGIKA SIMPAN KE DATABASE (PRISMA) 🔥
            if (rawEnvelope) {
                shortEnvelopeId = crypto.createHash('md5').update(rawEnvelope).digest('hex').substring(0, 10);

                const expirationDate = new Date();
                expirationDate.setHours(expirationDate.getHours() + 24);

                try {
                    await prisma.primeEnvelope.upsert({
                        where: { shortId: shortEnvelopeId },
                        update: {
                            envelope: rawEnvelope,
                            expiresAt: expirationDate
                        },
                        create: {
                            shortId: shortEnvelopeId,
                            envelope: rawEnvelope,
                            expiresAt: expirationDate
                        }
                    });
                } catch (dbError) {
                    console.error("Gagal nyimpen envelope ke Database:", dbError);
                }
            }

            const epNumber = epData.episodeNumber || 1;
            const epTitle = epData.title || `Episode ${epNumber}`;

            if (epNumber === 1 && epData.duration) {
                defaultRuntimeMinutes = Math.floor(epData.duration / 60);
            }

            episodes.push({
                slug: `${this.slugify(seriesData.title || "")}-episode-${epNumber}-${epId.split('-').pop()}`,
                id: epId,
                episodeNumber: epNumber,
                title: epTitle,
                airDate: epData.releaseDate || "",
                durationSeconds: epData.duration || 0,
                runtimeText: epData.runtime || "",
                synopsis: epData.synopsis || "",
                image: epData.images?.covershot || epData.images?.packshot || "",
                shortid: shortEnvelopeId
            });
        }

        // Urutkan episode dari 1 ke atas
        episodes.sort((a, b) => a.episodeNumber - b.episodeNumber);

        const seriesTitle = seriesData.title || "Unknown Title";
        const releaseYear = seriesData.releaseYear || "";

        // 6. Return struktur cantik
        return {
            id: titleId,
            internalId: seriesInternalId,
            title: seriesTitle,
            originalTitle: seriesData.parentTitle || seriesTitle,
            slug: `${this.slugify(seriesTitle)}-${releaseYear}`,
            overview: seriesData.synopsis || "",
            banner: seriesData.images?.heroshot || null,
            cover: {
                potrait: seriesData.images?.packshot || seriesData.images?.covershot || "",
                landscape: seriesData.images?.covershot || ""
            },
            releaseDate: seriesData.releaseDate || "",
            releaseYear: releaseYear,
            runtimeMinutes: defaultRuntimeMinutes,
            voteAverage: seriesData.amazonRating?.value || 0,
            genres: genres,
            hasVideo: episodes.length > 0,
            seasons: [
                {
                    id: `season-${seriesData.seasonNumber || 1}-${titleId}`,
                    tmdbId: 0,
                    seasonNumber: seriesData.seasonNumber || 1,
                    title: `Season ${seriesData.seasonNumber || 1}`,
                    episodes: episodes
                }
            ]
        };
    }

    /**
     * Fungsi Sakti buat nyari Playback Envelope
     */
    static extractEnvelope(rawData: any, epId: string): string | null {
        const atfActions = rawData?.body?.atf?.state?.action?.atf || {};
        const btfActions = rawData?.body?.btf?.state?.action?.btf || {};
        const allActions = { ...atfActions, ...btfActions };

        if (allActions[epId]) {
            const playAction = allActions[epId].primaryActions?.find((a: any) => a.actionType === "PLAY");
            if (playAction?.payload?.playback?.playbackEnvelope) {
                return playAction.payload.playback.playbackEnvelope;
            }
        }

        for (const key in allActions) {
            const primaryActions = allActions[key]?.primaryActions || [];
            for (const action of primaryActions) {
                if (action.actionType === "PLAY" && action.payload?.playback?.playbackID === epId) {
                    if (action.payload?.playback?.playbackEnvelope) {
                        return action.payload.playback.playbackEnvelope;
                    }
                }
            }
        }

        return null;
    }
}