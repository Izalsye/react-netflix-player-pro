import "dotenv/config";
import prisma from '../prisma/prisma';

export async function recordHit(req: Request, visitorId: string, endpoint: string, method: string) {

  // Potong paksa jadi 191 karakter (Standar maksimal VARCHAR di Prisma/MySQL)
  const safeVisitorId = visitorId.substring(0, 191);

  prisma.apiStat.create({
    data: {
      visitorId: safeVisitorId,
      endpoint: endpoint,
      method: method,
    }
  }).catch((error: any) => { // ✅ Fix 1: Ditambahin (error: any)
    console.error('Gagal mencatat hit ke Database:', error.message);
  });
}

export async function getStatsSummary() {
  try {
    const totalHits = await prisma.apiStat.count();

    // Menghitung visitor unik
    const uniqueVisitors = await prisma.apiStat.groupBy({
      by: ['visitorId'],
    });

    // Endpoint paling populer
    const topEndpoints = await prisma.apiStat.groupBy({
      by: ['endpoint'],
      _count: { endpoint: true },
      orderBy: { _count: { endpoint: 'desc' } },
      take: 1,
    });

    // Method paling sering
    const topMethods = await prisma.apiStat.groupBy({
      by: ['method'],
      _count: { method: true },
      orderBy: { _count: { method: 'desc' } },
      take: 1,
    });

    return {
      totalHits: totalHits,
      visitors: uniqueVisitors.length,
      topEndpoint: topEndpoints.length > 0 ? topEndpoints[0].endpoint : '-',
      topMethod: topMethods.length > 0 ? topMethods[0].method : '-'
    };
  } catch (error: any) { // ✅ Fix 2: Ditambahin (error: any)
    console.error('Gagal mengambil ringkasan stats:', error);
    return { totalHits: 0, visitors: 0, topEndpoint: '-', topMethod: '-' };
  }
}