// file: lib/bot.ts
import { Bot } from 'grammy';
import { BOT_TOKEN } from './bot/config';
import { CommandHandler } from './bot/handlers/CommandHandler';
import { CallbackHandler } from './bot/handlers/CallbackHandler';
import { EventHandler } from './bot/handlers/EventHandler';
import { MessageHandler } from './bot/handlers/MessageHandler'; // 👈 IMPORT INI
// Pastikan Token Ada
if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN is missing in .env");

// Inisialisasi Bot
export const bot = new Bot(BOT_TOKEN);

// ==========================================
// REGISTRASI SEMUA HANDLER
// ==========================================
CommandHandler.register(bot);
CallbackHandler.register(bot);
EventHandler.register(bot);
MessageHandler.register(bot); // 👈 DAFTARIN INI JUGA

console.log("✅ Bot Handlers berhasil diregistrasi!");