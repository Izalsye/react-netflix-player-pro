// file: lib/bot.ts
import { Bot, InlineKeyboard } from 'grammy';
import prisma from '../prisma/prisma';
import crypto from 'crypto';

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) throw new Error("TELEGRAM_BOT_TOKEN is missing in .env");

export const bot = new Bot(token);

// ==========================================
// 0. KONFIGURASI GAMBAR & URL BASE
// ==========================================
const BANNER_URL = "https://i.imgur.com/a9RG0KS.jpeg";
const BASE_API_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://indocast.site';

const MIDTRANS_API_URL = process.env.NODE_ENV === 'production'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';

// ==========================================
// 1. HELPER FUNCTIONS
// ==========================================
function generateApiKey() {
    const randomString = crypto.randomBytes(24).toString('hex');
    return `indocast_${randomString}`;
}

function hashKey(apiKey: string) {
    return crypto.createHash('sha256').update(apiKey).digest('hex');
}

function getFormattedDate() {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    const d = new Date();
    const dayName = days[d.getDay()];
    const day = String(d.getDate()).padStart(2, '0');
    const monthName = months[d.getMonth()];
    const year = d.getFullYear();
    const time = d.toLocaleTimeString('id-ID', { hour12: false });

    return `${dayName}, ${day} ${monthName} ${year} | ${time} WIB`;
}

// Format Tanggal Masa Aktif VIP
function formatExpiredDate(date: Date | null) {
    if (!date) return 'Selamanya (Free)';
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'];
    const d = new Date(date);
    return `${String(d.getDate()).padStart(2, '0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

// Ngitung sisa hari VIP dari sekarang sampai expired
function getRemainingDays(date: Date | null) {
    if (!date) return 0;
    const now = new Date();
    const diffMs = date.getTime() - now.getTime();
    return diffMs > 0 ? Math.ceil(diffMs / (1000 * 60 * 60 * 24)) : 0;
}

// Helper anti-crash nama user di HTML
function safeHtml(text: string | null | undefined) {
    if (!text) return '';
    return text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&/g, '&amp;');
}

async function getOrCreateTgUser(tgUser: any) {
    const tgIdStr = String(tgUser.id);
    let user = await prisma.user.findUnique({ where: { telegramId: tgIdStr } });

    if (!user) {
        user = await prisma.user.create({
            data: {
                telegramId: tgIdStr,
                firstName: tgUser.first_name,
                lastName: tgUser.last_name || null,
                username: tgUser.username || null,
                isBot: tgUser.is_bot || false,
                role: "FREE",
                status: "ACTIVE"
            }
        });
    } else {
        user = await prisma.user.update({
            where: { telegramId: tgIdStr },
            data: {
                firstName: tgUser.first_name,
                lastName: tgUser.last_name || null,
                username: tgUser.username || null,
                lastActiveAt: new Date()
            }
        });
    }
    return user;
}

// ==========================================
// 2. TEKS TEMPLATE (MODERN HTML UI)
// ==========================================
const TEXT = {
    dashboard: (user: any, isVip: boolean, hasApiKey: boolean, subEndsAt: Date | null) =>
        `👋 Halo, <b>${safeHtml(user.firstName)}</b>!\n` +
        `📅 <i>${getFormattedDate()}</i>\n\n` +
        `👤 <b>INFORMASI AKUN</b>\n` +
        `├ <b>ID Tele</b>: <code>${user.telegramId}</code>\n` +
        `├ <b>Username</b>: ${user.username ? '@' + safeHtml(user.username) : '-'}\n` +
        `├ <b>Status</b>: ${isVip ? '👑 <b>VIP PREMIUM</b>' : '🌱 <b>FREE USER</b>'}\n` +
        `└ <b>Masa Aktif</b>: <code>${isVip ? formatExpiredDate(subEndsAt) : 'Selamanya'}</code> ${isVip ? `<i>(Sisa ${getRemainingDays(subEndsAt)} Hari)</i>` : ''}\n\n` +
        `🌐 <b>STATISTIK API</b>\n` +
        `├ <b>Status Key</b>: ${hasApiKey ? '✅ <b>Aktif</b>' : '❌ <b>Belum Dibuat</b>'}\n` +
        `└ <b>Base URL</b>: <code>${BASE_API_URL}</code>\n\n` +
        `💡 <b>Pintas Cepat:</b>\n` +
        `/start - Muat Ulang Menu Utama\n` +
        `/bantuan - Syarat & Ketentuan Layanan`,

    apiInfo: (rawKey: string, isVip: boolean, limitPerDay: number, usageToday: number) => {
        const strUsage = usageToday.toLocaleString('id-ID');
        const strLimit = limitPerDay >= 1000000 ? '∞ (Unlimited)' : limitPerDay.toLocaleString('id-ID');
        const limitDisplay = `<b>${strUsage}</b> / ${strLimit}`;

        return `🔑 <b>MANAJEMEN API KEY</b>\n\n` +
            `<b>Status Akses:</b> 🟢 AKTIF (Lifetime)\n` +
            `<b>Pemakaian Hari Ini:</b> ${limitDisplay} Request\n` +
            `<b>Base URL API:</b> <code>${BASE_API_URL}</code>\n\n` +
            `<b>🔗 API Key Kamu:</b>\n<code>${rawKey}</code>\n\n` +
            `<i>(ℹ️ Ketuk API Key di atas untuk menyalin otomatis. Jika API Key kamu bocor ke publik, segera klik tombol Reset di bawah!)</i>`;
    },

    tos:
        `📜 <b>INFORMASI & KEBIJAKAN LAYANAN</b>\n\n` +
        `<b>Indocast API</b> menyediakan akses bypass DRM streaming dengan stabilitas dan performa tinggi.\n\n` +
        `⚠️ <b>Larangan Keras:</b>\n` +
        `🚫 Melakukan Spam atau serangan DDoS.\n` +
        `🚫 Memperjualbelikan API Key pribadi.\n` +
        `🚫 Menggunakan script bot auto-hit secara brutal.\n\n` +
        `<i>Pelanggaran terhadap aturan di atas akan mengakibatkan <b>Banned Permanen</b> secara sepihak tanpa *refund*.</i>`
};

// ==========================================
// 3. KEYBOARD MENUS (CLEAN & MODERN)
// ==========================================
const mainMenu = new InlineKeyboard()
    .text("🔑 Kelola API", "menu_api").text("👑 Beli VIP", "menu_buy_vip").row()
    .text("🧾 Riwayat", "menu_history").text("ℹ️ Bantuan", "menu_tos").row()
    .url("💬 Grup Diskusi", "https://t.me/wenetviqi");

const backMenu = new InlineKeyboard().text("🔙 Kembali ke Beranda", "menu_main");

const apiMenu = (hasKey: boolean) => {
    const kb = new InlineKeyboard();
    if (!hasKey) {
        kb.text("⚡ Buat API Key", "action_gen_api").row();
    } else {
        kb.text("🔄 Ganti / Reset API Key", "action_regen_api").row();
    }
    return kb.text("🔙 Kembali ke Beranda", "menu_main");
};

// ==========================================
// 4. COMMAND HANDLER
// ==========================================
bot.command(['start', 'bantuan'], async (ctx) => {
    const tgUser = ctx.from;
    if (!tgUser) return;

    try {
        if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
            const pmKb = new InlineKeyboard().url("🤖 Chat Bot Secara Pribadi", `https://t.me/${ctx.me.username}?start=true`);
            return ctx.reply(`👋 Halo <b>${safeHtml(tgUser.first_name)}</b>!\n\nUntuk mengelola API Key dan VIP, silakan *Japri* (Chat Pribadi) ke bot melalui tombol di bawah ini ya!`, {
                parse_mode: "HTML",
                reply_markup: pmKb,
                reply_parameters: { message_id: ctx.message!.message_id }
            });
        }

        if (ctx.message?.text === '/bantuan') {
            await ctx.reply(TEXT.tos, { parse_mode: "HTML", reply_markup: backMenu });
            return;
        }

        const user = await getOrCreateTgUser(tgUser);
        const fullUser = await prisma.user.findUnique({
            where: { id: user.id },
            include: { apiKey: true }
        });

        const isVip = fullUser?.role === 'VIP';
        const hasApiKey = !!fullUser?.apiKey;
        const subEndsAt = fullUser?.subEndsAt || null;

        await ctx.replyWithPhoto(BANNER_URL, {
            caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
            parse_mode: "HTML",
            reply_markup: mainMenu
        });

    } catch (error) {
        console.error("Gagal load dashboard:", error);
        await ctx.reply("⏳ Sistem sedang sibuk bre, coba lagi dalam beberapa detik.");
    }
});

// ==========================================
// 5. CALLBACK QUERY HANDLER
// ==========================================
bot.on("callback_query:data", async (ctx) => {
    const data = ctx.callbackQuery.data;
    const tgUser = ctx.from;

    await ctx.answerCallbackQuery();

    if (ctx.chat?.type !== 'private') return;

    try {
        const user = await getOrCreateTgUser(tgUser);
        const fullUserData = await prisma.user.findUnique({
            where: { id: user.id },
            include: { apiKey: true, plan: true }
        });

        const isVip = fullUserData?.role === 'VIP';
        const hasApiKey = !!fullUserData?.apiKey;
        const subEndsAt = fullUserData?.subEndsAt || null;

        // --- KEMBALI KE DASHBOARD ---
        if (data === "menu_main") {
            await ctx.editMessageCaption({
                caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
                parse_mode: "HTML",
                reply_markup: mainMenu
            }).catch(async () => {
                await ctx.deleteMessage();
                await ctx.replyWithPhoto(BANNER_URL, {
                    caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
                    parse_mode: "HTML",
                    reply_markup: mainMenu
                });
            });
        }

        // --- BANTUAN ---
        else if (data === "menu_tos") {
            await ctx.editMessageCaption({ caption: TEXT.tos, parse_mode: "HTML", reply_markup: backMenu }).catch(async () => {
                await ctx.editMessageText(TEXT.tos, { parse_mode: "HTML", reply_markup: backMenu });
            });
        }

        // --- KELOLA API & AMBIL DATA USAGE HARIAN ---
        else if (data === "menu_api") {
            if (!fullUserData?.apiKey) {
                const msg = `⚠️ <b>BELUM ADA API KEY</b>\n\nKamu belum memiliki API Key untuk mengakses <code>${BASE_API_URL}</code>.\n\nKlik tombol di bawah untuk membuat Key secara gratis.`;
                await ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: apiMenu(false) }).catch(async () => {
                    await ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: apiMenu(false) });
                });
            } else {
                const rawKeyText = fullUserData.apiKey.rawKey || "Key tidak ditemukan";

                // Ambil limit dari relasi Plan user (kalau free default 100 atau sesuai DB)
                const limitPerDay = fullUserData.plan?.limitPerDay ?? 100;

                // Query ke tabel DailyUsage untuk tanggal hari ini (jam 00:00)
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                const usageRecord = await prisma.dailyUsage.findUnique({
                    where: {
                        userId_date: {
                            userId: user.id,
                            date: today
                        }
                    }
                });

                const usageToday = usageRecord?.count || 0;

                const msg = TEXT.apiInfo(rawKeyText, isVip, limitPerDay, usageToday);
                await ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: apiMenu(true) }).catch(async () => {
                    await ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: apiMenu(true) });
                });
            }
        }

        // --- GEN / REGEN API ---
        else if (data === "action_gen_api" || data === "action_regen_api") {
            const rawKey = generateApiKey();
            const hashedKey = hashKey(rawKey);

            if (data === "action_gen_api") {
                await prisma.apiKey.create({
                    data: { userId: user.id, hashedKey, rawKey, label: "Default Key" }
                });
            } else {
                await prisma.apiKey.update({
                    where: { userId: user.id },
                    data: { hashedKey, rawKey }
                });
            }

            const prefixMsg = data === "action_gen_api" ? "✅ <b>API KEY BERHASIL DIBUAT</b>" : "🔄 <b>API KEY BERHASIL DIRESET</b>";
            const txt = `${prefixMsg}\n\n<code>${rawKey}</code>\n\n<i>⚠️ Segera salin dan simpan di tempat yang aman.</i>`;

            await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: backMenu }).catch(async () => {
                await ctx.editMessageText(txt, {
                    parse_mode: "HTML",
                    reply_markup: backMenu
                });
            });
        }

        // --- RIWAYAT TRANSAKSI ---
        else if (data === "menu_history") {
            const trxs = await prisma.transaction.findMany({
                where: { userId: user.id },
                orderBy: { createdAt: 'desc' },
                take: 5,
                include: { plan: true }
            });

            let txt = `🧾 <b>5 RIWAYAT TRANSAKSI TERAKHIR</b>\n\n`;

            if (trxs.length === 0) {
                txt += `<i>Belum ada catatan transaksi.</i>`;
            } else {
                trxs.forEach((t, i) => {
                    const date = t.createdAt.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                    const icon = t.status === 'SETTLEMENT' || t.status === 'SUCCESS' ? '✅' : t.status === 'PENDING' ? '⏳' : '❌';
                    txt += `${i + 1}. ${icon} <b>${t.plan.name}</b> (Rp${t.amount.toLocaleString('id-ID')})\n   └ <i>${date} - ${t.status}</i>\n\n`;
                });
            }

            await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: backMenu }).catch(async () => {
                await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: backMenu });
            });
        }

        // --- BELI VIP ---
        else if (data === "menu_buy_vip") {
            const plans = await prisma.plan.findMany({ where: { isActive: true }, orderBy: { price: 'asc' } });

            if (plans.length === 0) {
                const msg = "⚠️ <i>Mohon maaf, belum ada paket VIP yang tersedia saat ini.</i>";
                return ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: backMenu }).catch(() => ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: backMenu }));
            }

            const kb = new InlineKeyboard();
            plans.forEach(p => {
                kb.text(`👑 ${p.name} - Rp ${p.price.toLocaleString('id-ID')}`, `plan_${p.id}`).row();
            });
            kb.text("🔙 Kembali", "menu_main");

            const txt = "🛒 <b>PEMBELIAN PAKET VIP</b>\n\nUpgrade akunmu sekarang untuk menikmati limit <i>unlimited</i> dan akses penuh ke seluruh fitur Indocast API.\n\n👇 <b>Pilih paket yang tersedia:</b>";

            await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: kb }).catch(async () => {
                await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: kb });
            });
        }

        // --- PILIH METODE BAYAR ---
        else if (data.startsWith("plan_")) {
            const planId = data.replace("plan_", "");
            const plan = await prisma.plan.findUnique({ where: { id: planId } });
            if (!plan) return;

            const kb = new InlineKeyboard()
                .text("⚡ Bayar via QRIS (Otomatis)", `pay_qris_${plan.id}`).row()
                .text("🏦 Transfer Manual (Admin)", `pay_admin_${plan.id}`).row()
                .text("🔙 Batal", "menu_buy_vip");

            const txt = `📋 <b>DETAIL PESANAN</b>\n\n` +
                `📦 <b>Paket:</b> ${plan.name}\n` +
                `💰 <b>Harga:</b> Rp ${plan.price.toLocaleString('id-ID')}\n` +
                `⏳ <b>Tambahan Masa Aktif:</b> ${plan.durationDays} Hari\n\n` +
                `Pilih metode pembayaran yang kamu inginkan:`;

            await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: kb }).catch(async () => {
                await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: kb });
            });
        }

        // --- BAYAR ADMIN ---
        else if (data.startsWith("pay_admin_")) {
            const txt = `🏦 <b>METODE TRANSFER MANUAL</b>\n\n` +
                `Kirim pembayaran sesuai nominal ke salah satu rekening berikut:\n` +
                `🔹 <b>DANA / GOPAY:</b> <code>08123456789</code>\n` +
                `🔹 <b>BCA:</b> <code>123456789</code> (a/n Faisol)\n\n` +
                `📸 <i>PENTING: Jika sudah berhasil transfer, harap kirimkan bukti resi/screenshot ke admin <b>@wenetviqi</b> agar status VIP kamu segera diaktifkan.</i>`;

            await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: backMenu }).catch(async () => {
                await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: backMenu });
            });
        }

        // --- BAYAR QRIS OTOMATIS ---
        else if (data.startsWith("pay_qris_")) {
            const planId = data.replace("pay_qris_", "");
            const plan = await prisma.plan.findUnique({ where: { id: planId } });
            if (!plan) return;

            await ctx.editMessageCaption({ caption: "⏳ <i>Sedang membuat kode QRIS, mohon tunggu sebentar...</i>", parse_mode: "HTML" }).catch(() => { });

            const transaction = await prisma.transaction.create({
                data: {
                    userId: user.id,
                    planId: plan.id,
                    amount: plan.price,
                    status: 'PENDING',
                    paymentMethod: 'QRIS',
                }
            });

            const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
            const authString = Buffer.from(`${serverKey}:`).toString('base64');

            const response = await fetch(MIDTRANS_API_URL, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Basic ${authString}`
                },
                body: JSON.stringify({
                    payment_type: 'qris',
                    transaction_details: { order_id: transaction.id, gross_amount: plan.price },
                    customer_details: { first_name: user.firstName, last_name: user.lastName || '' }
                })
            });

            const midtransData = await response.json();
            const qrisUrl = midtransData.actions?.find((a: any) => a.name === 'generate-qr-code')?.url;

            if (!qrisUrl) {
                const errMsg = "❌ <b>Sistem Gagal!</b>\n\nTidak dapat menggenerate QRIS dari Midtrans saat ini. Silakan kembali dan gunakan metode <b>Transfer Manual (Admin)</b>.";
                return ctx.editMessageCaption({ caption: errMsg, parse_mode: "HTML", reply_markup: backMenu }).catch(() => ctx.editMessageText(errMsg, { parse_mode: "HTML", reply_markup: backMenu }));
            }

            await ctx.deleteMessage();

            const checkKb = new InlineKeyboard()
                .url("🔗 Buka Link QRIS", qrisUrl).row()
                .text("🔄 Cek Status Pembayaran", `check_pay_${transaction.id}`).row()
                .text("🔙 Kembali ke Beranda", "menu_main");

            const sentMsg = await ctx.replyWithPhoto(qrisUrl, {
                caption: `⚡ <b>INVOICE #${transaction.id.slice(-5).toUpperCase()}</b>\n\n` +
                    `📦 <b>Paket:</b> ${plan.name}\n` +
                    `💰 <b>Total Bayar:</b> Rp ${plan.price.toLocaleString('id-ID')}\n\n` +
                    `<i>Langkah Pembayaran:</i>\n` +
                    `1. Screenshot/Simpan gambar QRIS di atas, atau klik "Buka Link QRIS".\n` +
                    `2. Buka aplikasi m-Banking atau E-Wallet.\n` +
                    `3. Scan/Upload gambar QRIS dan lakukan pembayaran.\n\n` +
                    `✅ <b>Pembayaran akan terkonfirmasi OTOMATIS jika berhasil.</b>`,
                parse_mode: "HTML",
                reply_markup: checkKb
            });

            await prisma.transaction.update({
                where: { id: transaction.id },
                data: { qrisUrl: qrisUrl, telegramMsgId: sentMsg.message_id }
            });
        }

        // --- CEK STATUS PEMBAYARAN (MANUAL FALLBACK) ---
        else if (data.startsWith("check_pay_")) {
            const orderId = data.replace("check_pay_", "");
            const transaction = await prisma.transaction.findUnique({
                where: { id: orderId },
                include: { plan: true }
            });

            if (!transaction) return;

            if (transaction.status === 'SETTLEMENT' || transaction.status === 'SUCCESS') {
                await ctx.deleteMessage();
                await ctx.replyWithPhoto(BANNER_URL, {
                    caption: `🎉 <b>PEMBAYARAN BERHASIL!</b> 🎉\n\n` +
                        `Terima kasih! Akun kamu kini telah resmi menjadi <b>VIP PREMIUM</b> selama <b>${transaction.plan.durationDays} hari</b> ke depan.\n\n` +
                        `Silakan buka menu <b>🔑 Kelola API</b> untuk melihat perubahan limit harian kamu.`,
                    parse_mode: "HTML",
                    reply_markup: mainMenu
                });
            } else if (transaction.status === 'EXPIRE' || transaction.status === 'CANCEL') {
                await ctx.answerCallbackQuery({ text: "❌ Pembayaran kedaluwarsa atau dibatalkan oleh sistem.", show_alert: true });
            } else {
                await ctx.answerCallbackQuery({ text: "⚠️ Pembayaran belum terdeteksi. Jika sudah transfer, tunggu sekitar 1-2 menit lalu coba klik tombol ini lagi.", show_alert: true });
            }
        }

    } catch (error) {
        console.error("Error Callback Query:", error);
        // ✅ GANTI JADI "show_alert"
        await ctx.answerCallbackQuery({ text: "❌ Pembayaran kedaluwarsa...", show_alert: true });
    }
});

// ==========================================
// 6. EVENT HANDLER: NEW MEMBER DI GRUP
// ==========================================
bot.on("message:new_chat_members", async (ctx) => {
    const newMembers = ctx.message.new_chat_members;
    for (const member of newMembers) {
        if (member.is_bot) continue;

        const botUsername = ctx.me.username;
        const kb = new InlineKeyboard().url("🤖 Chat Bot Disini", `https://t.me/${botUsername}?start=true`);

        try {
            await ctx.replyWithPhoto(BANNER_URL, {
                caption: `👋 Halo <b>${safeHtml(member.first_name)}</b>!\n\nSelamat datang di Komunitas Indocast API.\nDapatkan akses VIP dan API Key gratismu sekarang melalui Bot Resmi kami di bawah ini:`,
                parse_mode: "HTML",
                reply_markup: kb
            });
        } catch (e) {
            console.error("Gagal kirim ucapan selamat datang:", e);
        }
    }
});

// LIST EFFECT ID
// 🔥 Api Berkobar (Fire): 5104841245755180586 (Ini yang lagi lu pake sekarang)

// 🎉 Pesta / Kembang Api (Party Popper): 5046509860389126442 (Cocok juga nih buat ucapan "Pembayaran Berhasil")

// ❤️ Hati / Cinta (Heart): 5044134455711629726

// 👍 Jempol Ke Atas (Thumbs Up): 5107584321108051014

// 👎 Jempol Ke Bawah (Thumbs Down): 5104858069142078462

// 💩 Kotoran (Poop): 5046589136895476101 (Jangan pake ini buat yang abis bayar ya bre, ngamuk ntar usernya kwkwk)