// file: lib/bot.ts
import { Bot, InlineKeyboard } from 'grammy';
import prisma from '../prisma/prisma';
import crypto from 'crypto';

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) throw new Error("TELEGRAM_BOT_TOKEN is missing in .env");

export const bot = new Bot(token);

// ==========================================
// 1. HELPER FUNCTIONS & MIDTRANS CONFIG
// ==========================================

// 🎯 FIX: Format API Key disamakan dengan Web (indocast_ + 48 chars hex)
function generateApiKey() {
    const randomString = crypto.randomBytes(24).toString('hex');
    return `indocast_${randomString}`;
}

function hashKey(apiKey: string) {
    return crypto.createHash('sha256').update(apiKey).digest('hex');
}

const MIDTRANS_API_URL = process.env.NODE_ENV === 'production'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';

// 🎯 FUNGSI SINKRONISASI USER BARU & LAMA
async function getOrCreateTgUser(tgUser: any) {
    const tgIdStr = String(tgUser.id);

    let user = await prisma.user.findUnique({ where: { telegramId: tgIdStr } });

    if (!user) {
        const legacyUser = await prisma.user.findUnique({ where: { id: tgIdStr } });

        if (legacyUser) {
            user = await prisma.user.update({
                where: { id: tgIdStr },
                data: {
                    telegramId: tgIdStr,
                    firstName: tgUser.first_name,
                    lastName: tgUser.last_name || null,
                    username: tgUser.username || null,
                    lastActiveAt: new Date()
                }
            });
        } else {
            // USER BARU LANGSUNG TERDAFTAR SEBAGAI FREE
            user = await prisma.user.create({
                data: {
                    telegramId: tgIdStr,
                    firstName: tgUser.first_name,
                    lastName: tgUser.last_name || null,
                    username: tgUser.username || null,
                    isBot: tgUser.is_bot || false,
                    role: "FREE",
                    status: "ACTIVE"
                }
            });
        }
    } else {
        user = await prisma.user.update({
            where: { telegramId: tgIdStr },
            data: {
                firstName: tgUser.first_name,
                lastName: tgUser.last_name || null,
                username: tgUser.username || null,
                lastActiveAt: new Date()
            }
        });
    }

    return user;
}

// ==========================================
// 2. TEKS TEMPLATE
// ==========================================
const TEXT = {
    intro: (name: string) =>
        `🎬 *SELAMAT DATANG DI INDOCAST API STREAM* 🎬\n\n` +
        `Halo *${name}*! Pusat REST API terbaik untuk *Streaming Film, Drama, Movie, Series, dan TV* dengan bypass DRM.\n\n` +
        `Silakan pilih menu di bawah ini:`,
    buySc:
        `🛒 *BELI SOURCE CODE INDOCAST API*\n\n` +
        `Tertarik memiliki API Stream ini di servermu sendiri? Hubungi Admin di grup untuk negosiasi harga!`,
    tos:
        `📜 *KEBIJAKAN LAYANAN & KUOTA*\n\n` +
        `1. *Kuota:* User FREE memiliki limit harian terbatas. Upgrade VIP untuk limit hingga 1 Juta Request/hari.\n` +
        `2. *Banned:* Sistem otomatis memblokir IP/Akun yang terdeteksi melakukan DDoS.\n`
};

// ==========================================
// 3. KEYBOARD MENUS
// ==========================================
const mainMenu = new InlineKeyboard()
    .text("🔑 Info Akun & API", "menu_info_api")
    .text("⚡ Generate API Key", "menu_gen_api").row()
    .text("💎 Beli / Perpanjang VIP", "menu_buy_vip").row()
    .text("🛒 Beli Source Code", "menu_buy_sc")
    .text("📜 Informasi", "menu_tos").row()
    .url("💬 Group Diskusi", "https://t.me/wenetviqi");

const backMenu = new InlineKeyboard().text("🔙 Kembali ke Menu", "menu_main");

// ==========================================
// 4. COMMAND HANDLER (/start)
// ==========================================
bot.command('start', async (ctx) => {
    const tgUser = ctx.from;
    if (!tgUser) return;

    try {
        await getOrCreateTgUser(tgUser); // Langsung daftar otomatis
        await ctx.reply(TEXT.intro(tgUser.first_name), { parse_mode: "Markdown", reply_markup: mainMenu });
    } catch (error) {
        console.error("Gagal simpan user:", error);
        await ctx.reply("Sistem sedang sibuk bre, coba lagi nanti.");
    }
});

// ==========================================
// 5. CALLBACK QUERY HANDLER (Logic Dinamis)
// ==========================================
bot.on("callback_query:data", async (ctx) => {
    const data = ctx.callbackQuery.data;
    const tgUser = ctx.from;

    await ctx.answerCallbackQuery();

    try {
        // --- MENU STATIK ---
        if (data === "menu_main") {
            await ctx.editMessageText(TEXT.intro(tgUser.first_name), { parse_mode: "Markdown", reply_markup: mainMenu });
        }
        else if (data === "menu_buy_sc") {
            await ctx.editMessageText(TEXT.buySc, { parse_mode: "Markdown", reply_markup: backMenu });
        }
        else if (data === "menu_tos") {
            await ctx.editMessageText(TEXT.tos, { parse_mode: "Markdown", reply_markup: backMenu });
        }

        // --- INFO AKUN & API ---
        else if (data === "menu_info_api") {
            const user = await getOrCreateTgUser(tgUser);
            const fullUserData = await prisma.user.findUnique({
                where: { id: user.id },
                include: { apiKey: true, plan: true }
            });

            if (!fullUserData || !fullUserData.apiKey) {
                return ctx.editMessageText(`❌ Kamu belum memiliki API Key. Klik *Generate API Key* di menu utama.`, { parse_mode: "Markdown", reply_markup: backMenu });
            }

            const k = fullUserData.apiKey;
            const isVip = fullUserData.role === 'VIP';
            const planName = fullUserData.plan?.name || "Paket Gratis";
            const vipStatus = isVip && fullUserData.subEndsAt && fullUserData.subEndsAt.getTime() > Date.now()
                ? `Berlaku s/d ${fullUserData.subEndsAt.toLocaleDateString('id-ID')}`
                : "Belum berlangganan";

            // Tombol "Perpanjang Key" dihapus karena Key sekarang Lifetime
            const infoApiMenu = new InlineKeyboard()
                .text("🔄 Generate Ulang Key", "action_regen_api").row()
                .text("💎 Beli Paket VIP", "menu_buy_vip").row()
                .text("🔙 Kembali ke Menu", "menu_main");

            const infoText =
                `👤 *INFORMASI AKUN*\n` +
                `*Role:* ${isVip ? '🌟 VIP Member' : '🆓 User Free'}\n` +
                `*Paket:* ${planName}\n` +
                `*Status VIP:* ${vipStatus}\n\n` +
                `🔑 *INFORMASI API KEY*\n` +
                `*Status Key:* 🟢 AKTIF (Lifetime)\n` +
                `*API Key Kamu:*\n\`${k.rawKey}\`\n\n` +
                `_(Tap API Key di atas untuk menyalin)_`;

            await ctx.editMessageText(infoText, { parse_mode: "Markdown", reply_markup: infoApiMenu });
        }

        // --- GENERATE & REGENERATE API KEY (SINKRON WEB) ---
        else if (data === "menu_gen_api" || data === "action_regen_api") {
            const user = await getOrCreateTgUser(tgUser);
            const rawKey = generateApiKey();
            const hashedKey = hashKey(rawKey);

            if (data === "menu_gen_api") {
                const existingKey = await prisma.apiKey.findUnique({ where: { userId: user.id } });
                if (existingKey) {
                    return ctx.editMessageText(`⚠️ Kamu *SUDAH MEMILIKI* API Key! Cek di menu Info Akun.`, { parse_mode: "Markdown", reply_markup: backMenu });
                }

                // 🎯 Sesuai web: label 'Default Key' dan tidak ada expiresAt
                await prisma.apiKey.create({
                    data: {
                        userId: user.id,
                        hashedKey,
                        rawKey,
                        label: "Default Key"
                    }
                });
            } else {
                // 🎯 Regenerate: Update key lama jadi baru, tanpa mengubah masa aktif (karena lifetime)
                await prisma.apiKey.update({
                    where: { userId: user.id },
                    data: { hashedKey, rawKey }
                });
            }

            const prefixMsg = data === "menu_gen_api" ? "✅ *API KEY BERHASIL DIGENERATE*" : "🔄 *API KEY BERHASIL DIRESET*";
            await ctx.editMessageText(`${prefixMsg}\n\n\`${rawKey}\`\n\n_Segera simpan key ini di tempat yang aman!_`, { parse_mode: "Markdown", reply_markup: backMenu });
        }

        // ==========================================
        // 💎 FLOW PEMBELIAN VIP LANGSUNG DI BOT 💎
        // ==========================================

        // 1. TAMPILKAN DAFTAR PLAN
        else if (data === "menu_buy_vip") {
            const plans = await prisma.plan.findMany({ where: { isActive: true }, orderBy: { price: 'asc' } });

            if (plans.length === 0) {
                return ctx.editMessageText("Mhn maaf bre, belum ada paket VIP yang tersedia saat ini.", { reply_markup: backMenu });
            }

            const kb = new InlineKeyboard();
            plans.forEach(p => {
                kb.text(`💎 ${p.name} - Rp ${p.price.toLocaleString('id-ID')}`, `plan_${p.id}`).row();
            });
            kb.text("🔙 Kembali", "menu_main");

            await ctx.editMessageText("🛒 *PILIH PAKET VIP*\n\nSilakan pilih paket VIP yang sesuai dengan kebutuhanmu:", { parse_mode: "Markdown", reply_markup: kb });
        }

        // 2. PILIH METODE PEMBAYARAN (QRIS / ADMIN)
        else if (data.startsWith("plan_")) {
            const planId = data.replace("plan_", "");
            const plan = await prisma.plan.findUnique({ where: { id: planId } });
            if (!plan) return;

            const kb = new InlineKeyboard()
                .text("⚡ Bayar via QRIS (Otomatis)", `pay_qris_${plan.id}`).row()
                .text("🏦 Transfer Admin (Manual)", `pay_admin_${plan.id}`).row()
                .text("🔙 Batal", "menu_buy_vip");

            await ctx.editMessageText(`Konfirmasi Pilihan:\n\n📦 *Paket:* ${plan.name}\n💰 *Harga:* Rp ${plan.price.toLocaleString('id-ID')}\n⏳ *Durasi:* ${plan.durationDays} Hari\n\nSilakan pilih metode pembayaran:`, { parse_mode: "Markdown", reply_markup: kb });
        }

        // 3a. PEMBAYARAN MANUAL
        else if (data.startsWith("pay_admin_")) {
            await ctx.editMessageText("🏦 *PEMBAYARAN MANUAL*\n\nSilakan transfer ke rekening berikut:\n- DANA/GOPAY: `08123456789`\n- BCA: `123456789` a/n Faisol\n\nJika sudah transfer, *Screenshot bukti pembayaran* dan kirim ke admin @wenetviqi agar VIP mu diaktifkan.", { parse_mode: "Markdown", reply_markup: backMenu });
        }

        // 3b. PEMBAYARAN OTOMATIS (QRIS MIDTRANS)
        else if (data.startsWith("pay_qris_")) {
            const planId = data.replace("pay_qris_", "");
            const user = await getOrCreateTgUser(tgUser);
            const plan = await prisma.plan.findUnique({ where: { id: planId } });

            if (!plan) return;

            // Bikin teks loading biar bot kelihatan interaktif
            await ctx.editMessageText("⏳ _Sedang membuat QRIS pembayaran, mohon tunggu sebentar..._", { parse_mode: "Markdown" });

            // Bikin Transaksi di DB (Sama persis kayak logic web)
            const transaction = await prisma.transaction.create({
                data: {
                    userId: user.id,
                    planId: plan.id,
                    amount: plan.price,
                    status: 'PENDING',
                    paymentMethod: 'QRIS',
                }
            });

            // Tembak Midtrans langsung dari Bot
            const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
            const authString = Buffer.from(`${serverKey}:`).toString('base64');
            const midtransPayload = {
                payment_type: 'qris',
                transaction_details: {
                    order_id: transaction.id,
                    gross_amount: plan.price,
                },
                customer_details: {
                    first_name: user.firstName,
                    last_name: user.lastName || '',
                }
            };

            const response = await fetch(MIDTRANS_API_URL, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': `Basic ${authString}`
                },
                body: JSON.stringify(midtransPayload)
            });

            const midtransData = await response.json();
            const qrisUrl = midtransData.actions?.find((a: any) => a.name === 'generate-qr-code')?.url;

            if (!qrisUrl) {
                return ctx.editMessageText("❌ Waduh, gagal bikin QRIS dari Midtrans bre. Hubungi admin ya.", { reply_markup: backMenu });
            }

            // Update DB dengan url QRIS
            await prisma.transaction.update({
                where: { id: transaction.id },
                data: { qrisUrl: qrisUrl }
            });

            // Hapus pesan loading, lalu kirim FOTO QRIS
            await ctx.deleteMessage();

            const checkKb = new InlineKeyboard()
                .text("🔄 Cek Status Pembayaran", `check_pay_${transaction.id}`).row()
                .text("🔙 Batal Transaksi", "menu_main");

            await ctx.replyWithPhoto(qrisUrl, {
                caption: `⚡ *INVOICE PEMBAYARAN VIP* ⚡\n\n` +
                    `📦 *Paket:* ${plan.name}\n` +
                    `💰 *Total:* Rp ${plan.price.toLocaleString('id-ID')}\n` +
                    `🔖 *Order ID:* \`${transaction.id}\`\n\n` +
                    `Silakan scan QRIS di atas menggunakan m-Banking atau E-Wallet (OVO, DANA, GOPAY, ShopeePay, dll).\n\n` +
                    `_Jika sudah bayar, pastikan klik tombol *Cek Status Pembayaran* di bawah ini!_`,
                parse_mode: "Markdown",
                reply_markup: checkKb
            });
        }

        // 4. CEK STATUS PEMBAYARAN LUNAS / BELUM
        else if (data.startsWith("check_pay_")) {
            const orderId = data.replace("check_pay_", "");

            // Kita cuma butuh cek DB. Karena kalau user lunas, Webhook lu otomatis update DB jadi SETTLEMENT!
            const transaction = await prisma.transaction.findUnique({
                where: { id: orderId },
                include: { plan: true }
            });

            if (!transaction) return;

            if (transaction.status === 'SETTLEMENT' || transaction.status === 'SUCCESS') {
                // Hapus QRIS nya biar chat gak penuh
                await ctx.deleteMessage();

                await ctx.reply(
                    `🎉 *PEMBAYARAN BERHASIL!* 🎉\n\n` +
                    `Terima kasih bre! Akun kamu sekarang sudah terupgrade menjadi *VIP* untuk *${transaction.plan.durationDays} Hari* kedepan.\n\n` +
                    `Silakan klik tombol *Info Akun & API* di menu utama untuk melihat status VIP kamu.`,
                    { parse_mode: "Markdown", reply_markup: mainMenu }
                );
            } else if (transaction.status === 'EXPIRE' || transaction.status === 'CANCEL') {
                await ctx.answerCallbackQuery({ text: "❌ Transaksi kedaluwarsa atau dibatalkan.", show_alert: true });
            } else {
                await ctx.answerCallbackQuery({ text: "⚠️ Pembayaran belum masuk. Jika sudah bayar, tunggu 1-2 menit lalu klik lagi.", show_alert: true });
            }
        }

    } catch (error) {
        console.error("Error di Callback Query:", error);
        await ctx.reply("Waduh, ada sistem yang nyangkut bre. Coba lagi.");
    }
});

// ==========================================
// 6. EVENT HANDLER: MEMBER BARU JOIN GRUP
// ==========================================
bot.on("message:new_chat_members", async (ctx) => {
    const newMembers = ctx.message.new_chat_members;
    for (const member of newMembers) {
        if (member.is_bot) continue;

        const welcomeMenu = new InlineKeyboard().url("🤖 Chat Bot API", "https://t.me/TestAkrabBot"); // Ganti nama bot lu
        try {
            await ctx.reply(`👋 Selamat datang, *${member.first_name}*!\nJangan lupa chat bot kami untuk dapetin API Key ya!`, { parse_mode: "Markdown", reply_markup: welcomeMenu });
        } catch (error) {
            console.error("Welcome message error:", error);
        }
    }
});