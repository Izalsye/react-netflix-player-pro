import * as cheerio from 'cheerio';
import {
    PcwCard,
    PcwBlock,
    NormalizedItem,
    NormalizedHomeResponse,
    IqiyiDetailResponse,
    IqiyiEpisode,
    SubtitleResponse,
    NormalizedSubtitle
} from '../../types/iqiyi';

// 🎯 KAMUS TRANSLASI (Mandarin -> Indonesia)
const TITLE_DICTIONARY: Record<string, string> = {
    "热门推荐": "Rekomendasi populer",
    "免费精选（印菲越test组）": "Limited Time Free",
    "为你推荐": "Rekomendasi untuk Anda",
    "Combo Asia Vision+": "Combo Asia Vision+",
    "人气热榜": "Populer",
    "即将上线": "Segera Tayang",
    "影人榜": "All Star",
    "网剧片库推荐": "Drama Web Pilihan",
    "电视剧精选": "Drama Pilihan",
    "动漫精选": "Anime Pilihan",
    "电影精选": "Film Pilihan",
    "综艺精选": "Variety Show Pilihan",
    "东南亚": "Asia Tenggara",
    "topic组件（多组card）": "Topik Spesial",
    "热播榜": "Populer Sekarang",
    "期待榜": "Paling Dinantikan",
    "排行榜-电视剧精选": "Drama Pilihan",
    "排行榜-电影精选": "Film Pilihan",
    "排行榜-动漫精选": "Anime Pilihan",
    "排行榜-综艺精选": "Variety Show Pilihan",
    "飙升榜": "Lagi Naik Daun",
    "必看榜": "Wajib Tonton",
};

// Helper: Bikin slug yang rapi
function createSlug(title: string, year: string): string {
    const cleanTitle = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    return year ? `${cleanTitle}-${year}` : cleanTitle;
}

// Helper: Perbaiki protokol dan inject suffix resolusi kalau ada
function fixAndResizeImageUrl(url?: string, suffix?: string): string | null {
    if (!url) return null;
    let fullUrl = url.startsWith('//') ? `https:${url}` : url;

    if (suffix) {
        const lastDotIndex = fullUrl.lastIndexOf('.');
        if (lastDotIndex !== -1) {
            const path = fullUrl.substring(0, lastDotIndex);
            const ext = fullUrl.substring(lastDotIndex);

            // Cegah double suffix jika ternyata dari iQIYI sudah ada
            if (!path.endsWith(suffix)) {
                return `${path}${suffix}${ext}`;
            }
        }
    }
    return fullUrl;
}

// Tambahkan parameter `isSlider` dengan default false
export function mapPcwBlockToItem(block: PcwBlock, isSlider: boolean = false): NormalizedItem {
    const title = block.title || 'Unknown Title';
    const year = block.kv_pair?.year || '';

    // 🎯 FIX: Tambahkan fallback ke loc_suffix_album karena untuk tipe movie loc_Suffix_play sering kosong
    const rawPath = block.kv_pair?.loc_Suffix_play || block.kv_pair?.loc_suffix_album || '';
    const cleanPath = rawPath ? rawPath.split('?')[0] : null;

    const isSeries = block.kv_pair?.channel_id !== '1' || (block.update && block.update.toLowerCase().includes('episode'));

    let epsNum = null;
    if (block.update) {
        const match = block.update.match(/\d+/);
        if (match) epsNum = parseInt(match[0], 10);
    }

    // 🎯 Logic pengisian object Banner vs Cover
    let bannerObj = null;
    let coverObj = null;

    if (isSlider) {
        // Jika Slider, isi Banner tanpa ditembak resolusi, Cover jadikan null
        bannerObj = {
            cover: fixAndResizeImageUrl(block.image?.url || block.image?.url_webp, '') || "",
            background: fixAndResizeImageUrl(block.image_bg?.url || block.image_h?.url, '') || "",
            title: fixAndResizeImageUrl(block.image_title?.url || block.image_title?.url_webp, '') || ""
        };
    } else {
        // Jika BUKAN Slider (Section dll), isi Cover ditembak resolusi, Banner jadikan null
        // Catatan: Jika block.image_bg kosong, kita fallback ke block.image
        const rawBgUrl = block.image_bg?.url || block.image_h?.url || block.image?.url || block.image?.url_webp;
        coverObj = {
            potrait: fixAndResizeImageUrl(block.image?.url || block.image?.url_webp, '_260_360') || "",
            landscape: fixAndResizeImageUrl(rawBgUrl, '_480_270') || ""
        };
    }

    return {
        pathdetail: cleanPath, // <-- Sekarang pasti terisi
        id: block.kv_pair?.qipu_id || String(Math.floor(Math.random() * 100000)),
        contentType: isSeries ? 'tv_series' : 'movie',
        title: title,
        slug: createSlug(title, year),
        overview: block.desc || '',
        tagline: null,
        banner: bannerObj,
        cover: coverObj,
        releaseDate: year ? `${year}-01-01` : null,
        runtimeMinutes: null,
        voteAverage: parseFloat(block.score || '0') || 0,
        viewCount: Math.floor(Math.random() * 500000),
        genres: block.kv_pair?.tags ? block.kv_pair.tags.split('|') : [],
        hasVideo: true,
        numberOfSeasons: isSeries ? 1 : undefined,
        numberOfEpisodes: isSeries ? (epsNum || undefined) : undefined
    };
}

// 🎯 UPDATE FUNGSI INI
export function formatIqiyiHome(cards: PcwCard[], baseInfo?: any): NormalizedHomeResponse {
    const response: NormalizedHomeResponse & { hasNextPage?: boolean } = {
        sliderItems: [],
        sections: [],
        hasNextPage: baseInfo?.has_next === 1 // 🎯 Info buat frontend kalau ada next page
    };

    cards.forEach(card => {
        // 🎯 UPDATE: Skip card tipe menu dan tipe banner iklan/VIP
        if (card.card_type === 'pcw_library_entrance' || card.card_type === 'pcw_tab_banner') return;

        const itemsToMap = card.blocks || [];
        if (itemsToMap.length === 0) return;

        // 🎯 AMBIL JUDUL DINAMIS BERDASARKAN BAHASA
        let cleanTitle = card.name; // Fallback title
        if (card.top_banner && card.top_banner.length > 0 && card.top_banner[0].title) {
            // Ambil dari banner pertama (ex: "Top Picks for You", "Limited Time Free")
            cleanTitle = card.top_banner[0].title;
        }

        if (card.card_type === 'pcw_focus_banner') {
            response.sliderItems?.push(...itemsToMap.map(item => mapPcwBlockToItem(item, true)));
        }
        else if (card.card_type === 'pcw_vertical_list' || card.card_type === 'pcw_rank_list') {
            if (itemsToMap.length > 0) { // Jika ada isinya
                response.sections.push({
                    sectionId: card.id,
                    type: card.card_type === 'pcw_rank_list' ? 'trending' : 'normal',
                    title: cleanTitle, // Sudah bahasa Indo/Inggris tanpa hardcore dictionary!
                    slug: createSlug(cleanTitle, ''),
                    items: itemsToMap.map(item => mapPcwBlockToItem(item, false))
                });
            }
        }
    });

    return response;
}

// 🎯 Tambahkan parameter baseInfo
export function formatIqiyiTrending(cards: PcwCard[], baseInfo?: any): NormalizedHomeResponse {
    const response: NormalizedHomeResponse = {
        sections: [],
        hasNextPage: baseInfo?.has_next === 1 // 🎯 Penanda Next Page untuk Frontend
    };

    cards.forEach(card => {
        // 🎯 UPDATE: Skip card tipe menu dan tipe banner iklan/VIP
        if (card.card_type === 'pcw_library_entrance' || card.card_type === 'pcw_tab_banner') return;

        const itemsToMap = card.blocks || [];
        if (itemsToMap.length === 0) return;

        // 🎯 LOGIC AMBIL JUDUL DINAMIS TANPA HARDCODE
        let cleanTitle = card.name.split('-')[1] || card.name;
        if (card.top_banner && card.top_banner.length > 0 && card.top_banner[0].title) {
            cleanTitle = card.top_banner[0].title;
        }

        response.sections.push({
            sectionId: card.id,
            type: 'trending',
            title: cleanTitle,
            slug: createSlug(cleanTitle, ''),
            items: itemsToMap.map(item => mapPcwBlockToItem(item, false))
        });
    });

    return response;
}

export function extractNextData(html: string) {
    try {
        const $ = cheerio.load(html);
        const nextDataText = $('#__NEXT_DATA__').html();
        if (!nextDataText) return null;
        return JSON.parse(nextDataText);
    } catch (e) {
        return null;
    }
}

export function mapIqiyiDetail(props: any): IqiyiDetailResponse {
    // 🎯 1. AMAN-KAN STATE 
    const pageProps = props?.pageProps || props || {};
    const initialState = pageProps?.initialState || {};

    const playState = initialState?.play || {};
    const albumState = initialState?.album || {};

    // iQIYI kadang nyimpen di videoInfo, kadang di curVideoInfo
    const videoInfo = playState?.videoInfo || playState?.curVideoInfo || albumState?.videoInfo || {};
    const albumInfo = albumState?.videoAlbumInfo || playState?.videoAlbumInfo || videoInfo;

    const rawId = albumInfo?.albumId || videoInfo?.albumId || videoInfo?.tvId || videoInfo?.qipuId || "0";
    const publishTimeStr = albumInfo?.publishTime || videoInfo?.publishTime || videoInfo?.issueTime || "";
    const releaseDate = publishTimeStr ? String(publishTimeStr).substring(0, 10) : "";

    // 🎯 2. FIX COVER: Ambil dari thumbnail / schemaImage yang terbukti ada di JSON
    const rawPortrait = videoInfo?.thumbnailUrl2 || albumInfo?.thumbnailUrl2 || albumInfo?.posterPic || videoInfo?.imageLoader || videoInfo?.posterPic || albumInfo?.albumPic260 || "";

    const rawLandscape = videoInfo?.schemaVideoImage || albumInfo?.schemaVideoImage || videoInfo?.thumbnailUrl1 || albumInfo?.thumbnailUrl1 || videoInfo?.imgUrl || albumInfo?.albumPic480 || "";

    const coverObj = {
        potrait: fixAndResizeImageUrl(rawPortrait, '_320_420') || rawPortrait || "",
        landscape: fixAndResizeImageUrl(rawLandscape, '') || rawLandscape || ""
    };

    // 🎯 3. FIX OVERVIEW & TITLE
    const overview = albumInfo?.desc || videoInfo?.mergeDesc || videoInfo?.desc || albumInfo?.description || videoInfo?.description || "";
    const title = albumInfo?.name || videoInfo?.name || albumInfo?.title || videoInfo?.title || "Unknown Title";

    // 🎯 4. FIX GENRES: Sapu bersih dari categoryTagMap (TypeDy = Movie, TypeDsj = Series)
    let genres: string[] = [];
    const catMap = albumInfo?.categoryTagMap || videoInfo?.categoryTagMap || {};
    const typeDsj = catMap.TypeDsj || []; // Biasa dipakai series
    const typeDy = catMap.TypeDy || [];   // Biasa dipakai movie

    const rawCategories = [...typeDsj, ...typeDy];

    if (rawCategories.length > 0) {
        genres = rawCategories.map((t: any) => t?.name || t?.subName || t?.tagName).filter(Boolean);
    } else {
        // Fallback terakhir misal dia pakai string koma/pipa
        const tags = albumInfo?.tags || videoInfo?.tags || "";
        if (typeof tags === 'string') {
            genres = tags.split(/[,|]/).map(g => g.trim()).filter(Boolean);
        }
    }

    // 🎯 5. FIX RUNTIME: Ambil dari key "len" (contoh: "01:35:48")
    let runtimeMinutes = 0;
    const lenStr = videoInfo?.len || albumInfo?.len || "";
    const dashData = playState?.prePlayerData?.dash?.data?.program?.video;
    let dashDuration = 0;

    if (Array.isArray(dashData) && dashData.length > 0) {
        dashDuration = dashData[0]?.duration || 0;
    }

    if (dashDuration > 0) {
        runtimeMinutes = Math.floor(Number(dashDuration) / 60);
    } else if (lenStr && lenStr.includes(':')) {
        const parts = lenStr.split(':').map(Number);
        if (parts.length === 3) runtimeMinutes = parts[0] * 60 + parts[1]; // HH:MM:SS -> Menit
        else if (parts.length === 2) runtimeMinutes = parts[0]; // MM:SS -> Menit
    } else if (videoInfo?.min) {
        runtimeMinutes = Number(videoInfo.min);
    }

    // 🎯 6. EKSTRAK EPISODE
    const cachePlayList = playState?.cachePlayList || {};
    const episodes: IqiyiEpisode[] = [];
    const keys = Object.keys(cachePlayList);

    if (keys.length > 0) {
        const firstKey = keys[0];
        const rawEpisodes = cachePlayList[firstKey] || [];

        rawEpisodes.forEach((ep: any) => {
            const cleanSlug = ep.playLocSuffix ? ep.playLocSuffix.split('?')[0] : "";
            episodes.push({
                slug: cleanSlug,
                id: String(ep.tvId || ep.qipuId),
                episodeNumber: ep.order || 1,
                title: ep.subTitle || ep.seoTitle || ep.name || `Episode ${ep.order || 1}`,
                airDate: ep.publishTime || "",
                _iqiyi_tvId: ep.tvId || ep.qipuId,
                _iqiyi_vid: ep.vid
            });
        });
    }

    // 🚨 7. MAGIC REQUEST: JIKA MOVIE (Episodes Kosong), BUATKAN SEASON 1 EP 1 OTOMATIS!
    if (episodes.length === 0) {
        const rawPath = videoInfo?.playLocSuffix || albumInfo?.playLocSuffix || "";
        const cleanSlug = rawPath ? rawPath.split('?')[0] : createSlug(title, albumInfo?.year || videoInfo?.year || "");

        episodes.push({
            slug: cleanSlug,
            id: String(rawId),
            episodeNumber: 1,
            title: title,
            airDate: releaseDate,
            _iqiyi_tvId: videoInfo?.tvId || rawId,
            _iqiyi_vid: videoInfo?.vid || ""
        });
    }

    const seasons = [{
        id: `season-1-${rawId}`,
        tmdbId: 0,
        seasonNumber: 1,
        title: "Season 1",
        episodes: episodes
    }];

    return {
        id: String(rawId),
        title: title,
        originalTitle: title,
        slug: createSlug(title, albumInfo?.year || videoInfo?.year || ""),
        overview: overview,
        banner: null,
        cover: coverObj,
        releaseDate: releaseDate,
        runtimeMinutes: runtimeMinutes,
        voteAverage: playState?.playScoreInfo?.score ? parseFloat(playState.playScoreInfo.score) : (parseFloat(videoInfo?.score) || parseFloat(videoInfo?.voteAverage) || 0),
        genres: genres,
        hasVideo: true,
        seasons: seasons
    };
}

export function mapSubtitle(stl: SubtitleResponse[], baseUrl: string): NormalizedSubtitle | null {
    const indonesian = stl.find(s => s.lid === 24);
    if (!indonesian) return null;

    return {
        label: indonesian._name,
        url: `${baseUrl}${indonesian.srt}`,
        vtt: `${baseUrl}${indonesian.webvtt}`
    };
}

export function mapIqiyiPlayUrl(streamData: any, siteOrigin: string = '') {
    const payload = streamData?.data?.data || streamData?.data || streamData;
    const program = payload?.program;
    const baseUrl = payload?.dstl || "https://meta.video.iqiyi.com";

    if (!program) {
        return {
            error: true,
            message: "No program found. Check API Response Structure."
        };
    }

    // 🎯 KAMUS BAHASA SUBTITLE BIAR GAK UNRECOGNIZED
    const getLangCode = (name: string) => {
        const cleanName = name.toLowerCase().trim();
        const langMap: Record<string, string> = {
            'bahasa indonesia': 'id',
            'bahasa inggris': 'en',
            'mandarin sederhana': 'zh',
            'mandarin tradisional': 'zh-tw',
            'bahasa malay': 'ms',
            'bahasa melayu': 'ms',
            'bahasa malaysia': 'ms',
            'bahasa thailand': 'th',
            'bahasa vietnam': 'vi',
            'bahasa korea': 'ko',
            'bahasa jepang': 'ja',
            'bahasa spanyol': 'es',
            'bahasa arab': 'ar',
        };
        return langMap[cleanName] || 'und'; // 'und' = undefined/unknown
    };

    // 1. Mapping Subtitle
    const stlArray = program.stl || [];
    const subtitles = stlArray.map((sub: any) => {
        const rawName = sub._name || '';
        return {
            lang: getLangCode(rawName), // 🔥 Fix "Unrecognized"
            label: rawName.replace('Bahasa ', ''),
            subUrl: sub.srt ? `${baseUrl}${sub.srt}` : '',
            subUrl_proxy: sub.srt ? `/api/iqiyi/subtitle?url=${encodeURIComponent(`${baseUrl}${sub.srt}`)}` : ''
        };
    });

    // 2. Ambil Video Object
    const videoArray = program.video || [];
    const bestVideo = videoArray.find((v: any) =>
        (v.m3u8 && v.m3u8.length > 50) || (v.play?.ts?.l)
    );

    let rawM3u8 = bestVideo?.m3u8 || bestVideo?.play?.ts?.l || null;
    let streamType = 'unknown';
    let dashPayload = null;

    // 3. Deteksi Tipe Stream & REWRITE M3U8 TS KE PROXY
    if (typeof rawM3u8 === 'string') {
        if (rawM3u8.trim().startsWith('{')) {
            streamType = 'dash';
            try {
                dashPayload = JSON.parse(rawM3u8);
                rawM3u8 = null;
            } catch (e) {
                console.error("Gagal parse DASH JSON:", e);
            }
        } else if (rawM3u8.includes('#EXTM3U')) {
            streamType = 'raw_hls';
            // 🚀 SULAP SEMUA URL .TS BIAR MASUK PROXY KITA
            const proxyBase = siteOrigin ? `${siteOrigin}/api/iqiyi/stream-proxy?url=` : `/api/iqiyi/stream-proxy?url=`;

            rawM3u8 = rawM3u8.split('\n').map((line: string) => {
                const trimmed = line.trim();
                // Kalau baris ini adalah link http (link file .ts), bungkus pake proxy kita!
                if (trimmed.startsWith('http')) {
                    return `${proxyBase}${encodeURIComponent(trimmed)}`;
                }
                return line;
            }).join('\n');

        } else if (rawM3u8.startsWith('http')) {
            streamType = 'hls_url';
        }
    }

    return {
        subtitles,
        streamType,
        m3u8: rawM3u8,
        dashData: dashPayload,
        quality: bestVideo?.bid || null
    };
}

export function formatIqiyiSearch(videos: any[]): NormalizedHomeResponse {
    const response: NormalizedHomeResponse = {
        sections: []
    };

    if (!videos || videos.length === 0) return response;

    const mappedItems: NormalizedItem[] = videos.map(vid => {
        const cleanTitle = vid.name?.replace(/<[^>]*>?/gm, '') || 'Unknown';
        const rawImageUrl = vid.albumPic || vid.image?.url || '';

        // 🎯 Terapkan formating terbaru untuk search result
        const coverObj = {
            potrait: fixAndResizeImageUrl(rawImageUrl, '_260_360') || "",
            landscape: fixAndResizeImageUrl(rawImageUrl, '_480_270') || ""
        };

        const rawPath = vid.playLocSuffix
            || (vid.albumUrl ? vid.albumUrl.split('/album/')[1]?.split('?')[0] : null)
            || (vid.url ? vid.url.split('/play/')[1]?.split('?')[0] : null);

        return {
            pathdetail: rawPath,
            id: String(vid.albumId || vid.qipuId),
            contentType: vid.contentType === 1 ? 'tv_series' : 'movie',
            title: cleanTitle,
            slug: createSlug(cleanTitle, vid.publishYear || ''),
            overview: vid.desc || '',
            tagline: null,
            banner: null, // Karena hasil search, bukan slider
            cover: coverObj,
            releaseDate: vid.publishYear ? `${vid.publishYear}-01-01` : null,
            runtimeMinutes: null,
            voteAverage: parseFloat(vid.score || '0') || 0,
            viewCount: Math.floor(Math.random() * 500000),
            genres: [],
            hasVideo: true,
            numberOfSeasons: 1,
            numberOfEpisodes: vid.episodeList?.length || undefined
        };
    });

    response.sections.push({
        sectionId: 'search-results',
        type: 'normal',
        title: 'Hasil Pencarian',
        slug: 'search-results',
        items: mappedItems
    });

    return response;
}