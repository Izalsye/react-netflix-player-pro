import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

const IQIYI_BASE = process.env.IQIYI_BASE || 'https://pcw-api.iq.com';
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

const DEFAULT_IQIYI_COOKIE = process.env.IQIYI_COOKIES || 'lang=en_us; mod=id; random-uuid=9f172ded00fc496985a93cc4eb8a42fd; ak_bmsc=8CC6CB4C32B2DCE5B670356724F5A5C5~000000000000000000000000000000~YAAQLT7VjBWL5tSeAQAAlt4D2gCRykpThbJte19Xzw3VQMP6U/ddEtZ6HvGOlP+zWzO1VOg/NHOXFsZ5iSpT0mX2nw2kyTYjHFcq/WGWktAPM4phYKBrLaROLTLXAGc8elSLIvhl01YK36nVll42sS1dRz/vxY7rBtyYMOfc5QTOh2oHlU5L4Ol+UuNADlz7b9/n5qvZFJno3kKmug84dYsgap+tVXpsoRcW3F3lVvKaK7B1mc1RFIvLzgRiKJq4ZBXU8ydUbR+fJ42Xqz1Y24Aj06YK/jSnFIZ93rDSxUHkPmjfYQ1oy9h+webScW+CWnehkBMVUo7YvcPDVa6+c4WtE8c/ORL41U2Q; QC005=089ef02376449fb1ed033d0113734804; adcookie=1; b_ext_ip=112.215.243.247; _gcl_au=1.1.981078753.1781774149; QC007=DIRECT; QC006=hfcy1xkoxtlaxsf27fg3frgz; _gid=GA1.2.275455672.1781774151; _mlcp=MLCP.1.1781774151611.1936314740; _mlss=W3sicGl4ZWxJZCI6InB4bC1rTnBVMnp5USIsInNlc3Npb25JZCI6IjE3ODE3NzQxNTE2MTRfZWI0NjBiM2M1MTE0NGI2YyIsInNlc3Npb25TdGFydFRpbWVzdGFtcCI6MTc4MTc3NDE1MTYxNCwic2Vzc2lvbkxhc3RBY3RpdmVUaW1lc3RhbXAiOjE3ODE3NzQxNTE2MTR9XQ==; _mlcs=MLCP.1.1781774151633.1; __gads=ID=6c0e6861f26b89b1:T=1781774151:RT=1781774151:S=ALNI_MbXptrM6lfYkIFTUoCAaY0F1hNfTA; __gpi=UID=00001473d2c73706:T=1781774151:RT=1781774151:S=ALNI_MbcnxTm2dnbkQFJT5-h1LhS1qkwDg; __eoi=ID=eea6a360369bebf8:T=1781774151:RT=1781774151:S=AA-AfjaDoHiJvsGgkeg0itRRGgBn; __uuid=a60a11d7-0eae-959b-838d-3269b6dd71bc; QC008=1781774149.1781774154.1781774154.4; nu=0; I00001=0c65w3M6IbMu2bibMDEBhF5DNvOHYiishyuF7OX2wBrGnu7PWUE8euxwXZU7OUMxLf98; I00002=%7B%22msg%22%3A%22%22%2C%22code%22%3A%22A00000%22%2C%22data%22%3A%7B%22birthday%22%3A%22826390800%22%2C%22uid%22%3A%2230125299091%22%2C%22nickname%22%3A%22User7039b9593%22%2C%22icon%22%3A%22http%3A%2F%2Fwww.iqiyipic.com%2Fcommon%2Ffix%2Fheadicons%2Fmale-130.png%22%7D%7D; I00019=1; lastGlobalLoginMsg=%7B%22path%22%3A103%2C%22icon%22%3A%22%2F%2Fwww.iqiyipic.com%2Fcommon%2Ffix%2Fheadicons%2Fmale-130.png%22%2C%22nickname%22%3A%22User7039b9593%22%2C%22email%22%3A%22%22%2C%22realEmail%22%3A%22%22%2C%22phone%22%3A%22%22%2C%22realPhone%22%3A%22%22%2C%22isPhonePwdLogin%22%3A%22%22%2C%22areaCode%22%3A%22%22%7D; pspStatusUid=30125299091; pspStatus=1; abtest=%7B%22pcw_setting_subscription%22%3A%228546_B%2C8706_C%22%7D; cloudmode_msg_sended=1; QC173=0; IQC163=1; QC010=15786802; QCVtype=34; _ga=GA1.2.621831086.1781774149; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2233672eca-26c9-405b-a65c-ba069b4d9bb9%5C%22%2C%5B1781774151%2C460000000%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-f0gmQVAm-nS1Hl7UVCEGv0LP2YgymuY3S6Xf1VoMwha2DjyEOpChbb2HnB8rVlAgBubAuXujU8V8aQCTg2HrFEaOIgA03Iooy-d4EH_QdV-lp6UxgNEjjNcNRB6CLp6azYjMXIWRQ-L02jYZ-Em0eCUXcJw%3D%3D%22%5D%5D; __dfp=a0d75438f053d850ebbf90d520d3e6278a1d3f2c7b5fe9f045c7acbbea28616402@1783070153655@1781774154655; _ga_PCTZRE9688=GS2.1.s1781774149$o1$g1$t1781774293$j60$l0$h0; _gat_gtag_UA_145147433_3=1; _ga_VTJGB1PRBJ=GS2.1.s1781774149$o1$g1$t1781774293$j60$l0$h0; bm_sv=B04DA364C13FC9325C36045858A9B527~YAAQLT7VjM6X5tSeAQAAeBsG2gAnOsM4+FGW5zYQnLfeDaruJBYLv+YDJ7cB+Y2IFiVeSpBawLKZdzZ4d3RRRRrV4z+YvkT0cz2Rj5suHu1xWifwuZoBGK+VEz7z0y2nLI5pdPZmyLpco2PcKWsM4Y5GcI1e+b9NXZhZMsfYCsvGFmJTL2FU3rPEZUK37Y5sTL4LmG1VVX9EhmsK9of/2aY4FNnufNipc9iXKR7OekQunRCcmAO4Q6S06KTd~1';

const cache = new Map<string, { val: any, exp: number }>();

function buildIqiyiHeaders(req: Request, targetHost: string = "pcw-api.iq.com"): Record<string, string> {
    const incomingHeaders = Object.fromEntries(req.headers.entries());

    let safeAcceptEncoding = incomingHeaders["accept-encoding"] || "gzip, deflate, br";
    safeAcceptEncoding = safeAcceptEncoding.replace(/,?\s*zstd/gi, '').trim();
    if (safeAcceptEncoding.startsWith(',')) safeAcceptEncoding = safeAcceptEncoding.substring(1).trim();

    return {
        "Accept": incomingHeaders["accept"] || "*/*",
        "Accept-Encoding": safeAcceptEncoding,
        "Accept-Language": incomingHeaders["accept-language"] || "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Content-type": "application/x-www-form-urlencoded",
        "Cookie": incomingHeaders["Cookie"] || DEFAULT_IQIYI_COOKIE,
        "Host": targetHost,
        "Origin": "https://www.iq.com",
        "Referer": incomingHeaders["Referer"] || "https://www.iq.com/",
        "User-Agent": incomingHeaders["user-agent"] || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
        "sec-ch-ua": incomingHeaders["sec-ch-ua"] || '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
        "sec-ch-ua-mobile": incomingHeaders["sec-ch-ua-mobile"] || "?0",
        "sec-ch-ua-platform": incomingHeaders["sec-ch-ua-platform"] || '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
    };
}

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

async function Get(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY
        ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false })
        : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);

                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function Post(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string> } = { label: 'iqiyi-get' }
) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    // 🎯 UPDATE 1: Bikin URL dan Host dinamis (Bisa nerima absolute URL seperti proxyPost)
    let upstreamUrl = path;
    let targetHost = "pcw-api.iq.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
        upstreamUrl = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
    } else {
        const pathWithQuery = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
        upstreamUrl = `${IQIYI_BASE}${pathWithQuery}`;
        const u = new URL(IQIYI_BASE);
        targetHost = u.hostname;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${upstreamUrl}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(
                typeof hit.val === 'string' ? hit.val : JSON.stringify(hit.val),
                { headers: { 'Content-Type': typeof hit.val === 'string' ? 'text/html' : 'application/json', 'x-cache': 'HIT' } }
            );
        }
    }

    const headers = {
        ...buildIqiyiHeaders(req, targetHost), // <-- Lempar targetHost dinamis
        ...opts.headers
    };

    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            if (status !== 200) {
                console.error(`[ProxyGet Error] Upstream status is ${status}`);
                return { error: true, status, message: "Upstream or Proxy failed" };
            }

            // 🎯 UPDATE 2: Kalau bentuknya HTML, return teks mentah. Jangan dipaksa JSON.parse!
            if (contentType.includes('text/html')) {
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: text, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return text;
            }

            try {
                const parsedJSON = JSON.parse(text);
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: parsedJSON, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return parsedJSON;
            } catch (parseError) {
                // Fallback kalau ternyata JSON rusak, return teks aja daripada error
                return text;
            }
        }

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        console.error(`[IqiyiProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; send?: boolean; headers?: Record<string, string> } = { label: 'iqiyi-post' }
) {

    let upstreamUrl = path;
    let targetHost = "pcw-api.iq.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        upstreamUrl = `${IQIYI_BASE}${path}`;
        const u = new URL(IQIYI_BASE);
        targetHost = u.hostname;
    }

    const headers = { ...buildIqiyiHeaders(req, targetHost), ...opts.headers };
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    const reqContentType = headers["Content-Type"] || headers["content-type"] || "application/json";

    try {
        const { status, contentType, text } = await Post(upstreamUrl, headers, stringBody, reqContentType, 15_000);
        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return text; }
        }
        return new Response(text, { status, headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}