import { makeXTrSignature } from './xtrSignature';
import { recordHit } from './stats';
import { validateApiKey } from './apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import { NextRequest, NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

const UPSTREAM_BASE = process.env.UPSTREAM_BASE || "https://api4sg.aoneroom.com";
const KEY_HEX = process.env.XTR_KEY_HEX || "efa891974eecd3148df63aa611602defd101259ba521022c57ae0566bd8e";
const AUTH = process.env.AUTH || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";

// 👇 Konfigurasi Proxy Opsional via .env
// Jika kamu butuh warp proxy lagi, tambahkan USE_LOCAL_PROXY=true di .env kamu.
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

const cache = new Map<string, { val: any, exp: number }>();

const DEFAULT_CLIENT_INFO = JSON.stringify({
  "package_name": "com.community.oneroom",
  "version_name": "3.0.13.0401.03",
  "version_code": 50020091,
  "os": "android",
  "os_version": "9",
  "install_ch": "google-play",
  "device_id": "8efacd6500fa50924f0649dc19da3d63",
  "install_store": "gp",
  "brand": "samsung",
  "model": "SM-G955F",
  "system_language": "in",
  "net": "NETWORK_WIFI",
  "region": "ID",
  "timezone": "Asia/Jakarta",
  "sp_code": "51011",
  "X-Play-Mode": "2",
  "X-Idle-Data": "1",
  "X-Family-Mode": "0",
  "X-Content-Mode": "0"
});

function mask(s?: string | null, keepStart = 10, keepEnd = 6) {
  if (!s) return s;
  if (s.length <= keepStart + keepEnd) return "***";
  return `${s.slice(0, keepStart)}***${s.slice(-keepEnd)}`;
}

function pickHeadersForLog(h: Record<string, string>) {
  return {
    "user-agent": h["user-agent"],
    "x-play-mode": h["x-play-mode"],
    "x-idle-data": h["x-idle-data"],
    "x-family-mode": h["x-family-mode"],
    "x-content-mode": h["x-content-mode"],
    "x-client-status": h["x-client-status"],
    "x-client-info": h["x-client-info"],
    "x-tr-signature": mask(h["x-tr-signature"]),
    "authorization": mask(h["authorization"]),
  };
}

async function httpsGet(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
  const u = new URL(urlStr);
  const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

  return new Promise<{ status: number; statusMessage?: string; headers: Record<string, any>; text: string }>((resolve, reject) => {
    const req = https.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        path: u.pathname + u.search,
        method: "GET",
        headers,
        agent: agent as any, // Hanya pakai agent kalau USE_PROXY=true
      },
      (res) => {
        let data = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          resolve({
            status: res.statusCode || 0,
            statusMessage: res.statusMessage,
            headers: res.headers as any,
            text: data,
          });
        });
      }
    );

    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`timeout ${timeoutMs}ms`));
    });

    req.on("error", reject);
    req.end();
  });
}

async function httpsPost(urlStr: string, headers: Record<string, string>, body: string, timeoutMs = 15_000) {
  const u = new URL(urlStr);
  const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

  return new Promise<{ status: number; statusMessage?: string; headers: Record<string, any>; text: string }>((resolve, reject) => {
    const req = https.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        path: u.pathname + u.search,
        method: "POST",
        headers: {
          ...headers,
          "Content-Length": Buffer.byteLength(body),
        },
        agent: agent as any, // Hanya pakai agent kalau USE_PROXY=true
      },
      (res) => {
        let data = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => (data += chunk));
        res.on("end", () => {
          resolve({
            status: res.statusCode || 0,
            statusMessage: res.statusMessage,
            headers: res.headers as any,
            text: data,
          });
        });
      }
    );

    req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

export async function proxyGet(
  req: Request,
  path: string,
  query: Record<string, string>,
  opts: { label: string; transform?: (d: any) => any; cacheTtlMs?: number; send?: boolean } = { label: 'proxy' }
) {
  const apiKey = req.headers.get('x-api-key');
  const visitorId = apiKey ? `apiKey:${apiKey}` : `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

  // 🔥 INI KODE PENGGANTINYA (Sudah di-sort) 🔥
  const sp = new URLSearchParams();
  const sortedKeys = Object.keys(query).sort();
  for (const k of sortedKeys) {
    if (query[k] !== undefined && query[k] !== null && query[k] !== "") {
      sp.set(k, query[k]);
    }
  }
  const qs = sp.toString();
  const pathWithQuery = qs ? `${path}?${qs}` : path;

  const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
  if (cacheKey) {
    const hit = cache.get(cacheKey);
    if (hit && hit.exp > Date.now()) {
      if (opts.send === false) return hit.val;
      return new Response(JSON.stringify(hit.val), {
        headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' },
      });
    }
  }

  const tsMs = Date.now().toString();
  const xtr = makeXTrSignature({ method: "GET", pathWithQuery, tsMs, keyHex: KEY_HEX });

  const authHeader = AUTH.startsWith('Bearer ') ? AUTH : `Bearer ${AUTH}`;

  const headers: Record<string, string> = {
    "user-agent": req.headers.get("user-agent") || "com.community.oneroom/50020091 (Linux; U; Android 9; in_ID; SM-G955F; Build/PPR1.180610.011; Cronet/145.0.7582.0)",
    "priority": req.headers.get("priority") || "u=1, i",
    "x-play-mode": req.headers.get("x-play-mode") || "2",
    "x-idle-data": req.headers.get("x-idle-data") || "1",
    "x-family-mode": req.headers.get("x-family-mode") || "0",
    "x-content-mode": req.headers.get("x-content-mode") || "0",
    "x-client-status": req.headers.get("x-client-status") || "1",
    "x-tr-signature": xtr,
    "authorization": authHeader,
    "x-client-info": req.headers.get("x-client-info") || DEFAULT_CLIENT_INFO,
    // "x-forwarded-for": req.headers.get("x-forwarded-for") || "114.124.130.123",
    // "client-ip": req.headers.get("x-forwarded-for") || "114.124.130.123",
    // 🔥 TAMBAHAN HEADER WAJIB DARI LOG FRIDA
    "X-UtmSource": "alive",
    "X-PM-Active": "true",
    "X-PM-Level": "2",
    "X-Client-Build": "1787251390091643536.81f63ed4811a92b52591d8dc5b91cb06-178725097065600348.fc4976e86db2fd0a4e1d68e3b1af4650",
  };

  const upstreamUrl = `${UPSTREAM_BASE}${pathWithQuery}`;

  const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  console.log(`[proxyGet:${reqId}] -> upstream`, {
    label: opts.label,
    method: "GET",
    upstreamUrl,
    pathWithQuery,
    visitorId,
    headers: pickHeadersForLog(headers),
    cacheKey: cacheKey ? "on" : "off",
  });

  try {
    const { status, statusMessage, headers: upHeaders, text } = await httpsGet(upstreamUrl, headers, 15_000);

    console.log(`[proxyGet:${reqId}] <- upstream response`, {
      status,
      statusMessage,
      contentType: upHeaders["content-type"],
      server: upHeaders["server"],
      via: upHeaders["via"],
      xCache: upHeaders["x-cache"],
    });

    let json: any;
    try {
      json = JSON.parse(text);
    } catch (err: any) {
      console.log(`[proxyGet:${reqId}] Failed to parse JSON. Status:`, status);
      
      // Deteksi logika error biar gak asal nuduh WAF
      let reason = "Upstream returned non-JSON format";
      if (status === 403 || text.includes("cloudflare") || text.includes("Just a moment")) {
        reason = "🚨 Possible WAF / Cloudflare Block";
      } else if (status >= 500) {
        reason = "🔥 Upstream Server Error (5xx)";
      } else if (status === 404) {
        reason = "🔍 Endpoint Not Found (404)";
      } else if (!text || text.trim() === "") {
        reason = "👻 Upstream returned empty response";
      }

      const errorPayload = {
        error: true,
        message: reason,
        http_status: status,
        upstream_server: upHeaders["server"] || "unknown", // Biar ketahuan server Nginx/Cloudflare/Envoy
        content_type: upHeaders["content-type"] || "unknown",
        raw_response: text ? text.substring(0, 2000) : "[EMPTY]" // Tampilin 2000 karakter buat diinvestigasi
      };

      // Balikin errorPayload ke route lu biar gak crash
      if (opts.send === false) return errorPayload;
      // Kalau statusnya 200 tapi isinya bukan JSON, balikin 502 (Bad Gateway). Sisanya balikin status aslinya.
      const finalStatus = (status >= 200 && status < 300) ? 502 : (status || 500);
      return NextResponse.json(errorPayload, { status: finalStatus });
    }
    const out = opts.transform ? opts.transform(json) : json;

    if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs) {
      cache.set(cacheKey, { val: out, exp: Date.now() + opts.cacheTtlMs });
    }

    if (opts.send === false) return out;
    return new Response(JSON.stringify(out), {
      status,
      headers: { 'Content-Type': 'application/json', 'x-cache': 'MISS' },
    });
  } catch (e: any) {
    console.error(`[proxyGet:${reqId}] upstream request failed`, {
      name: e?.name,
      message: e?.message,
      stack: e?.stack,
    });

    const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
    return new Response(JSON.stringify({ error: true, message: msg }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

export async function proxyPost(
  req: Request,
  path: string,
  body: any,
  opts: { label: string; cacheTtlMs?: number; send?: boolean } = { label: 'proxy-post' }
) {
  const bodyString = typeof body === 'string' ? body : JSON.stringify(body);
  const tsMs = Date.now().toString();

  const xtr = makeXTrSignature({
    method: "POST",
    pathWithQuery: path,
    tsMs,
    keyHex: KEY_HEX,
    body: bodyString,
    contentType: "application/json; charset=utf-8"
  });

  const headers: Record<string, string> = {
    "user-agent": req.headers.get("user-agent") || "com.community.oneroom/50020091 (Linux; U; Android 9; in_ID; SM-G955F; Build/PPR1.180610.011; Cronet/145.0.7582.0)",
    "content-type": "application/json; charset=utf-8",
    "x-play-mode": req.headers.get("x-play-mode") || "2",
    "x-idle-data": req.headers.get("x-idle-data") || "1",
    "x-family-mode": req.headers.get("x-family-mode") || "0",
    "x-content-mode": req.headers.get("x-content-mode") || "0",
    "x-client-status": req.headers.get("x-client-status") || "1",
    "x-tr-signature": xtr,
    "authorization": AUTH.startsWith('Bearer ') ? AUTH : `Bearer ${AUTH}`,
    "x-client-info": req.headers.get("x-client-info") || DEFAULT_CLIENT_INFO,
  };

  try {
    const upstreamUrl = `${UPSTREAM_BASE}${path}`;
    const { status, text } = await httpsPost(upstreamUrl, headers, bodyString);

    let json: any;
    try {
      json = JSON.parse(text);
    } catch {
      return new Response(text, { status });
    }

    if (opts.send === false) return json;
    return NextResponse.json(json, { status });
  } catch (e: any) {
    return NextResponse.json({ error: true, message: e.message }, { status: 502 });
  }
}