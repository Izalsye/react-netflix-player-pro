import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path prisma lu
import crypto from 'crypto';

export async function validateRequest(req: Request) {
    try {
        // 1. Ambil API Key dari header (bisa pakai x-api-key atau Authorization)
        const rawKey = req.headers.get('x-api-key');

        if (!rawKey) {
            return { error: 'API Key is missing', status: 401 };
        }

        // 2. Hash key untuk dicocokkan dengan database
        const hashedKey = crypto.createHash('sha256').update(rawKey).digest('hex');

        // 3. Cari User berdasarkan ApiKey
        const apiKeyData = await prisma.apiKey.findUnique({
            where: { hashedKey },
            include: { user: true },
        });

        if (!apiKeyData) {
            return { error: 'Invalid API Key', status: 401 };
        }

        const user = apiKeyData.user;

        // 4. Cek apakah VIP sudah expired, kalau iya turunkan ke FREE
        let activeRole = user.role;
        if (user.role === 'VIP' && user.subEndsAt) {
            const now = new Date();
            if (now > user.subEndsAt) {
                activeRole = 'FREE';
                // (Opsional) Update status role-nya di DB kembali ke FREE
                await prisma.user.update({
                    where: { id: user.id },
                    data: { role: 'FREE' }
                });
            }
        }

        // 5. Cek & Update Kuota Harian (Daily Usage)
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0); // Reset jam jadi 00:00:00 untuk patokan hari ini

        let usage = await prisma.dailyUsage.findUnique({
            where: {
                userId_date: {
                    userId: user.id,
                    date: today,
                },
            },
        });

        // Kalau belum ada record hari ini, buat baru
        if (!usage) {
            usage = await prisma.dailyUsage.create({
                data: { userId: user.id, date: today, count: 0 },
            });
        }

        // 6. Validasi Limit Sesuai Role
        const maxRequests = activeRole === 'VIP' ? 1000000 : 600;

        if (usage.count >= maxRequests) {
            return {
                error: `Rate limit exceeded. Your plan (${activeRole}) allows ${maxRequests} requests per day.`,
                status: 429
            };
        }

        // 7. Tambah hitungan request hari ini (+1)
        await prisma.dailyUsage.update({
            where: { id: usage.id },
            data: { count: usage.count + 1 },
        });

        // Lolos validasi, kembalikan data user biar bisa dipakai di rute API
        return { success: true, user: { ...user, activeRole } };

    } catch (error) {
        console.error('API AUTH ERROR:', error);
        return { error: 'Internal Server Error', status: 500 };
    }
}