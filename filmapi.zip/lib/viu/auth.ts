// auth.ts
import https from "node:https";
import { URL } from "node:url";
import { HttpsProxyAgent } from 'https-proxy-agent';

const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// Helper request pakai node:https murni agar aman lewat proxy
function rawRequest(urlStr: string, method: string, headers: Record<string, string>, body?: string): Promise<{ status: number; text: string }> {
    return new Promise((resolve, reject) => {
        const u = new URL(urlStr);
        const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

        const reqOptions: https.RequestOptions = {
            protocol: u.protocol,
            hostname: u.hostname,
            path: u.pathname + u.search,
            method: method,
            headers: headers,
            agent: agent as any,
            rejectUnauthorized: false,
        };

        const req = https.request(reqOptions, (res) => {
            const chunks: Buffer[] = [];
            res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
            res.on("end", () => {
                const text = Buffer.concat(chunks).toString('utf8');
                resolve({ status: res.statusCode || 0, text });
            });
        });

        req.setTimeout(15_000, () => req.destroy(new Error("Timeout")));
        req.on("error", reject);
        if (body) req.write(body);
        req.end();
    });
}

// Bikin variabel global untuk cache token
let cachedVipToken: string | null = null;
let tokenExpirationTime: number = 0;

async function getGuestToken(): Promise<string> {
    const url = 'https://api-gateway-global.viu.com/api/auth/token?platform_flag_label=web&area_id=1000&language_flag_id=8&countryCode=ID&ut=0';
    const body = JSON.stringify({
        appVersion: "4.19.11",
        countryCode: "ID",
        language: "8",
        platform: "browser",
        platformFlagLabel: "web",
        uuid: "52b4ba02-0585-4918-9772-0db600db6cf1",
        carrierId: "0"
    });

    const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
        'Origin': 'https://www.viu.com',
        'Referer': 'https://www.viu.com/'
    };

    const res = await rawRequest(url, 'POST', headers, body);
    const data = JSON.parse(res.text);
    return data.token as string;
}

export async function refreshViuToken(): Promise<string> {
    const now = Date.now();

    if (cachedVipToken && tokenExpirationTime > (now + 5 * 60 * 1000)) {
        console.log("⚡ Menggunakan Cached VIP Token");
        return cachedVipToken;
    }

    console.log("🔄 Fetching Token VIP baru lewat Proxy...");

    // 1. Ambil guest token pakai helper murni https
    const guestToken = await getGuestToken();
    if (!guestToken) {
        throw new Error("Gagal mendapatkan guest token dari Viu.");
    }

    // 2. Eksekusi Login VIP
    const loginUrl = 'https://api-gateway-global.viu.com/api/auth/login';
    const loginBody = JSON.stringify({
        phone: process.env.VIU_PHONE || "6282229738027",
        password: process.env.VIU_PASSWORD || "Anak2016",
        provider: "phone"
    });

    const loginHeaders = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${guestToken}`,
        'Origin': 'https://umc-global.viu.com',
        'Referer': 'https://umc-global.viu.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'
    };

    const loginRes = await rawRequest(loginUrl, 'POST', loginHeaders, loginBody);
    let loginData;
    try {
        loginData = JSON.parse(loginRes.text);
    } catch (e) {
        console.error("Raw Login Response:", loginRes.text);
        throw new Error("Respon login bukan JSON valid.");
    }

    if (loginData?.token) {
        // Fix TS Error: Meng-cast token menjadi string secara eksplisit
        cachedVipToken = loginData.token as string;
        tokenExpirationTime = now + (24 * 60 * 60 * 1000);
        return cachedVipToken;
    } else {
        console.error("Login Response Error:", loginData);
        throw new Error("Gagal login ke Viu, cek kredensial atau blokir proxy.");
    }
}