import {
    ViuHomeResponse,
    ViuBanner,
    ViuSection,
    ViuMediaItem,
    ViuCategoryResponse,
    ViuSearchResponse,
    ViuDetailResponse,
    ViuEpisode
} from '@/types/viu';

// FUNGSI UTAMA: Mengubah data mentah Viu jadi ViuMediaItem
const mapToMediaItem = (item: any, type: 'series' | 'movie' | 'product' = 'series'): ViuMediaItem => ({
    id: item.product_id || item.series_id || item.id || '',
    seriesId: item.series_id || '',
    title: item.name || item.series_name || item.title || 'Untitled',
    synopsis: item.synopsis || item.description || '',
    thumbnail: item.cover_landscape_image_url || item.cover_image_url || item.thumbnail || '',
    portraitThumbnail: item.cover_portrait_image_url || '',
    isPremium: (item.premium_time > 0 && item.is_free_premium_time == 0) || false,
    episodeCount: String(item.number || item.product_number || item.episodeCount || '1'),
    category: item.category_id ? { id: String(item.category_id), name: item.category_name || '' } : undefined,
    type: type
});

export function mapViuHomeData(rawData: any): ViuHomeResponse {
    if (!rawData?.data) return { status: "error", banners: [], sections: [] };

    const banners: ViuBanner[] = (rawData.data.banner || []).map((b: any) => ({
        ...mapToMediaItem(b),
        imageUrl: b.image_url || b.product_image_url || '',
        targetUrl: b.image_navigation_url || ''
    }));

    const rawSections = [...(rawData.data.grid || []), ...(rawData.data.grid_plugins || [])];
    const sections: ViuSection[] = rawSections
        .map((g: any) => ({
            sectionId: g.grid_id || '',
            sectionName: g.name || 'Unnamed Section',
            description: g.description || '',
            items: (g.product || []).map((p: any) => mapToMediaItem(p))
        }))
        .filter((s) => s.items.length > 0);

    return { status: "success", banners, sections };
}

export function mapViuTabCategoriData(rawData: any): ViuCategoryResponse {
    if (!rawData?.data) return { status: "error", heroSection: [], series: [] };

    return {
        status: "success",
        heroSection: (rawData.data.category_series_total || []).map((c: any) => mapToMediaItem(c)),
        series: (rawData.data.series || []).map((s: any) => mapToMediaItem(s))
    };
}

export function mapViuSearchData(rawData: any): ViuSearchResponse {
    if (!rawData?.data) return { status: "error", results: [], totals: { series: 0, movie: 0, product: 0 } };

    const { data } = rawData;
    const seriesList = (data.series || []).map((s: any) => mapToMediaItem(s, 'series'));
    const movieList = (data.movie || []).map((m: any) => mapToMediaItem(m, 'movie'));
    const productList = (data.product || []).map((p: any) => mapToMediaItem(p, 'product'));

    return {
        status: "success",
        results: [...seriesList, ...movieList, ...productList],
        totals: {
            series: data.series_total?.total || 0,
            movie: data.movie_total?.total || 0,
            product: data.product_total?.total || 0
        }
    };
}

// Tambahkan ini di mapper.ts
export function mapViuDetailData(rawData: any, episodeRaw: any): ViuDetailResponse {
    // 1. Mapping Series Info (dari detail/vod/detail)
    const info = rawData?.data?.series || {};

    const detail: ViuMediaItem = {
        id: info.series_id || '',
        seriesId: info.series_id || '',
        title: info.name || 'Untitled',
        synopsis: info.description || '',
        thumbnail: info.cover_image_url || info.series_image_url || '',
        isPremium: false,
        episodeCount: String(info.product_total || '0'),
        category: info.category_id ? { id: String(info.category_id), name: info.category_name || '' } : undefined,
        type: 'series'
    };

    // 2. Mapping Episodes (dari vod/product-list)
    const episodes: ViuEpisode[] = (episodeRaw?.data?.product_list || []).map((p: any) => ({
        id: p.product_id || '',
        idEp: p.ccs_product_id || '',
        seriesId: p.series_id || '',
        name: p.synopsis || p.name || 'Episode',
        episodeNum: p.number || '0',
        coverEpisode: p.cover_image_url || p.cover_landscape_image_url || '',
        type: 'product'
    }));

    // 3. Return objek tunggal yang sesuai interface ViuDetailResponse
    return {
        status: "success",
        detail,
        episodes
    };
}

export function mapViuPlayData(
    detailRes: any,
    playRes: any,
    lang: string = 'id',
    qualityParam: string = '720'
) {
    const streamInfo = playRes?.data?.stream;
    if (!detailRes?.data?.current_product || !streamInfo) {
        return { status: "error", success: false };
    }

    const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';
    const makeProxy = (url: string, isSub: boolean = false) => {
        if (!url) return '';
        const proxyPath = `/api/viu/bikinsendirijing?url=${encodeURIComponent(url)}${isSub ? '&isSub=true' : ''}`;
        return SITE_URL ? `${SITE_URL}${proxyPath}` : proxyPath;
    };

    const drmmakeProxy = (url: string, isSub: boolean = false) => {
        if (!url) return '';
        const proxyPath = `/api/viu/drm-proxy?url=${encodeURIComponent(url)}${isSub ? '&isSub=true' : ''}`;
        return SITE_URL ? `${SITE_URL}${proxyPath}` : proxyPath;
    };

    // 1. Mapping Subtitles (Bentuk Array Vidio)
    const subtitles = (detailRes.data.current_product.subtitle || []).map((sub: any) => ({
        language: sub.name,
        url: sub.subtitle_url,
        url_proxy: makeProxy(sub.subtitle_url, true),
        code: sub.code
    }));

    // 2. Mapping Streams (Ambil HLS & DASH)
    const hlsData = streamInfo.url || {};
    const dashData = streamInfo.dashurl || {};

    // Viu pakai prefix 's' untuk resolusi (contoh: s720p, s1080p)
    let target = qualityParam.includes('p') ? qualityParam : `${qualityParam}p`;
    if (!target.startsWith('s')) target = `s${target}`;

    // Cari target HLS, fallback ke index 0 (kualitas paling rendah/tinggi yang tersedia) kalau gak ketemu
    let hlsUrl = hlsData[target];
    let hlsQuality = target;
    if (!hlsUrl && Object.keys(hlsData).length > 0) {
        hlsQuality = Object.keys(hlsData)[0];
        hlsUrl = hlsData[hlsQuality];
    }

    // Cari target DASH, fallback ke index 0 kalau gak ketemu
    let dashUrl = dashData[target];
    let dashQuality = target;
    if (!dashUrl && Object.keys(dashData).length > 0) {
        dashQuality = Object.keys(dashData)[0];
        dashUrl = dashData[dashQuality];
    }

    // Mapping Semua HLS
    const allHls = Object.entries(hlsData).map(([key, url]) => ({
        quality: key.replace('s', ''), // hilangin huruf 's' biar rapi (s720p -> 720p)
        url: url,
        url_proxy: makeProxy(url as string)
    }));

    // Mapping Semua DASH
    const allDash = Object.entries(dashData).map(([key, url]) => ({
        quality: key.replace('s', ''),
        url: url,
        url_proxy: makeProxy(url as string)
    }));

    // 3. Mapping DRM
    const isDrm = streamInfo.is_drm === 'y';
    const drm = isDrm && streamInfo.drm ? {
        licenseServers: {
            drm_license_url: streamInfo.drm.license_url,
            drm_license_url_proxy: drmmakeProxy(streamInfo.drm.license_url as string),
            certificateURL: streamInfo.drm.certificateURL // Ambil langsung dari streamInfo.drm
        },
        customData: {
            token: streamInfo.drm.token?.authorization,
        }
    } : null;

    // 4. Return Final (Struktur Rapi)
    return {
        success: true,
        hls: {
            url: hlsUrl || '',
            url_proxy: makeProxy(hlsUrl),
            quality: hlsQuality?.replace('s', '') || ''
        },
        dash: {
            url: dashUrl || '',
            url_proxy: makeProxy(dashUrl),
            quality: dashQuality?.replace('s', '') || ''
        },
        allHls: allHls,
        allDash: allDash,
        subtitles: subtitles,
        isDrm: isDrm,
        licenseServers: drm?.licenseServers || null,
        customData: drm?.customData || null
    };
}