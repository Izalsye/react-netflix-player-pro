import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

const VIU_BASE = process.env.VIU_BASE || 'https://api-gateway-global.viu.com';
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// Token default jika tidak ada header authorization dari client
const DEFAULT_VIU_TOKEN = process.env.VIU_DEFAULT_TOKEN || '';

const cache = new Map<string, { val: any, exp: number }>();

function buildViuHeaders(req: Request, targetHost: string = "api-gateway-global.viu.com"): Record<string, string> {
    const incomingHeaders = Object.fromEntries(req.headers.entries());

    // Viu mensupport gzip, deflate, br. Kita strip zstd agar node:zlib tidak error.
    let safeAcceptEncoding = incomingHeaders["accept-encoding"] || "gzip, deflate, br";
    safeAcceptEncoding = safeAcceptEncoding.replace(/,?\s*zstd/gi, '').trim();
    if (safeAcceptEncoding.startsWith(',')) safeAcceptEncoding = safeAcceptEncoding.substring(1).trim();

    const headers: Record<string, string> = {
        "Accept": incomingHeaders["accept"] || "application/json, text/plain, */*",
        "Accept-Encoding": safeAcceptEncoding,
        "Accept-Language": incomingHeaders["accept-language"] || "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": targetHost,
        "Origin": "https://www.viu.com",
        "Referer": incomingHeaders["referer"] || "https://www.viu.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
        "sec-ch-ua": incomingHeaders["sec-ch-ua"] || '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
        "sec-ch-ua-mobile": incomingHeaders["sec-ch-ua-mobile"] || "?0",
        "sec-ch-ua-platform": incomingHeaders["sec-ch-ua-platform"] || '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
    };

    // Sisipkan Cookie jika ada
    if (incomingHeaders["cookie"]) {
        headers["Cookie"] = incomingHeaders["cookie"];
    }
    if (incomingHeaders["content-type"]) {
        headers["Content-Type"] = incomingHeaders["content-type"];
    }

    // Sisipkan Authorization Bearer Token (Sangat penting untuk endpoint status/subscription Viu)
    const authHeader = incomingHeaders["authorization"] || DEFAULT_VIU_TOKEN;
    if (authHeader) {
        headers["Authorization"] = authHeader.startsWith('Bearer') ? authHeader : `Bearer ${authHeader}`;
    }

    return headers;
}

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

async function Get(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY
        ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false })
        : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);

                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function Post(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string> } = { label: 'viu-get' }
) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    let upstreamUrl = path;
    let targetHost = "api-gateway-global.viu.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
        upstreamUrl = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
    } else {
        const pathWithQuery = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
        upstreamUrl = `${VIU_BASE}${pathWithQuery}`;
        const u = new URL(VIU_BASE);
        targetHost = u.hostname;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${upstreamUrl}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(
                typeof hit.val === 'string' ? hit.val : JSON.stringify(hit.val),
                { headers: { 'Content-Type': typeof hit.val === 'string' ? 'text/html' : 'application/json', 'x-cache': 'HIT' } }
            );
        }
    }

    const headers = {
        ...buildViuHeaders(req, targetHost),
        ...opts.headers
    };

    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            if (status !== 200) {
                console.error(`[ProxyGet Error] Upstream status is ${status}`);
                return { error: true, status, message: "Upstream or Proxy failed" };
            }

            if (contentType.includes('text/html')) {
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: text, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return text;
            }

            try {
                const parsedJSON = JSON.parse(text);
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: parsedJSON, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return parsedJSON;
            } catch (parseError) {
                return text;
            }
        }

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        console.error(`[ViuProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; send?: boolean; headers?: Record<string, string> } = { label: 'viu-post' }
) {

    let upstreamUrl = path;
    let targetHost = "api-gateway-global.viu.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        upstreamUrl = `${VIU_BASE}${path}`;
        const u = new URL(VIU_BASE);
        targetHost = u.hostname;
    }

    const headers = { ...buildViuHeaders(req, targetHost), ...opts.headers };
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    const reqContentType = headers["Content-Type"] || headers["content-type"] || "application/json";

    try {
        const { status, contentType, text } = await Post(upstreamUrl, headers, stringBody, reqContentType, 15_000);
        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return text; }
        }
        return new Response(text, { status, headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}