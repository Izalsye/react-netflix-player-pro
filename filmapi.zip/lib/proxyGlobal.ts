import { recordHit } from './stats';
import { validateApiKey } from './apiKeyService';
import { NextResponse } from 'next/server';

interface ScrapeOptions {
    label?: string;
    cacheTtlSeconds?: number;
}

export async function proxyScrape(
    req: Request,
    targetUrl: string,
    scraperFn: (html: string) => any,
    opts: ScrapeOptions = { label: 'scrape', cacheTtlSeconds: 0 }
) {
    // 3. Fetch HTML ke Target Upstream (meniru Browser Asli)
    try {
        const fetchOptions: RequestInit = {
            method: 'GET',
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1"
            },
            // Gunakan Next.js cache bawaan
            next: { revalidate: opts.cacheTtlSeconds }
        };

        const response = await fetch(targetUrl, fetchOptions);

        if (!response.ok) {
            throw new Error(`Upstream responded with status: ${response.status}`);
        }

        const html = await response.text();

        // 4. Jalankan fungsi mapping HTML -> JSON (dari parameter route)
        const mappedData = scraperFn(html);

        // 5. Kembalikan Response JSON Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        console.error(`[proxyScrape Error] ${targetUrl}:`, error.message);
        return NextResponse.json({ code: 502, message: "Upstream fetch failed: " + error.message, data: null }, { status: 502 });
    }
}