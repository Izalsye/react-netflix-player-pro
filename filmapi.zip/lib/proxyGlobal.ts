import { NextResponse } from 'next/server';

interface ScrapeOptions {
    label?: string;
    // cacheTtlSeconds dihapus
}

export async function proxyScrape(
    req: Request,
    targetUrl: string,
    scraperFn: (html: string) => any,
    opts: ScrapeOptions = { label: 'scrape' }
) {
    try {
        const fetchOptions: RequestInit = {
            method: 'GET',
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1"
            },
            // Hilangkan cache sama sekali
            cache: 'no-store'
        };

        const response = await fetch(targetUrl, fetchOptions);

        // Handle 404 dengan aman tanpa melempar Error
        if (response.status === 404) {
            console.warn(`[proxyScrape 404] ${targetUrl}`);
            return NextResponse.json({
                code: 404,
                message: "Data tidak ditemukan (404 dari sumber)",
                data: null
            }, { status: 404 });
        }

        // Handle status error lain selain 2xx dan 404
        if (!response.ok) {
            throw new Error(`Upstream responded with status: ${response.status}`);
        }

        const html = await response.text();

        // Jalankan fungsi mapping HTML -> JSON
        const mappedData = scraperFn(html);

        // Kembalikan Response JSON Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        console.error(`[proxyScrape Error] ${targetUrl}:`, error.message);
        return NextResponse.json({
            code: 502,
            message: "Upstream fetch failed: " + error.message,
            data: null
        }, { status: 502 });
    }
}