// lib/proxyGlobal.ts
import { NextResponse } from 'next/server';

interface ScrapeOptions {
    label?: string;
}

export async function proxyScrapeRaw(
    targetUrl: string,
    scraperFn: (html: string) => any,
    opts: ScrapeOptions = { label: 'scrape' }
) {
    const fetchOptions: RequestInit = {
        method: 'GET',
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1"
        },
        cache: 'no-store'
    };

    const response = await fetch(targetUrl, fetchOptions);

    // 🔥 HANDLE 404 DENGAN THROW (Biar gak masuk ke Redis & Scraper batal jalan)
    if (response.status === 404) {
        console.warn(`[proxyScrape 404] ${targetUrl}`);
        throw { status: 404, message: "Data tidak ditemukan (404 dari sumber)" };
    }

    if (!response.ok) {
        throw { status: response.status, message: `Upstream responded with status: ${response.status}` };
    }

    const html = await response.text();

    // Jalankan fungsi mapping HTML -> JSON
    const mappedData = scraperFn(html);

    // Kembalikan Data Murni (Bukan NextResponse)
    return mappedData;
}