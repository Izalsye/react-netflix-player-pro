import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

// 👇 Base URL Target untuk WeTV
const WETV_BASE = "https://wetv.vip";

// 👇 Konfigurasi Proxy Opsional (Sangat disarankan pakai proxy/VPN luar jika server NextJS lu di region yang diblokir WeTV)
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// 👇 Default Cookie cadangan (Dari Log lu) jika client lupa ngirim cookie
const DEFAULT_WETV_COOKIE = process.env.WETV_COOKIES || '';

const cache = new Map<string, { val: any, exp: number }>();

// 👇 Helper pencocokan header otomatis sesuai log request WeTV
function buildWeTVHeaders(req: Request): Record<string, string> {
    const incomingHeaders = Object.fromEntries(req.headers.entries());

    return {
        "Accept": incomingHeaders["accept"] || "*/*",
        "Accept-Language": incomingHeaders["accept-language"] || "en-US,en;q=0.9",
        "Connection": "keep-alive",
        // Gunakan cookie dari client jika ada, kalau gak ada pakai default log
        "Cookie": incomingHeaders["cookie"] || DEFAULT_WETV_COOKIE,
        "Host": "wetv.vip",
        "Referer": incomingHeaders["referer"] || "https://wetv.vip/id",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
        "sec-ch-ua": incomingHeaders["sec-ch-ua"] || '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
        "sec-ch-ua-mobile": incomingHeaders["sec-ch-ua-mobile"] || "?0",
        "sec-ch-ua-platform": incomingHeaders["sec-ch-ua-platform"] || '"Windows"',
        "Sec-Fetch-Dest": incomingHeaders["sec-fetch-dest"] || "empty",
        "Sec-Fetch-Mode": incomingHeaders["sec-fetch-mode"] || "cors",
        "Sec-Fetch-Site": incomingHeaders["sec-fetch-site"] || "same-origin",
        // 🔥 PAKSA IDENTITY: Biar WeTV balikin teks polos/JSON biasa, gak dikompres gzip/br/zstd
        "Accept-Encoding": "identity"
    };
}

async function httpsGet(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
            },
            (res) => {
                let data = "";
                res.setEncoding("utf8");
                res.on("data", (chunk) => (data += chunk));
                res.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: data,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function httpsPost(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
            },
            (res) => {
                let data = "";
                res.setEncoding("utf8");
                res.on("data", (chunk) => (data += chunk));
                res.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: data,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    // 🎯 UPDATE: Tambahkan properti headers opsional di dalam opts
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string> } = { label: 'wetv-get' }
) {

    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    // 🛡️ PROTEKSI URL: Cek apakah base path udah bawa '?' dari sananya atau belum
    let pathWithQuery = path;
    if (qs) {
        pathWithQuery = path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(JSON.stringify(hit.val), {
                headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' },
            });
        }
    }

    // 🎯 LOGIC MERGE HEADERS: Gabungin header bawaan request dengan custom headers dari route
    const headers = {
        ...buildWeTVHeaders(req),
        ...opts.headers // Override Referer / Origin dari luar masuk ke sini
    };

    const upstreamUrl = `${WETV_BASE}${pathWithQuery}`;
    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await httpsGet(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return text; }
        }

        if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs && contentType.includes('application/json')) {
            try { cache.set(cacheKey, { val: JSON.parse(text), exp: Date.now() + opts.cacheTtlMs }); } catch { }
        }

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        console.error(`[wetvProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; contentType?: string } = { label: 'wetv-post' }
) {
    const bodyString = typeof body === 'string' ? body : JSON.stringify(body);
    const headers = buildWeTVHeaders(req);
    const upstreamUrl = `${WETV_BASE}${path}`;
    const cType = opts.contentType || req.headers.get('content-type') || "application/json";

    try {
        const { status, contentType, text } = await httpsPost(upstreamUrl, headers, bodyString, cType);

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        return NextResponse.json({ error: true, message: e.message }, { status: 502 });
    }
}