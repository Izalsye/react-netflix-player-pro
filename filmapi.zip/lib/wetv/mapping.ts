import {
    WeTVItem,
    WeTVHomeResponse,
    WeTVChannelResponse,
    WeTVPlayDetailResponse,
    WeTVStreamInfoResponse,
    WeTVExploreResponse
} from '@/types/wetv';

// 📑 Kamus lokal daftar nama channel WeTV berdasarkan ID-nya (Fallback Gate)
const WETV_CHANNELS: Record<string, string> = {
    '1001': 'Untukmu',
    '10370': 'FREE',
    '10108': 'Kolosal❤️‍🔥',
    '10003': 'Indonesia',
    '10054': 'Mandarin',
    '10022': 'Anime',
    '10336': 'Mini Series',
    '10473': 'Micro Drama',
    '10077': 'Korea',
    '10096': 'VarShow',
    '10062': 'Film'
};

// ==========================================
// 🛠️ SHARED HELPERS
// ==========================================

export function extractNextDataFromHtml(html: string): any {
    try {
        const match = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]*?)<\/script>/);
        if (match && match[1]) {
            return JSON.parse(match[1].trim());
        }
    } catch (e) {
        console.error("❌ Gagal mengekstrak __NEXT_DATA__", e);
    }
    return null;
}

function transformItem(item: any): WeTVItem {
    // 🧠 LOGIC BACA BADGE (VIP / EXPRES / SEWA)
    let badgeText = "";

    if (item.mark_label_list && typeof item.mark_label_list === 'object') {
        badgeText = item.mark_label_list["2"]?.text || item.mark_label_list["3"]?.text || "";
    } else if (item.markLabelList && Array.isArray(item.markLabelList) && item.markLabelList.length > 0) {
        badgeText = item.markLabelList[0]?.text || "";
    } else if (item.labels && typeof item.labels === 'object') {
        badgeText = item.labels["2"]?.text || item.labels["1"]?.text || "";
    } else if (item.labels && Array.isArray(item.labels)) {
        const vipLabel = item.labels.find((l: any) => l.text === "VIP");
        if (vipLabel) badgeText = "VIP";
    }

    const statusTxt = item.mark_label_list?.["1"]?.text
        || (Array.isArray(item.labels) ? item.labels.find((l: any) => l.text !== "VIP" && !isNaN(parseFloat(l.text)))?.text : item.labels?.["1"]?.text)
        || item.first_feature_time
        || item.update_desc_country
        || "";

    // Extract Tags if available
    let tags: string[] = [];
    if (item.tag_label_list && Array.isArray(item.tag_label_list)) {
        tags = item.tag_label_list.map((t: any) => t.text);
    }

    return {
        id: item.id || item.cid || "",
        title: item.title || "",
        subtitle: item.subtitle || item.secondTitle || "",
        coverVertical: item.img_list?.img_v || item.posterVt || item.pic || "",
        coverHorizontal: item.img_list?.img_h || item.img_list?.img_web_big || item.posterHz || item.pic || "",
        score: item.film_score || item.score || statusTxt || "0", // Fallback ke statusTxt kalau rating bentuknya angka
        badge: badgeText,
        statusText: statusTxt,
        tags: tags,
        episodes: item.episode_id || 0
    };
}

// ==========================================
// 🚀 MAIN MAPPING FUNCTIONS
// ==========================================

export function mapWeTVHomeJson(rawPayload: any): WeTVHomeResponse {
    const pageProps = rawPayload?.props?.pageProps || rawPayload?.pageProps || rawPayload;
    if (!pageProps) return { success: false, message: "Payload Home tidak valid." };

    const cleanTabs = (pageProps.channels || []).map((c: any) => ({
        id: c.channel?.id || "",
        name: c.channel?.name || "",
        pageType: c.channel?.page_type || ""
    }));

    const modules = pageProps.data?.modules || [];

    const carouselModule = modules.find((m: any) => m.type === "MODULE_TYPE_CAROUSEL");
    const hotModule = modules.find((m: any) => m.name === "WeTV Hot" || m.type === "MODULE_TYPE_RANK");
    const comingSoonModule = modules.find((m: any) => m.name === "Segera Tayang" || m.type === "MODULE_TYPE_CMS_TILING_PAGE");
    const latestModule = modules.find((m: any) => m.name === "Terbaru" || m.type === "MODULE_TYPE_SLIDE_PAGE");

    return {
        success: true,
        pageName: pageProps.pageName || "index",
        serverTime: pageProps.serverTime || new Date().toISOString(),
        menus: cleanTabs,
        sections: {
            banners: carouselModule?.items ? carouselModule.items.map(transformItem) : [],
            wetvHot: hotModule?.items ? hotModule.items.map(transformItem) : [],
            segeraTayang: comingSoonModule?.items ? comingSoonModule.items.map(transformItem) : [],
            terbaru: latestModule?.items ? latestModule.items.map(transformItem) : []
        }
    };
}

export function mapWeTVApiChannelJson(rawPayload: any, channelId?: string): WeTVChannelResponse {
    if (!rawPayload) return { success: false, namaChannel: "Unknown", totalModules: 0, modules: [] };

    let data = rawPayload;
    if (typeof rawPayload === 'string') {
        try { data = JSON.parse(rawPayload); } catch { return { success: false, namaChannel: "Unknown", totalModules: 0, modules: [] }; }
    }

    const resData = data?.response || data;
    const rawModules = resData?.modules || [];
    const cleanModules: any[] = [];

    let channelName = "Unknown";
    if (resData?.nodes && Array.isArray(resData.nodes)) {
        const matchedNode = resData.nodes.find((node: any) => node.channel?.id === channelId);
        if (matchedNode?.channel?.name) channelName = matchedNode.channel.name;
    }

    if ((channelName === "Unknown" || !resData?.nodes) && channelId) {
        channelName = WETV_CHANNELS[channelId] || `Channel ${channelId}`;
    }

    const validModuleTypes = ["MODULE_TYPE_CAROUSEL", "MODULE_TYPE_MODULE_ITEMS", "MODULE_TYPE_SLIDE_PAGE", "MODULE_TYPE_RANK"];

    rawModules.forEach((mod: any) => {
        if (validModuleTypes.includes(mod.type) && mod.items && mod.items.length > 0) {
            const mappedItems = mod.items.map(transformItem);
            cleanModules.push({
                moduleType: mod.type,
                moduleName: mod.name || "Rekomendasi",
                itemCount: mappedItems.length,
                items: mappedItems
            });
        }
    });

    return {
        success: true,
        namaChannel: channelName,
        totalModules: cleanModules.length,
        modules: cleanModules,
        pagination: {
            hasNextPage: resData?.has_next_page || false,
            nextPageContext: resData?.page_ctx || ""
        }
    };
}

export function mapWeTVNextPropsChannelJson(rawPayload: any, channelId?: string): WeTVChannelResponse {
    if (!rawPayload) return { success: false, namaChannel: "Unknown", totalModules: 0, modules: [] };

    let data = rawPayload;
    if (typeof rawPayload === 'string') {
        try { data = JSON.parse(rawPayload); } catch { return { success: false, namaChannel: "Unknown", totalModules: 0, modules: [] }; }
    }

    const props = data?.pageProps || data;
    const rawModules = props?.data?.modules || [];
    const rawChannels = props?.channels || [];
    const cleanModules: any[] = [];

    let channelName = "Unknown";
    if (channelId && Array.isArray(rawChannels)) {
        const matched = rawChannels.find((c: any) => c.channel?.id === channelId);
        if (matched?.channel?.name) channelName = matched.channel.name;
    }

    if (channelName === "Unknown" && channelId) {
        channelName = WETV_CHANNELS[channelId] || `Channel ${channelId}`;
    }

    const validModuleTypes = ["MODULE_TYPE_CAROUSEL", "MODULE_TYPE_MODULE_ITEMS", "MODULE_TYPE_SLIDE_PAGE", "MODULE_TYPE_RANK"];

    rawModules.forEach((mod: any) => {
        if (validModuleTypes.includes(mod.type) && mod.items && mod.items.length > 0) {
            const mappedItems = mod.items.map(transformItem);
            cleanModules.push({
                moduleType: mod.type,
                moduleName: mod.name || "Rekomendasi",
                itemCount: mappedItems.length,
                items: mappedItems
            });
        }
    });

    return {
        success: true,
        namaChannel: channelName,
        totalModules: cleanModules.length,
        modules: cleanModules,
        pagination: {
            hasNextPage: props?.data?.has_next_page || false,
            nextPageContext: props?.data?.page_ctx || ""
        }
    };
}

export function mapWeTVPlayDetailJson(rawPayload: any): WeTVPlayDetailResponse {
    if (!rawPayload) return { success: false, message: "Payload Detail Video tidak valid." };

    let pageProps = rawPayload?.pageProps || rawPayload;
    if (typeof rawPayload === 'string') {
        try { pageProps = JSON.parse(rawPayload)?.pageProps; } catch { return { success: false, message: "Gagal parse string payload." }; }
    }

    let innerData: any = {};
    if (typeof pageProps?.data === 'string') {
        try {
            innerData = JSON.parse(pageProps.data);
        } catch (e) {
            console.error("❌ Gagal unwrap string data dari hulu:", e);
        }
    } else if (pageProps?.data) {
        innerData = pageProps.data;
    }

    const cover = innerData?.coverInfo || {};
    const rawEpisodes = innerData?.videoList || [];
    const rawHot = pageProps?.hot || [];

    const mainEpisodes: any[] = [];
    const trailers: any[] = [];
    const extras: any[] = [];

    rawEpisodes.forEach((ep: any) => {
        const titleText = ep.title || "";
        const titleUpper = titleText.toUpperCase();
        const titleLower = titleText.toLowerCase();

        let epNum = ep.episode || ep.manEpisode || "0";
        if (epNum === "0" || epNum === "00" || !epNum) {
            let num = "0";
            let part = "";
            let type = "";

            const epMatch = titleText.match(/(?:EP|Episode|Epsidie)\s*(\d+)/i);
            if (epMatch) num = epMatch[1];

            const partMatch = titleText.match(/Part\s*(\d+(?:-\d+)?)/i);
            if (partMatch) part = `-${partMatch[1]}`;

            if (titleLower.includes("prolog")) num = "0";
            if (titleLower.includes("tambahan")) type = "-Extra";
            else if (titleLower.includes("temani hatiku") || titleText.includes('"')) type = "-Spesial";

            if (epMatch || partMatch || titleLower.includes("prolog")) {
                epNum = `${num}${type}${part}`;
            }
        }

        let badgeText = "";
        if (ep.markLabelList && Array.isArray(ep.markLabelList) && ep.markLabelList.length > 0) {
            badgeText = ep.markLabelList[0]?.text || "";
        } else if (ep.labels && typeof ep.labels === 'object') {
            badgeText = ep.labels["2"]?.text || ep.labels["1"]?.text || "";
        } else if (ep.isFree === false) {
            badgeText = "VIP";
        }

        const formattedVideo = {
            vid: ep.vid || "",
            title: titleText,
            episodeNumber: epNum,
            durationSeconds: ep.duration || 0,
            isFree: ep.isFree !== undefined ? !!ep.isFree : true,
            badge: badgeText,
            thumbnail: ep.pic_640_360 || ep.pic_496_280 || ep.pic_332_187 || ""
        };

        if (titleUpper.includes("TRAILER")) {
            trailers.push(formattedVideo);
        } else if (titleUpper.includes("BTS:") || titleUpper.includes("BLOOPERS") || titleUpper.includes("_CLIP")) {
            extras.push(formattedVideo);
        } else {
            mainEpisodes.push(formattedVideo);
        }
    });

    const genres = Array.from(new Set([
        ...(cover.mainGenres || []),
        ...(cover.subGenres || [])
    ]));

    return {
        success: true,
        pageName: pageProps.pageName || "play",
        series: {
            id: cover.cid || "",
            title: cover.title || "",
            subtitle: cover.secondTitle || "",
            description: cover.description || "",
            year: cover.year || "",
            region: cover.areaName || "",
            genres: genres as string[],
            score: cover.score || "0",
            coverVertical: cover.posterVt || "",
            coverHorizontal: cover.posterHz || "",
            episodeTotal: parseInt(cover.episodeAll || "0", 10),
            episodeUpdated: parseInt(cover.episodeUpdated || "0", 10),
            updateInfo: cover.updateInfo || ""
        },
        episodes: mainEpisodes,
        trailers: trailers,
        extras: extras,
        recommendations: rawHot.map((item: any) => transformItem(item))
    };
}

function cleanJsonpPayload(rawText: string): any {
    if (!rawText) return null;
    let cleanText = rawText.trim();
    if (cleanText.includes("(")) {
        cleanText = cleanText.substring(cleanText.indexOf("(") + 1);
        if (cleanText.endsWith(");")) {
            cleanText = cleanText.substring(0, cleanText.length - 2);
        } else if (cleanText.endsWith(")")) {
            cleanText = cleanText.substring(0, cleanText.length - 1);
        }
    }
    return JSON.parse(cleanText);
}

export function mapWeTVStreamInfoJson(rawPayload: any): WeTVStreamInfoResponse {
    let data = rawPayload;

    if (typeof rawPayload === 'string') {
        try {
            data = cleanJsonpPayload(rawPayload);
        } catch {
            return { success: false, message: "Gagal memproses format JSONP stream hulu." };
        }
    }

    if (!data || data.em > 0) {
        return {
            success: false,
            message: data?.msg || "Gagal mendapatkan izin stream. Video mungkin premium/VIP.",
            errCode: data?.em || -1
        };
    }

    const flInfo = data?.fl || {};
    const vlInfo = data?.vl?.vi?.[0] || {};
    const sflInfo = data?.sfl || {};

    const availableResolutions = (flInfo.fi || []).map((format: any) => ({
        id: format.id,
        name: format.name,
        resolution: format.resolution || format.cname,
        fileSizeByte: format.fs || 0
    }));

    let streamUrl = "";
    if (vlInfo.ul?.ui?.[0]) {
        const baseUrl = vlInfo.ul.ui[0].url || "";
        const hlsPath = vlInfo.ul.ui[0].hls?.pt || vlInfo.ul.ui[0].hls?.pname || "";
        streamUrl = `${baseUrl}${hlsPath}`;
    }

    const subtitles = (sflInfo.fi || []).map((sub: any) => {
        let subUrl = sub.url || "";
        if (sub.urlList?.ui?.[0]?.url) {
            subUrl = sub.urlList.ui[0].url;
        }
        return {
            id: sub.id,
            language: sub.name || "",
            langCode: sub.lang || "",
            url: subUrl,
            isSelected: sub.selected === 1
        };
    });

    return {
        success: true,
        previewDurationSeconds: data.preview || 0,
        ipAddress: data.ip || "",
        videoMeta: {
            vid: vlInfo.vid || "",
            title: vlInfo.ti || "",
            durationSeconds: parseFloat(vlInfo.td || "0"),
            audioTrack: vlInfo.ai?.name || "Audio Asli"
        },
        stream: {
            manifestUrl: streamUrl,
            resolutions: availableResolutions
        },
        subtitles: subtitles
    };
}

/**
 * 🧭 FUNGSI KEENAM: Mapper untuk API Explore (/explorar.json)
 */
export function mapWeTVExploreJson(rawPayload: any): WeTVExploreResponse {
    let data = rawPayload;
    if (typeof rawPayload === 'string') {
        try { data = JSON.parse(rawPayload); } catch { return { success: false, message: "Invalid JSON", filters: [], items: [], pagination: { hasNextPage: false, nextPageContext: "" } }; }
    }

    const pageData = data?.pageProps?.data || data?.data;

    if (!pageData) {
        return {
            success: false,
            message: "Data explore tidak ditemukan",
            filters: [],
            items: [],
            pagination: { hasNextPage: false, nextPageContext: "" }
        };
    }

    // 1. Ambil Filters (Untuk dropdown UI)
    const filters = pageData.filter?.dimensions?.map((dim: any) => ({
        paramKey: dim.key,
        name: dim.name,
        options: dim.options.map((opt: any) => ({
            name: opt.name,
            value: opt.value,
            isSelected: opt.is_selected || false
        }))
    })) || [];

    // 2. Ambil List Film
    const items = (pageData.albums || []).map((album: any) => {
        // Gunakan transformItem agar standard
        const item = transformItem(album);

        // Tambahkan description khusus untuk explore
        return {
            ...item,
            description: album.description || ""
        }
    });

    return {
        success: true,
        filters: filters,
        items: items,
        pagination: {
            hasNextPage: pageData.has_next_page || false,
            nextPageContext: pageData.page_ctx || ""
        }
    };
}

/**
 * 🔍 FUNGSI KEENAM: Untuk Hasil Pencarian (Search)
 */
export function mapWeTVSearchJson(rawPayload: any): any {
    const pageData = rawPayload?.pageProps?.data;

    if (!pageData) {
        return {
            success: false,
            message: "Data pencarian tidak ditemukan",
            data: null
        };
    }

    // Map Items / Hasil Pencarian
    const items = (pageData.result || []).map((item: any) => {
        // 🧠 LOGIC BACA BADGE (VIP / EXPRES / SEWA) dari objek labels
        let badgeText = "";
        let isVip = false;

        if (item.labels && typeof item.labels === 'object') {
            const labelValues = Object.values(item.labels) as any[];
            // Cek label VIP / Sewa
            const vipLabel = labelValues.find(l => l.text === "VIP" || l.text === "Sewa");
            if (vipLabel) {
                badgeText = vipLabel.text;
                isVip = true;
            } else if (labelValues.length > 0) {
                // Ambil label pertama aja kalau bukan VIP (misal: "Total 60 EP")
                badgeText = labelValues[0].text;
            }
        }

        // Gabung genre utama dan sub genre
        const tags = Array.from(new Set([
            ...(item.mainGenres || []),
            ...(item.subGenres || [])
        ]));

        return {
            id: item.cid || item.id || "",
            title: item.title || "Untitled",
            subtitle: item.secondTitle || item.subtitle || "",
            description: item.description || "",
            coverVertical: item.posterVt || item.pic || "",
            coverHorizontal: item.posterHz || item.pic || "",
            score: item.score || "0",
            badge: badgeText,
            tags: tags,
            isVip: isVip,
            year: item.year || "",
            region: item.areaName || "",
            episodeTotal: item.episodeAll ? parseInt(item.episodeAll, 10) : 0,
            episodeUpdated: item.episodeUpdated ? parseInt(item.episodeUpdated, 10) : 0,
        };
    });

    return {
        success: true,
        message: "Success mengambil data pencarian",
        data: {
            query: pageData.q || "",
            totalResults: pageData.count || 0,
            currentPage: pageData.cur || 1,
            items: items
        }
    };
}