// import puppeteer from 'puppeteer';

// export async function getWeTvData(cid: string, vid: string) {
//     console.log(`\n[Sniffer] Mulai mencari M3U8, KEYID, dan Subtitle untuk CID: ${cid}, VID: ${vid}...`);

//     const browser = await puppeteer.launch({
//         headless: false, // Balikin ke true biar enteng di background
//         executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
//         args: [
//             '--no-sandbox',
//             '--disable-setuid-sandbox',
//             '--autoplay-policy=no-user-gesture-required'
//         ]
//     });

//     const page = await browser.newPage();
//     await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36');

//     const capturedData = await new Promise((resolve) => {
//         let result = {
//             streamUrl: "",
//             keyId: "",
//             subtitleUrl: ""
//         };

//         const responseHandler = async (response: any) => {
//             const url = response.url();

//             // 1 & 2. TANGKAP M3U8 & EKSTRAK KEYID 
//             if (url.includes('.m3u8') && (url.includes('wetvinfo') || url.includes('svp_'))) {
//                 if (!result.streamUrl) {
//                     result.streamUrl = url;
//                     console.log(`[+] M3U8 URL Ditemukan!`);
//                 }

//                 if (!result.keyId) {
//                     try {
//                         const bodyText = await response.text();
//                         const match = bodyText.match(/KEYID=0x([A-F0-9a-f]+)/);

//                         if (match && match[1]) {
//                             result.keyId = match[1];
//                             console.log(`[+] KEYID Ditemukan: ${result.keyId}`);
//                         }
//                     } catch (err) { }
//                 }
//             }

//             // 3. TANGKAP URL SUBTITLE YANG VALID
//             if ((url.endsWith('.vtt') || url.endsWith('.srt') || url.includes('.vtt?') || url.includes('.srt?')) && !url.includes('.ts')) {
//                 if (!result.subtitleUrl) {
//                     result.subtitleUrl = url;
//                     console.log(`[+] Subtitle File Ditemukan!`);
//                 }
//             } else if (url.includes('api/getVideoInfo') || url.includes('getvinfo')) {
//                 try {
//                     const jsonResp = await response.json();
//                     if (jsonResp?.sfl?.fi && jsonResp.sfl.fi.length > 0) {
//                         result.subtitleUrl = jsonResp.sfl.fi[0].url;
//                         console.log(`[+] Subtitle URL Ditemukan dari JSON!`);
//                     }
//                 } catch (e) { }
//             }

//             // Selesaikan jika semua data sudah lengkap
//             if (result.streamUrl && result.keyId && result.subtitleUrl) {
//                 page.off('response', responseHandler);
//                 resolve(result);
//             }
//         };

//         page.on('response', responseHandler);

//         // Timeout kembali ke 15 detik standar
//         setTimeout(() => {
//             console.warn("\n[Sniffer] ⏱️ Timeout 15 detik habis. Mengembalikan data yang berhasil ditangkap...");
//             resolve(result);
//         }, 15000);

//         page.goto(`https://wetv.vip/id/play/${cid}/${vid}`, { waitUntil: 'domcontentloaded' })
//             .then(async () => {
//                 try {
//                     await page.waitForSelector('video', { timeout: 5000 });
//                 } catch (e) { }
//             })
//             .catch(() => { });
//     });

//     await browser.close();
//     return capturedData;
// }