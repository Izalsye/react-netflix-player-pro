import { generateCKey } from './ckey';

export class WeTVCore {
    private ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36";

    // 🔥 Simpan cookie di memory server. Ambil awalan dari .env (opsional)
    private activeCookie: string = process.env.WETV_COOKIES || "";

    private get headers() {
        return {
            "User-Agent": this.ua,
            "Cookie": this.activeCookie // 👈 Pake yang ada di memory, bukan .env lagi
        };
    }

    private _generateGuid(): string {
        return Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    }

    // 🔥 HELPER BUAT GABUNGIN COOKIE BIAR GAK DUPLIKAT (ANTI 403 WAF)
    private mergeCookies(oldCookie: string, rawNewCookies: string[]): string {
        const cookieMap = new Map<string, string>();

        // 1. Ekstrak dan simpan cookie lama
        oldCookie.split(';').forEach(pair => {
            const parts = pair.trim().split('=');
            if (parts[0]) cookieMap.set(parts[0], parts.slice(1).join('='));
        });

        // 2. Timpa dengan cookie baru hasil auto-heal
        rawNewCookies.forEach(pair => {
            const cleanCookie = pair.split(';')[0].trim(); // Buang "Path=/; Domain=..."
            const parts = cleanCookie.split('=');
            if (parts[0]) cookieMap.set(parts[0], parts.slice(1).join('='));
        });

        // 3. Rakit ulang jadi satu string rapi dan bersih
        return Array.from(cookieMap.entries()).map(([k, v]) => `${k}=${v}`).join('; ');
    }

    async refreshVipCookie() {
        console.log("🔄 [WeTV] Memperbarui Cookie VIP secara otomatis...");

        // 🔥 PENTING: Gunakan GUID yang SAMA PERSIS dengan asal muasal auth_info & h38_sign lu!
        // JANGAN pakai this._generateGuid() di sini!
        const fixedGuid = "1a97c928d7b7b4d9e6188bf2eda617bf";

        try {
            const url = `https://pbaccess.wetv.vip/trpc_web_login.WebLogin/Login?vappid=50560306&vsecret=f6b675fbb1ec757c3e4486954a06c21299b9ddaedb230ad6&vplatform=2&raw=1&video_appid=1200004&guid=${fixedGuid}`;

            const response = await fetch(url, {
                method: "POST",
                cache: "no-store", // Wajib biar Next.js ga nge-cache
                headers: {
                    "Accept": "application/json, text/plain, */*",
                    "Content-Type": "application/json",
                    "Origin": "https://wetv.vip",
                    "Referer": "https://wetv.vip/id",
                    "User-Agent": this.ua,
                    "Cookie": this.activeCookie,
                    // Pastikan h38_sign ini pasangan asli dari auth_info di bawah
                    "h38_sign": "000000014068b89153f4562362f80aafc61e5f2b1f1bbe9f47f26dad070abd18f1840856efa7dfb8b39ea9fd5e612dcfa466e132700e128a52734a5183ca9b054eb4904d071ce9053a971f3e6feda483550b50f609b9fd4b0ec83d6db51719869479e9bc380e39cc4381609eb2dbc764027698bff7d91c0f51029a8044a2771cf65bdc18505e611ef44148208e788e5ccbfecb60a4c6adebc9094e5c92ef13af8ab865d95d65385577c48ea7340981c67fabd495f14015ebecfe00872b0be0dbfe9d3d7ef26cb4af665b5a1f6f184bcfe2a2c731a28c28da2f8b570276"
                },
                body: JSON.stringify({
                    "account": { "user_id": "82229738027", "user_type": 3, "area_id": "+62" },
                    "auth_info": "4c3a011751150bf2c8082cfec21633c294c65d1413ae2238f1999c9ac7d0adba4d8d797b99b008d8d8d2ec6309b3f2d3725d212369ba1ab26c9c5ce1dfae28860a1671d0fa736ae1da910e6dc02022e1a1f6c622760ad5a9836d37ffbb81284eed6e3e5fe7078a9bd70f02a2dfc600ed4b39c8e7753fbadcc16c76ec1de0881847e26f0725d734593b823414d5462dc06f0ba5401d8f6b665ee7cae1fb83be5ceeda67d94440f140ad40c921040f49bcfdd95fa8ca0f62159e195c2ebcd1cfffc0850a8ae91a92dc50bea4fc79fc40236235575950e3c1e972a97f7155f17b752c4631c07ad0ad1b95335115c288cce3632ba7911b0ba0e954176dba3a3017729638eacd03f6ec0b21ed775d49c0745f15dd6b1e2085c82e62369133a66d",
                    "key_info": {
                        "client_pub": "041793eaf15458b544eec1903070600540652373f158530a9f49583b65f638a13bd0708d646dcf75b31424197fb5066690a0f8c9cf8467ee56b083a1adb069b6a4",
                        "key_version": 1
                    }
                })
            });

            const data = await response.json();
            if (data.ret === 0) {
                let rawCookies: string[] = [];
                if (typeof response.headers.getSetCookie === 'function') {
                    rawCookies = response.headers.getSetCookie();
                } else {
                    const setCookieHeader = response.headers.get('set-cookie');
                    if (setCookieHeader) {
                        rawCookies = setCookieHeader.split(/,(?=\s*[a-zA-Z0-9_-]+\=)/);
                    }
                }

                if (rawCookies.length > 0) {
                    this.activeCookie = this.mergeCookies(this.activeCookie, rawCookies);
                    console.log("✅ [WeTV] Cookie VIP berhasil di-merge tanpa duplikat!");
                } else {
                    console.warn("⚠️ [WeTV] Server membalas ret:0 tapi menolak memberikan Cookie (Kemungkinan Signature Expired).");
                    // 🔥 JANGAN KOSONGIN ACTIVE COOKIE KALAU GAGAL DAPET COOKIE BARU!
                }
            }
        } catch (e) {
            console.error("❌ [WeTV] Error saat menyedot cookie:", e);
        }
    }

    // 1️⃣ GENERATE URL PLAY & STREAM FORMATS
    async getPlayUrl(vid: string, cid: string, req: Request, defn: string = "fhd", isRetry: boolean = false): Promise<any> {
        const guid = this._generateGuid();
        const tm = String(Math.floor(Date.now() / 1000));
        const platform = "4830201";
        const appVer = "3.8.2";

        // 🔥 CKey dengan 5 Parameter (Terbukti Valid)
        const ckey = generateCKey(vid, tm, appVer, guid, platform);

        const clientIp = "103.174.114.204";

        const params = new URLSearchParams({
            vid, cid, platform, appVer, defn, charge: "0", otype: "json",
            guid, tm, cKey: ckey, encryptVer: "8.1",
            sphttps: "1", host: "play.wetvinfo.com", ehost: "play.wetvinfo.com",
            refer: "wetv.vip", sdtfrom: "v1090", splatid: platform,
            drm_type: "4", spdrm: "3", sphdr: "2", spwm: "4", dtype: "3",
            defnpayver: "1", spau: "1", spvvpay: "1", spadseg: "3",
            spsrt: "2", spfl: "1", deession: guid + ".0." + tm,
        });

        try {
            const response = await fetch(`https://play.wetvinfo.com/getvinfo?${params.toString()}`, {
                headers: { ...this.headers, "X-Forwarded-For": clientIp }
            });

            let rawText = await response.text();
            if (rawText.startsWith("QZOutputJson=")) rawText = rawText.slice(13);
            if (rawText.endsWith(";")) rawText = rawText.slice(0, -1);

            const data = JSON.parse(rawText);

            // 🔥 JEBAKAN AUTO-HEAL 1: Nangkep Error 83 (Pay Limit / Cookie Expired)
            if ((data.code === 83 || data.em === 83) && !isRetry) {
                console.warn("⚠️ [WeTV] Error 83 (Pay Limit). Cookie VIP Expired! Memulai Sedot Cookie...");
                await this.refreshVipCookie(); // Sedot cookie baru
                return await this.getPlayUrl(vid, cid, req, defn, true); // Tembak ulang pakai cookie baru!
            }

            if (data.vl) {
                const vi = data.vl.vi[0];

                // 🔥 JEBAKAN AUTO-HEAL 2: Nangkep limit preview WeTV
                const previewDur = data.preview ? parseFloat(data.preview) : 0;
                const totalDur = vi.td ? parseFloat(vi.td) : 0;
                if (previewDur > 0 && previewDur < totalDur && !isRetry) {
                    console.warn(`⚠️ [WeTV] Limit VIP (Preview) kedetect di video ${vid}. Mencoba sedot cookie baru...`);
                    await this.refreshVipCookie();
                    return await this.getPlayUrl(vid, cid, req, defn, true);
                }

                const ui = vi.ul?.ui?.[0] || {};
                const hls = ui.hls || {};
                const hlsFile = hls.pt || hls.pname || "";
                const playUrl = ui.url + hlsFile;
                const fmtId = hlsFile.match(/f(\d+)/)?.[1] || "";
                const fmtIdNum = parseInt(fmtId);
                const maxFmt = Math.max(fmtIdNum, 321003);

                // 🔥 PERUBAHAN 1: Ganti "playUrl" jadi "url" di dalam array resolutions
                const formats = (data.fl?.fi || []).filter((f: any) => f.id <= maxFmt || f.id === 321007).map((f: any) => ({
                    name: f.name, resolution: f.cname || f.resolution, drm: f.drm,
                    url: ui.url + hlsFile.replace("f" + fmtId, "f" + f.id),
                }));
                const subs = (data.sfl?.fi || []).map((s: any) => ({ lang: s.lang, name: s.name, url: s.url }));

                // 🔥 PERUBAHAN 2: Ganti nama properti yang di-return jadi "url" dan "resolutions"
                return { url: playUrl, resolutions: formats, subtitles: subs, vid: vi.lnk, preview: data.preview, duration: vi.td || 0, baseUrl: ui.url };
            }

            // Kalau nggak dapet data.vl dan bukan error 83, lempar balasan aslinya
            return data;
        } catch (e: any) {
            return { error: e.message };
        }
    }

    // 2️⃣ CDN PART DISCOVERY (BYPASS VIP PREVIEW LIMIT)
    async getFullM3u8(vid: string, cid: string, req: Request, defn: string = "shd", proxyBase: string = "") {
        const data = await this.getPlayUrl(vid, cid, req, defn);

        if (!data.url) return null;
        const m3u8Url = data.url;

        const baseUrl = m3u8Url.substring(0, m3u8Url.lastIndexOf("/") + 1);

        const resp = await fetch(m3u8Url, { headers: this.headers });

        // 🔥 KEMBALIKAN KE EXPRESS: Ambil raw text, JANGAN dibersihkan \r nya
        const m3u8Text = await resp.text();

        const duration = parseFloat(data.duration) || 0;
        const preview = data.preview ? parseFloat(data.preview) : 0;
        const isVip = preview > 0 && preview < duration;

        if (!isVip) {
            return m3u8Text.replace(/^([^#\n][^\n]*\.ts[^\n]*)/gm, (line) =>
                line.startsWith("http") ? line : baseUrl + line
            );
        }

        const segMatch = m3u8Text.match(/\d+_(gzc_[^.]+\.f\d+)\.\d+\.ts/);
        if (!segMatch) {
            return m3u8Text.replace(/^([^#\n][^\n]*\.ts[^\n]*)/gm, (line) =>
                line.startsWith("http") ? line : baseUrl + line
            );
        }

        const fileBase = segMatch[1];
        const lines = m3u8Text.split("\n");
        const previewSegs: { extinf: string, url: string }[] = [];
        let lastPreviewBre = 0;

        for (let i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("#EXTINF:")) {
                const segLine = lines[i + 1] || "";
                if (segLine && !segLine.startsWith("#")) {
                    const url = segLine.startsWith("http") ? segLine : baseUrl + segLine;
                    previewSegs.push({ extinf: lines[i], url });
                    const breMatch = url.match(/bre=(\d+)/);
                    if (breMatch) lastPreviewBre = parseInt(breMatch[1]);
                }
            }
        }

        let part1RemainSize = 0;
        try {
            const url = `${baseUrl}00_${fileBase}.1.ts?index=0&start=0&end=1000&brs=0&bre=999999999&ver=4`;
            const r = await fetch(url, { method: 'HEAD' });
            if (r.ok || r.status === 206) {
                const fullSize = parseInt(r.headers.get("content-length") || "0");
                part1RemainSize = Math.max(0, fullSize - (lastPreviewBre + 1));
            }
        } catch { }

        const parts: { part: number, size: number }[] = [];
        for (let p = 2; p <= 10; p++) {
            const url = `${baseUrl}00_${fileBase}.${p}.ts?index=0&start=0&end=1000&brs=0&bre=999999&ver=4`;
            try {
                const r = await fetch(url, { method: 'HEAD' });
                if (r.ok || r.status === 206) {
                    parts.push({ part: p, size: parseInt(r.headers.get("content-length") || "0") });
                } else break;
            } catch { break; }
        }

        const previewDur = previewSegs.reduce((s, seg) => s + parseFloat(seg.extinf.replace("#EXTINF:", "")), 0);
        const remainDur = duration - previewDur;

        // 🔥 KEMBALIKAN KE EXPRESS: Versi 3 murni
        let out = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-TARGETDURATION:13\n";

        for (const seg of previewSegs) {
            out += `${seg.extinf}\n${seg.url}\n`;
        }
        // 🔥 KEMBALIKAN KE EXPRESS: Tanpa embel-embel cache buster ?t=...
        out += `#EXT-X-MAP:URI="${proxyBase}/api/wetv/init.ts"\n`;

        const totalBytes = part1RemainSize + parts.reduce((s, p) => s + p.size, 0);
        const bytesPerSec = totalBytes / (remainDur || 1);
        const segBytes = Math.floor((bytesPerSec * 10) / 188) * 188;

        const addPartSegments = (partNum: number, size: number, startBrs: number) => {
            const partDur = remainDur * (size / totalBytes);
            let offset = 0;
            while (offset < size) {
                const end = Math.min(offset + segBytes, size);
                const actualEnd = Math.floor(end / 188) * 188;
                const bre = startBrs + (actualEnd || end) - 1;
                out += `#EXTINF:${((partDur * ((actualEnd || end) - offset)) / size).toFixed(3)},\n`;
                out += `${baseUrl}00_${fileBase}.${partNum}.ts?index=0&start=0&end=1000&brs=${startBrs + offset}&bre=${bre}&ver=4\n`;
                offset = actualEnd || end;
            }
        };

        if (part1RemainSize > 0) addPartSegments(1, part1RemainSize, lastPreviewBre + 1);
        for (const { part, size } of parts) addPartSegments(part, size, 0);

        out += "#EXT-X-ENDLIST\n";
        return out;
    }
}