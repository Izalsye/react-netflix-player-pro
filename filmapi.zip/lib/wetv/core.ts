import { generateCKey } from './ckey';

export class WeTVCore {
    private ua = "Mozilla/5.0 (Linux; Android 14; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    // 🔥 SUNTIK COOKIE VIP KE REQUEST HEADERS
    private get headers() {
        return {
            "User-Agent": this.ua,
            "Cookie": process.env.WETV_COOKIES || ""
        };
    }

    private _generateGuid(): string {
        return Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    }

    // 1️⃣ GENERATE URL PLAY & STREAM FORMATS
    async getPlayUrl(vid: string, cid: string, req: Request, defn: string = "fhd") {
        const guid = this._generateGuid();
        const tm = String(Math.floor(Date.now() / 1000));
        const platform = "4830201";
        const appVer = "3.8.2";
        const ckey = generateCKey(vid, tm, appVer, guid, platform);

        const clientIp = req.headers.get('x-forwarded-for') || "113.160.100.50";

        const params = new URLSearchParams({
            vid, cid, platform, appVer, defn, charge: "0", otype: "json",
            guid, tm, cKey: ckey, encryptVer: "8.1",
            sphttps: "1", host: "play.wetvinfo.com", ehost: "play.wetvinfo.com",
            refer: "wetv.vip", sdtfrom: "v1090", splatid: platform,
            drm_type: "4", spdrm: "3", sphdr: "2", spwm: "4", dtype: "3",
            defnpayver: "1", spau: "1", spvvpay: "1", spadseg: "3",
            spsrt: "2", spfl: "1", deession: guid + ".0." + tm,
        });

        try {
            const response = await fetch(`https://play.wetvinfo.com/getvinfo?${params.toString()}`, {
                headers: { ...this.headers, "X-Forwarded-For": clientIp }
            });

            let rawText = await response.text();
            if (rawText.startsWith("QZOutputJson=")) rawText = rawText.slice(13);
            if (rawText.endsWith(";")) rawText = rawText.slice(0, -1);

            const data = JSON.parse(rawText);

            if (data.vl) {
                const vi = data.vl.vi[0];
                const ui = vi.ul?.ui?.[0] || {};
                const hls = ui.hls || {};
                const hlsFile = hls.pt || hls.pname || "";
                const playUrl = ui.url + hlsFile;
                const fmtId = hlsFile.match(/f(\d+)/)?.[1] || "";
                const fmtIdNum = parseInt(fmtId);
                const maxFmt = Math.max(fmtIdNum, 321003);

                // 🔥 PERUBAHAN 1: Ganti "playUrl" jadi "url" di dalam array resolutions
                const formats = (data.fl?.fi || []).filter((f: any) => f.id <= maxFmt || f.id === 321007).map((f: any) => ({
                    name: f.name, resolution: f.cname || f.resolution, drm: f.drm,
                    url: ui.url + hlsFile.replace("f" + fmtId, "f" + f.id),
                }));
                const subs = (data.sfl?.fi || []).map((s: any) => ({ lang: s.lang, name: s.name, url: s.url }));

                // 🔥 PERUBAHAN 2: Ganti nama properti yang di-return jadi "url" dan "resolutions"
                return { url: playUrl, resolutions: formats, subtitles: subs, vid: vi.lnk, preview: data.preview, duration: vi.td || 0, baseUrl: ui.url };
            }
            return data;
        } catch (e: any) {
            return { error: e.message };
        }
    }

    // 2️⃣ CDN PART DISCOVERY (BYPASS VIP PREVIEW LIMIT)
    async getFullM3u8(vid: string, cid: string, req: Request, defn: string = "shd", proxyBase: string = "") {
        const data = await this.getPlayUrl(vid, cid, req, defn);

        if (!data.url) return null;
        const m3u8Url = data.url;

        const baseUrl = m3u8Url.substring(0, m3u8Url.lastIndexOf("/") + 1);

        const resp = await fetch(m3u8Url, { headers: this.headers });

        // 🔥 KEMBALIKAN KE EXPRESS: Ambil raw text, JANGAN dibersihkan \r nya
        const m3u8Text = await resp.text();

        const duration = parseFloat(data.duration) || 0;
        const preview = data.preview ? parseFloat(data.preview) : 0;
        const isVip = preview > 0 && preview < duration;

        if (!isVip) {
            return m3u8Text.replace(/^([^#\n][^\n]*\.ts[^\n]*)/gm, (line) =>
                line.startsWith("http") ? line : baseUrl + line
            );
        }

        const segMatch = m3u8Text.match(/\d+_(gzc_[^.]+\.f\d+)\.\d+\.ts/);
        if (!segMatch) {
            return m3u8Text.replace(/^([^#\n][^\n]*\.ts[^\n]*)/gm, (line) =>
                line.startsWith("http") ? line : baseUrl + line
            );
        }

        const fileBase = segMatch[1];
        const lines = m3u8Text.split("\n");
        const previewSegs: { extinf: string, url: string }[] = [];
        let lastPreviewBre = 0;

        for (let i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("#EXTINF:")) {
                const segLine = lines[i + 1] || "";
                if (segLine && !segLine.startsWith("#")) {
                    const url = segLine.startsWith("http") ? segLine : baseUrl + segLine;
                    previewSegs.push({ extinf: lines[i], url });
                    const breMatch = url.match(/bre=(\d+)/);
                    if (breMatch) lastPreviewBre = parseInt(breMatch[1]);
                }
            }
        }

        let part1RemainSize = 0;
        try {
            const url = `${baseUrl}00_${fileBase}.1.ts?index=0&start=0&end=1000&brs=0&bre=999999999&ver=4`;
            const r = await fetch(url, { method: 'HEAD' });
            if (r.ok || r.status === 206) {
                const fullSize = parseInt(r.headers.get("content-length") || "0");
                part1RemainSize = Math.max(0, fullSize - (lastPreviewBre + 1));
            }
        } catch { }

        const parts: { part: number, size: number }[] = [];
        for (let p = 2; p <= 10; p++) {
            const url = `${baseUrl}00_${fileBase}.${p}.ts?index=0&start=0&end=1000&brs=0&bre=999999&ver=4`;
            try {
                const r = await fetch(url, { method: 'HEAD' });
                if (r.ok || r.status === 206) {
                    parts.push({ part: p, size: parseInt(r.headers.get("content-length") || "0") });
                } else break;
            } catch { break; }
        }

        const previewDur = previewSegs.reduce((s, seg) => s + parseFloat(seg.extinf.replace("#EXTINF:", "")), 0);
        const remainDur = duration - previewDur;

        // 🔥 KEMBALIKAN KE EXPRESS: Versi 3 murni
        let out = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-TARGETDURATION:13\n";

        for (const seg of previewSegs) {
            out += `${seg.extinf}\n${seg.url}\n`;
        }

        // 🔥 KEMBALIKAN KE EXPRESS: Tanpa embel-embel cache buster ?t=...
        out += `#EXT-X-MAP:URI="${proxyBase}/api/wetv/init.ts"\n`;

        const totalBytes = part1RemainSize + parts.reduce((s, p) => s + p.size, 0);
        const bytesPerSec = totalBytes / (remainDur || 1);
        const segBytes = Math.floor((bytesPerSec * 10) / 188) * 188;

        const addPartSegments = (partNum: number, size: number, startBrs: number) => {
            const partDur = remainDur * (size / totalBytes);
            let offset = 0;
            while (offset < size) {
                const end = Math.min(offset + segBytes, size);
                const actualEnd = Math.floor(end / 188) * 188;
                const bre = startBrs + (actualEnd || end) - 1;
                out += `#EXTINF:${((partDur * ((actualEnd || end) - offset)) / size).toFixed(3)},\n`;
                out += `${baseUrl}00_${fileBase}.${partNum}.ts?index=0&start=0&end=1000&brs=${startBrs + offset}&bre=${bre}&ver=4\n`;
                offset = actualEnd || end;
            }
        };

        if (part1RemainSize > 0) addPartSegments(1, part1RemainSize, lastPreviewBre + 1);
        for (const { part, size } of parts) addPartSegments(part, size, 0);

        out += "#EXT-X-ENDLIST\n";
        return out;
    }
}