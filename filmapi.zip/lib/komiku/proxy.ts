// lib/komiku/proxy.ts
import { validateApiKey } from '../apiKeyService';
import { recordHit } from '../stats';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";

const KOMIKU_BASE = process.env.KOMIKU_BASE || 'https://komiku.org';

const requestHeaders = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "Cache-Control": "no-cache",
    "Referer": `${KOMIKU_BASE}/`
};

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

// 🎯 FIX: GetHtml dengan fitur Follow Redirect (maxRedirects)
async function GetHtml(
    urlStr: string,
    customHeaders: Record<string, string> = {},
    timeoutMs = 15_000,
    maxRedirects = 5 // Batas maksimal ikut redirect
): Promise<{ status: number; text: string }> {

    if (maxRedirects === 0) {
        return Promise.reject(new Error("Terlalu banyak redirect (301/302)"));
    }

    const u = new URL(urlStr);

    // 🎯 FIX TYPESCRIPT: Kasih tipe Record<string, string>
    const finalHeaders: Record<string, string> = {
        ...requestHeaders,
        ...customHeaders,
        "Host": u.hostname
    };

    return new Promise((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers: finalHeaders,
                rejectUnauthorized: false, // Bypass SSL ketat kalau ada
            },
            (res) => {
                const statusCode = res.statusCode || 0;

                // 🎯 FIX: Kalau server nyuruh pindah (301, 302, dll), kita ikutin!
                if (statusCode >= 300 && statusCode < 400 && res.headers.location) {
                    const redirectUrl = new URL(res.headers.location, urlStr).toString();

                    // Panggil ulang fungsinya pakai URL baru (Rekursif)
                    resolve(GetHtml(redirectUrl, customHeaders, timeoutMs, maxRedirects - 1));
                    return;
                }

                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: statusCode,
                        text: text,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

export async function proxyGetHtml(
    req: Request,
    path: string,
    opts: { label: string; send?: boolean; headers?: Record<string, string> } = { label: 'komiku-html' }
) {
    // Pastikan path selalu valid
    let upstreamUrl = path;
    let targetHost = "komiku.org"; // Default host

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        const cleanPath = path.startsWith('/') ? path : `/${path}`;
        upstreamUrl = `${KOMIKU_BASE}${cleanPath}`;
    }

    const finalOpts = { ...opts };
    finalOpts.headers = { ...finalOpts.headers, "Host": targetHost };

    try {
        const { status, text } = await GetHtml(upstreamUrl, finalOpts.headers || {}, 15_000);

        // 🚀 LOGGING STATUS
        if (status !== 200) {
            // console.error(`[Proxy] Failed! Status: ${status}, Response Head: ${text?.substring(0, 200)}...`);
        }

        if (opts.send === false) {
            if (status !== 200) {
                // console.log("[Proxy] Error Text Content:", text);
                // Kalau mau strictly balikin error object pas gagal, uncomment baris di bawah:
                return { error: true, status, message: `Upstream failed with status ${status}` };
            }
            return text; // 🎯 Mengembalikan STRING HTML Mentah
        }

        return new Response(text, { status, headers: { 'Content-Type': 'text/html' } });
    } catch (e: any) {
        // 🚀 LOGGING ERROR
        console.error(`[Proxy] Caught error:`, e.message);
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        if (opts.send === false) return { error: true, status: 502, message: msg };
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502 });
    }
}