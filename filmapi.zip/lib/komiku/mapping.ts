// lib/komiku/mapping.ts
import * as cheerio from 'cheerio';
import {
    KomikuCard,
    KomikuSection,
    KomikuHomeResponse,
    KomikuDetailResponse,
    KomikuChapterItem,
    KomikuChildSection,
    KomikuTerbaruResponse,
    KomikuFilterGroup,
    KomikuFilterOption,
    KomikuFiltersResponse,
    KomikuSearchResponse,
    KomikuImage,
    KomikuViewResponse,
} from '@/types/komiku';

const BASE_URL = "https://komiku.org";
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL
    ? process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, '')
    : "http://localhost:3000";

// --- UTILITY SCRAPING ---
function normalizeText(value: string | undefined): string {
    return (value || "").replace(/\s+/g, " ").trim();
}

function cleanTitle(value: string | undefined): string {
    return normalizeText(value)
        .replace(/^Baca\s+(Komik|Manga|Manhwa|Manhua)?\s*/i, "")
        .replace(/^Komik\s+/i, "")
        .trim();
}

function getAbsoluteUrl(url: string | undefined): string {
    if (!url || url.startsWith("data:")) return "";
    try {
        return new URL(url, BASE_URL).toString();
    } catch {
        return "";
    }
}

function extractMangaSlug(url: string | undefined): string {
    if (!url) return "";
    const match = url.match(/\/manga\/([^/]+)/i);
    return match ? match[1] : "";
}

// 🎯 FUNGSI BARU: Nangkep Slug Asli dari URL Chapter (Biar gak kena jebakan)
export function extractChapterSlug(url: string | undefined): string {
    if (!url) return "";
    const match = url.match(/\/([^/]+)-chapter-[^/]+\/?$/i);
    return match ? match[1] : "";
}

function extractChapterNumber(url: string | undefined): string {
    if (!url) return "";
    const chapterNumberPattern = "([\\d]+(?:[.-]\\d+)*)";
    const match =
        url.match(new RegExp(`-chapter-${chapterNumberPattern}/?$`, "i")) ||
        url.match(new RegExp(`/chapter/${chapterNumberPattern}/?$`, "i")) ||
        url.match(new RegExp(`/${chapterNumberPattern}/?$`, "i"));
    return match ? match[1] : "";
}

function parseType(text: string): string {
    const match = text.match(/\b(Manga|Manhwa|Manhua)\b/i);
    if (!match) return "Unknown";
    const type = match[1].toLowerCase();
    return type.charAt(0).toUpperCase() + type.slice(1);
}

// 🎯 Nangkep angka views dengan cerdas
function extractViews(text: string): string {
    const match = text.match(/([\d.,]+(?:rb|jt|k|m)?)\s*(?:x|views?|pembaca)/i);
    return match ? match[1] : "Unknown";
}

// --- FUNGSI PARSING CARD ---
function parseCard($: cheerio.CheerioAPI, el: any): KomikuCard | null {
    const card = $(el);

    // 1. Cari Link & Slug
    const titleLinkEl = card.find('h3 a[href*="/manga/"], h4 a[href*="/manga/"]').first();
    const coverLinkEl = card.find('a[href*="/manga/"]').first();

    const targetLinkEl = titleLinkEl.length ? titleLinkEl : coverLinkEl;
    const originalLink = getAbsoluteUrl(targetLinkEl.attr("href"));
    const slug = extractMangaSlug(originalLink);

    if (!slug) return null;

    // 2. Cari Gambar
    const imgEl = card.find("img").first();
    const thumbnail = getAbsoluteUrl(
        imgEl.attr("data-src") || imgEl.attr("data-lazy-src") || imgEl.attr("src")
    );

    // 3. Ekstrak Judul (Versi Tahan Banting)
    let rawTitle = card.find('h3').first().text().trim() ||
        card.find('h4').first().text().trim() ||
        titleLinkEl.text().trim() ||
        titleLinkEl.attr("title") ||
        coverLinkEl.attr("title") ||
        imgEl.attr("alt") ||
        "";

    // Jaring Pengaman (Fallback): Kalau semua elemen HTML di atas gagal/kosong,
    // kita sulap 'slug' (contoh: return-of-the-flowery) jadi Judul Asli.
    if (!rawTitle && slug) {
        rawTitle = slug.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    const title = cleanTitle(rawTitle);

    // 4. Ekstrak Chapter
    const latestChapterEl = card.find('a[href*="chapter"]').last();
    const latestChapter = normalizeText(latestChapterEl.text() || latestChapterEl.attr("title"));
    const chapterNumber = extractChapterNumber(getAbsoluteUrl(latestChapterEl.attr("href"))) || latestChapter.match(/Chapter\s*([\d.]+)/i)?.[1] || "";

    // 5. Ekstrak Tipe 
    let type = card.attr('data-tipe') || parseType(targetLinkEl.attr("title") + " " + imgEl.attr("alt") + " " + card.text());
    if (type) type = type.charAt(0).toUpperCase() + type.slice(1).toLowerCase();

    // 6. Ekstrak Genre, Warna, Views, dan Deskripsi
    const infoTexts: string[] = [];
    let fullRawText = "";
    card.find("span.ls2t, span.ls4s, span.judul2, p, small, .vw").each((_, node) => {
        const text = normalizeText($(node).text());
        fullRawText += " " + text;
        if (text && !/^up\s*\d+/i.test(text) && !/^chapter\b/i.test(text) && !/^(manga|manhwa|manhua)$/i.test(text)) {
            infoTexts.push(text);
        }
    });

    let genre = "Unknown";
    const combinedInfo = infoTexts.find(t => t.includes('·') || t.includes('|')) || infoTexts[0] || "";
    if (combinedInfo) {
        genre = combinedInfo.split(/\s*[·|]\s*/)[0];
        genre = genre.replace(/views?/i, '').replace(/pembaca/i, '').trim() || "Unknown";
    }

    const views = extractViews(fullRawText);
    const isColored = /\b(berwarna|color|colored)\b/i.test(card.text());
    const description = normalizeText(card.find('p').first().text());

    return {
        title: title || "Tanpa Judul",
        slug,
        thumbnail,
        type: type || "Unknown",
        genre,
        views,
        latestChapter,
        chapterNumber,
        isColored,
        description
    };
}

// --- MAPPING HOME PAGE ---
export function mapKomikuHome(html: string): KomikuHomeResponse {
    const $ = cheerio.load(html);
    const sections: KomikuSection[] = [];

    // 1. 🏆 PERINGKAT KOMIKU
    const rankSection = $('#Rekomendasi_Komik');
    if (rankSection.length) {
        const title = rankSection.find('h2.lsh3').text().trim() || "Peringkat Komiku";
        const children: KomikuChildSection[] = [];

        const rankTabs = [
            { id: 'mingguan', name: 'Mingguan' },
            { id: 'harian', name: 'Harian' },
            { id: 'total', name: 'Total' }
        ];

        rankTabs.forEach(tab => {
            const items: KomikuCard[] = [];
            rankSection.find(`#rank-${tab.id} article.ls4`).each((_, el) => {
                const card = parseCard($, el);
                if (card) items.push(card);
            });
            if (items.length > 0) children.push({ id: tab.id, title: tab.name, items });
        });

        if (children.length > 0) sections.push({ id: 'peringkat-komiku', title, children });
    }

    // 2. 🔥 KOMIK POPULER UPDATE
    const popSection = $('#Komik_Populer');
    if (popSection.length) {
        const title = popSection.find('h2.lsh3').text().trim() || "Komik Populer Update";
        const children: KomikuChildSection[] = [];
        const allItems: KomikuCard[] = [];

        popSection.find('#ls12-populer article.ls2').each((_, el) => {
            const card = parseCard($, el);
            if (card) allItems.push(card);
        });

        if (allItems.length > 0) {
            children.push({ id: 'semua', title: 'Semua', items: allItems });

            ['Manga', 'Manhwa', 'Manhua'].forEach(tipe => {
                const filtered = allItems.filter(item => item.type.toLowerCase() === tipe.toLowerCase());
                if (filtered.length > 0) {
                    children.push({ id: tipe.toLowerCase(), title: tipe, items: filtered });
                }
            });

            sections.push({ id: 'populer-update', title, children });
        }
    }

    // 3. ✨ BARU DITAMBAHKAN (TERBARU)
    const terbaruSection = $('#Baru_Ditambahkan');
    if (terbaruSection.length) {
        const title = terbaruSection.find('h2.lsh3').text().trim() || "Baru Ditambahkan";
        const children: KomikuChildSection[] = [];
        const allItems: KomikuCard[] = [];

        terbaruSection.find('#ls12-baru article.ls2').each((_, el) => {
            const card = parseCard($, el);
            if (card) allItems.push(card);
        });

        if (allItems.length > 0) {
            children.push({ id: 'semua', title: 'Semua', items: allItems });

            ['Manga', 'Manhwa', 'Manhua'].forEach(tipe => {
                const filtered = allItems.filter(item => item.type.toLowerCase() === tipe.toLowerCase());
                if (filtered.length > 0) {
                    children.push({ id: tipe.toLowerCase(), title: tipe, items: filtered });
                }
            });

            sections.push({ id: 'baru-ditambahkan', title, children });
        }
    }

    // 4. 🎭 SECTION BERDASARKAN GENRE
    $('.lsgenre').each((_, el) => {
        const sec = $(el);
        const title = sec.find('h2.lsh3').text().trim();
        if (!title) return;

        const items: KomikuCard[] = [];
        sec.find('.ls12 article.ls2').each((_, cardEl) => {
            const card = parseCard($, cardEl);
            if (card) items.push(card);
        });

        if (items.length > 0) {
            const idId = title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
            sections.push({
                id: `genre-${idId}`,
                title,
                children: [
                    { id: 'semua', title: 'Semua', items }
                ]
            });
        }
    });

    return {
        success: true,
        sections
    };
}

// --- MAPPING PAGINATION (Untuk route Terbaru dan Populer) ---
export function mapKomikuPagination(html: string, page: number): KomikuTerbaruResponse {
    const $ = cheerio.load(html);
    const items: KomikuCard[] = [];

    $('.bge').each((_, el) => {
        const card = parseCard($, el);
        if (card) items.push(card);
    });

    const hasNext = html.includes('hx-get=');

    return {
        success: true,
        page,
        items,
        hasNext
    };
}

// --- MAPPING SEARCH ---
export function mapKomikuSearch(html: string, keyword: string): KomikuSearchResponse {
    const $ = cheerio.load(html);
    const items: KomikuCard[] = [];

    $('.bge').each((_, el) => {
        const card = parseCard($, el);
        if (card) items.push(card);
    });

    return {
        success: true,
        keyword,
        items
    };
}

// --- MAPPING FILTERS ---
export function mapKomikuFilters(html: string): KomikuFiltersResponse {
    const $ = cheerio.load(html);
    const filters: KomikuFilterGroup[] = [];

    $('form.filer2 select').each((_, selectEl) => {
        const select = $(selectEl);
        const name = select.attr('name');

        if (!name) return;

        const options: KomikuFilterOption[] = [];
        select.find('option').each((_, optionEl) => {
            const opt = $(optionEl);
            const value = opt.attr('value') || "";
            const label = normalizeText(opt.text());

            options.push({ value, label });
        });

        filters.push({
            name,
            options
        });
    });

    return {
        success: true,
        filters
    };
}

// --- MAPPING DETAIL PAGE ---
export function mapKomikuDetail(html: string, slug: string): KomikuDetailResponse {
    const $ = cheerio.load(html);

    const title = normalizeText($("h1 [itemprop='name']").first().text() || $("h1").first().text());
    const alternativeTitle = normalizeText($("p.j2").first().text());
    const description = normalizeText($("p.desc").first().text());
    const sinopsis = normalizeText($("section#Sinopsis p").first().text());

    const imgEl = $("section#Informasi img").first();
    const thumbnail = getAbsoluteUrl(imgEl.attr("data-src") || imgEl.attr("src"));

    const info: Record<string, string> = {};
    $("section#Informasi table tr, section#Informasi .inftable tr").each((_, el) => {
        const cells = $(el).find("td, th");
        const key = normalizeText(cells.first().text()).replace(/:$/, "");
        const value = normalizeText(cells.last().text());
        if (key && value && key !== value) info[key] = value;
    });

    const genres: string[] = [];
    $("section#Informasi a[href*='/genre/'], section#Informasi ul.genre li").each((_, el) => {
        genres.push(normalizeText($(el).text()));
    });

    const chapters: KomikuChapterItem[] = [];
    $("section#Chapter table tr, table#Daftar_Chapter tr").each((_, el) => {
        const row = $(el);
        const linkEl = row.find('a[href*="chapter"]').first();
        if (!linkEl.length) return;

        const originalLink = getAbsoluteUrl(linkEl.attr("href"));
        const chapterNumber = extractChapterNumber(originalLink);

        // 🎯 FIX TERPENTING: Ekstrak slug aslinya dari URL Chapter
        const realChapterSlug = extractChapterSlug(originalLink) || slug;

        // 🎯 Bersihin Views pake extractViews
        let chapterViews = normalizeText(row.find(".pembaca, td.pembaca, i").first().text());
        const cleanViews = extractViews(chapterViews);
        if (cleanViews !== "Unknown") chapterViews = cleanViews;

        chapters.push({
            slugChapter: realChapterSlug,
            title: normalizeText(linkEl.text()),
            chapterNumber,
            // 👇 Disini sekarang pakai realChapterSlug
            apiLink: chapterNumber ? `/api/komiku/view?slug=${realChapterSlug}&chapter=${chapterNumber}` : null,
            views: chapterViews,
            date: normalizeText(row.find(".tanggalseries").first().text() || row.find("td").last().text()),
        });
    });

    const similarKomik: KomikuCard[] = [];
    $("section").filter((_, el) => /Komik Serupa/i.test(normalizeText($(el).text())))
        .find('a[href*="/manga/"]')
        .each((_, el) => {
            const linkElement = $(el);
            const cardElement = linkElement.closest("article, li, div");
            const parsedCard = parseCard($, cardElement.get(0));
            if (parsedCard && !similarKomik.some(k => k.slug === parsedCard.slug)) {
                similarKomik.push(parsedCard);
            }
        });

    return {
        success: true,
        title,
        alternativeTitle,
        description,
        sinopsis,
        thumbnail,
        genres: [...new Set(genres)],
        slug,
        info,
        chapters,
        similarKomik
    };
}

// --- MAPPING VIEW (BACA CHAPTER) ---
function chapterSortValue(chapter: string | null | undefined): number {
    const normalized = String(chapter || "").replace(/-/g, ".");
    const value = parseFloat(normalized);
    return Number.isNaN(value) ? 0 : value;
}

export function mapKomikuView(html: string, slug: string, chapter: string): KomikuViewResponse {
    const $ = cheerio.load(html);

    const title = normalizeText($("#Judul h1").first().text() || $("h1").first().text() || $("meta[itemprop='name']").attr("content"));

    const mangaTitleElement = $('#Judul a[href*="/manga/"], a[href*="/manga/"]').first();
    const mangaTitle = normalizeText(mangaTitleElement.find("b").first().text() || mangaTitleElement.text() || mangaTitleElement.attr("title"));
    const mangaLink = getAbsoluteUrl(mangaTitleElement.attr("href"));
    const mangaSlug = extractMangaSlug(mangaLink);

    const info: Record<string, string> = {};
    $("#Judul table tr, table.tbl tr").each((_, el) => {
        const cells = $(el).find("td, th");
        const key = normalizeText(cells.first().text()).replace(/:$/, "");
        const value = normalizeText(cells.last().text());
        if (key && value && key !== value) info[key] = value;
    });

    const images: KomikuImage[] = [];
    $("#Baca_Komik img, img.ww, img[id]").each((_, el) => {
        const img = $(el);
        const src = getAbsoluteUrl(img.attr("data-src") || img.attr("src"));
        const id = normalizeText(img.attr("id"));
        const fallbackSrc = src.replace(/cdn\.komiku\.org/i, "img.komiku.org");
        // 🎯 UDAH GW GANTI REGEX-NYA JADI: /komiku\.org.*upload/i
        if (src && /komiku\.org.*upload/i.test(src) && (!id || /^\d+$/.test(id))) {
            images.push({
                alt: normalizeText(img.attr("alt")),
                id,
                src,
                fallbackSrc,
                // 🎯 FORMAT URL PROXY
                url_proxy: `${SITE_URL}/api/komiku/image?url=${encodeURIComponent(src)}`,
                fallbackSrc_proxy: `${SITE_URL}/api/komiku/image?url=${encodeURIComponent(fallbackSrc)}`,

            });
        }
    });

    const uniqueImages = images.filter((image, index, allImages) =>
        image.src && allImages.findIndex((item) => item.src === image.src) === index
    );

    const chapterValueInfo = $(".chapterInfo").attr("valuechapter") || chapter;
    const totalImages = $(".chapterInfo").attr("valuegambar") || uniqueImages.length.toString();
    const viewAnalyticsUrl = $(".chapterInfo").attr("valueview") || "";
    const publishDate = $("time[property='datePublished']").attr("datetime") || $("meta[itemprop='datePublished']").attr("content") || normalizeText($("time").first().text());

    const descriptionText = normalizeText($("#Description").first().text()) || normalizeText($("p").filter((_, el) => /Baca online|update di Komiku/i.test($(el).text())).first().text());

    const navigationLinks = $("#Judul").parent().find('a[href*="chapter"]').toArray()
        .map((el) => getAbsoluteUrl($(el).attr("href"))).filter(Boolean);

    const currentChapterNumber = chapterSortValue(chapterValueInfo);
    const chapterCandidates = [...new Set(navigationLinks.filter((link) =>
        extractMangaSlug(link) === slug || extractChapterNumber(link) !== String(chapterValueInfo)
    ))];

    const prevLink = chapterCandidates
        .filter((link) => chapterSortValue(extractChapterNumber(link)) < currentChapterNumber)
        .sort((a, b) => chapterSortValue(extractChapterNumber(b)) - chapterSortValue(extractChapterNumber(a)))[0] || "";

    const nextLink = chapterCandidates
        .filter((link) => chapterSortValue(extractChapterNumber(link)) > currentChapterNumber)
        .sort((a, b) => chapterSortValue(extractChapterNumber(a)) - chapterSortValue(extractChapterNumber(b)))[0] || "";

    const formatNavInfo = (link: string) => {
        if (!link) return null;
        const navChapter = extractChapterNumber(link);
        const realSlug = extractChapterSlug(link) || slug; // Antisipasi nama slug berubah
        return navChapter ? {
            apiLink: `/api/komiku/view?slug=${realSlug}&chapter=${navChapter}`,
            slug: realSlug,
            chapter: navChapter
        } : null;
    };

    return {
        success: true,
        title,
        mangaTitle,
        mangaSlug,
        mangaApiLink: mangaSlug ? `/api/komiku/detail?slug=${mangaSlug}` : null,
        description: descriptionText,
        info,
        images: uniqueImages,
        meta: {
            chapterNumber: chapterValueInfo,
            totalImages: parseInt(totalImages, 10) || 0,
            publishDate,
            viewAnalyticsUrl,
        },
        navigation: {
            prevChapter: formatNavInfo(prevLink),
            nextChapter: formatNavInfo(nextLink),
            allChaptersApiLink: mangaSlug ? `/api/komiku/detail?slug=${mangaSlug}` : null,
        }
    };
}