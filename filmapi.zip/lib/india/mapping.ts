// lib/india/mapping.ts

// Helper untuk membersihkan dan menyeragamkan format item video
function mapVideoItem(item: any, type: "movie" | "tvseries") {
    return {
        id: item.videos_id,
        title: item.title,
        description: item.description || "",
        slug: item.slug,
        type: type,
        poster: item.poster_url,
        thumbnail: item.thumbnail_url,
        is_paid: item.is_paid === "1",
        release: item.release,
        quality: item.video_quality || "SD"
    };
}

export function mapHomeData(rawData: any) {
    // Kalau server asli balikin kosong atau error
    if (!rawData) {
        return {
            code: 404,
            message: "Data kosong atau tidak ditemukan",
            data: null
        };
    }

    const rawSeries = rawData.latest_tvseries || [];
    const rawMovies = rawData.latest_movies || [];

    // 1. BANNER: Ambil 5 series terbaru
    const banner = rawSeries.slice(0, 5).map((item: any) => mapVideoItem(item, "tvseries"));

    // 2. MOVIES: Semua movie terbaru
    const movies = rawMovies.map((item: any) => mapVideoItem(item, "movie"));

    // 3. SERIES: Ambil sisa series (mulai dari index ke-5)
    const series = rawSeries.slice(5).map((item: any) => mapVideoItem(item, "tvseries"));

    // 4. RETURN DENGAN CODE & MESSAGE
    return {
        code: 200,
        message: "success",
        data: {
            banner: banner,
            sections: [
                {
                    title: "Latest Movies",
                    type: "movie",
                    items: movies
                },
                {
                    title: "Latest Series",
                    type: "tvseries",
                    items: series
                }
            ]
        }
    };
}

export function mapSeriesData(rawData: any) {
    // Validasi kalau datanya kosong atau bukan array
    if (!rawData || !Array.isArray(rawData)) {
        return {
            code: 404,
            message: "Data series tidak ditemukan atau kosong",
            data: []
        };
    }

    // Looping data mentah dan rapikan pakai helper mapVideoItem
    const mappedSeries = rawData.map((item: any) => mapVideoItem(item, "tvseries"));

    return {
        code: 200,
        message: "success",
        data: mappedSeries
    };
}

export function mapSearchData(rawData: any) {
    if (!rawData) {
        return {
            code: 404,
            message: "error: data tidak ditemukan atau kosong",
            data: {
                movies: [],
                series: []
            }
        };
    }

    // Ambil array dari data mentah
    const rawMovies = rawData.movie || [];
    const rawSeries = rawData.tvseries || [];

    // Rapikan menggunakan helper mapVideoItem
    const movies = rawMovies.map((item: any) => mapVideoItem(item, "movie"));
    const series = rawSeries.map((item: any) => mapVideoItem(item, "tvseries"));

    // Catatan: is_paid dari endpoint search kadang tidak dikirim oleh server aslinya, 
    // tapi helper mapVideoItem kita akan otomatis menganggapnya 'false' (gratis) jika tidak ada.

    return {
        code: 200,
        message: "success",
        data: {
            movies: movies,
            series: series
        }
    };
}

export function mapDetailData(rawData: any) {
    if (!rawData || !rawData.videos_id) {
        return {
            code: 404,
            message: "Detail video tidak ditemukan",
            data: null
        };
    }

    const genres = Array.isArray(rawData.genre)
        ? rawData.genre.map((g: any) => g.name).filter((n: string) => n !== "Unknown").join(", ")
        : "";

    // 1. Cek apakah ini TV Series atau Movie
    const isTvSeries = rawData.is_tvseries === "1";

    // 2. Mapping Season & Episode secara dinamis
    let seasons: any[] = [];

    if (isTvSeries && Array.isArray(rawData.season)) {
        // LOGIKA UNTUK TV SERIES (Struktur Lama)
        seasons = rawData.season.map((seasonItem: any) => {
            const rawSeasonName = seasonItem.seasons_name || "";
            const sessionNum = rawSeasonName.replace(/[A-Za-z]/g, '').trim();

            return {
                id: seasonItem.seasons_id,
                sesion_num: sessionNum,
                name: rawSeasonName,
                episodes: Array.isArray(seasonItem.episodes) ? seasonItem.episodes.map((ep: any) => {
                    const matchNumber = ep.episodes_name ? ep.episodes_name.match(/\d+/) : null;
                    const episodeNum = matchNumber ? parseInt(matchNumber[0], 10) : 0;

                    return {
                        id: ep.episodes_id,
                        episode_num: episodeNum,
                        title: ep.episodes_name,
                        thumbnail: ep.image_url,
                        stream_url: ep.file_url,
                        stream_key: ep.stream_key || null
                    };
                }) : []
            };
        });
    } else if (!isTvSeries && Array.isArray(rawData.videos) && rawData.videos.length > 0) {
        // LOGIKA UNTUK MOVIE BEREPIOSODE (Bungkus ke dalam Dummy Season 1)
        seasons = [{
            id: "1", // ID Dummy
            sesion_num: "1",
            name: "Season 1",
            episodes: rawData.videos.map((vid: any) => {
                // Movie pakai field "label", bukan "episodes_name"
                const matchNumber = vid.label ? vid.label.match(/\d+/) : null;
                const episodeNum = matchNumber ? parseInt(matchNumber[0], 10) : 0;

                return {
                    id: vid.video_file_id, // Movie pakai video_file_id
                    episode_num: episodeNum,
                    title: vid.label, // Title ambil dari label
                    // Video di movie nggak punya thumbnail satuan, jadi fallback ke thumbnail utama
                    thumbnail: rawData.thumbnail_url,
                    stream_url: vid.file_url,
                    stream_key: vid.stream_key || null
                };
            })
        }];
    }

    // 3. Mapping Related Video (Karena fieldnya beda antara movie dan series)
    let rawRelated = [];
    if (isTvSeries && Array.isArray(rawData.related_tvseries)) {
        rawRelated = rawData.related_tvseries;
    } else if (!isTvSeries && Array.isArray(rawData.related_movie)) {
        rawRelated = rawData.related_movie;
    }

    const related = rawRelated.map((item: any) => mapVideoItem(item, isTvSeries ? "tvseries" : "movie"));

    // 4. Return Data Final
    const detailData = {
        id: rawData.videos_id,
        title: rawData.title,
        description: rawData.description || "Tidak ada deskripsi.",
        slug: rawData.slug,
        type: isTvSeries ? "tvseries" : "movie",
        poster: rawData.poster_url,
        thumbnail: rawData.thumbnail_url,
        is_paid: rawData.is_paid === "1",
        release: rawData.release,
        quality: rawData.video_quality || "SD",
        genres: genres,
        seasons: seasons, // <-- Sekarang aman, selalu ngeluarin array seasons
        related: related  // <-- Aman, menyesuaikan tipe datanya
    };

    return {
        code: 200,
        message: "success",
        data: detailData
    };
}