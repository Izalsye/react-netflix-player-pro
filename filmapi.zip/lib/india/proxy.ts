import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib"; // 👈 Tambahan wajib untuk handle gzip
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

// 👇 Base URL Target
const SINETRON_BASE = "https://app.sinetron.my.id";

// 👇 Konfigurasi Proxy Opsional
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// 👇 Ambil API-KEY dan Auth dari Environment Variable (.env)
// Gua kasih fallback value sesuai contoh lu kalau di .env belum di-set
const SINETRON_API_KEY = process.env.SINETRON_API_KEY || "dba12e2096a2f80";
const SINETRON_AUTH = process.env.SINETRON_AUTH || "Basic YWRtaW46MTIzNA==";

const cache = new Map<string, { val: any, exp: number }>();

// 👇 Helper pencocokan header persis seperti log OkHttp Android
function buildSinetronHeaders(): Record<string, string> {
    return {
        "API-KEY": SINETRON_API_KEY,
        "Authorization": SINETRON_AUTH,
        "Host": "app.sinetron.my.id",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.9.0"
    };
}

async function httpsGet(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
            },
            (res) => {
                let stream: any = res;
                // 🎯 DETEKSI GZIP: Kalau server beneran ngirim gzip, kita decompress dulu
                if (res.headers['content-encoding'] === 'gzip') {
                    stream = res.pipe(zlib.createGunzip());
                }

                let data = "";
                stream.setEncoding("utf8");
                stream.on("data", (chunk: string) => (data += chunk));
                stream.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: data,
                    });
                });
                stream.on("error", reject);
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function httpsPost(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
            },
            (res) => {
                let stream: any = res;
                // 🎯 DETEKSI GZIP juga untuk POST
                if (res.headers['content-encoding'] === 'gzip') {
                    stream = res.pipe(zlib.createGunzip());
                }

                let data = "";
                stream.setEncoding("utf8");
                stream.on("data", (chunk: string) => (data += chunk));
                stream.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: data,
                    });
                });
                stream.on("error", reject);
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string> } = { label: 'sinetron-get' }
) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    let pathWithQuery = path;
    if (qs) {
        pathWithQuery = path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(JSON.stringify(hit.val), {
                headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' },
            });
        }
    }

    const headers = {
        ...buildSinetronHeaders(),
        ...opts.headers
    };

    const upstreamUrl = `${SINETRON_BASE}${pathWithQuery}`;
    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await httpsGet(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return text; }
        }

        if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs && contentType.includes('application/json')) {
            try { cache.set(cacheKey, { val: JSON.parse(text), exp: Date.now() + opts.cacheTtlMs }); } catch { }
        }

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        console.error(`[sinetronProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; contentType?: string } = { label: 'sinetron-post' }
) {

    const bodyString = typeof body === 'string' ? body : JSON.stringify(body);
    const headers = buildSinetronHeaders();
    const upstreamUrl = `${SINETRON_BASE}${path}`;
    const cType = opts.contentType || req.headers.get('content-type') || "application/json";

    try {
        const { status, contentType, text } = await httpsPost(upstreamUrl, headers, bodyString, cType);

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        return NextResponse.json({ error: true, message: e.message }, { status: 502 });
    }
}