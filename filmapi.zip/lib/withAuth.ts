// file: lib/withAuth.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from './apiKeyService';

export async function withAuth(req: NextRequest, handler: Function) {

    // Kalau aman, baru jalanin fungsi utamanya
    return handler(req);
}