// file: lib/bot/config.ts
export const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
export const BANNER_URL = "https://i.imgur.com/a9RG0KS.jpeg";
export const BASE_API_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://indocast.site';

export const MIDTRANS_API_URL = process.env.NODE_ENV === 'production'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';

export const EFFECTS = {
    FIRE: "5104841245755180586",
    PARTY: "5046509860389126442",
    HEART: "5044134455711629726",
    THUMB_UP: "5107584321108051014",
    THUMB_DOWN: "5104858069142078462",
    POOP: "5046589136895476101"
};