// file: lib/bot/utils.ts
import crypto from 'crypto';
import prisma from '../../prisma/prisma'; // Sesuaikan path jika beda

export class BotUtils {
    static generateApiKey() {
        const randomString = crypto.randomBytes(24).toString('hex');
        return `indocast_${randomString}`;
    }

    static hashKey(apiKey: string) {
        return crypto.createHash('sha256').update(apiKey).digest('hex');
    }

    static getFormattedDate() {
        const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

        const d = new Date();
        const dayName = days[d.getDay()];
        const day = String(d.getDate()).padStart(2, '0');
        const monthName = months[d.getMonth()];
        const year = d.getFullYear();
        const time = d.toLocaleTimeString('id-ID', { hour12: false });

        return `${dayName}, ${day} ${monthName} ${year} | ${time} WIB`;
    }

    static formatExpiredDate(date: Date | null) {
        if (!date) return 'Selamanya (Free)';
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'];
        const d = new Date(date);
        return `${String(d.getDate()).padStart(2, '0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
    }

    static getRemainingDays(date: Date | null) {
        if (!date) return 0;
        const now = new Date();
        const diffMs = date.getTime() - now.getTime();
        return diffMs > 0 ? Math.ceil(diffMs / (1000 * 60 * 60 * 24)) : 0;
    }

    static safeHtml(text: string | null | undefined) {
        if (!text) return '';
        return text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&/g, '&amp;');
    }

    static async getOrCreateTgUser(tgUser: any) {
        const tgIdStr = String(tgUser.id);
        let user = await prisma.user.findUnique({ where: { telegramId: tgIdStr } });

        if (!user) {
            user = await prisma.user.create({
                data: {
                    telegramId: tgIdStr,
                    firstName: tgUser.first_name,
                    lastName: tgUser.last_name || null,
                    username: tgUser.username || null,
                    isBot: tgUser.is_bot || false,
                    role: "FREE",
                    status: "ACTIVE"
                }
            });
        } else {
            user = await prisma.user.update({
                where: { telegramId: tgIdStr },
                data: {
                    firstName: tgUser.first_name,
                    lastName: tgUser.last_name || null,
                    username: tgUser.username || null,
                    lastActiveAt: new Date()
                }
            });
        }
        return user;
    }
}