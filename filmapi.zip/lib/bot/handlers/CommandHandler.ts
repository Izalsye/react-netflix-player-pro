// file: lib/bot/handlers/CommandHandler.ts
import { Bot, InlineKeyboard } from 'grammy';
import prisma from '../../../prisma/prisma';
import { BANNER_URL } from '../config';
import { BotUtils } from '../utils';
import { TEXT, Menus } from '../views';
import { AdminController } from '../../admin';

export class CommandHandler {
    static register(bot: Bot) {
        bot.command(['start', 'bantuan'], async (ctx) => {
            const tgUser = ctx.from;
            if (!tgUser) return;

            try {
                if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
                    const pmKb = new InlineKeyboard().url("🤖 Chat Bot Secara Pribadi", `https://t.me/${ctx.me.username}?start=true`);
                    return ctx.reply(`👋 Halo <b>${BotUtils.safeHtml(tgUser.first_name)}</b>!\n\nUntuk mengelola API Key dan VIP, silakan *Japri* (Chat Pribadi) ke bot melalui tombol di bawah ini ya!`, {
                        parse_mode: "HTML",
                        reply_markup: pmKb,
                        reply_parameters: { message_id: ctx.message!.message_id }
                    });
                }

                if (ctx.message?.text === '/bantuan') {
                    await ctx.reply(TEXT.tos, { parse_mode: "HTML", reply_markup: Menus.backMenu });
                    return;
                }

                const user = await BotUtils.getOrCreateTgUser(tgUser);
                const fullUser = await prisma.user.findUnique({
                    where: { id: user.id },
                    include: { apiKey: true }
                });

                const isVip = fullUser?.role === 'VIP';
                const hasApiKey = !!fullUser?.apiKey;
                const subEndsAt = fullUser?.subEndsAt || null;
                const isAdmin = AdminController.isAdmin(tgUser.id);

                await ctx.replyWithPhoto(BANNER_URL, {
                    caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
                    parse_mode: "HTML",
                    reply_markup: Menus.getMainMenu(isAdmin)
                });

            } catch (error) {
                console.error("Gagal load dashboard:", error);
                await ctx.reply("⏳ Sistem sedang sibuk bre, coba lagi dalam beberapa detik.");
            }
        });
    }
}