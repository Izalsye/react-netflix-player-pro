// file: lib/bot/handlers/CallbackHandler.ts
import { Bot, InlineKeyboard } from 'grammy';
import prisma from '../../../prisma/prisma';
import { BANNER_URL, BASE_API_URL, MIDTRANS_API_URL } from '../config';
import { BotUtils } from '../utils';
import { TEXT, Menus } from '../views';
import { AdminController } from '../../admin';
// 🔥 TAMBAHIN INI: State buat nyimpen admin lagi milih provider apa
export const adminCookieState = new Map<string, string>();
export class CallbackHandler {
    static register(bot: Bot) {
        bot.on("callback_query:data", async (ctx) => {
            const data = ctx.callbackQuery.data;
            const tgUser = ctx.from;

            if (ctx.chat?.type !== 'private') return;

            // 🔥 FIX ERROR: Kita pisah cara ngejawab loading-nya biar gak bentrok
            const isActionMenu = data.includes("admin_") || data.includes("check_pay");
            if (!isActionMenu) {
                // Jawab loading diam-diam untuk menu biasa
                await ctx.answerCallbackQuery().catch(() => { });
            }

            try {
                const user = await BotUtils.getOrCreateTgUser(tgUser);
                const fullUserData = await prisma.user.findUnique({
                    where: { id: user.id },
                    include: { apiKey: true, plan: true }
                });

                const isVip = fullUserData?.role === 'VIP';
                const hasApiKey = !!fullUserData?.apiKey;
                const subEndsAt = fullUserData?.subEndsAt || null;
                const isAdmin = AdminController.isAdmin(tgUser.id);

                // --- DASHBOARD ---
                if (data === "menu_main") {
                    await ctx.editMessageCaption({
                        caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
                        parse_mode: "HTML",
                        reply_markup: Menus.getMainMenu(isAdmin)
                    }).catch(async () => {
                        await ctx.deleteMessage().catch(() => { });
                        await ctx.replyWithPhoto(BANNER_URL, {
                            caption: TEXT.dashboard(user, isVip, hasApiKey, subEndsAt),
                            parse_mode: "HTML",
                            reply_markup: Menus.getMainMenu(isAdmin)
                        });
                    });
                }

                // --- TOS ---
                else if (data === "menu_tos") {
                    await ctx.editMessageCaption({ caption: TEXT.tos, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(async () => {
                        await ctx.editMessageText(TEXT.tos, { parse_mode: "HTML", reply_markup: Menus.backMenu });
                    });
                }

                // --- KELOLA API ---
                else if (data === "menu_api") {
                    if (!fullUserData?.apiKey) {
                        const msg = `⚠️ <b>BELUM ADA API KEY</b>\n\nKamu belum memiliki API Key untuk mengakses <code>${BASE_API_URL}</code>.\n\nKlik tombol di bawah untuk membuat Key secara gratis.`;
                        await ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: Menus.apiMenu(false) }).catch(async () => {
                            await ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: Menus.apiMenu(false) });
                        });
                    } else {
                        const rawKeyText = fullUserData.apiKey.rawKey || "Key tidak ditemukan";
                        const limitPerDay = fullUserData.plan?.limitPerDay ?? 100;

                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        const usageRecord = await prisma.dailyUsage.findUnique({
                            where: { userId_date: { userId: user.id, date: today } }
                        });
                        const usageToday = usageRecord?.count || 0;

                        const msg = TEXT.apiInfo(rawKeyText, isVip, limitPerDay, usageToday);
                        await ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: Menus.apiMenu(true) }).catch(async () => {
                            await ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: Menus.apiMenu(true) });
                        });
                    }
                }

                // --- GEN / REGEN API ---
                else if (data === "action_gen_api" || data === "action_regen_api") {
                    const rawKey = BotUtils.generateApiKey();
                    const hashedKey = BotUtils.hashKey(rawKey);

                    if (data === "action_gen_api") {
                        await prisma.apiKey.create({
                            data: { userId: user.id, hashedKey, rawKey, label: "Default Key" }
                        });
                    } else {
                        await prisma.apiKey.update({
                            where: { userId: user.id },
                            data: { hashedKey, rawKey }
                        });
                    }

                    const prefixMsg = data === "action_gen_api" ? "✅ <b>API KEY BERHASIL DIBUAT</b>" : "🔄 <b>API KEY BERHASIL DIRESET</b>";
                    const txt = `${prefixMsg}\n\n<code>${rawKey}</code>\n\n<i>⚠️ Segera salin dan simpan di tempat yang aman.</i>`;

                    await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(async () => {
                        await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: Menus.backMenu });
                    });
                }

                // --- RIWAYAT TRANSAKSI ---
                else if (data === "menu_history") {
                    const trxs = await prisma.transaction.findMany({
                        where: { userId: user.id },
                        orderBy: { createdAt: 'desc' },
                        take: 5,
                        include: { plan: true }
                    });

                    let txt = `🧾 <b>5 RIWAYAT TRANSAKSI TERAKHIR</b>\n\n`;
                    if (trxs.length === 0) {
                        txt += `<i>Belum ada catatan transaksi.</i>`;
                    } else {
                        trxs.forEach((t, i) => {
                            const date = t.createdAt.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                            const icon = t.status === 'SETTLEMENT' || t.status === 'SUCCESS' ? '✅' : t.status === 'PENDING' ? '⏳' : '❌';
                            txt += `${i + 1}. ${icon} <b>${t.plan.name}</b> (Rp${t.amount.toLocaleString('id-ID')})\n   └ <i>${date} - ${t.status}</i>\n\n`;
                        });
                    }

                    await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(async () => {
                        await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: Menus.backMenu });
                    });
                }

                // --- BELI VIP ---
                else if (data === "menu_buy_vip") {
                    const plans = await prisma.plan.findMany({ where: { isActive: true }, orderBy: { price: 'asc' } });
                    if (plans.length === 0) {
                        const msg = "⚠️ <i>Mohon maaf, belum ada paket VIP yang tersedia saat ini.</i>";
                        return ctx.editMessageCaption({ caption: msg, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(() => ctx.editMessageText(msg, { parse_mode: "HTML", reply_markup: Menus.backMenu }));
                    }

                    const kb = new InlineKeyboard();
                    plans.forEach(p => {
                        kb.text(`👑 ${p.name} - Rp ${p.price.toLocaleString('id-ID')}`, `plan_${p.id}`).row();
                    });
                    kb.text("🔙 Kembali", "menu_main");

                    const txt = "🛒 <b>PEMBELIAN PAKET VIP</b>\n\nUpgrade akunmu sekarang untuk menikmati limit <i>unlimited</i> dan akses penuh ke seluruh fitur Indocast API.\n\n👇 <b>Pilih paket yang tersedia:</b>";
                    await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: kb }).catch(async () => {
                        await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: kb });
                    });
                }

                // --- PILIH METODE BAYAR ---
                else if (data.startsWith("plan_")) {
                    const planId = data.replace("plan_", "");
                    const plan = await prisma.plan.findUnique({ where: { id: planId } });
                    if (!plan) return;

                    const kb = new InlineKeyboard()
                        .text("⚡ Bayar via QRIS (Otomatis)", `pay_qris_${plan.id}`).row()
                        .text("🏦 Transfer Manual (Admin)", `pay_admin_${plan.id}`).row()
                        .text("🔙 Batal", "menu_buy_vip");

                    const txt = `📋 <b>DETAIL PESANAN</b>\n\n` +
                        `📦 <b>Paket:</b> ${plan.name}\n` +
                        `💰 <b>Harga:</b> Rp ${plan.price.toLocaleString('id-ID')}\n` +
                        `⏳ <b>Tambahan Masa Aktif:</b> ${plan.durationDays} Hari\n\n` +
                        `Pilih metode pembayaran yang kamu inginkan:`;

                    await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: kb }).catch(async () => {
                        await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: kb });
                    });
                }

                // --- BAYAR ADMIN ---
                else if (data.startsWith("pay_admin_")) {
                    const txt = `🏦 <b>METODE TRANSFER MANUAL</b>\n\n` +
                        `Kirim pembayaran sesuai nominal ke salah satu rekening berikut:\n` +
                        `🔹 <b>DANA / GOPAY:</b> <code>08123456789</code>\n` +
                        `🔹 <b>BCA:</b> <code>123456789</code> (a/n Faisol)\n\n` +
                        `📸 <i>PENTING: Jika sudah berhasil transfer, harap kirimkan bukti resi/screenshot ke admin <b>@wenetviqi</b> agar status VIP kamu segera diaktifkan.</i>`;

                    await ctx.editMessageCaption({ caption: txt, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(async () => {
                        await ctx.editMessageText(txt, { parse_mode: "HTML", reply_markup: Menus.backMenu });
                    });
                }

                // --- BAYAR QRIS ---
                else if (data.startsWith("pay_qris_")) {
                    const planId = data.replace("pay_qris_", "");
                    const plan = await prisma.plan.findUnique({ where: { id: planId } });
                    if (!plan) return;

                    await ctx.editMessageCaption({ caption: "⏳ <i>Sedang membuat kode QRIS, mohon tunggu sebentar...</i>", parse_mode: "HTML" }).catch(() => { });

                    const transaction = await prisma.transaction.create({
                        data: {
                            userId: user.id, planId: plan.id, amount: plan.price,
                            status: 'PENDING', paymentMethod: 'QRIS',
                        }
                    });

                    const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
                    const authString = Buffer.from(`${serverKey}:`).toString('base64');

                    const response = await fetch(MIDTRANS_API_URL, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json', 'Content-Type': 'application/json',
                            'Authorization': `Basic ${authString}`
                        },
                        body: JSON.stringify({
                            payment_type: 'qris',
                            transaction_details: { order_id: transaction.id, gross_amount: plan.price },
                            customer_details: { first_name: user.firstName, last_name: user.lastName || '' }
                        })
                    });

                    const midtransData = await response.json();
                    const qrisUrl = midtransData.actions?.find((a: any) => a.name === 'generate-qr-code')?.url;

                    if (!qrisUrl) {
                        const errMsg = "❌ <b>Sistem Gagal!</b>\n\nTidak dapat menggenerate QRIS. Silakan gunakan metode <b>Transfer Manual (Admin)</b>.";
                        return ctx.editMessageCaption({ caption: errMsg, parse_mode: "HTML", reply_markup: Menus.backMenu }).catch(() => ctx.editMessageText(errMsg, { parse_mode: "HTML", reply_markup: Menus.backMenu }));
                    }

                    await ctx.deleteMessage().catch(() => { });

                    const checkKb = new InlineKeyboard()
                        .url("🔗 Buka Link QRIS", qrisUrl).row()
                        .text("🔄 Cek Status Pembayaran", `check_pay_${transaction.id}`).row()
                        .text("🔙 Kembali ke Beranda", "menu_main");

                    const sentMsg = await ctx.replyWithPhoto(qrisUrl, {
                        caption: `⚡ <b>INVOICE #${transaction.id.slice(-5).toUpperCase()}</b>\n\n` +
                            `📦 <b>Paket:</b> ${plan.name}\n💰 <b>Total Bayar:</b> Rp ${plan.price.toLocaleString('id-ID')}\n\n` +
                            `✅ <b>Pembayaran akan terkonfirmasi OTOMATIS jika berhasil.</b>`,
                        parse_mode: "HTML",
                        reply_markup: checkKb
                    });

                    await prisma.transaction.update({
                        where: { id: transaction.id },
                        data: { qrisUrl: qrisUrl, telegramMsgId: sentMsg.message_id }
                    });
                }

                // --- CEK STATUS PEMBAYARAN MANUAL ---
                else if (data.startsWith("check_pay_")) {
                    const orderId = data.replace("check_pay_", "");
                    const transaction = await prisma.transaction.findUnique({
                        where: { id: orderId }, include: { plan: true, user: true }
                    });
                    if (!transaction) return;

                    if (transaction.status === 'SETTLEMENT' || transaction.status === 'SUCCESS') {
                        await ctx.deleteMessage().catch(() => { });
                        await ctx.replyWithPhoto(BANNER_URL, {
                            caption: `🎉 <b>PEMBAYARAN BERHASIL!</b> 🎉\n\nTerima kasih! Akun VIP PREMIUM aktif selama <b>${transaction.plan.durationDays} hari</b>.`,
                            parse_mode: "HTML", reply_markup: Menus.getMainMenu(isAdmin)
                        });
                        await AdminController.notifyOwner(transaction.user, transaction.plan.name, transaction.amount);
                    } else if (transaction.status === 'EXPIRE' || transaction.status === 'CANCEL') {
                        await ctx.answerCallbackQuery({ text: "❌ Pembayaran kedaluwarsa atau dibatalkan oleh sistem.", show_alert: true });
                    } else {
                        await ctx.answerCallbackQuery({ text: "⚠️ Pembayaran belum terdeteksi. Tunggu 1-2 menit lalu coba lagi.", show_alert: true });
                    }
                }

                // ==========================================
                // 🔥 SELIPIN MENU SET COOKIE DI SINI 🔥
                // ==========================================
                
                // 1. Menu Pilih Provider
                else if (data === "admin_set_cookie") {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    
                    const cookieKb = new InlineKeyboard()
                        .text("🔵 WeTV", "set_cookie_WETV")
                        .text("🟢 iQIYI", "set_cookie_IQIYI").row()
                        .text("🟣 HBO", "set_cookie_HBO")
                        .text("🟡 Viu", "set_cookie_VIU").row()
                        .text("🔙 Batal", "admin_panel");

                    await ctx.editMessageCaption({
                        caption: "🍪 <b>PILIH PROVIDER</b>\n\nProvider mana yang mau di-update cookie VIP-nya?",
                        parse_mode: "HTML",
                        reply_markup: cookieKb
                    }).catch(() => {});
                }

                // 2. Nangkep Pilihan Provider
                else if (data.startsWith("set_cookie_")) {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    
                    const provider = data.replace("set_cookie_", ""); // Hasilnya: WETV, IQIYI, dll
                    
                    // Simpan ke state kalau admin ini lagi mau masukin cookie
                    adminCookieState.set(String(tgUser.id), provider);

                    await ctx.reply(`🟢 Kamu memilih <b>${provider}</b>.\n\nSilakan <b>paste Cookie VIP</b> yang baru sekarang juga (Kirim teks bebas).\n\n<i>Ketik /cancel untuk membatalkan.</i>`, { parse_mode: "HTML" });
                    await ctx.answerCallbackQuery();
                }
                // ==========================================
                // 🔥 BAGIAN ADMIN PANEL & KELOLA USER 🔥
                // ==========================================
                else if (data === "admin_panel" || data === "admin_refresh") {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    if (data === "admin_refresh") await ctx.answerCallbackQuery("🔄 Memperbarui data...");

                    // 🔥 HAPUS STATE: Kalau lu balik ke dashboard, mode nangkep angka dimatikan
                    AdminController.adminState.delete(String(tgUser.id));

                    const stats = await AdminController.getStats();
                    const adminTxt = AdminController.formatDashboard(stats);

                    await ctx.editMessageCaption({
                        caption: adminTxt, parse_mode: "HTML", reply_markup: AdminController.menu()
                    }).catch(async (e) => {
                        if (e.message.includes("is not modified")) return;
                        await ctx.deleteMessage().catch(() => { });
                        await ctx.replyWithPhoto(BANNER_URL, { caption: adminTxt, parse_mode: "HTML", reply_markup: AdminController.menu() });
                    });
                }

                // --- LIST USER TEXT (DENGAN PAGINATION) ---
                else if (data === "admin_users" || data.startsWith("admin_page_")) {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    await ctx.answerCallbackQuery("👥 Memuat data pengguna...");

                    const page = data.startsWith("admin_page_") ? parseInt(data.replace("admin_page_", "")) : 1;

                    // Ambil 10 user per halaman
                    const { users, totalPages, currentPage } = await AdminController.getUsersList(page, 10);

                    // 🔥 SIMPAN MAPPING KE STATE (Buat cocokin input angka admin ke ID database)
                    const usersMap: Record<number, string> = {};
                    users.forEach((u, i) => {
                        usersMap[(currentPage - 1) * 10 + i + 1] = u.id;
                    });
                    AdminController.adminState.set(String(tgUser.id), { active: true, usersMap });

                    const txt = AdminController.formatUserList(users, currentPage, totalPages);

                    await ctx.editMessageCaption({
                        caption: txt, parse_mode: "HTML", reply_markup: AdminController.userListPagination(currentPage, totalPages)
                    }).catch((e) => {
                        if (e.message.includes("is not modified")) return;
                    });
                }

                // --- AKSI: BANNED / UNBAN USER ---
                else if (data.startsWith("admin_ban_")) {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    const targetId = data.replace("admin_ban_", "");
                    const updatedUser = await AdminController.toggleBan(targetId);

                    if (!updatedUser) return;
                    await ctx.answerCallbackQuery({ text: `✅ Status user diubah menjadi: ${updatedUser.status}`, show_alert: true });

                    const txt = AdminController.formatUserDetail(updatedUser);
                    await ctx.editMessageCaption({
                        caption: txt, parse_mode: "HTML", reply_markup: AdminController.userDetailMenu(updatedUser)
                    }).catch(() => { });
                }

                // --- AKSI: GIVE VIP (7 HARI) ---
                else if (data.startsWith("admin_give_")) {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    const targetId = data.replace("admin_give_", "");
                    const updatedUser = await AdminController.addVipDays(targetId, 7);

                    if (!updatedUser) return;
                    await ctx.answerCallbackQuery({ text: "🎁 Berhasil memberikan VIP 7 Hari!", show_alert: true });

                    const txt = AdminController.formatUserDetail(updatedUser);
                    await ctx.editMessageCaption({
                        caption: txt, parse_mode: "HTML", reply_markup: AdminController.userDetailMenu(updatedUser)
                    }).catch(() => { });

                    // Kirim DM ucapan ke user
                    try {
                        if (updatedUser.telegramId) { // 👈 Tambahin pengecekan ini
                            await ctx.api.sendMessage(updatedUser.telegramId, "🎁 <b>SELAMAT!</b> Admin telah memberikan hadiah <b>VIP PREMIUM gratis selama 7 Hari</b> ke akunmu! Silakan cek menu /start.", { parse_mode: "HTML" });
                        }
                    } catch (e) { console.log("Gagal kirim notif DM ke user."); }
                }

                // --- AKSI: ACC VIP MANUAL (30 HARI) ---
                else if (data.startsWith("admin_acc_")) {
                    if (!isAdmin) return ctx.answerCallbackQuery({ text: "❌ Anda bukan Admin!", show_alert: true });
                    const targetId = data.replace("admin_acc_", "");
                    const updatedUser = await AdminController.addVipDays(targetId, 30);

                    if (!updatedUser) return;
                    await ctx.answerCallbackQuery({ text: "💸 Berhasil ACC VIP 30 Hari!", show_alert: true });

                    const txt = AdminController.formatUserDetail(updatedUser);
                    await ctx.editMessageCaption({
                        caption: txt, parse_mode: "HTML", reply_markup: AdminController.userDetailMenu(updatedUser)
                    }).catch(() => { });

                    // Kirim DM Konfirmasi ke user
                    try {
                        if (updatedUser.telegramId) { // 👈 Tambahin pengecekan ini juga
                            await ctx.api.sendMessage(updatedUser.telegramId, "✅ <b>PEMBAYARAN MANUAL BERHASIL!</b>\n\nAdmin telah mengkonfirmasi pembayaranmu. <b>VIP Premium 30 Hari telah aktif</b> di akunmu. Selamat menikmati!", { parse_mode: "HTML" });
                        }
                    } catch (e) { console.log("Gagal kirim notif DM ke user."); }
                }

            } catch (error) {
                console.error("Error Callback Query:", error);
                await ctx.answerCallbackQuery({ text: "❌ Terjadi kesalahan sistem atau proses belum selesai.", show_alert: true }).catch(() => { });
            }
        });
    }
}