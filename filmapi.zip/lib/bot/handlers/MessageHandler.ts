// file: lib/bot/handlers/MessageHandler.ts
import { Bot } from 'grammy';
import fs from 'fs';
import path from 'path';
import { AdminController } from '../../admin';
import { BANNER_URL } from '../config';
import { adminCookieState } from './CallbackHandler';

export class MessageHandler {
    static register(bot: Bot) {
        // Nangkep semua chat teks biasa yang dikirim ke bot
        bot.on("message:text", async (ctx) => {
            const tgId = String(ctx.from.id);
            const text = ctx.message.text.trim();

            // Hanya diproses kalau yang ngechat adalah Admin
            if (AdminController.isAdmin(tgId)) {
                // ==========================================
                // 🔥 LOGIC SET COOKIE 🔥
                // ==========================================
                const cookieProvider = adminCookieState.get(tgId);

                if (cookieProvider) {
                    if (text === '/cancel') {
                        adminCookieState.delete(tgId);
                        return ctx.reply("✅ Update cookie dibatalkan.");
                    }

                    await ctx.reply("⏳ <i>Menyimpan cookie...</i>", { parse_mode: "HTML" });

                    try {
                        const envVarName = `${cookieProvider}_COOKIES`; // Hasilnya WETV_COOKIES dll

                        // 1. Update Memory PM2 saat ini (Efek Instan)
                        process.env[envVarName] = text;

                        // 2. Tulis ke file .env (Biar gak hilang kalau server restart)
                        const envPath = path.resolve(process.cwd(), '.env');
                        if (fs.existsSync(envPath)) {
                            let envData = fs.readFileSync(envPath, 'utf8');
                            const regex = new RegExp(`^${envVarName}=.*`, 'gm');

                            if (envData.match(regex)) {
                                envData = envData.replace(regex, `${envVarName}="${text}"`);
                            } else {
                                envData += `\n${envVarName}="${text}"\n`;
                            }

                            fs.writeFileSync(envPath, envData);
                            await ctx.reply(`✅ <b>SUKSES!</b>\n\nCookie untuk <b>${cookieProvider}</b> berhasil diperbarui dan disimpan ke file <code>.env</code>.`, { parse_mode: "HTML" });
                        } else {
                            await ctx.reply("⚠️ File `.env` tidak ditemukan di root. Cookie hanya di-update di memori Bot.");
                        }
                    } catch (error: any) {
                        console.error("Gagal nulis .env:", error);
                        await ctx.reply(`❌ Gagal menyimpan ke .env: ${error.message}`);
                    } finally {
                        // Hapus state biar admin bisa pake command/ngetik angka lagi
                        adminCookieState.delete(tgId);
                    }

                    return; // 🔥 WAJIB RETURN BIAR GAK JALANIN LOGIC KELOLA USER DI BAWAHNYA
                }
                const state = AdminController.adminState.get(tgId);

                // Kalau admin lagi ada di mode "Kelola User"
                if (state && state.active) {
                    const num = parseInt(text);

                    if (!isNaN(num) && state.usersMap[num]) {
                        // Admin masukin nomor yang bener
                        const targetId = state.usersMap[num];
                        const targetUser = await AdminController.getUserDetail(targetId);

                        if (targetUser) {
                            // Hapus chat angka admin biar bersih
                            await ctx.deleteMessage().catch(() => { });

                            const txt = AdminController.formatUserDetail(targetUser);

                            // Kirim ulang banner + detail actionnya
                            await ctx.replyWithPhoto(BANNER_URL, {
                                caption: txt,
                                parse_mode: "HTML",
                                reply_markup: AdminController.userDetailMenu(targetUser)
                            });

                            // Bersihin state biar bot ga nangkep angka lain lagi secara gak sengaja
                            AdminController.adminState.delete(tgId);
                        }
                    } else if (!isNaN(num)) {
                        // Admin ngetik angka ngawur (misal milih 15 padahal list cuma sampai 10)
                        await ctx.deleteMessage().catch(() => { });
                        await ctx.reply("❌ Nomor tidak valid atau tidak ada di halaman ini.").then(m => {
                            setTimeout(() => ctx.api.deleteMessage(ctx.chat.id, m.message_id).catch(() => { }), 3000); // Pesan hilang otomatis 3 detik
                        });
                    }
                }
            }
        });
    }
}