// file: lib/bot/handlers/EventHandler.ts
import { Bot, InlineKeyboard } from 'grammy';
import { BANNER_URL } from '../config';
import { BotUtils } from '../utils';

export class EventHandler {
    static register(bot: Bot) {
        bot.on("message:new_chat_members", async (ctx) => {
            const newMembers = ctx.message.new_chat_members;
            for (const member of newMembers) {
                if (member.is_bot) continue;

                const botUsername = ctx.me.username;
                const kb = new InlineKeyboard().url("🤖 Chat Bot Disini", `https://t.me/${botUsername}?start=true`);

                try {
                    await ctx.replyWithPhoto(BANNER_URL, {
                        caption: `👋 Halo <b>${BotUtils.safeHtml(member.first_name)}</b>!\n\nSelamat datang di Komunitas Indocast API.\nDapatkan akses VIP dan API Key gratismu sekarang melalui Bot Resmi kami di bawah ini:`,
                        parse_mode: "HTML",
                        reply_markup: kb
                    });
                } catch (e) {
                    console.error("Gagal kirim ucapan selamat datang:", e);
                }
            }
        });
    }
}