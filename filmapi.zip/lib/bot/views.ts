// file: lib/bot/views.ts
import { InlineKeyboard } from 'grammy';
import { BotUtils } from './utils';
import { BASE_API_URL } from './config';

export const TEXT = {
    dashboard: (user: any, isVip: boolean, hasApiKey: boolean, subEndsAt: Date | null) =>
        `👋 Halo, <b>${BotUtils.safeHtml(user.firstName)}</b>!\n` +
        `📅 <i>${BotUtils.getFormattedDate()}</i>\n\n` +
        `👤 <b>INFORMASI AKUN</b>\n` +
        `├ <b>ID Tele</b>: <code>${user.telegramId}</code>\n` +
        `├ <b>Username</b>: ${user.username ? '@' + BotUtils.safeHtml(user.username) : '-'}\n` +
        `├ <b>Status</b>: ${isVip ? '👑 <b>VIP PREMIUM</b>' : '🌱 <b>FREE USER</b>'}\n` +
        `└ <b>Masa Aktif</b>: <code>${isVip ? BotUtils.formatExpiredDate(subEndsAt) : 'Selamanya'}</code> ${isVip ? `<i>(Sisa ${BotUtils.getRemainingDays(subEndsAt)} Hari)</i>` : ''}\n\n` +
        `🌐 <b>STATISTIK API</b>\n` +
        `├ <b>Status Key</b>: ${hasApiKey ? '✅ <b>Aktif</b>' : '❌ <b>Belum Dibuat</b>'}\n` +
        `└ <b>Base URL</b>: <code>${BASE_API_URL}</code>\n\n` +
        `💡 <b>Pintas Cepat:</b>\n` +
        `/start - Muat Ulang Menu Utama\n` +
        `/bantuan - Syarat & Ketentuan Layanan`,

    apiInfo: (rawKey: string, isVip: boolean, limitPerDay: number, usageToday: number) => {
        const strUsage = usageToday.toLocaleString('id-ID');
        const strLimit = limitPerDay >= 1000000 ? '∞ (Unlimited)' : limitPerDay.toLocaleString('id-ID');
        const limitDisplay = `<b>${strUsage}</b> / ${strLimit}`;

        return `🔑 <b>MANAJEMEN API KEY</b>\n\n` +
            `<b>Status Akses:</b> 🟢 AKTIF (Lifetime)\n` +
            `<b>Pemakaian Hari Ini:</b> ${limitDisplay} Request\n` +
            `<b>Base URL API:</b> <code>${BASE_API_URL}</code>\n\n` +
            `<b>🔗 API Key Kamu:</b>\n<code>${rawKey}</code>\n\n` +
            `<i>(ℹ️ Ketuk API Key di atas untuk menyalin otomatis. Jika API Key kamu bocor ke publik, segera klik tombol Reset di bawah!)</i>`;
    },

    tos:
        `📜 <b>INFORMASI & KEBIJAKAN LAYANAN</b>\n\n` +
        `<b>Indocast API</b> menyediakan akses bypass DRM streaming dengan stabilitas dan performa tinggi.\n\n` +
        `⚠️ <b>Larangan Keras:</b>\n` +
        `🚫 Melakukan Spam atau serangan DDoS.\n` +
        `🚫 Memperjualbelikan API Key pribadi.\n` +
        `🚫 Menggunakan script bot auto-hit secara brutal.\n\n` +
        `<i>Pelanggaran terhadap aturan di atas akan mengakibatkan <b>Banned Permanen</b> secara sepihak tanpa *refund*.</i>`
};

export class Menus {
    static getMainMenu(isAdmin: boolean) {
        const kb = new InlineKeyboard()
            .text("🔑 Kelola API", "menu_api").text("👑 Beli VIP", "menu_buy_vip").row()
            .text("🧾 Riwayat", "menu_history").text("ℹ️ Bantuan", "menu_tos").row()
            .url("💬 Grup Diskusi", "https://t.me/wenetviqi");

        if (isAdmin) {
            kb.row().text("⚙️ Admin Panel", "admin_panel");
        }
        return kb;
    }

    static get adminMenu() {
        return new InlineKeyboard()
            .text("🍪 Set Cookie Provider", "admin_set_cookie").row()
            .text("🔙 Kembali ke Beranda", "menu_main");
    }

    static get cookieProviderMenu() {
        return new InlineKeyboard()
            .text("🔵 WeTV", "set_cookie_WETV")
            .text("🟢 iQIYI", "set_cookie_IQIYI").row()
            .text("🟣 HBO", "set_cookie_HBO")
            .text("🟡 Viu", "set_cookie_VIU").row()
            .text("🔙 Batal", "admin_panel");
    }

    static get backMenu() {
        return new InlineKeyboard().text("🔙 Kembali ke Beranda", "menu_main");
    }

    static apiMenu(hasKey: boolean) {
        const kb = new InlineKeyboard();
        if (!hasKey) {
            kb.text("⚡ Buat API Key", "action_gen_api").row();
        } else {
            kb.text("🔄 Ganti / Reset API Key", "action_regen_api").row();
        }
        return kb.text("🔙 Kembali ke Beranda", "menu_main");
    }
}