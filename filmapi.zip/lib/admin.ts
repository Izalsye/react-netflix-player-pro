// file: lib/admin.ts
import prisma from '../prisma/prisma';
import { InlineKeyboard } from 'grammy';
import { bot } from './bot';

export class AdminController {
    static ADMIN_ID = process.env.ADMIN_TELEGRAM_ID;

    // 🔥 STATE UNTUK NANGKEP BALASAN ANGKA DARI ADMIN
    static adminState = new Map<string, { active: boolean, usersMap: Record<number, string> }>();

    static isAdmin(tgId: number | string): boolean {
        return String(tgId) === this.ADMIN_ID;
    }

    // --- FUNGSI STATISTIK ---
    static async getStats() {
        const totalUsers = await prisma.user.count();
        const vipUsers = await prisma.user.count({ where: { role: 'VIP' } });
        const freeUsers = await prisma.user.count({ where: { role: 'FREE' } });

        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const startOfYear = new Date(now.getFullYear(), 0, 1);

        const calcRevenue = async (dateFilter: any = {}) => {
            const res = await prisma.transaction.aggregate({
                _sum: { amount: true },
                where: { status: { in: ['SETTLEMENT', 'SUCCESS'] }, ...dateFilter }
            });
            return res._sum.amount || 0;
        };

        const totalTrxCount = await prisma.transaction.count({ where: { status: { in: ['SETTLEMENT', 'SUCCESS'] } } });
        const monthlyTrxCount = await prisma.transaction.count({ where: { status: { in: ['SETTLEMENT', 'SUCCESS'] }, createdAt: { gte: startOfMonth } } });

        const totalRevenue = await calcRevenue();
        const monthlyRevenue = await calcRevenue({ createdAt: { gte: startOfMonth } });
        const yearlyRevenue = await calcRevenue({ createdAt: { gte: startOfYear } });

        return { totalUsers, vipUsers, freeUsers, totalTrxCount, monthlyTrxCount, totalRevenue, monthlyRevenue, yearlyRevenue };
    }

    // --- FUNGSI MANAJEMEN USER (PAGINATION) ---
    static async getUsersList(page: number = 1, take: number = 10) {
        const skip = (page - 1) * take;
        const [users, total] = await Promise.all([
            prisma.user.findMany({ orderBy: { createdAt: 'desc' }, skip, take }),
            prisma.user.count()
        ]);
        const totalPages = Math.ceil(total / take) || 1;
        return { users, totalPages, currentPage: page, total };
    }

    static async getUserDetail(userId: string) {
        return await prisma.user.findUnique({ where: { id: userId } });
    }

    static async toggleBan(userId: string) {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) return null;

        const newStatus = user.status === 'ACTIVE' ? 'BANNED' : 'ACTIVE';
        return await prisma.user.update({ where: { id: userId }, data: { status: newStatus } });
    }

    static async addVipDays(userId: string, days: number) {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) return null;

        const now = new Date();
        const baseDate = (user.subEndsAt && user.subEndsAt > now) ? user.subEndsAt : now;
        const newEndsAt = new Date(baseDate);
        newEndsAt.setDate(newEndsAt.getDate() + days);

        return await prisma.user.update({
            where: { id: userId },
            data: { role: 'VIP', subStartsAt: user.subStartsAt || new Date(), subEndsAt: newEndsAt }
        });
    }

    // --- TEMPLATE TEKS ---
    static formatDashboard(stats: any) {
        return `👑 <b>DASHBOARD OWNER</b> 👑\n\n` +
            `👥 <b>Statistik Pengguna:</b>\n` +
            `├ Total: <b>${stats.totalUsers.toLocaleString('id-ID')}</b> User\n` +
            `├ VIP: <b>${stats.vipUsers.toLocaleString('id-ID')}</b> User\n` +
            `└ Free: <b>${stats.freeUsers.toLocaleString('id-ID')}</b> User\n\n` +
            `🛒 <b>Statistik Transaksi:</b>\n` +
            `├ Bulan Ini: <b>${stats.monthlyTrxCount}</b> TRX\n` +
            `└ Total: <b>${stats.totalTrxCount}</b> TRX\n\n` +
            `💰 <b>Pendapatan:</b>\n` +
            `├ Bulan Ini: <b>Rp ${stats.monthlyRevenue.toLocaleString('id-ID')}</b>\n` +
            `└ <b>Total: Rp ${stats.totalRevenue.toLocaleString('id-ID')}</b>`;
    }

    // 🔥 TAMPILAN LIST SEPERTI GAMBAR REFERENSI
    static formatUserList(users: any[], page: number, totalPages: number) {
        let txt = `👥 <b>Daftar Pengguna</b>\n\n`;
        users.forEach((u, i) => {
            const num = (page - 1) * 10 + i + 1;
            const icon = u.role === 'VIP' ? '👑' : '🌱';
            const status = u.status === 'BANNED' ? '(BANNED)' : '';
            txt += `${num}. ${u.firstName} (@${u.username || '-'}) ${icon} ${status}\n`;
        });
        txt += `\n📄 Halaman <b>${page}/${totalPages}</b>\n`;
        txt += `💡 <i>Masukkan nomor untuk lanjut.</i>`;
        return txt;
    }

    static formatUserDetail(user: any) {
        const endDate = user.subEndsAt ? new Date(user.subEndsAt).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }) : 'Tidak Ada (Free)';
        return `👤 <b>DETAIL PENGGUNA</b>\n\n` +
            `├ <b>Nama:</b> ${user.firstName} (@${user.username || '-'}) \n` +
            `├ <b>ID Tele:</b> <code>${user.telegramId}</code>\n` +
            `├ <b>Role:</b> ${user.role === 'VIP' ? '👑 VIP PREMIUM' : '🌱 FREE USER'}\n` +
            `├ <b>Status:</b> ${user.status === 'BANNED' ? '🚫 BANNED' : '✅ ACTIVE'}\n` +
            `└ <b>Aktif s/d:</b> ${endDate}\n\n` +
            `👇 <i>Pilih tindakan:</i>`;
    }

    // --- TEMPLATE MENU KEYBOARD ---
    static menu() {
        return new InlineKeyboard()
            .text("🔄 Refresh Data", "admin_refresh")
            .text("👥 Kelola User", "admin_users").row()
            .text("🍪 Set Cookie", "admin_set_cookie").row() // 👈 Tambahin di baris baru
            .text("🔙 Kembali ke Beranda", "menu_main");
    }

    // 🔥 TOMBOL PAGINATION
    static userListPagination(page: number, totalPages: number) {
        const kb = new InlineKeyboard();
        if (page > 1) kb.text("⬅️ Sebelumnya", `admin_page_${page - 1}`);
        if (page < totalPages) kb.text("Selanjutnya ➡️", `admin_page_${page + 1}`);
        kb.row();
        kb.text("🔙 Kembali ke Dashboard", "admin_panel");
        return kb;
    }

    static userDetailMenu(user: any) {
        const isBanned = user.status === 'BANNED';
        return new InlineKeyboard()
            .text(isBanned ? "✅ Cabut Ban (Unban)" : "🚫 Banned Akun Ini", `admin_ban_${user.id}`).row()
            .text("🎁 Kasih VIP Gratis (7 Hari)", `admin_give_${user.id}`).row()
            .text("💸 ACC VIP Manual (30 Hari)", `admin_acc_${user.id}`).row()
            .text("🔙 Kembali ke List User", "admin_users");
    }

    static async notifyOwner(user: any, planName: string, amount: number) {
        if (!this.ADMIN_ID) return;
        const text = `🚨 <b>TRANSAKSI VIP BERHASIL!</b> 🚨\n\n👤 <b>Pelanggan:</b> ${user.firstName} (@${user.username || '-'}) [<code>${user.telegramId}</code>]\n📦 <b>Paket:</b> ${planName}\n💰 <b>Nominal:</b> Rp ${amount.toLocaleString('id-ID')}\n✅ <b>Status:</b> Sukses & Aktif`;
        try { await bot.api.sendMessage(this.ADMIN_ID, text, { parse_mode: 'HTML' }); } catch (e) { }
    }
}