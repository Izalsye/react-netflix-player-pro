// file: lib/drakorid.ts
import { NextResponse } from 'next/server';
import { recordHit } from './stats'; // Sesuaikan path-nya
import { validateApiKey } from './apiKeyService'; // Sesuaikan path-nya

// ==========================================
// 1. KONFIGURASI CORE & STATE
// ==========================================
const DRAKOR_COOKIE = process.env.DRAKOR_COOKIE || "";
let cachedCsrfToken: string | null = null;
let lastTokenFetchTime = 0;
const TOKEN_CACHE_DURATION = parseInt(process.env.TOKEN_CACHE_DURATION || "300000"); // 5 Menit dalam milidetik

interface FetchOptions {
    path: string;
    payload?: Record<string, string>;
}

interface ScrapeOptions {
    label?: string;
    cacheTtlSeconds?: number;
}

// ==========================================
// 2. FUNGSI PENGAMBIL CSRF TOKEN (OTOMATIS)
// ==========================================
async function getCsrfToken(force = false): Promise<string> {
    const now = Date.now();
    // Gunakan cache jika masih valid dan tidak dipaksa force refresh
    if (!force && cachedCsrfToken && (now - lastTokenFetchTime < TOKEN_CACHE_DURATION)) {
        return cachedCsrfToken;
    }

    console.log("[Drakor Core] Mengambil token CSRF baru...");
    try {
        const res = await fetch("https://drakorid.co/", {
            headers: {
                "Cookie": DRAKOR_COOKIE,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/148.0.0.0"
            }
        });

        const html = await res.text();
        const match = html.match(/var\s+token_now\s*=\s*["']([^"']+)["']/i);

        if (match && match[1]) {
            cachedCsrfToken = match[1];
            lastTokenFetchTime = Date.now();
            return cachedCsrfToken;
        }
        throw new Error("Gagal menemukan token di HTML");
    } catch (error) {
        console.error("[Drakor Core] Gagal ambil token:", error);
        throw error;
    }
}

// ==========================================
// 3. CORE FETCHERS (Bawah Kap)
// ==========================================
export async function postDrakor(options: FetchOptions, isRetry = false): Promise<any> {
    const { path, payload = {} } = options;
    const token = await getCsrfToken(isRetry); // Force refresh jika ini adalah retry

    const formParams = new URLSearchParams();
    formParams.append('token', token);
    for (const key in payload) formParams.append(key, payload[key]);

    const res = await fetch(`https://drakorid.co${path}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Cookie": DRAKOR_COOKIE,
            "Referer": "https://drakorid.co/",
            "X-Requested-With": "XMLHttpRequest"
        },
        body: formParams.toString()
    });

    const responseText = await res.text();

    // Jika response kosong atau menandakan token salah, retry sekali
    if (!isRetry && (responseText === "" || responseText.includes('token'))) {
        console.warn("[Drakor Core] Response kosong/invalid, mencoba refresh token...");
        return postDrakor(options, true);
    }

    try {
        return JSON.parse(responseText);
    } catch {
        return responseText;
    }
}

export async function getDrakorHtml(path: string): Promise<string> {
    if (!DRAKOR_COOKIE) {
        throw new Error("DRAKOR_COOKIE belum disetting di .env!");
    }

    const targetUrl = path.startsWith("http") ? path : `https://drakorid.co${path}`;

    try {
        const res = await fetch(targetUrl, {
            method: "GET",
            headers: {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Cookie": DRAKOR_COOKIE,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/148.0.0.0",
                "Referer": "https://drakorid.co/",
            }
            // Note: Caching Next.js bisa di-handle di wrapper-nya
        });

        const html = await res.text();

        if (html.includes('class="login"') || html.includes('Belum login')) {
            console.error("🚨 [Drakor Core] COOKIE DI .ENV LU UDAH BASI!");
            throw new Error("Cookie DrakorID Basi");
        }

        return html;
    } catch (error) {
        console.error("[Drakor Core] Error GET HTML:", error);
        throw error;
    }
}

// ==========================================
// 4. PROXY WRAPPERS (Buat dipakai di Route Handler)
// ==========================================

/**
 * Proxy untuk metode GET (Scraping HTML dengan Cheerio)
 */
export async function proxyDrakorGet(
    req: Request,
    path: string,
    scraperFn: (html: string) => any,
    opts: ScrapeOptions = { label: 'drakor-scrape', cacheTtlSeconds: 0 }
) {
    // 3. Fetch HTML ke Target Upstream via Drakor Core
    try {
        const html = await getDrakorHtml(path);

        // 4. Jalankan fungsi mapping HTML -> JSON
        const mappedData = scraperFn(html);

        // 5. Kembalikan Response JSON Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        console.error(`[proxyDrakorGet Error] ${path}:`, error.message);
        return NextResponse.json({ code: 502, message: "Upstream fetch failed: " + error.message, data: null }, { status: 502 });
    }
}

/**
 * Proxy untuk metode POST (Ambil Link / Token Player / Slider)
 */
export async function proxyDrakorPost(
    req: Request,
    options: FetchOptions,
    mapperFn?: (data: any) => any
) {
    try {
        const responseData = await postDrakor(options);

        // 4. Mapping data kalau ada mapperFn (misal perlu extract link dari JSON)
        const finalData = mapperFn ? mapperFn(responseData) : responseData;

        // 5. Kembalikan Response JSON
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: finalData
        });

    } catch (error: any) {
        console.error(`[proxyDrakorPost Error] ${options.path}:`, error.message);
        return NextResponse.json({ code: 502, message: "Upstream POST failed: " + error.message, data: null }, { status: 502 });
    }
}

// Tambahin ini di lib/drakorid.ts (di bawah fungsi proxy yang lain)
export async function proxyDrakorCustom(
    req: Request,
    logicFn: () => Promise<any>
) {
    const endpointPath = new URL(req.url).pathname;

    // 3. Jalankan Logic Custom dari Endpoint
    try {
        const resultData = await logicFn(); // Eksekusi callback

        return NextResponse.json({
            code: 0,
            message: "ok",
            data: resultData
        });
    } catch (error: any) {
        console.error(`[proxyDrakorCustom Error] ${endpointPath}:`, error.message);
        // Tangkap custom error code kalau ada, default 500
        const status = error.message.includes('wajib diisi') ? 400 : 500;
        return NextResponse.json({ code: status, message: error.message, data: null }, { status });
    }
}