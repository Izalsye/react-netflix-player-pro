import crypto from 'crypto';

interface SignatureParams {
    deviceId: string;
    timestampMs: string | number;
}

/**
 * Generate MD5 Signature untuk API Cinema
 * Rumus: MD5(Secret_Key + device_id + cur_time)
 */
export function generateCinemaSignature({
    deviceId,
    timestampMs
}: SignatureParams): string {
    // Ambil secret key dari env, kasih fallback kalau misalnya env belum ke-load
    const secretKey = process.env.CINEMAID_SECRET_KEY || "47Q8tBqO4YqrMHf4";

    // Gabungkan string sesuai rumus
    const rawData = `${secretKey}${deviceId}${timestampMs}`;

    // Hash menggunakan MD5
    const hashValue = crypto.createHash('md5').update(rawData).digest('hex');

    // Return dalam bentuk Uppercase (huruf besar) sesuai format header_sign
    return hashValue.toUpperCase();
}