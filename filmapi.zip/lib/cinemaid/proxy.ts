import { generateCinemaSignature } from './signature';
import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { decryptCinemaResponse } from './decrypt';

// 👇 Konfigurasi Upstream untuk CinemaID
const UPSTREAM_BASE = process.env.CINEMAID_UPSTREAM_BASE || "https://freecinenewph.t62nds.com";

// 👇 Token dan Static Sign (Dari Log)
const CINEMAID_TOKEN = process.env.CINEMAID_TOKEN || "gAAAAABqFlOgFdSU_n0nEnfundYALA2_dP9zx9IA5CRGvnv2ls9_el2NJL06Wgr-HhElrfe5OKeTMSuhMIK4tpOPJ_CbbjKC07ScaLMh4ZZR4fvmjBpJBdIjaedOq_oFBfv0uaPOGLYXzFYHUziUZyX_bMsTaxzsEOfJIN-nsAyx85RGRU1xJnxK0FhNhZRyJ0Jdd0Ci74JzxjcHvy5KbIEvITWSFA-V_J0vBIyMokdhEq719hXNk4tjYVnRbKqQSqB94gRLMQkt";
const DEFAULT_DEVICE_ID = process.env.CINEMAID_DEFAULT_DEVICE_ID || "f04cf4ea3b06ac32";

// 👇 Konfigurasi Proxy Opsional via .env
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

const cache = new Map<string, { val: any, exp: number }>();

function mask(s?: string | null, keepStart = 10, keepEnd = 6) {
    if (!s) return s;
    if (s.length <= keepStart + keepEnd) return "***";
    return `${s.slice(0, keepStart)}***${s.slice(-keepEnd)}`;
}

// Menyesuaikan log untuk melihat header penting CinemaID
function pickHeadersForLog(h: Record<string, string>) {
    return {
        "user-agent": h["user-agent"],
        "androidid": h["androidid"],
        "cur_time": h["cur_time"],
        "header_sign": h["header_sign"],
        "token": mask(h["token"], 15, 10),
    };
}

// 👇 Helper untuk generate headers CinemaID
function buildCinemaHeaders(req: Request, deviceId: string, timestampMs: string): Record<string, string> {
    const headerSign = generateCinemaSignature({
        deviceId,
        timestampMs,
    });

    return {
        "androidid": deviceId,
        "app_id": "movieph",
        "app_language": "id",
        "channel_code": "movieph_1002",
        "cur_time": timestampMs,
        "device_id": deviceId,
        "en_al": "0",
        "gaid": "8c20cbbc-0d79-483e-b448-2cdc0568633d",
        "is_display": "WIB",
        "is_language": "in",
        "is_vvv": "1",
        "mob_mfr": "samsung",
        "mobmodel": "SM-G955F",
        "package_name": "com.movieph.bj.playvibes",
        "sign": headerSign,
        "sys_platform": "2",
        "sysrelease": "9",
        "token": CINEMAID_TOKEN,
        "version": "40000",
        "User-Agent": "okhttp/4.10.0",
    };
}

async function httpsGet(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; statusMessage?: string; headers: Record<string, any>; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
            },
            (res) => {
                let data = "";
                res.setEncoding("utf8");
                res.on("data", (chunk) => (data += chunk));
                res.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        statusMessage: res.statusMessage,
                        headers: res.headers as any,
                        text: data,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

// PERBAIKAN: Tambah parameter contentType biar nggak 404
async function httpsPost(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; statusMessage?: string; headers: Record<string, any>; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType, // <-- Pakai yang dinamis
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
            },
            (res) => {
                let data = "";
                res.setEncoding("utf8");
                res.on("data", (chunk) => (data += chunk));
                res.on("end", () => resolve({ status: res.statusCode || 0, statusMessage: res.statusMessage, headers: res.headers as any, text: data }));
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    opts: { label: string; transform?: (d: any) => any; cacheTtlMs?: number; send?: boolean } = { label: 'proxy-get' }
) {

    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;
    const publicEndpoint = opts.label || new URL(req.url).pathname || path;

    await recordHit(req, visitorId, publicEndpoint, req.method);
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();
    const pathWithQuery = qs ? `${path}?${qs}` : path;

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(JSON.stringify(hit.val), {
                headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' },
            });
        }
    }

    const tsMs = Date.now().toString();
    const headers = buildCinemaHeaders(req, DEFAULT_DEVICE_ID, tsMs);
    const upstreamUrl = `${UPSTREAM_BASE}${pathWithQuery}`;

    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        // PERBAIKAN: Cukup kirim url, headers, dan timeout
        const { status, text } = await httpsGet(upstreamUrl, headers, 15_000);

        let json: any;
        if (text.trim().startsWith('{') || text.trim().startsWith('[')) {
            try {
                json = JSON.parse(text);
            } catch {
                return new Response(text, { status });
            }
        } else {
            json = decryptCinemaResponse(text);
            if (!json) {
                return new Response(text, { status, headers: { 'Content-Type': 'text/plain' } });
            }
        }

        const out = opts.transform ? opts.transform(json) : json;

        // PERBAIKAN: Kembalikan fungsi simpan cache
        if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs) {
            cache.set(cacheKey, { val: out, exp: Date.now() + opts.cacheTtlMs });
        }

        if (opts.send === false) return out;
        return NextResponse.json(out, { status });
    } catch (e: any) {
        console.error(`[proxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}
export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; cacheTtlMs?: number; send?: boolean; contentType?: string } = { label: 'proxy-post' }
) {

    const bodyString = typeof body === 'string' ? body : JSON.stringify(body);
    const tsMs = Date.now().toString();
    const headers = buildCinemaHeaders(req, DEFAULT_DEVICE_ID, tsMs);
    const upstreamUrl = `${UPSTREAM_BASE}${path}`;

    const cType = opts.contentType || "application/x-www-form-urlencoded";

    try {
        // 1. Mulai hitung waktu request jaringan
        console.time('NetworkRequest');
        const { status, text } = await httpsPost(upstreamUrl, headers, bodyString, cType);
        // Stop hitung waktu request jaringan
        console.timeEnd('NetworkRequest');

        let json: any;

        if (text.trim().startsWith('{') || text.trim().startsWith('[')) {
            try {
                json = JSON.parse(text);
            } catch {
                return new Response(text, { status });
            }
        } else {
            // Regex untuk mengecek apakah string berbentuk Base64 valid
            const isBase64 = /^[A-Za-z0-9+/]*={0,2}$/.test(text.trim());

            if (!isBase64) {
                // Jika bukan Base64, berarti ini teks biasa (seperti error mandarin tadi)
                console.warn(`⚠️ [CinemaID Proxy] Menerima respon plaintext (Bukan Terenkripsi): ${text}`);
                return new Response(text, { status, headers: { 'Content-Type': 'text/plain' } });
            }

            // Jika lolos cek Base64, baru lakukan dekripsi
            console.time('DecryptProcess');
            json = decryptCinemaResponse(text);
            console.timeEnd('DecryptProcess');

            if (!json) {
                return new Response(text, { status, headers: { 'Content-Type': 'text/plain' } });
            }
        }

        if (opts.send === false) return json;
        return NextResponse.json(json, { status });
    } catch (e: any) {
        return NextResponse.json({ error: true, message: e.message }, { status: 502 });
    }
}