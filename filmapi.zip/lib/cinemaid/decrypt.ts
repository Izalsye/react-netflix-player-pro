import crypto from 'crypto';

/**
 * Decrypt respon dari server CinemaID
 * Algorithm: AES/CBC/PKCS5Padding (aes-128-cbc)
 */
export function decryptCinemaResponse(encryptedBase64: string): any {
    // Nilai hex dari log lu (bisa dipindah ke .env juga kalau mau lebih rapi)
    const keyHex = process.env.CINEMAID_AES_KEY || '30313233343536373839313233343536';
    const ivHex = process.env.CINEMAID_AES_IV || '32303135303330313230313233343536';

    try {
        // Convert hex string ke Buffer
        const key = Buffer.from(keyHex, 'hex');
        const iv = Buffer.from(ivHex, 'hex');

        // Inisialisasi decipher
        const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);

        // Dekripsi dari base64 ke utf8
        let decryptedText = decipher.update(encryptedBase64, 'base64', 'utf8');
        decryptedText += decipher.final('utf8');

        // Hasilnya berupa string JSON, langsung kita parse
        return JSON.parse(decryptedText);
    } catch (error: any) {
        console.error('[CinemaID Decrypt Error] Gagal decrypt response:', error.message);
        // Kalau gagal (misal server tiba-tiba ngasih error text biasa), kita return null
        return null;
    }
}