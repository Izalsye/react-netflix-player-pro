export enum Language {
    ENGLISH = 'eng',
    SPANISH = 'esp',
    FRENCH = 'fra',
    INDONESIAN = 'ind',
    PORTUGUESE_BR = 'ptb',
    RUSSIAN = 'rus',
    THAI = 'tha',
    VIETNAMESE = 'vie',
    GERMAN = 'deu'
}

export enum Viewer {
    HORIZONTAL = 'horizontal',
    VERTICAL = 'vertical'
}

export enum Quality {
    LOW = 'low',
    HIGH = 'high',
    SUPER_HIGH = 'super_high'
}

export enum Ranking {
    HOTTEST = 'hottest',
    TRENDING = 'trending',
    COMPLETED = 'completed'
}

export enum PageType {
    SERVICE_AGREEMENT = 'service_agreement',
    SUBSCRIPTION_EXPLANATION = 'subscription_explanation',
    TITLE_BOOKMARKS = 'title_bookmarks'
}

export enum TitleType {
    SERIALIZING = 'serializing',
    COMPLETED = 'completed',
    ONE_SHOT = 'one-shot'
}