// file: lib/mangaplus/client.ts
import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { Language, Viewer, Quality, Ranking, TitleType } from './constants';
import { decodeMangaPlusResponse } from './parser';
import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import { mapAllTitles, mapFeaturedTitles, mapMangaDetail, mapMangaHome, mapMangaRanking, mapMangaViewer } from './mangaplusMap';

export interface MangaPlusConfig {
    lang?: string | null;
    clang?: string | null;
    viewer?: Viewer;
}

export class MangaPlusClient {
    private api = 'https://jumpg-api.tokyo-cdn.com/api';
    private appVersion = 237;
    private lang: Language;
    private clang: Language[];
    private viewer: Viewer;
    private secret: string | null = null;

    constructor(config?: MangaPlusConfig) {
        // 1. Tentukan bahasa utama (lang)
        this.lang = this.parseLanguage(config?.lang, Language.INDONESIAN);

        // 2. Tentukan bahasa konten (clang). Jika config.clang kosong, pakai nilai dari config.lang
        const targetClang = config?.clang ? config.clang : (config?.lang || 'eng');
        const additionalLang = this.parseLanguage(targetClang, Language.INDONESIAN);

        // 3. Masukkan ke array filter bahasa konten
        this.clang = [this.lang, additionalLang];
        this.viewer = config?.viewer || Viewer.VERTICAL;
    }

    /**
     * Helper internal untuk memetakan string query param ke Enum Language asli
     */
    private parseLanguage(langStr: string | null | undefined, defaultLang: Language): Language {
        if (!langStr) return defaultLang;
        const found = Object.entries(Language).find(([_, val]) => val === langStr.toLowerCase());
        return found ? (found[1] as Language) : defaultLang;
    }

    private get clangString(): string {
        return this.clang.join(',');
    }

    private bool2str(value: boolean): string {
        return value ? 'yes' : 'no';
    }

    /**
     * Otomatis mengurus autentikasi token internal sebelum hit API utama
     */
    private async ensureAuth() {
        if (process.env.MANGAPLUS_SECRET) {
            this.secret = process.env.MANGAPLUS_SECRET;
            return;
        }
        if ((global as any).mangaplusDeviceSecret) {
            this.secret = (global as any).mangaplusDeviceSecret;
            return;
        }

        // Jalankan auto-register jika token benar-benar kosong
        const dummyId = "nextjs_proxy_device_arsha_12345";
        const deviceToken = crypto.createHash('md5').update(dummyId, 'utf-8').digest('hex');
        const securityKey = crypto.createHash('md5').update(deviceToken + '4Kin9vGg', 'utf-8').digest('hex');

        const url = new URL(`${this.api}/register`);
        url.searchParams.append('os', 'android');
        url.searchParams.append('os_ver', '35');
        url.searchParams.append('app_ver', this.appVersion.toString());
        url.searchParams.append('device_token', deviceToken);
        url.searchParams.append('security_key', securityKey);

        const response = await fetch(url.toString(), {
            method: 'PUT',
            headers: { 'User-Agent': 'okhttp/4.12.0', 'Connection': 'Keep-Alive' }
        });

        if (response.ok) {
            const arrayBuffer = await response.arrayBuffer();
            const decodedData = await decodeMangaPlusResponse(Buffer.from(arrayBuffer));
            if (decodedData.success?.registerationData?.deviceSecret) {
                const secretToken = decodedData.success.registerationData.deviceSecret;
                this.secret = secretToken;
                (global as any).mangaplusDeviceSecret = secretToken;
            }
        }
    }

    /**
     * Core Fetcher & Protobuf Decoder
     */
    public async request(method: string, endpoint: string, queryParams: Record<string, any> = {}): Promise<any> {
        await this.ensureAuth();

        const url = new URL(`${this.api}${endpoint}`);
        const params: Record<string, string> = {
            ...queryParams,
            os: 'android',
            os_ver: '35',
            app_ver: this.appVersion.toString(),
        };

        if (this.secret) params['secret'] = this.secret;

        Object.keys(params).forEach(key => {
            if (params[key] !== undefined) url.searchParams.append(key, params[key]);
        });

        const response = await fetch(url.toString(), {
            method: method,
            headers: {
                'Accept-Encoding': 'gzip',
                'Connection': 'Keep-Alive',
                'Host': url.hostname,
                'User-Agent': 'okhttp/4.12.0',
            },
            next: { revalidate: 3600 }
        });

        if (!response.ok) throw new Error(`Upstream error: ${response.status} ${response.statusText}`);

        const arrayBuffer = await response.arrayBuffer();
        const decodedData = await decodeMangaPlusResponse(Buffer.from(arrayBuffer));

        if (decodedData.error) {
            const subject = decodedData.error.englishPopup?.subject?.replace(/\s+/g, '') || 'MangaPlusError';
            const body = decodedData.error.englishPopup?.body || 'Unknown API Error';
            throw new Error(`[${subject}] ${body}`);
        }

        return decodedData.success;
    }

    /**
     * PROXY WRAPPER STANDARD (Sama persis polanya dengan provider lain lu)
     */
    public async proxy(req: Request, label: string, fetchFn: () => Promise<any>) {

        try {
            const finalData = await fetchFn();
            return NextResponse.json({ code: 0, message: "ok", data: finalData });
        } catch (error: any) {
            console.error(`[proxyMangaPlus Error] ${label}:`, error.message);
            return NextResponse.json({ code: 502, message: "Upstream fetch failed: " + error.message, data: null }, { status: 502 });
        }
    }

    // ==========================================
    // CLEAN DATA ENDPOINTS (Sudah Ter-mapping)
    // ==========================================

    async getHomeClean() {
        const successData = await this.request('GET', '/home_v6', {
            lang: this.lang,
            viewer_mode: this.viewer,
            clang: this.clangString
        });

        const homeViewData = successData?.homeViewV6;

        // Satukan data biner mentah
        const combinedRaw = {
            banners: [] as any[],
            sections: homeViewData?.sections || [],
            popup: homeViewData?.popup || null
        };

        // Cari seksi banner di dalam list sections, lalu naikkan ke root objek penampung
        if (Array.isArray(homeViewData?.sections)) {
            const foundBannerSection = homeViewData.sections.find((s: any) => s.bannerSection?.banners);
            if (foundBannerSection?.bannerSection?.banners) {
                combinedRaw.banners = foundBannerSection.bannerSection.banners;
            }
        }

        // Tembak langsung ke mapper ter-revisi
        return mapMangaHome(combinedRaw);
    }

    async getTitleDetailClean(titleId: number) {
        const successData = await this.request('GET', '/title_detailV3', {
            title_id: titleId.toString(),
            lang: this.lang,
            clang: this.clangString
        });

        // Panggil mapper eksternal untuk merapikan struktur datanya
        return mapMangaDetail(successData?.titleDetailView || successData);
    }

    async getAllTitlesClean(type: TitleType = TitleType.SERIALIZING) {
        const successData = await this.request('GET', '/title_list/all_v3', {
            type,
            lang: this.lang,
            clang: this.clangString
        });

        // Trik reverse lookup buat ngubah kode 'ind' jadi string panjang 'INDONESIAN'
        const currentLangValue = this.lang.toString().toLowerCase();
        const foundKey = Object.entries(Language).find(([_, val]) => val === currentLangValue);
        const targetLangStr = foundKey ? foundKey[0] : "INDONESIAN";

        // Tembak data searchView langsung ke modul map eksternal
        return mapAllTitles(successData?.searchView, targetLangStr);
    }

    async getRankingClean(ranking: Ranking = Ranking.HOTTEST) {
        const successData = await this.request('GET', '/title_list/rankingV2', {
            lang: this.lang,
            type: ranking,
            clang: this.clangString
        });

        // Ambil nama Key panjang dari Enum Language (contoh: 'ind' -> 'INDONESIAN')
        const currentLangValue = this.lang.toString().toLowerCase();
        const foundKey = Object.entries(Language).find(([_, val]) => val === currentLangValue);
        const targetLangStr = foundKey ? foundKey[0] : "INDONESIAN";

        // Kirim data biner mentah ke mapper eksternal
        return mapMangaRanking(successData?.titleRankingViewV2, targetLangStr);
    }

    async getFeaturedClean() {
        const successData = await this.request('GET', '/title_list/favorite_titles', {
            lang: this.lang,
            clang: this.clangString
        });

        // 1. Cari Key Name dari Enum Language berdasarkan value current this.lang (misal: 'ind' -> 'INDONESIAN')
        const currentLangValue = this.lang.toString().toLowerCase();
        const foundKey = Object.entries(Language).find(([_, val]) => val === currentLangValue);

        // 2. Ambil nama Key-nya, kalau gak ketemu default ke "INDONESIAN"
        let targetLangStr = foundKey ? foundKey[0] : "INDONESIAN";

        // Oper ke mapper eksternal dengan nama bahasa panjang yang dinamis dan otomatis!
        return mapFeaturedTitles(successData?.favoriteTitlesView, targetLangStr);
    }

    async getMangaDataClean(chapterId: number, options?: { split?: boolean; quality?: Quality; ticket?: boolean; free?: boolean; subscription?: boolean }) {
        const successData = await this.request('GET', '/manga_viewer', {
            chapter_id: chapterId.toString(),
            split: this.bool2str(options?.split ?? true),
            img_quality: options?.quality || Quality.SUPER_HIGH,
            ticket_reading: this.bool2str(options?.ticket ?? false),
            free_reading: this.bool2str(options?.free ?? false),
            subscription_reading: this.bool2str(options?.subscription ?? false),
            viewer_mode: this.viewer,
            clang: this.clangString
        });

        // Lempar data mentah protobuf langsung ke modul map eksternal
        return mapMangaViewer(successData?.mangaViewer);
    }
}