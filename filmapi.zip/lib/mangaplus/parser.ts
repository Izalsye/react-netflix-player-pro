import path from 'path';
import protobuf from 'protobufjs';

// Setup path ke file proto yang udah lu save
const PROTO_PATH = path.resolve(process.cwd(), 'lib/mangaplus/mangaplus_api.proto');

export const decodeMangaPlusResponse = async (buffer: Buffer | Uint8Array) => {
    try {
        // 1. Load skema protobuf
        const root = await protobuf.load(PROTO_PATH);

        // 2. Targetin message 'Response' (karena semua data dibungkus di message ini)
        const ResponseMessage = root.lookupType('mangaplus_api.Response');

        // 3. Decode buffer dari API
        const decoded = ResponseMessage.decode(buffer);

        // 4. Convert ke plain JS Object biar gampang diolah di Next.js (misal buat route handler API)
        return ResponseMessage.toObject(decoded, {
            enums: String,  // Ubah enum angka jadi string (misal: 0 jadi 'SUCCESS')
            longs: String,  // Amanin angka gede (int64) jadi string biar gak precision loss
            defaults: true, // Masukin default value kalau field-nya kosong
        });
    } catch (error) {
        console.error("Gagal nge-decode response MangaPlus:", error);
        throw error;
    }
};