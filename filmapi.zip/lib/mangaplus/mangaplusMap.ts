// file: lib/mangaplus/mangaplusMap.ts

export interface CleanChapter {
    id: number;
    titleId: number;
    name: string;
    subTitle: string;
    thumbnail: string;
    viewCount: number;
    commentCount: number;
    isFree: boolean;
}

export interface HalamanKomik {
    url: string;
    width: number;
    height: number;
}

export interface CleanViewerData {
    judul: string;
    namachapter: string;
    idchapter: number;
    subjudul: string;
    halamankomik: HalamanKomik[];
    chapters: CleanChapter[]; // Tetap kita sertakan untuk navigasi Prev/Next di UI
}

/**
 * Memetakan object bab mentah dari Protobuf menjadi bentuk yang bersih
 */
export function mapChapter(raw: any): CleanChapter {
    return {
        id: typeof raw.chapterId === 'string' ? parseInt(raw.chapterId) : (raw.chapterId || 0),
        titleId: raw.titleId || 0,
        name: raw.name || "",
        subTitle: raw.subTitle || "",
        thumbnail: raw.thumbnailUrl || "",
        viewCount: raw.viewCount || 0,
        commentCount: raw.commentCount || 0,
        isFree: raw.viewedForFree || false
    };
}

/**
 * Memetakan seluruh data penampil (viewer) manga ke bahasa Indonesia
 */
export function mapMangaViewer(viewerData: any): CleanViewerData {
    const rawPages = viewerData?.pages || [];
    const rawChapters = viewerData?.chapters || [];

    // Ambil id chapter yang sedang aktif dibaca saat ini
    const currentChapterId = typeof viewerData?.chapterId === 'string'
        ? parseInt(viewerData.chapterId)
        : (viewerData?.chapterId || 0);

    // Filter dan bersihkan data halaman gambar komik
    const cleanPages: HalamanKomik[] = rawPages
        .filter((page: any) => page.mangaPage?.imageUrl)
        .map((page: any) => ({
            url: page.mangaPage.imageUrl,
            width: page.mangaPage.width,
            height: page.mangaPage.height
        }));

    // Bersihkan daftar seluruh bab komik pendukung
    const cleanChapters: CleanChapter[] = rawChapters.map((ch: any) => mapChapter(ch));

    // Cari info subjudul bab aktif dari daftar chapters pendukung
    const activeChapterInfo = cleanChapters.find((ch) => ch.id === currentChapterId);
    const subjudulAktif = activeChapterInfo ? activeChapterInfo.subTitle : "";

    return {
        judul: viewerData?.titleName || "",
        namachapter: viewerData?.chapterName || "",
        idchapter: currentChapterId,
        subjudul: subjudulAktif,
        halamankomik: cleanPages,
        chapters: cleanChapters,
    };
}

// Tambahan Interface untuk Detail Komik
export interface CleanBanner {
    id: number;
    url: string;
    actionUrl: string;
}

export interface CleanDetailData {
    idkomik: number;
    judul: string;
    author: string;
    sinopsis: string;
    coverPortrait: string;
    coverLandscape: string;
    coverMain: string;
    totalView: number;
    bahasa: string;
    statusUpdate: string;
    jadwalRilis: string;
    isSimulpub: boolean;
    tags: string[];
    chapters: CleanChapter[];
}

/**
 * Memetakan seluruh data detail manga ke format bahasa Indonesia yang manusiawi
 */
export function mapMangaDetail(detailData: any): CleanDetailData {
    const titleObj = detailData?.title || {};
    const rawChapters = detailData?.chapterListV2 || [];
    const rawTags = detailData?.tags || [];
    const rawBanners = detailData?.titleBanners || [];

    // 1. Mapping daftar bab komik menggunakan fungsi mapChapter yang sudah ada sebelumnya
    const cleanChapters: CleanChapter[] = rawChapters.map((ch: any) => mapChapter(ch));

    // 2. Mapping tags kategori menjadi array string simpel
    const cleanTags: string[] = rawTags.map((t: any) => t.tag || "");

    // 3. Mapping banner promosi bawaan komik
    const cleanBanners: CleanBanner[] = rawBanners.map((b: any) => ({
        id: b.id || 0,
        url: b.imageUrl || "",
        actionUrl: b.action?.url || ""
    }));

    return {
        idkomik: titleObj.titleId || 0,
        judul: titleObj.name || "",
        author: titleObj.author || "",
        sinopsis: detailData?.overview || "",
        coverPortrait: titleObj.portraitImageUrl || "",
        coverLandscape: titleObj.landscapeImageUrl || "",
        coverMain: detailData?.titleImageUrl || "",
        totalView: detailData?.numberOfViews || 0,
        bahasa: titleObj.language || "",
        statusUpdate: titleObj.titleUpdateStatus || "",
        jadwalRilis: detailData?.titleLabels?.releaseSchedule || "",
        isSimulpub: detailData?.titleLabels?.isSimulpub || false,
        tags: cleanTags,
        chapters: cleanChapters
    };
}

// home
// Tambahan Interface untuk Halaman Beranda (Home)
export interface HomeKomikItem {
    idkomik: number;
    judul: string;
    author: string;
    coverPortrait: string;
    idchapter: number;
    namachapter: string;
    subjudulchapter: string;
    totalViewChapter: number;
    statusUpdate: string;
}

export interface HomeBannerSimpel {
    id: number;
    url: string;
    actionUrl: string;
}

export interface CleanHomeData {
    banners: HomeBannerSimpel[];
    unggulan: HomeKomikItem[];
    rekomendasiBanners: HomeBannerSimpel[];
    komikLainnya: HomeKomikItem[];
    popup: {
        id: number;
        url: string;
        actionUrl: string;
    } | null;
}

/**
 * Memetakan seluruh isi data beranda (HomeViewV6) ke bahasa Indonesia yang simpel
 */

export function mapMangaHome(rawHomeData: any): CleanHomeData {
    const cleanBanners: HomeBannerSimpel[] = [];
    const cleanUnggulan: HomeKomikItem[] = [];
    const cleanRekomendasiBanners: HomeBannerSimpel[] = [];
    const cleanKomikLainnya: HomeKomikItem[] = [];

    // 1. Ambil banner utama atas
    if (Array.isArray(rawHomeData?.banners)) {
        rawHomeData.banners.forEach((b: any) => {
            cleanBanners.push({
                id: b.id || 0,
                url: b.imageUrl || "",
                actionUrl: b.action?.url || ""
            });
        });
    }

    // 2. Bedah array 'sections' (Awas jangan typo updates lagi kwkwkw)
    if (Array.isArray(rawHomeData?.sections)) {
        rawHomeData.sections.forEach((sec: any) => {

            // Masuk ke weeklySection -> contents
            if (Array.isArray(sec.weeklySection?.contents)) {
                sec.weeklySection.contents.forEach((contentBlock: any) => {
                    if (Array.isArray(contentBlock?.contentItems)) {
                        contentBlock.contentItems.forEach((item: any) => {

                            // A. Mapping Komik Unggulan Utama / Highlight Banner (mVBanner)
                            const mvBanner = item.mVBanner || item.mvBanner; // Jaga-jaga pascal atau camelCase
                            if (mvBanner?.titleGroups?.titles) {
                                mvBanner.titleGroups.titles.forEach((t: any) => {
                                    const titleObj = t.title || {};
                                    cleanUnggulan.push({
                                        idkomik: titleObj.titleId || 0,
                                        judul: titleObj.name || "",
                                        author: titleObj.author || "",
                                        coverPortrait: titleObj.portraitImageUrl || "",
                                        idchapter: t.chapterId || 0,
                                        namachapter: t.chapterName || "",
                                        subjudulchapter: t.chapterSubTitle || "",
                                        totalViewChapter: mvBanner.titleGroups.viewCount || 0,
                                        statusUpdate: titleObj.titleUpdateStatus || ""
                                    });
                                });
                            }

                            // B. Mapping Kumpulan Banner Rekomendasi Tengah (carouselBanners)
                            if (item.carouselBanners?.banners) {
                                item.carouselBanners.banners.forEach((b: any) => {
                                    cleanRekomendasiBanners.push({
                                        id: b.id || 0,
                                        url: b.imageUrl || "",
                                        actionUrl: b.action?.url || ""
                                    });
                                });
                            }

                            // C. Mapping Kumpulan List Komik Update Reguler (minorLanguageBanner / titleGroup)
                            const sideGroup = item.minorLanguageBanner || item.titleGroup;
                            if (sideGroup && Array.isArray(sideGroup.titleGroups)) {
                                sideGroup.titleGroups.forEach((group: any) => {
                                    if (Array.isArray(group.titles)) {
                                        group.titles.forEach((t: any) => {
                                            const titleObj = t.title || {};
                                            cleanKomikLainnya.push({
                                                idkomik: titleObj.titleId || 0,
                                                judul: titleObj.name || "",
                                                author: titleObj.author || "",
                                                coverPortrait: titleObj.portraitImageUrl || "",
                                                idchapter: t.chapterId || 0,
                                                namachapter: t.chapterName || "",
                                                subjudulchapter: t.chapterSubTitle || "",
                                                totalViewChapter: group.viewCount || 0,
                                                statusUpdate: titleObj.titleUpdateStatus || ""
                                            });
                                        });
                                    }
                                });
                            }

                        });
                    }
                });
            }
        });
    }

    // 3. Ambil Popup Iklan Rilis Komik
    let cleanPopup = null;
    const popupObj = rawHomeData?.popup;
    if (popupObj?.oneImage) {
        cleanPopup = {
            id: popupObj.popupId || 0,
            url: popupObj.oneImage.imageUrl || "",
            actionUrl: popupObj.oneImage.action?.url || ""
        };
    }

    return {
        banners: cleanBanners,
        unggulan: cleanUnggulan,
        rekomendasiBanners: cleanRekomendasiBanners,
        komikLainnya: cleanKomikLainnya,
        popup: cleanPopup
    };
}

// file: lib/mangaplus/mangaplusMap.ts

export interface UnggulanKomikSimpel {
    idkomik: number;
    judul: string;
    author: string;
    totalView: number;
    bahasa: string;
    coverUnggulan: string;
    statusUpdate: string;
}

// Kita update interfacenya biar bawa info fallback
export interface CleanUnggulanView {
    bahasaDiminta: string;
    bahasaTerpilih: string;
    isFallback: boolean;
    keterangan: string;
    totalKomik: number;
    daftarKomik: UnggulanKomikSimpel[];
}

/**
 * Memetakan data komik favorit/unggulan pilihan editor MangaPlus
 */
export function mapFeaturedTitles(rawFeaturedData: any, targetLang: string = "INDONESIAN"): CleanUnggulanView {
    const favoriteBlocks = rawFeaturedData?.favoriteTitles || [];

    const normalizedTarget = targetLang.toUpperCase();
    let selectedBlock = favoriteBlocks.find((block: any) => block.language === normalizedTarget);

    let isFallback = false;
    let keterangan = `Menampilkan komik unggulan dalam versi bahasa ${normalizedTarget}.`;

    // 2. Fallback: Kalau blok bahasa yang diminta gak ketemu, pinjam blok ENGLISH
    if (!selectedBlock || !selectedBlock.titles || selectedBlock.titles.length === 0) {
        selectedBlock = favoriteBlocks.find((block: any) => block.language === "ENGLISH");
        isFallback = true;
        keterangan = `Komik unggulan versi bahasa ${normalizedTarget} belum tersedia dari server MangaPlus. Mengalihkan secara otomatis ke rekomendasi versi bahasa ENGLISH.`;
    }

    const cleanList: UnggulanKomikSimpel[] = [];

    // 3. Mapping isi list komiknya
    if (selectedBlock && Array.isArray(selectedBlock.titles)) {
        selectedBlock.titles.forEach((t: any) => {
            cleanList.push({
                idkomik: t.titleId || 0,
                judul: t.name || "",
                author: t.author || "",
                totalView: t.viewCount || 0,
                bahasa: t.language || "",
                coverUnggulan: t.favoriteImageUrl || t.portraitImageUrl || "",
                statusUpdate: t.titleUpdateStatus || "NONE"
            });
        });
    }

    return {
        bahasaDiminta: normalizedTarget,
        bahasaTerpilih: selectedBlock?.language || normalizedTarget,
        isFallback: isFallback,
        keterangan: keterangan,
        totalKomik: cleanList.length,
        daftarKomik: cleanList
    };
}

// Tambahan Interface untuk Sistem Ranking
export interface RankingKomikItem {
    peringkat: number;
    idkomik: number;
    judul: string;
    author: string;
    coverPortrait: string;
    bahasa: string;
    skor: number;
    statusUpdate: string;
}

export interface CleanRankingView {
    totalKomik: number;
    daftarRanking: RankingKomikItem[];
}

/**
 * Memetakan data biner ranking komik menjadi list terstruktur bahasa Indonesia
 */
export function mapMangaRanking(rawRankingData: any, targetLang: string = "INDONESIAN"): CleanRankingView {
    const rawList = rawRankingData?.rankedTitles || [];
    const cleanList: RankingKomikItem[] = [];

    const normalizedTarget = targetLang.toUpperCase();

    rawList.forEach((rankBlock: any, index: number) => {
        const titleVariants = rankBlock?.titles || [];
        if (titleVariants.length === 0) return;

        // Peringkat dihitung berdasarkan urutan indeks array root (dimulai dari rank 1)
        const currentRank = index + 1;

        // 1. Cari dulu apakah ada variasi komik dalam bahasa yang diminta user (misal INDONESIAN)
        let selectedTitle = titleVariants.find((t: any) => t.language === normalizedTarget);

        // 2. Fallback: Kalau bahasa target absen, otomatis pinjam variasi bahasa ENGLISH
        if (!selectedTitle) {
            selectedTitle = titleVariants.find((t: any) => t.language === "ENGLISH");
        }

        // 3. Fallback Ekstrim: Kalau ENGLISH juga ga ada, ambil variasi bahasa apa pun yang tersedia di urutan pertama
        if (!selectedTitle) {
            selectedTitle = titleVariants[0];
        }

        if (selectedTitle) {
            cleanList.push({
                peringkat: currentRank,
                idkomik: selectedTitle.titleId || 0,
                judul: selectedTitle.name || "",
                author: selectedTitle.author || "",
                coverPortrait: selectedTitle.portraitImageUrl || selectedTitle.favoriteImageUrl || "",
                bahasa: selectedTitle.language || "",
                skor: rankBlock.score || 0,
                statusUpdate: selectedTitle.titleUpdateStatus || "NONE"
            });
        }
    });

    return {
        totalKomik: cleanList.length,
        daftarRanking: cleanList
    };
}

// file: lib/mangaplus/mangaplusMap.ts

// 1. Kita update interfacenya biar tiap item buku bawa informasi status bahasanya bre
export interface BukuKomikItem {
    idkomik: number;
    judul: string;
    author: string;
    coverPortrait: string;
    bahasa: string;
    isFallback: boolean; // Flag penanda jika terpaksa pakai bahasa lain
    keterangan: string;  // Info keterangan status bahasa
    tags: string[];
    labelMajalah: string;
    timestampRilisBerikutnya: number;
    waktuRilisBerikutnya: string; // <-- Properti teks manusia baru bre!
}

export interface CleanAllTitlesView {
    totalBuku: number;
    daftarBuku: BukuKomikItem[];
}

/**
 * Helper super simpel buat ngubah UNIX timestamp (detik) ke Bahasa Indonesia manusiawi
 */
function formatWaktuManusia(timestampDetik: number): string {
    if (!timestampDetik || timestampDetik === 0) return "Belum dijadwalkan";

    const date = new Date(timestampDetik * 1000);

    // Gunakan built-in Intl buat format tanggal otomatis ke Bahasa Indonesia
    return date.toLocaleString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    }) + " WIB";
}

/**
 * Memetakan seluruh daftar pustaka komik MangaPlus menjadi flat array bahasa Indonesia
 */
export function mapAllTitles(rawListData: any, targetLang: string = "INDONESIAN"): CleanAllTitlesView {
    const rawGroups = rawListData?.allTitlesGroup || [];
    const cleanList: BukuKomikItem[] = [];

    const normalizedTarget = targetLang.toUpperCase();

    rawGroups.forEach((group: any) => {
        const titleVariants = group?.titles || [];
        if (titleVariants.length === 0) return;

        let selectedTitle = null;
        let isFallback = false;
        let keterangan = "";

        // 1. Cari variasi komik dalam bahasa regional yang diminta (misal INDONESIAN)
        selectedTitle = titleVariants.find((t: any) => t.language === normalizedTarget);
        if (selectedTitle) {
            keterangan = `Tersedia dalam versi bahasa ${normalizedTarget}.`;
        }

        // 2. Fallback 1: Kalau bahasa target ga ketemu, pinjam variasi bahasa ENGLISH
        if (!selectedTitle) {
            selectedTitle = titleVariants.find((t: any) => t.language === "ENGLISH");
            if (selectedTitle) {
                isFallback = true;
                keterangan = `Versi bahasa ${normalizedTarget} tidak tersedia untuk judul ini. Otomatis dialihkan ke versi bahasa ENGLISH.`;
            }
        }

        // 3. Fallback Ekstrim: Ambil variasi bahasa pertama apa saja yang terdaftar di server
        if (!selectedTitle) {
            selectedTitle = titleVariants[0];
            if (selectedTitle) {
                isFallback = true;
                keterangan = `Versi bahasa ${normalizedTarget} dan ENGLISH tidak tersedia. Otomatis menampilkan opsi bahasa pertama yang tersedia (${selectedTitle.language}).`;
            }
        }

        // 4. Ambil tags kategori/genre komik
        const tags: string[] = Array.isArray(group.tags) ? group.tags.map((tg: any) => tg.tag || "") : [];

        // Ambil data timestamp detiknya
        const tsDetik = parseInt(group.nextChapterStartTimestamp || "0");

        if (selectedTitle) {
            cleanList.push({
                idkomik: selectedTitle.titleId || 0,
                judul: selectedTitle.name || group.theTitle || "",
                author: selectedTitle.author || "",
                coverPortrait: selectedTitle.portraitImageUrl || "",
                bahasa: selectedTitle.language || "",
                isFallback: isFallback,
                keterangan: keterangan,
                tags: tags,
                labelMajalah: group.label?.label || "",
                timestampRilisBerikutnya: parseInt(group.nextChapterStartTimestamp || "0"),
                waktuRilisBerikutnya: formatWaktuManusia(tsDetik)
            });
        }
    });

    return {
        totalBuku: cleanList.length,
        daftarBuku: cleanList
    };
}