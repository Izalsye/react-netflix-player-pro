export function pickByQuality(items: any[], wantedQuality: any) {
  if (!Array.isArray(items) || items.length === 0) return null;
  const wq = wantedQuality != null ? Number(wantedQuality) : null;

  if (wq != null && !Number.isNaN(wq)) {
    const exact = items.find((x) => Number(x.quality) === wq);
    if (exact) return exact;
  }

  const sorted = [...items].sort(
    (a, b) => Number(b.quality || 0) - Number(a.quality || 0),
  );
  return sorted[0] || null;
}

export function pickSubtitleUrl(subtitles: any[], langWanted: string) {
  if (!Array.isArray(subtitles) || subtitles.length === 0) return null;

  const want = (langWanted || "").toLowerCase();
  if (want) {
    const exact = subtitles.find(
      (s) => String(s.lang || "").toLowerCase() === want,
    );
    if (exact?.sub_url) return exact.sub_url;
  }

  const inId = subtitles.find(
    (s) => String(s.lang || "").toLowerCase() === "in_id",
  );
  if (inId?.sub_url) return inId.sub_url;

  const en = subtitles.find((s) => String(s.lang || "").toLowerCase() === "en");
  if (en?.sub_url) return en.sub_url;

  return subtitles[0]?.sub_url ?? null;
}

export function buildCandidatesFromDetail(detailData: any, episodeFallback = 1) {
  const list = detailData?.resourceDetectors?.[0]?.resolutionList;
  if (!Array.isArray(list) || list.length === 0) return [];

  return list
    .map((r: any) => {
      const caps = Array.isArray(r?.extCaptions) ? r.extCaptions : [];
      return {
        episode: Number(r?.episode ?? r?.ep ?? episodeFallback),
        quality: r?.resolution != null ? Number(r.resolution) : null,
        format: "MP4",
        vid_url: r?.resourceLink ?? null,
        signCookie: r?.signCookie ?? null,
        subtitles: caps.map((c: any) => ({
          lang: c?.lan ?? "",
          sub_url: c?.url ?? null,
        })),
      };
    })
    .filter((x: any) => x.vid_url);
}

export function buildCandidatesFromPlay(playJson: any, captionsJson: any, episodeFallback = 1) {
  const streams = playJson?.data?.streams;
  if (!Array.isArray(streams) || streams.length === 0) return [];

  const caps = captionsJson?.data?.extCaptions;
  const subtitles = Array.isArray(caps)
    ? caps.map((c: any) => ({ lang: c?.lan ?? "", sub_url: c?.url ?? null }))
    : [];

  return streams
    .map((s: any) => ({
      episode: Number(episodeFallback),
      quality: s?.resolutions != null ? Number(s.resolutions) : null,
      format: s?.format ?? "MP4",
      vid_url: s?.url ?? null,
      // 🛠️ FIX 2: PASTIKAN INI ADA DI SINI!
      signCookie: s?.signCookie ?? null,
      subtitles,
    }))
    .filter((x: any) => x.vid_url);
}
