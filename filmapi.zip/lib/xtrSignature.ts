import crypto from 'crypto';

interface SignatureParams {
  method: string;
  pathWithQuery: string;
  tsMs: string;
  keyHex: string;
  body?: string; // Tambahkan opsional untuk POST
  contentType?: string; // Tambahkan opsional (default: application/json; charset=utf-8)
}

export function makeXTrSignature({
  method,
  pathWithQuery,
  tsMs,
  keyHex,
  body,
  contentType = "application/json; charset=utf-8"
}: SignatureParams) {
  const key = Buffer.from(keyHex, 'hex');
  let payloadStr = "";

  if (method.toUpperCase() === 'POST' && body) {
    // 1. Hitung MD5 dari body (dalam bentuk hex)
    const bodyMd5 = crypto.createHash('md5').update(body).digest('hex');

    // 2. Hitung Content Length
    const contentLength = Buffer.byteLength(body).toString();

    // 3. Susun sesuai log: METHOD\n\nCONTENT_TYPE\nCONTENT_LENGTH\nTIMESTAMP\nBODY_MD5\nPATH
    payloadStr = `${method}\n\n${contentType}\n${contentLength}\n${tsMs}\n${bodyMd5}\n${pathWithQuery}`;
  } else {
    // Logic lama untuk GET
    payloadStr = `${method}\n\n\n\n${tsMs}\n\n${pathWithQuery}`;
  }

  const payload = Buffer.from(payloadStr, 'utf8');
  const mac = crypto.createHmac('md5', key).update(payload).digest();
  const sigB64 = mac.toString('base64');

  return `${tsMs}|2|${sigB64}`;
}