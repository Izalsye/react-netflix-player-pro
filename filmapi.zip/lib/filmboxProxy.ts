import https from "node:https";
import { URL } from "node:url";
import { HttpsProxyAgent } from 'https-proxy-agent';

export const API_BASE = "https://h5-api.aoneroom.com/wefeed-h5api-bff";
export const PLAY_BASE = "https://movieboxhd.net/wefeed-h5api-bff";

const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL_FILMBOX || '';

// ==========================================
// HELPER: SANITIZE STATUS UNTUK NGINX
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 500;
    // Mencegah Nginx/Cloudflare nimpa response JSON jadi HTML
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400;
    }
    return status;
}

export async function fetchUpstream(
    urlStr: string,
    method: string = 'GET',
    body?: any,
    customHeaders?: Record<string, string>,
    useProxyOverride?: boolean,
    maxRetries: number = 1
) {
    const u = new URL(urlStr);
    const authToken = process.env.FILMBOX_AUTH_TOKEN;
    const authCookie = process.env.FILMBOX_COOKIE;
    const shouldProxy = useProxyOverride !== undefined ? useProxyOverride : USE_PROXY;
    const agent = (shouldProxy && PROXY_URL) ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    const headers: Record<string, string> = {
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'en-US,en;q=0.9,id;q=0.8',
        'origin': 'https://movieboxhd.net',
        'referer': 'https://movieboxhd.net/',
        'sec-ch-ua-platform': '"Windows"',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
        'x-client-info': JSON.stringify({ timezone: 'Asia/Jakarta' }),
        'x-no-high-risk-restrict': '0',
        'x-request-lang': 'id',
        'x-vip-restrict': '1',
        ...customHeaders
    };

    if (authToken) {
        headers['authorization'] = authToken.startsWith('Bearer ') ? authToken : `Bearer ${authToken}`;
    }
    // 2. 🔥 COOKIE KHUSUS UNTUK ENDPOINT GETPLAY 🔥
    // Kita cek apakah urlStr mengandung kata '/subject/play'
    if (authCookie && urlStr.includes('/subject/play') && !headers['Cookie']) {
        headers['Cookie'] = authCookie;
    }
    if (!headers['Host'] && !headers['host']) headers['Host'] = u.hostname;
    if (method === 'POST' && !headers['content-type']) headers['content-type'] = 'application/json';

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await new Promise<any>((resolve, reject) => {
                const options: https.RequestOptions = {
                    hostname: u.hostname,
                    port: u.port || 443,
                    path: u.pathname + u.search,
                    method,
                    headers,
                    agent: agent as any,
                    timeout: 8000,
                    rejectUnauthorized: false
                };

                const req = https.request(options, (res) => {
                    let data = "";
                    res.setEncoding('utf8');
                    res.on("data", (chunk) => (data += chunk));
                    res.on("end", () => {
                        const rawData = data.trim();

                        const isHtml = rawData.toLowerCase().startsWith("<!doctype") || rawData.toLowerCase().startsWith("<html");
                        if (isHtml || rawData.includes("internetpositif")) {
                            reject({
                                isCustomError: true,
                                status: res.statusCode, // Tangkap status asli
                                message: "Kena blokir WAF / Response berupa HTML",
                                rawData: rawData
                            });
                            return;
                        }

                        try {
                            const parsed = JSON.parse(rawData || "{}");
                            if (parsed.code && parsed.code !== 0 && parsed.code !== 200) {
                                reject({
                                    isCustomError: true,
                                    status: res.statusCode,
                                    message: parsed.message || "Upstream merespons dengan JSON error",
                                    rawData: parsed
                                });
                                return;
                            }
                            resolve(parsed);
                        } catch (err) {
                            reject({
                                isCustomError: true,
                                status: res.statusCode,
                                message: "Gagal parse response JSON",
                                rawData: rawData
                            });
                        }
                    });
                });

                req.on("error", (err: any) => {
                    reject({
                        isCustomError: true,
                        status: 500,
                        message: `Koneksi Error: ${err.message || err.code}`,
                        code: err.code || 'UNKNOWN',
                        rawData: null
                    });
                });

                req.on("timeout", () => {
                    req.destroy(new Error("Request Timeout dari Sistem"));
                });

                if (body) {
                    req.write(typeof body === 'string' ? body : JSON.stringify(body));
                }

                req.end();
            });

        } catch (error: any) {
            console.warn(`[Upstream Attempt ${attempt}/${maxRetries} Failed]:`, error.message || error);
            if (attempt === maxRetries) {
                throw error;
            }
            await new Promise(res => setTimeout(res, 500));
        }
    }
}

export async function filmboxProxy(
    req: Request,
    path: string,
    method: 'GET' | 'POST' = 'GET',
    query: Record<string, any> = {},
    body?: any,
    label: string = 'filmbox',
    useProxyOverride?: boolean
) {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined) sp.set(k, String(v));
    }

    const isPlayRoute = path.includes('/play') || path.includes('/caption');
    const baseUrl = isPlayRoute ? PLAY_BASE : API_BASE;
    const url = `${baseUrl}${path}${sp.toString() ? '?' + sp.toString() : ''}`;

    const customHeaders: Record<string, string> = {};
    if (isPlayRoute) {
        customHeaders['Host'] = 'movieboxhd.net';
        customHeaders['Origin'] = 'https://movieboxhd.net';
    }

    try {
        const json = await fetchUpstream(url, method, body, customHeaders, useProxyOverride);

        return new Response(JSON.stringify(json), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e: any) {
        const isCustom = e.isCustomError;
        const originalStatus = e.status || 502;
        const safeStatus = sanitizeStatus(originalStatus); // 👈 Terapkan di sini!

        return new Response(
            JSON.stringify({
                code: originalStatus, // Tetap laporkan code asli ke frontend
                message: e.message || "Internal Proxy Error",
                data: isCustom ? e.rawData : null
            }),
            {
                status: safeStatus, // Tapi HTTP statusnya disamarkan buat Nginx
                headers: { 'Content-Type': 'application/json' }
            }
        );
    }
}