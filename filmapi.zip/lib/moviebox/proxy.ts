import * as crypto from 'node:crypto';
import https from 'node:https';
import { URL } from 'node:url';
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

// ==========================================
// KONFIGURASI ENVIRONMENT MOVIEBOX
// ==========================================
const MOVIEBOX_BASE = process.env.MOVIEBOX_BASE || 'https://api4sg.aoneroom.com';
const MOVIEBOX_SECRET_HEX = process.env.MOVIEBOX_SECRET_HEX || 'efa891974eecd3148df63aa611602defd101259ba521022c57ae0566bd8e';
const MOVIEBOX_JWT_TOKEN = process.env.MOVIEBOX_JWT_TOKEN || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjIwNDc3MDM4MzY5NzM3NTQ3ODQsImV4cCI6MTc5NTAyNjU2OCwiaWF0IjoxNzg3MjUwMjY4fQ.XRsU1sthhxpsD4eblcGj4wow5pK5_ZE2P63tvfq24iw';

const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

const cache = new Map<string, { val: any; exp: number }>();

// Client Info Default (Android Dump)
const DEFAULT_CLIENT_INFO = JSON.stringify({
    "package_name": "com.community.oneroom",
    "version_name": "4.0.01.0813.02",
    "version_code": 50020121,
    "os": "android",
    "os_version": "9",
    "install_ch": "ps",
    "device_id": "58454c7b64a69df12bc00bc6bd3bb19f",
    "install_store": "ps",
    "gaid": "8c20cbbc-0d79-483e-b448-2cdc0568633d",
    "brand": "samsung",
    "model": "SM-G955F",
    "system_language": "in",
    "net": "NETWORK_4G",
    "region": "ID",
    "timezone": "Asia/Jakarta",
    "sp_code": "51011",
    "X-Child-UID": "",
    "X-PM-Active": "true",
    "X-Client-Build": "1787286954979725373.08143bfb95b4464dbec396c17b0e2e51-1787286870572187824.ae072ac8ad5226cae902cc6a9da6d6f1",
    "X-PM-Level": "2",
    "X-Play-Mode": "2",
    "X-Idle-Data": "1",
    "X-Family-Mode": "1",
    "X-Content-Mode": "0"
});

// ==========================================
// SIGNATURE GENERATOR
// ==========================================
interface SignatureParams {
    method: string;
    pathWithQuery: string;
    tsMs: string;
    keyHex: string;
    body?: string;
    contentType?: string;
}

export function makeXTrSignature({
    method,
    pathWithQuery,
    tsMs,
    keyHex,
    body,
    contentType = "application/json; charset=utf-8"
}: SignatureParams) {
    const key = Buffer.from(keyHex, 'hex');
    let payloadStr = "";

    if (method.toUpperCase() === 'POST' && body) {
        const bodyMd5 = crypto.createHash('md5').update(body, 'utf8').digest('hex');
        const contentLength = Buffer.byteLength(body, 'utf8').toString();
        payloadStr = `${method.toUpperCase()}\n\n${contentType}\n${contentLength}\n${tsMs}\n${bodyMd5}\n${pathWithQuery}`;
    } else {
        payloadStr = `${method.toUpperCase()}\n\n\n\n${tsMs}\n\n${pathWithQuery}`;
    }

    const payload = Buffer.from(payloadStr, 'utf8');
    const mac = crypto.createHmac('md5', key).update(payload).digest();
    const sigB64 = mac.toString('base64');

    return `${tsMs}|2|${sigB64}`;
}

// ==========================================
// LOW-LEVEL HTTPS CLIENT (NATIVE NODE.JS)
// ==========================================
async function httpsRequest(
    urlStr: string,
    method: string,
    headers: Record<string, string>,
    body?: string,
    timeoutMs = 15_000,
    useProxyOverride?: boolean
) {
    const u = new URL(urlStr);

    // Menentukan apakah pakai proxy berdasarkan override route atau fallback ke .env
    const shouldProxy = useProxyOverride !== undefined ? useProxyOverride : USE_PROXY;
    const agent = (shouldProxy && PROXY_URL) ? new (HttpsProxyAgent as any)(PROXY_URL) : undefined;

    return new Promise<{ status: number; statusMessage?: string; headers: Record<string, any>; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                port: u.port || 443,
                path: u.pathname + u.search,
                method: method.toUpperCase(),
                headers,
                agent,
                rejectUnauthorized: false // Bypass SSL check jika ada masalah cert
            },
            (res) => {
                let data = "";
                res.setEncoding("utf8");
                res.on("data", (chunk) => (data += chunk));
                res.on("end", () => {
                    resolve({
                        status: res.statusCode || 0,
                        statusMessage: res.statusMessage,
                        headers: res.headers as any,
                        text: data,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`Timeout ${timeoutMs}ms`)));
        req.on("error", reject);

        if (body && method.toUpperCase() === 'POST') {
            req.write(body);
        }

        req.end();
    });
}

// ==========================================
// BUILD DEFAULT ANDROID HEADERS
// ==========================================
function buildDefaultHeaders(req: Request, xtrSignature: string, customHeaders?: Record<string, string>): Record<string, string> {
    const authHeader = MOVIEBOX_JWT_TOKEN.startsWith('Bearer ') ? MOVIEBOX_JWT_TOKEN : `Bearer ${MOVIEBOX_JWT_TOKEN}`;

    const headers: Record<string, string> = {
        "user-agent": "com.community.oneroom/50020121 (Linux; U; Android 9; in_ID; SM-G955F; Build/PPR1.180610.011; Cronet/145.0.7582.0)",
        "priority": req.headers.get("priority") || "u=1, i",
        "authorization": authHeader,
        "x-tr-signature": xtrSignature,
        "x-client-info": req.headers.get("x-client-info") || DEFAULT_CLIENT_INFO,
        "x-client-status": "1",
        "x-play-mode": "2",
        "x-idle-data": "1",
        "x-family-mode": "1",
        "x-content-mode": "0",
        "X-UtmSource": "alive",
        "X-PM-Active": "true",
        "X-PM-Level": "2",
        "X-Client-Build": "1787286954979725373.08143bfb95b4464dbec396c17b0e2e51-1787286870572187824.ae072ac8ad5226cae902cc6a9da6d6f1",
        ...customHeaders
    };

    return headers;
}

// ==========================================
// HELPER: SANITIZE STATUS UNTUK NGINX
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 500;

    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400;
    }

    return status;
}

// ==========================================
// EXPORT PROXY FUNCTIONS
// ==========================================
export async function movieboxGet(
    req: Request,
    path: string,
    query: Record<string, string> = {},
    opts: { label?: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string>; useProxy?: boolean } = {}
) {
    const sp = new URLSearchParams();
    const sortedKeys = Object.keys(query).sort();
    for (const k of sortedKeys) {
        if (query[k] !== undefined && query[k] !== null && query[k] !== "") {
            sp.set(k, query[k]);
        }
    }

    const qs = sp.toString();
    const pathOnly = path.startsWith('http') ? new URL(path).pathname : path;
    const pathWithQuery = qs ? `${pathOnly}?${qs}` : pathOnly;
    const upstreamUrl = path.startsWith('http') ? path : `${MOVIEBOX_BASE}${pathWithQuery}`;

    const cacheKey = opts.cacheTtlMs ? `mbget|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return NextResponse.json(hit.val, { headers: { 'x-cache': 'HIT' } });
        }
    }

    const tsMs = Date.now().toString();
    const xtr = makeXTrSignature({ method: "GET", pathWithQuery, tsMs, keyHex: MOVIEBOX_SECRET_HEX });
    const headers = buildDefaultHeaders(req, xtr, opts.headers);

    try {
        // Meneruskan parameter opsi proxy ke fungsi low-level
        const { status, text, headers: upHeaders } = await httpsRequest(upstreamUrl, "GET", headers, undefined, 15_000, opts.useProxy);
        const safeStatus = sanitizeStatus(status);

        let json: any;
        try {
            json = JSON.parse(text);
        } catch {
            const errorPayload = {
                error: true,
                message: status === 403 ? "🚨 WAF / Cloudflare Block" : "Non-JSON Response",
                http_status: status,
                raw_response: text.substring(0, 1000)
            };
            if (opts.send === false) return errorPayload;
            return NextResponse.json(errorPayload, { status: safeStatus });
        }

        if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs) {
            cache.set(cacheKey, { val: json, exp: Date.now() + opts.cacheTtlMs });
        }

        if (opts.send === false) return json;
        return NextResponse.json(json, { status: safeStatus });

    } catch (e: any) {
        const errorPayload = { error: true, message: e.message || "Upstream Request Failed", details: "Proxy/Network Error" };
        if (opts.send === false) return errorPayload; // 👈 Tambahkan ini
        return NextResponse.json(errorPayload, { status: 500 });
    }
}

export async function movieboxPost(
    req: Request,
    path: string,
    body: any,
    opts: { label?: string; send?: boolean; headers?: Record<string, string>; useProxy?: boolean } = {}
) {
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    const pathOnly = path.startsWith('http') ? new URL(path).pathname + new URL(path).search : path;
    const upstreamUrl = path.startsWith('http') ? path : `${MOVIEBOX_BASE}${pathOnly}`;

    const tsMs = Date.now().toString();
    const reqContentType = "application/json; charset=utf-8";

    const xtr = makeXTrSignature({
        method: "POST",
        pathWithQuery: pathOnly,
        tsMs,
        keyHex: MOVIEBOX_SECRET_HEX,
        body: stringBody,
        contentType: reqContentType
    });

    const headers = buildDefaultHeaders(req, xtr, {
        "content-type": reqContentType,
        "content-length": Buffer.byteLength(stringBody, 'utf8').toString(),
        ...opts.headers
    });

    try {
        // Meneruskan parameter opsi proxy ke fungsi low-level
        const { status, text } = await httpsRequest(upstreamUrl, "POST", headers, stringBody, 15_000, opts.useProxy);
        const safeStatus = sanitizeStatus(status);

        let json: any;
        try {
            json = JSON.parse(text);
        } catch {
            if (opts.send === false) return text;
            return new Response(text, { status: safeStatus });
        }

        if (opts.send === false) return json;
        return NextResponse.json(json, { status: safeStatus });

    } catch (e: any) {
        return NextResponse.json({ error: true, message: e.message || "Upstream Request Failed" }, { status: 500 });
    }
}