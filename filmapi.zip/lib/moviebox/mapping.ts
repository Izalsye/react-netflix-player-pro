// utils/mapping.ts
import {
    MappedResponse,
    MappedHomeData,
    MappedSubTab,
    MappedTabData,
    SectionGroup,
    VideoItem,
    MappedSeason,
    MappedCast,
    MappedDetailData,
    MappedDub,
    MappedEpisode,
    MappedPlayDash,
    MappedPlayData,
    MappedPlayMp4,
    MappedPlaySubtitle,
    // filmbox
    MappedPlayDashFilmbox,
    MappedPlayDataFilmbox,
    MappedPlayHls,
    MappedPlaySubtitleFilmbox,
} from '@/types/moviebox';

export class MovieboxMapper {
    /**
     * Membersihkan dan merapikan data dari endpoint /bottom-tab
     */
    static mapHomeTabs(rawJson: any): MappedResponse<MappedHomeData> {
        // Jika dari upstream sudah error atau format tidak sesuai
        if (!rawJson || rawJson.code !== 0 || !rawJson.data) {
            return {
                code: rawJson?.code || 500,
                message: rawJson?.message || "Error atau format data tidak dikenali",
                data: null
            };
        }

        try {
            const rawData = rawJson.data;
            const version = rawData.version || "";

            // Kita cuma butuh tab "Beranda" (HOME) karena di situ letak subTabs nya
            const homeTab = rawData.bottomTabs?.find((tab: any) => tab.btTabCode === "HOME");

            // Map subTabs mentah menjadi data yang bersih
            const cleanTabs: MappedSubTab[] = homeTab?.subTabs?.map((sub: any) => ({
                tabId: sub.tabId,
                name: sub.name,
                tabCode: sub.tabCode,
                type: sub.type
            })) || [];

            // Kembalikan format yang rapi
            return {
                code: 0,
                message: "ok",
                data: {
                    version: version,
                    tabs: cleanTabs
                }
            };
        } catch (error: any) {
            return {
                code: 500,
                message: "Gagal memproses mapping data: " + error.message,
                data: null
            };
        }
    }

    /**
     * Helper internal untuk mengekstrak dan menstandarisasi 1 item film/drama
     */
    private static extractVideoItem(rawItem: any): VideoItem | null {
        // Terkadang datanya dibungkus di dalam properti "subject", kadang langsung (flat)
        const data = rawItem.subject ? rawItem.subject : rawItem;

        // Jika tidak ada subjectId yang valid, lewati (filter out item kosong / iklan / dll)
        if (!data || !data.subjectId || data.subjectId === "0" || data.subjectId === "") {
            return null;
        }

        // Ekstrak URL untuk SEO Route (Menghilangkan domain asli)
        const rawDetailUrl = data.detailUrl || rawItem.detailUrl || "";
        const cleanDetailPath = rawDetailUrl.replace("https://movie-box.co/detail/", "");

        return {
            subjectId: data.subjectId,
            title: data.title || rawItem.title || rawItem.content || "Unknown Title",
            coverUrl: data.cover?.url || rawItem.image?.url || rawItem.cover?.url || "",
            genre: data.genre || rawItem.genre || "",
            releaseDate: data.releaseDate || rawItem.releaseDate || "",
            imdbRate: data.imdbRate || data.imdbRatingValue || rawItem.imdbRate || "0",
            country: data.countryName || rawItem.countryName || "",
            detailPath: cleanDetailPath, // Contoh hasil: "ghost-in-the-cell-w2lyNQfhafa"
            isVip: !!(data.vipInfo?.requireMemberType === 1 || rawItem.vipInfo?.requireMemberType === 1),
            durationSeconds: data.durationSeconds || rawItem.durationSeconds || 0
        };
    }

    /**
     * Fungsi utama untuk memetakan respon /tabdata
     */
    static mapTabData(rawJson: any): MappedResponse<MappedTabData> {
        // Handle jika respons error atau bukan JSON yang valid
        if (!rawJson || rawJson.code !== 0 || !rawJson.data) {
            return {
                code: rawJson?.code || 500,
                message: rawJson?.message || "Data upstream bermasalah bre!",
                data: null
            };
        }

        try {
            const rawData = rawJson.data;
            const sections: SectionGroup[] = [];

            // Looping setiap grup/section dari raw data
            if (Array.isArray(rawData.items)) {
                for (const section of rawData.items) {
                    const sectionType = section.type;
                    let sectionTitle = section.title || "Lainnya";

                    // Kita kumpulkan item-item yang valid ke dalam array ini
                    let videoItems: VideoItem[] = [];

                    // 1. Logika untuk BANNER
                    if (sectionType === 'BANNER' && section.banner?.banners) {
                        videoItems = section.banner.banners
                            .map(this.extractVideoItem)
                            .filter(Boolean) as VideoItem[];
                    }
                    // 2. Logika untuk RANKING (Peringkat) -> Ini punya sub-kategori (Semua, Indo, Barat)
                    else if (sectionType === 'RANKING_LIST_MULTI_TAB' && section.rankingListData?.items) {
                        section.rankingListData.items.forEach((rankGroup: any) => {
                            const rankItems = rankGroup.subjects
                                ?.map(this.extractVideoItem)
                                .filter(Boolean) as VideoItem[];

                            if (rankItems.length > 0) {
                                // Pisah sub-kategori jadi section tersendiri biar frontend gampang bacanya
                                sections.push({
                                    sectionType: sectionType,
                                    sectionTitle: `${sectionTitle} - ${rankGroup.title}`,
                                    items: rankItems
                                });
                            }
                        });
                        continue; // Lewati push default di bawah karena sudah di-push per kategori
                    }
                    // 3. Logika untuk list film biasa (SUBJECTS_MOVIE, APPOINTMENT_LIST)
                    else if (['SUBJECTS_MOVIE', 'APPOINTMENT_LIST'].includes(sectionType) && section.subjects) {
                        videoItems = section.subjects
                            .map(this.extractVideoItem)
                            .filter(Boolean) as VideoItem[];
                    }
                    // 4. Logika untuk grup CUSTOM (Biasanya WWE/Sport VOD)
                    else if (sectionType === 'CUSTOM' && section.customData?.items) {
                        videoItems = section.customData.items
                            .map(this.extractVideoItem)
                            .filter(Boolean) as VideoItem[];
                    }

                    // Jika di dalam section tersebut ada film/drama-nya, baru kita masukkan ke respons akhir
                    if (videoItems.length > 0) {
                        sections.push({
                            sectionType,
                            sectionTitle,
                            items: videoItems
                        });
                    }
                }
            }

            return {
                code: 0,
                message: "ok",
                data: {
                    tabId: rawData.tabId || 0,
                    sections: sections
                }
            };

        } catch (error: any) {
            return {
                code: 500,
                message: "Gagal memproses data mapping: " + error.message,
                data: null
            };
        }
    }

    /**
     * Membersihkan dan merapikan data gabungan Detail + Season Info
     */
    static mapDetail(rawJson: any): MappedResponse<MappedDetailData> {
        if (!rawJson || rawJson.code !== 0 || !rawJson.data) {
            return {
                code: rawJson?.code || 500,
                message: rawJson?.message || "Data detail tidak valid bre!",
                data: null
            };
        }

        try {
            const data = rawJson.data;

            // 1. Ekstrak Genre jadi Array
            const genres = data.genre
                ? data.genre.split(',').map((g: string) => g.trim())
                : [];

            // 2. Ekstrak Subtitle jadi Array
            const subtitles = data.subtitles
                ? data.subtitles.split(',').map((s: string) => s.trim())
                : [];

            // 3. Mapping Cast / Staff List
            const cast: MappedCast[] = (data.staffList || []).map((staff: any) => ({
                id: staff.staffId,
                name: staff.name,
                role: staff.character || "Staff",
                avatar: staff.avatarUrl || ""
            }));

            // 4. Mapping Dubbing (Audio Languages)
            const dubs: MappedDub[] = (data.dubs || []).map((dub: any) => ({
                language: dub.lanName,
                code: dub.lanCode,
                subjectId: dub.subjectId,
                isOriginal: dub.original || false
            }));

            // 5. Build Season & Episode List
            // Mengubah "maxEp: 10" menjadi Array [ {episodeNumber: 1}, {episodeNumber: 2}, ... ]
            const seasons: MappedSeason[] = (data.seasons || []).map((season: any) => {
                const epList: MappedEpisode[] = [];
                // Looping dari episode 1 sampai maksimal episode (maxEp)
                for (let i = 1; i <= (season.maxEp || 0); i++) {
                    epList.push({
                        id: i,                    // Gunakan nomor episode sebagai ID sementara
                        name: `Episode ${i}`,     // Bikin judul otomatis (contoh: "Episode 1")
                        episodeNumber: i          // Nomor episode murni
                    });
                }

                return {
                    seasonNumber: season.se,
                    totalEpisodes: season.maxEp || 0,
                    episodes: epList
                };
            });

            // 6. VIP Rules
            const vipInfo = data.vipInfo || {};
            const vipRules = {
                isVipRequired: vipInfo.requireMemberType === 1,
                freeEpisodes: vipInfo.freeEpisodeCount || 0,
                previewSeconds: vipInfo.previewSeconds || 0
            };

            // Return Payload Rapi
            return {
                code: 0,
                message: "ok",
                data: {
                    subjectId: data.subjectId,
                    type: data.subjectType,
                    title: data.title,
                    description: data.description,
                    coverUrl: data.cover?.url || "",
                    trailerUrl: data.trailer?.VideoAddress?.url || null,
                    releaseDate: data.releaseDate,
                    genres: genres,
                    country: data.countryName || "",
                    rating: data.imdbRatingValue || "0",
                    viewers: data.viewers || 0,
                    vipRules: vipRules,
                    cast: cast,
                    subtitles: subtitles,
                    dubs: dubs,
                    seasons: seasons
                }
            };
        } catch (error: any) {
            return {
                code: 500,
                message: "Gagal memproses data mapping detail: " + error.message,
                data: null
            };
        }
    }

    /**
         * Membersihkan dan merapikan data hasil gabungan /getplay (DASH, MP4, Subtitles)
         */
    static mapPlayData(rawJson: any, requestedEp: string | number = 1): MappedResponse<MappedPlayData> {
        if (!rawJson || rawJson.code !== 0 || !rawJson.data) {
            return {
                code: rawJson?.code || 500,
                message: rawJson?.message || "Data play tidak valid bre!",
                data: null
            };
        }

        try {
            const rawData = rawJson.data;
            const playInfo = rawData.playInfo;
            const captions = rawData.captions;
            const resource = rawData.resource;

            const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "";

            // 1. Ekstrak Data DASH (Tetap url asli)
            let mappedDash: MappedPlayDash | null = null;
            if (playInfo && playInfo.streams && playInfo.streams.length > 0) {
                const stream = playInfo.streams[0];
                mappedDash = {
                    streamId: stream.id || "",
                    url: stream.url || "",
                    codec: stream.codecName || "",
                    resolutions: stream.resolutions ? stream.resolutions.split(',') : [],
                    authCookie: stream.signCookie || ""
                };
            }

            // 2. Ekstrak Data Subtitles
            let mappedSubtitles: MappedPlaySubtitle[] = [];
            if (captions && captions.extCaptions) {
                mappedSubtitles = captions.extCaptions.map((sub: any) => {
                    const originalUrl = sub.url || "";
                    const urlProxyStr = originalUrl ? `${baseUrl}/api/moviebox/indocast?url=${encodeURIComponent(originalUrl)}` : "";

                    return {
                        language: sub.lanName || "",
                        languageCode: sub.lan || "",
                        url: originalUrl,       // Tetap simpan aslinya
                        urlProxy: urlProxyStr   // Tambahkan urlProxy
                    };
                });
            }

            // 3. Ekstrak Data MP4 Resource
            let mappedMp4: MappedPlayMp4[] = [];
            if (resource && resource.list) {
                const filteredList = resource.list.filter(
                    (item: any) => String(item.ep) === String(requestedEp)
                );

                mappedMp4 = filteredList.map((item: any) => {
                    const originalUrl = item.resourceLink || "";
                    const urlProxyStr = originalUrl ? `${baseUrl}/api/moviebox/indocast?url=${encodeURIComponent(originalUrl)}` : "";

                    return {
                        id: item.episode || 0,
                        episodeNumber: item.ep || 1,
                        episodeName: `Episode ${item.ep || 1}`,
                        url: originalUrl,       // Tetap simpan aslinya
                        urlProxy: urlProxyStr,  // Tambahkan urlProxy
                        resolution: item.resolution || 0,
                        codec: item.codecName || "",
                        sizeBytes: item.size || "0",
                        isVipLocked: !!(item.vipInfo && item.vipInfo.requireMemberType === 1)
                    };
                });
            }

            const subjectId = resource?.subjectId || "";

            return {
                code: 0,
                message: "ok",
                data: {
                    subjectId: subjectId,
                    dash: mappedDash,
                    subtitles: mappedSubtitles,
                    mp4: mappedMp4
                }
            };
        } catch (error: any) {
            return {
                code: 500,
                message: "Gagal memproses data mapping play: " + error.message,
                data: null
            };
        }
    }

    // Untuk Filmbox _________________________________
    /**
     * Mengonversi raw data Moviebox /getplay menjadi format DTO Filmbox Lama (Backward Compatibility)
     */
    static mapPlayDataToFilmboxFormat(rawJson: any, requestedSe: string | number, requestedEp: string | number): MappedResponse<MappedPlayDataFilmbox> {
        if (!rawJson || rawJson.code !== 0 || !rawJson.data) {
            return {
                code: rawJson?.code || 500,
                message: rawJson?.message || "Data play tidak valid bre!",
                data: null
            };
        }

        try {
            const rawData = rawJson.data;
            const playInfo = rawData.playInfo;
            const captions = rawData.captions;
            const resource = rawData.resource;

            const BASE_DOMAIN = process.env.NEXT_PUBLIC_SITE_URL || '';
            const subjectId = resource?.subjectId || playInfo?.subjectId || "";
            
            // --- A. Ekstrak DASH (Play-Info) ---
            let selectedDash: any = null;
            let format = "MP4"; // Default fallback
            
            if (playInfo && playInfo.streams && playInfo.streams.length > 0) {
                selectedDash = playInfo.streams[0];
                format = selectedDash.format || "DASH";
            }

            // --- B. Ekstrak HLS / MP4 (Resource) ---
            // Moviebox memberikan link MP4 lewat resource.list
            const hlsArray: MappedPlayHls[] = [];
            let vidUrl = "";
            let vidUrlProxy = "";
            let finalQuality = 0;

            if (resource && resource.list) {
                // Filter episode yang sesuai dengan request (karena Moviebox kadang ngirim 10 episode sekaligus)
                const filteredResource = resource.list.filter(
                    (item: any) => String(item.ep) === String(requestedEp)
                );

                if (filteredResource.length > 0) {
                    const selectedStream = filteredResource[0]; // Ambil yang paling relevan (biasanya 360/480/auto)
                    vidUrl = selectedStream.resourceLink || "";
                    finalQuality = selectedStream.resolution || 0;
                    format = "MP4"; // Karena resourceLink biasanya MP4

                    // Buat proxy URL untuk video MP4 ini
                    if (vidUrl) {
                        const encodedUrl = encodeURIComponent(vidUrl);
                        vidUrlProxy = `${BASE_DOMAIN}/api/moviebox/indocast?url=${encodedUrl}`;
                        
                        // Masukkan ke array HLS style Filmbox (meskipun aslinya MP4)
                        hlsArray.push({
                            resolutions: String(finalQuality),
                            url: vidUrl,
                            url_proxy: vidUrlProxy
                        });
                    }
                }
            }

            // --- C. Format DASH ke Style Filmbox ---
            let dashData: MappedPlayDashFilmbox | null = null;
            if (selectedDash?.url) {
                const encodedDashUrl = encodeURIComponent(selectedDash.url);
                // Biarkan dash diload lgsg oleh player, atau jika pakai indocast:
                const dashProxyUrl = `${BASE_DOMAIN}/api/moviebox/indocast?url=${encodedDashUrl}`;

                dashData = {
                    url: selectedDash.url,
                    url_proxy: dashProxyUrl,
                    signCookie: selectedDash.signCookie || null,
                    signHeaderKey: null,
                    resolutions: selectedDash.resolutions || null
                };

                // Set default quality dari DASH kalau tidak ada MP4
                if (finalQuality === 0 && selectedDash.resolutions) {
                    finalQuality = parseInt(selectedDash.resolutions.split(',')[0]) || 0;
                }
            }

            // --- D. Ekstrak Subtitle ---
            let allSubtitles: MappedPlaySubtitleFilmbox[] = [];
            let finalSubUrl: string | null = null;
            let finalSubUrlProxy: string | null = null;

            if (captions && captions.extCaptions && captions.extCaptions.length > 0) {
                allSubtitles = captions.extCaptions.map((cap: any) => {
                    const originalUrl = cap.url || "";
                    const proxyUrl = originalUrl ? `${BASE_DOMAIN}/api/moviebox/indocast?url=${encodeURIComponent(originalUrl)}` : "";

                    return {
                        lang: cap.lanCode || cap.lan || "",
                        label: cap.lanName || cap.lan || "Unknown",
                        subUrl: originalUrl, // Di filmbox subUrl adalah proxy
                        id: cap.lanCode || cap.lan || "",
                        url: originalUrl,
                        url_proxy: originalUrl
                    };
                });

                // Set Subtitle utama (Pilih In_id kalau ada, kalo engga pake indeks [0])
                const indonesianSub = allSubtitles.find((sub) => sub.lang.toLowerCase() === 'in_id' || sub.lang.toLowerCase() === 'id');
                const defaultSub = indonesianSub || allSubtitles[0];

                finalSubUrl = defaultSub.url;
                finalSubUrlProxy = defaultSub.url_proxy;
            }

            // --- E. Bentuk DTO Akhir ---
            const dto: MappedPlayDataFilmbox = {
                subjectId: subjectId,
                se: parseInt(String(requestedSe)),
                episode: parseInt(String(requestedEp)),
                quality: finalQuality,
                format: format,
                vid_url: vidUrl,
                vid_url_proxy: vidUrlProxy,
                hls: hlsArray.length > 0 ? hlsArray : null,
                dash: dashData,
                sub_url: finalSubUrl,
                sub_url_proxy: finalSubUrlProxy,
                subtitles: allSubtitles
            };

            return {
                code: 0,
                message: "ok",
                data: dto
            };

        } catch (error: any) {
            return {
                code: 500,
                message: "Gagal memproses backward compatibility play: " + error.message,
                data: null
            };
        }
    }

    // _________________________________________________________________________________________
}