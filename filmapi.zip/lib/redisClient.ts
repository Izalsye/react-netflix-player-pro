// lib/redisClient.ts
import { Redis } from 'ioredis';

// Mengambil URL dari .env, fallback ke localhost jika kosong
const REDIS_URL = process.env.REDIS_URL || 'redis://127.0.0.1:6379';

// Inisialisasi koneksi Redis
export const redis = new Redis(REDIS_URL);

/**
 * Fungsi helper untuk mengambil data dari cache atau memanggil fungsi upstream jika belum ada.
 * 
 * @param key Kunci unik untuk menyimpan data di Redis (misal: 'filmbox:home')
 * @param fetchFn Fungsi yang akan dieksekusi jika data tidak ada di cache
 * @param ttl Durasi cache dalam hitungan detik (contoh: 3600 untuk 1 jam)
 */
export async function getOrSetCache(key: string, fetchFn: () => Promise<any>, ttl: number = 3600) {
    try {
        // Cek apakah data sudah ada di Redis
        const cachedData = await redis.get(key);

        if (cachedData) {
            console.log(`[Cache Hit] Redis merespons untuk key: ${key}`);
            return JSON.parse(cachedData);
        }

        console.log(`[Cache Miss] Mengambil data dari upstream untuk key: ${key}`);

        // Eksekusi fungsi upstream (fetch API asli)
        const freshData = await fetchFn();

        // Simpan hasilnya ke Redis dengan batas waktu (TTL)
        await redis.set(key, JSON.stringify(freshData), 'EX', ttl);

        return freshData;
    } catch (error) {
        console.warn(`[Redis Error] Terjadi masalah pada cache. Fallback ke data asli. Error:`, error);
        // Jika Redis mati atau error, jangan crash, langsung ambil data dari upstream
        return await fetchFn();
    }
}