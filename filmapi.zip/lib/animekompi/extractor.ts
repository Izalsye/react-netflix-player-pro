import axios from 'axios';
import * as cheerio from 'cheerio';
import CryptoJS from 'crypto-js'; // 🔥 Import alat tempur kriptografi
import vm from 'vm'; // 🔥 Import sandbox Node.js buat njebol AAEncode
/**
 * Helper function to decode the XOR encrypted payload found in GDrivePlayer
 */
function decodeXorPayload(encodedBase64: string, key: string): string {
    try {
        const decoded = Buffer.from(encodedBase64, 'base64').toString('binary');
        let result = '';
        for (let i = 0; i < decoded.length; i++) {
            result += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length));
        }
        return result;
    } catch (e) {

        return '';
    }
}

export async function extractGDrivePlayer(url: string): Promise<string | null> {
    try {
        const { data: html } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': url,
            }
        });

        // 1. Cari Kunci (Key) XOR
        const keyMatch = html.match(/var\s+k\s*=\s*['"]([^'"]+)['"]/i);

        // 2. Cari Payload Base64
        const payloadMatch = html.match(/atob\(['"]([^'"]+)['"]\)/i);

        if (keyMatch && keyMatch[1] && payloadMatch && payloadMatch[1]) {
            const key = keyMatch[1];
            const encodedPayload = payloadMatch[1];

            // 3. Dekripsi Payload
            const decryptedScript = decodeXorPayload(encodedPayload, key);

            // 4. 🔥 REGEX MAUT: Nangkep "file:", "url:", ATAU variabel HLS="..." 🔥
            const playlistMatch =
                decryptedScript.match(/HLS\s*=\s*['"]([^'"]+)['"]/i) || // <-- INI YANG NANGKEP HLS="..."
                decryptedScript.match(/(?:["']?file["']?|["']?url["']?)\s*:\s*['"](https?:\/\/[^'"]+)['"]/i) ||
                decryptedScript.match(/(?:["']?file["']?|["']?url["']?)\s*:\s*['"](\/hlsplaylist\.php[^'"]+)['"]/i);

            if (playlistMatch && playlistMatch[1]) {
                let finalUrl = playlistMatch[1];

                // Rapikan URL jika bentuknya relatif (misal: "hlsplaylist.php?..." atau "/hlsplaylist.php?...")
                if (finalUrl.startsWith('/')) {
                    finalUrl = `https://gdriveplayer.to${finalUrl}`;
                } else if (!finalUrl.startsWith('http')) {
                    finalUrl = `https://gdriveplayer.to/${finalUrl}`;
                }
                return finalUrl;
            } else {
            }
        }

        // --- FALLBACK JIKA TIDAK ADA ENKRIPSI (WEBSITE MODE BIASA) ---
        const sourceMatch = html.match(/(?:["']?file["']?|["']?url["']?)\s*:\s*['"](https?:\/\/[^'"]+)['"]/i) ||
            html.match(/HLS\s*=\s*['"]([^'"]+)['"]/i);

        if (sourceMatch && sourceMatch[1]) {
            let finalUrl = sourceMatch[1];
            if (!finalUrl.startsWith('http')) {
                finalUrl = finalUrl.startsWith('/') ? `https://gdriveplayer.to${finalUrl}` : `https://gdriveplayer.to/${finalUrl}`;
            }
            console.log(`🎯 [Extractor] Ketemu via Pola Standar! URL: ${finalUrl}`);
            return finalUrl;
        }

        console.log(`❌ [Extractor] Gagal nemu URL Video sama sekali.`);
        return null;
    } catch (error: any) {
        console.error("💥 [Extractor] GDrive gagal fetch:", error.message);
        return null;
    }
}

/**
 * 🕵️‍♂️ Extractor Khusus Blogger Video (Google Video)
 * Url Input: https://www.blogger.com/video.g?token=...
 */
export async function extractBlogger(url: string): Promise<string | null> {
    console.log(`\n🕵️‍♂️ [Extractor] Mulai bongkar Blogger Video: ${url.substring(0, 50)}...`);
    try {
        // 1. Ambil Token dari URL
        const tokenMatch = url.match(/token=([^&]+)/);
        if (!tokenMatch || !tokenMatch[1]) {
            console.log(`❌ [Extractor] Gagal mendapatkan token dari URL Blogger.`);
            return null;
        }
        const token = tokenMatch[1];

        // 2. Siapkan Payload (f.req) 
        const reqPayload = `[[["WcwnYd","[\\"${token}\\",null,0]",null,"generic"]]]`;
        const postData = new URLSearchParams({
            'f.req': reqPayload
        }).toString();

        // 3. Tembak endpoint batchexecute Google
        const { data } = await axios.post(
            'https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute',
            postData,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Origin': 'https://www.blogger.com',
                    'Referer': url
                }
            }
        );

        // 4. Cari link googlevideo.com di dalam response yang berantakan
        // Pola regex mencari string yang dimulai https:// dan diakhiri googlevideo.com/videoplayback...
        const videoUrlMatch = data.match(/"(https:\/\/[^"]+googlevideo\.com\/videoplayback[^"]+)"/i);

        if (videoUrlMatch && videoUrlMatch[1]) {
            // 5. Bersihkan URL dari karakter Unicode & sisa Backslash
            let cleanUrl = videoUrlMatch[1];
            cleanUrl = cleanUrl.replace(/\\u003d/ig, '=')
                .replace(/\\u0026/ig, '&')
                .replace(/\\/g, ''); // 🔥 INI KUNCINYA: Hapus SEMUA backslash

            console.log(`🎯 [Extractor] KETEMU DIRECT LINK BLOGGER! URL: ${cleanUrl.substring(0, 80)}...`);
            // 🔥 BUNGKUS DENGAN PROXY 🔥
            const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || '';
            const proxyUrl = `${baseUrl}/api/animekompi/proxy?url=${encodeURIComponent(cleanUrl)}`;
            return proxyUrl;
        }

        console.log(`❌ [Extractor] Request batchexecute sukses, tapi URL GoogleVideo tidak ditemukan.`);
        return null;

    } catch (error: any) {
        console.error("💥 [Extractor] Blogger gagal fetch:", error.message);
        return null;
    }
}

/**
 * 🛠️ Fungsi Dekripsi NovaPlayer v4.6.5 (Bypass 100% Akurat)
 * Hasil bedah forensik dari player-v4.6.5.min.js
 */
function decryptNova(ciphertext: string, pd: string): string {
    try {
        const cleanCipher = ciphertext.replace(/\s+/g, '');
        const parsedBase64 = CryptoJS.enc.Base64.parse(cleanCipher);

        // 🎯 RUMUS RAHASIA HASIL BONGKAR SOURCE CODE MEREKA!
        // Mereka sengaja memakai slice(0, 4) untuk Salt (16 byte),
        // dan slice(4) untuk Ciphertext. Ini beda dari standar OpenSSL!
        const salt = CryptoJS.lib.WordArray.create(parsedBase64.words.slice(0, 4));
        const actualCiphertext = CryptoJS.lib.WordArray.create(parsedBase64.words.slice(4));

        // Generate Key & IV pakai PBKDF2 (10000 iterasi) sesuai kode obfuscated mereka
        const keyIv = CryptoJS.PBKDF2(pd, salt, {
            keySize: 12, // 256-bit Key (8 words) + 128-bit IV (4 words)
            iterations: 10000,
            hasher: CryptoJS.algo.SHA256
        });

        const key = CryptoJS.lib.WordArray.create(keyIv.words.slice(0, 8));
        const iv = CryptoJS.lib.WordArray.create(keyIv.words.slice(8, 12));

        // Buka gembok AES-nya!
        const decrypted = CryptoJS.AES.decrypt(
            { ciphertext: actualCiphertext } as any,
            key,
            { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
        );

        return decrypted.toString(CryptoJS.enc.Utf8);
    } catch (e) {
        console.error("💥 [Decryptor] Gagal Dekripsi:", e);
        return "";
    }
}

/**
 * 🕵️‍♂️ Extractor Khusus NovaPlayer / Uranus / AbyssPlayer
 */
export async function extractNovaPlayer(url: string): Promise<string | null> {
    console.log(`\n🕵️‍♂️ [Extractor] Mulai bongkar NovaPlayer (Uranus): ${url.substring(0, 60)}...`);
    try {
        const { data: html } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': url,
            }
        });

        const $ = cheerio.load(html);
        let aaScript = '';

        $('script').each((_, el) => {
            const content = $(el).html() || '';
            if (content.includes('ﾟωﾟﾉ')) {
                aaScript = content;
            }
        });

        if (!aaScript) {
            console.log(`❌ [Extractor] Gagal menemukan script AAEncode di HTML.`);
            return null;
        }

        let pd = '', ps = '', dscontentp = '', finalApiUrl = '', textContent = '';

        try {
            const sandbox: any = {
                window: {}, document: {}, navigator: { userAgent: '' }
            };
            sandbox.window = sandbox;

            sandbox.eval = (code: string) => { sandbox.unpackedCode = code; };
            vm.createContext(sandbox);

            const safeCode = aaScript.trim().replace(/\(\s*['"]?_['"]?\s*\)[\s;]*$/, ".toString();");
            let decodedScript = vm.runInContext(safeCode, sandbox, { timeout: 2000 }) || '';
            textContent = typeof decodedScript === 'string' ? decodedScript : '';

            const bodyMatch = textContent.match(/^\s*function\s*[^{]+\{([\s\S]*)\}\s*$/);
            const payloadBody = bodyMatch ? bodyMatch[1] : textContent;

            try { vm.runInContext(payloadBody, sandbox, { timeout: 2000 }); } catch (e) { }

            if (sandbox.unpackedCode && typeof sandbox.unpackedCode === 'string') {
                console.log(`🕵️‍♂️ [Extractor] Lapis kedua (Dean Edwards) berhasil dibongkar!`);
                textContent = sandbox.unpackedCode;
            } else {
                textContent = payloadBody;
            }

            // 5. 🎯 REGEX BARU & LAMA (PERBAIKAN PRIORITAS KUNCI!)
            const localKeyMatch = textContent.match(/localKey\s*=\s*['"]([^'"]+)['"]/);
            const kakenMatch = textContent.match(/kaken\s*=\s*['"]([^'"]+)['"]/);

            const pdMatch = textContent.match(/pd\s*=\s*['"]?([^'";]+)['"]?/);
            const psMatch = textContent.match(/ps\s*=\s*['"]([^'"]+)['"]/);
            const dsMatch = textContent.match(/dscontentp\s*=\s*(?:'([^']+)'|"([^"]+)")/);

            // 💥 KUNCI UTAMA: Kalau 'pd' asli masih ada, JANGAN pakai 'localKey' gadungan!
            pd = pdMatch ? pdMatch[1] : (localKeyMatch ? localKeyMatch[1] : '');

            // kaken = dscontentp (payload request body)
            dscontentp = kakenMatch ? kakenMatch[1] : (dsMatch ? (dsMatch[1] || dsMatch[2]) : '');

            // Parameter ?p= yang bener itu selalu ada di regex 'ps'
            ps = psMatch ? psMatch[1] : '';

            if (pd && dscontentp && ps) {
                const baseUrl = new URL(url).origin;
                finalApiUrl = `${baseUrl}/api/?p=${ps}`;
                console.log(`🔓 [Extractor] Berhasil Bypass! Key: ${pd}, Target: ${finalApiUrl}`);
            } else {
                console.log(`❌ [Extractor] Variabel gagal ditangkap secara akurat.`);
                return null;
            }
        } catch (e: any) {
            console.error("💥 [Extractor] Gagal mengeksekusi Packed Script:", e.message);
            return null;
        }

        // 6. Tembak API POST
        const baseUrl = new URL(url).origin;
        console.log(`📡 [Extractor] Mengirim request POST ke API...`);

        const response = await axios.post(finalApiUrl, dscontentp, {
            headers: {
                'Accept': 'text/plain, */*; q=0.01',
                'Content-Type': 'text/plain',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Origin': baseUrl,
                'Referer': url,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        // 7. BYPASS AXIOS AUTO-PARSE
        let cipherTextStr = response.data;
        if (typeof response.data === 'object') {
            cipherTextStr = response.data.data || response.data.ciphertext || JSON.stringify(response.data);
        }

        if (!cipherTextStr || typeof cipherTextStr !== 'string') {
            return null;
        }

        // 8. Hancurkan Enkripsi AES (Memanggil Swiss Army Knife)
        console.log(`🔐 [Extractor] Mendekripsi respons API...`);
        const decryptedJsonStr = decryptNova(cipherTextStr, pd);

        if (!decryptedJsonStr) {
            return null;
        }

        const decryptedData = JSON.parse(decryptedJsonStr);
        // 9. Ambil Direct Link Videonya (Resolusi Paling Besar!)
        if (decryptedData) {
            let videoUrl = '';

            // 🎯 Kalau formatnya pakai "sources" (Versi Baru)
            if (decryptedData.sources && Array.isArray(decryptedData.sources) && decryptedData.sources.length > 0) {

                // Sortir array berdasarkan angka di label (misal dari "720p" kita ambil angka 720) dari besar ke kecil
                const sortedSources = decryptedData.sources.sort((a: any, b: any) => {
                    const resA = parseInt(a.label) || 0;
                    const resB = parseInt(b.label) || 0;
                    return resB - resA; // Descending (Besar -> Kecil)
                });

                // Comot array urutan pertama (yang paling besar)
                const bestSource = sortedSources[0];
                videoUrl = bestSource.file;

            }
            // 🎯 Kalau formatnya pakai "data" (Versi Lama / Fallback)
            else if (decryptedData.data) {
                if (Array.isArray(decryptedData.data)) {
                    videoUrl = decryptedData.data[0].file;
                } else if (decryptedData.data.file) {
                    videoUrl = decryptedData.data.file;
                }
            } else if (decryptedData.file) {
                videoUrl = decryptedData.file;
            }

            if (videoUrl) {
                // Bungkus pakai Proxy biar gak kena 403 Forbidden
                const proxyBaseUrl = process.env.NEXT_PUBLIC_SITE_URL || '';
                return `${proxyBaseUrl}/api/animekompi/proxy?url=${encodeURIComponent(videoUrl)}`;
            }
        }

        console.log(`❌ [Extractor] Gagal nemu link video di hasil dekripsi.`);
        return null;

    } catch (error: any) {
        return null;
    }
}

export async function resolveAnimekompiServer(serverName: string, embedUrl: string): Promise<string | null> {
    const nameLower = serverName.toLowerCase();
    const urlLower = embedUrl.toLowerCase();

    if (nameLower.includes('gdrive') || urlLower.includes('gdriveplayer')) {
        return await extractGDrivePlayer(embedUrl);
    }
    // 2. Jalur Blogger Video (Google Video)
    // 🔥 Cek mutlak berdasarkan URL, bukan nama server 🔥
    if (urlLower.includes('blogger.com/video.g')) {
        return await extractBlogger(embedUrl);
    }

    // 3. 🔥 JALUR BARU: NovaPlayer / Uranus / AbyssPlayer 🔥
    if (urlLower.includes('novaplayer') || urlLower.includes('abyssplayer') || urlLower.includes('uranus')) {
        return await extractNovaPlayer(embedUrl);
    }

    return null;
}