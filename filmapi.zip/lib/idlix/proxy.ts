import { URL } from "node:url";
import { execFile } from 'node:child_process';
import util from 'node:util';

const execFilePromise = util.promisify(execFile);

const IDLIX_BASE = process.env.IDLIX_BASE || 'https://z2.idlixku.com';
const DEFAULT_IDLIX_COOKIE = process.env.IDLIX_COOKIES || '';
const cache = new Map<string, { val: any, exp: number }>();

// 👇 Jalur global VPS supaya bisa diakses oleh user indocast-api
const CURL_BIN = '/usr/local/bin/curl-impersonate-chrome';

// ==========================================
// 🔥 HELPER: SANITIZE STATUS UNTUK NGINX 🔥
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 400;
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400; // Samarkan jadi 400 supaya Nginx/CF gak nimpa jadi HTML
    }
    return status;
}

// Fungsi inti GET via curl-impersonate
async function Get(urlStr: string, timeoutMs = 15_000) {
    const args = [
        '-s', '-k', 
        urlStr,
        '-H', 'Host: z2.idlixku.com',
        '-H', 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
        '-H', 'Accept: */*',
        '-H', 'Accept-Language: en-US,en;q=0.9',
        '-H', 'Accept-Encoding: gzip, deflate', 
        '-H', 'Referer: https://z2.idlixku.com/',
        '-H', 'Origin: https://z2.idlixku.com',
        '-H', 'sec-ch-ua: "Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
        '-H', 'sec-ch-ua-mobile: ?0',
        '-H', 'sec-ch-ua-platform: "Windows"',
        '-H', 'Sec-Fetch-Dest: empty',
        '-H', 'Sec-Fetch-Mode: cors',
        '-H', 'Sec-Fetch-Site: same-origin',
        '-H', 'Pragma: no-cache',
        '-H', 'Cache-Control: no-cache',
        '-H', `Cookie: ${DEFAULT_IDLIX_COOKIE}`,
        '--compressed'
    ];

    try {
        const { stdout } = await execFilePromise(CURL_BIN, args, { 
            timeout: timeoutMs, 
            maxBuffer: 1024 * 1024 * 5 
        });

        return {
            status: 200,
            contentType: 'application/json',
            text: stdout 
        };
    } catch (error: any) {
        console.error("🔥 CURL GET ERROR:", error.message);
        return {
            status: 502,
            contentType: 'application/json',
            text: '{"error": true, "message": "Gagal eksekusi curl-impersonate"}'
        };
    }
}

// ========================================================
// 1. FUNGSI POST YANG BARU (Bisa dinamis Host & Headers)
// ========================================================
// 🔥 Yg diubah 1: Tambahin parameter customHeaders
async function Post(urlStr: string, body: string, contentType: string, customHeaders: Record<string, string> = {}, timeoutMs = 15_000) {
    // 🔥 Yg diubah 2: Ambil hostname dari URL tujuan biar dinamis
    const targetUrl = new URL(urlStr);
    
    // 🔥 Yg diubah 3: Headernya kita jadiin object biar gampang di-merge sama customHeaders dari step 2/3
    const headers: Record<string, string> = {
        'Host': targetUrl.hostname, // <-- Nyesuaiin otomatis, entah ke z2.idlixku.com atau e2e.majorplay.net
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Referer': 'https://z2.idlixku.com/',
        'Origin': 'https://z2.idlixku.com',
        'sec-ch-ua': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        // 🔥 Yg diubah 4: Kalau domain beda, dia ganti ke cross-site (menghindari diblokir CDN)
        'Sec-Fetch-Site': targetUrl.hostname === 'z2.idlixku.com' ? 'same-origin' : 'cross-site',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'Cookie': DEFAULT_IDLIX_COOKIE,
        'Content-Type': contentType,
        ...customHeaders // 🔥 Yg diubah 5: Merge header bawaan dari proxyPost (seperti Cookie did, Origin, dll)
    };

    // 🔥 Yg diubah 6: Susun ulang args curl-nya
    const args = ['-s', '-k', '-X', 'POST', urlStr];
    for (const [key, val] of Object.entries(headers)) {
        if (val !== undefined && val !== null) {
            args.push('-H', `${key}: ${val}`);
        }
    }
    args.push('--data-raw', body, '--compressed');

    try {
        const { stdout } = await execFilePromise(CURL_BIN, args, { 
            timeout: timeoutMs, 
            maxBuffer: 1024 * 1024 * 5 
        });

        return {
            status: 200,
            contentType: 'application/json',
            text: stdout
        };
    } catch (error: any) {
        console.error("🔥 CURL POST ERROR:", error.message);
        return {
            status: 502,
            contentType: 'application/json',
            text: '{"error": true, "message": "Gagal eksekusi curl-impersonate"}'
        };
    }
}

export async function proxyGet(req: Request, path: string, query: Record<string, string>, opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string>; useProxyOverride?: boolean } = { label: 'idlix-get' }) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();
    let pathWithQuery = path;
    if (qs) pathWithQuery = path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`;

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(JSON.stringify(hit.val), { headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' } });
        }
    }

    const upstreamUrl = `${IDLIX_BASE}${pathWithQuery}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, 15_000);

        if (opts.send === false) {
            if (status !== 200) return { error: true, status, message: "Upstream failed", raw: text };
            try { 
                return JSON.parse(text); 
            } catch (parseError) { 
                return { error: true, message: "Failed to parse JSON", raw: text }; 
            }
        }

        if (cacheKey && status === 200 && opts.cacheTtlMs && contentType.includes('application/json')) {
            try { cache.set(cacheKey, { val: JSON.parse(text), exp: Date.now() + opts.cacheTtlMs }); } catch { }
        }

        return new Response(text, { status: sanitizeStatus(status), headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), {
            status: sanitizeStatus(502),
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

// ========================================================
// 2. FUNGSI proxyPost YANG BARU (Lempar header ke Post)
// ========================================================
export async function proxyPost(req: Request, path: string, body: any, opts: { label: string; send?: boolean; headers?: Record<string, string>; useProxyOverride?: boolean } = { label: 'idlix-post' }) {
    let upstreamUrl = path.startsWith('http') ? path : `${IDLIX_BASE}${path}`;
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    
    // 🔥 Yg diubah 7: Ambil Content-Type dari opts kalau ada
    const reqContentType = opts.headers?.['Content-Type'] || "application/json";

    try {
        // 🔥 Yg diubah 8: opts.headers HARUS dikirim ke fungsi Post() di argumen ke-4
        const { status, contentType, text } = await Post(upstreamUrl, stringBody, reqContentType, opts.headers || {}, 15_000);
        
        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return { error: true, status, text }; }
        }
        return new Response(text, { status: sanitizeStatus(status), headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), {
            status: sanitizeStatus(502),
            headers: { 'Content-Type': 'application/json' }
        });
    }
}