import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";
import crypto from 'node:crypto';
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';

const IDLIX_BASE = process.env.IDLIX_BASE || 'https://z2.idlixku.com';
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL_FILMBOX || '';
const DEFAULT_IDLIX_COOKIE = process.env.IDLIX_COOKIES || '...'; // (Anggap string cookie lu yg panjang ada di sini)
const cache = new Map<string, { val: any, exp: number }>();

// ==========================================
// 🔥 HELPER: SANITIZE STATUS UNTUK NGINX 🔥
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 400;
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400; // Samarkan jadi 400 supaya Nginx/CF gak nimpa jadi HTML
    }
    return status;
}

function buildIdlixHeaders(req: Request, targetHost: string = "z2.idlixku.com"): Record<string, string> {
    const headers: Record<string, string> = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Host": targetHost,
        "Referer": "https://z2.idlixku.com/",
        "Origin": "https://z2.idlixku.com",
        // 👇 Update User-Agent & sec-ch-ua persis seperti browser lu (Chrome 151)
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Not=A?Brand";v="99", "Google Chrome";v="151", "Chromium";v="151"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        "Pragma": "no-cache"
    };

    // 👇 Kita HAPUS paksaan cookie dari default. 
    // Step 2 dan Step 3 tetap aman karena mereka ngirim cookie lewat `opts.headers`

    return headers;
}

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

async function Get(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000, useProxyOverride?: boolean) {
    const u = new URL(urlStr);
    const shouldProxy = useProxyOverride !== undefined ? useProxyOverride : USE_PROXY;
    const agent = (shouldProxy && PROXY_URL)
        ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false, keepAlive: true })
        : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3",
                ciphers: crypto.constants.defaultCoreCipherList,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);

                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function Post(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000, useProxyOverride?: boolean) {
    const u = new URL(urlStr);
    const shouldProxy = useProxyOverride !== undefined ? useProxyOverride : USE_PROXY;
    const agent = (shouldProxy && PROXY_URL)
        ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false, keepAlive: true })
        : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3",
                ciphers: crypto.constants.defaultCoreCipherList,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(req: Request, path: string, query: Record<string, string>, opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string>; useProxyOverride?: boolean } = { label: 'idlix-get' }) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();
    let pathWithQuery = path;
    if (qs) pathWithQuery = path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`;

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${pathWithQuery}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(JSON.stringify(hit.val), { headers: { 'Content-Type': 'application/json', 'x-cache': 'HIT' } });
        }
    }

    const headers = { ...buildIdlixHeaders(req), ...opts.headers };
    const upstreamUrl = `${IDLIX_BASE}${pathWithQuery}`;
    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, headers, 15_000, opts.useProxyOverride);

        if (opts.send === false) {
            // Kita simpan status aslinya buat dibaca route, nanti route yg nyamarain
            if (status !== 200) return { error: true, status, message: "Upstream or Proxy failed", raw: text };
            try { return JSON.parse(text); } catch (parseError) { return { error: true, message: "Failed to parse JSON", raw: text }; }
        }

        if (cacheKey && status >= 200 && status < 300 && opts.cacheTtlMs && contentType.includes('application/json')) {
            try { cache.set(cacheKey, { val: JSON.parse(text), exp: Date.now() + opts.cacheTtlMs }); } catch { }
        }

        // 🔥 Terapkan sanitize di response kalau fungsi langsung dipanggil (send: true)
        return new Response(text, { status: sanitizeStatus(status), headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), {
            status: sanitizeStatus(502), // 👈 MENCEGAH NGINX HTML ERROR
            headers: { 'Content-Type': 'application/json' }
        });
    }
}

export async function proxyPost(req: Request, path: string, body: any, opts: { label: string; send?: boolean; headers?: Record<string, string>; useProxyOverride?: boolean } = { label: 'idlix-post' }) {
    let upstreamUrl = path;
    let targetHost = "z2.idlixku.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        upstreamUrl = `${IDLIX_BASE}${path}`;
        const u = new URL(IDLIX_BASE);
        targetHost = u.hostname;
    }

    const headers = { ...buildIdlixHeaders(req, targetHost), ...opts.headers };
    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    const reqContentType = headers["Content-Type"] || headers["content-type"] || "application/json";

    try {
        const { status, contentType, text } = await Post(upstreamUrl, headers, stringBody, reqContentType, 15_000, opts.useProxyOverride);
        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return { error: true, status, text }; }
        }
        return new Response(text, { status: sanitizeStatus(status), headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), {
            status: sanitizeStatus(502), // 👈 MENCEGAH NGINX HTML ERROR
            headers: { 'Content-Type': 'application/json' }
        });
    }
}