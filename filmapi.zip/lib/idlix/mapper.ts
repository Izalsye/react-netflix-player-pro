import {
    IdlixMediaItem,
    IdlixHomeSection,
    IdlixCleanHomeResponse,
    IdlixContentType,
    IdlixNetworkResponse,
    IdlixMoviesResponse,
    IdlixSeason,
    IdlixEpisode,
    IdlixMediaDetail,
    IdlixCastMember,
    IdlixCompany,
    IdlixPlayConfig,
    IdlixSubtitleItem
} from '@/types/idlix';

// ==========================================
// 🚀 HELPER: GENERATE PROXY URL UNTUK IDLIX
// ==========================================
function getProxyUrl(provider: string, type: string, originalUrl: string | null): string {
    if (!originalUrl) return '';
    const BASE_DOMAIN = process.env.NEXT_PUBLIC_SITE_URL || '';
    const encodedUrl = encodeURIComponent(originalUrl);
    // Arahkan ke endpoint proxy khusus Idlix lu
    return `${BASE_DOMAIN}/api/idlix/stream-proxy?url=${encodedUrl}&provider=${provider}&type=${type}`;
}

export class IdlixDataMapper {

    /**
     * Mengubah item mentah IDLIX dari berbagai bentuk nested objek 
     * menjadi flat model item yang seragam dan siap pakai.
     */
    public static mapItem(rawItem: any): IdlixMediaItem {
        const data = rawItem.content || rawItem;

        // 🔥 FIX: Deteksi otomatis jika API tidak mengirimkan contentType
        const isSeries = data.numberOfSeasons !== undefined || data.firstAirDate !== undefined;
        const contentType = rawItem.contentType || data.contentType || (isSeries ? 'series' : 'movie');

        // Supaya bisa baca format genre string maupun nested object
        let genres: string[] = [];
        if (Array.isArray(data.genres)) {
            genres = data.genres.map((g: any) => typeof g === 'object' ? g.name : g);
        }

        return {
            id: data.id || rawItem.id,
            contentType,
            title: data.title || data.name || '',
            slug: data.slug || '',
            overview: data.overview || '',
            tagline: data.tagline || null,
            posterPath: data.posterPath ? `https://image.tmdb.org/t/p/w500${data.posterPath}` : '',
            backdropPath: data.backdropPath ? `https://image.tmdb.org/t/p/original${data.backdropPath}` : '',
            logoPath: data.logoPath || null,
            releaseDate: data.releaseDate || data.firstAirDate || null,
            runtimeMinutes: data.runtime || null,
            voteAverage: data.voteAverage ? parseFloat(data.voteAverage) : 0,
            viewCount: data.viewCount ? parseInt(data.viewCount, 10) : 0,
            genres,
            hasVideo: !!data.hasVideo,

            ...(data.numberOfSeasons && { numberOfSeasons: data.numberOfSeasons }),
            ...(data.numberOfEpisodes && { numberOfEpisodes: data.numberOfEpisodes }),
        };
    }

    /**
     * Memproses Response API Homepage IDLIX mentah menjadi format seksi 
     * yang sudah terkelompok rapi (Membagi Slider Atas dan Seksi Konten).
     */
    public static mapHomepage(rawResponse: any): IdlixCleanHomeResponse {
        const sections: IdlixHomeSection[] = [];
        let sliderItems: IdlixMediaItem[] = [];

        if (Array.isArray(rawResponse.above)) {
            const featuredSection = rawResponse.above.find((s: any) => s.type === 'featured');
            if (featuredSection && Array.isArray(featuredSection.data)) {
                sliderItems = featuredSection.data.map((item: any) => this.mapItem(item));
            }

            rawResponse.above.forEach((section: any) => {
                if (section.type !== 'featured' && Array.isArray(section.data)) {
                    sections.push({
                        sectionId: section.id,
                        type: section.type,
                        title: section.title,
                        slug: section.slug,
                        items: section.data.map((item: any) => this.mapItem(item))
                    });
                }
            });
        }

        if (Array.isArray(rawResponse.below)) {
            rawResponse.below.forEach((section: any) => {
                if (Array.isArray(section.data)) {
                    sections.push({
                        sectionId: section.id,
                        type: section.type,
                        title: section.title || section.slug.replace('-', ' ').toUpperCase(),
                        slug: section.slug,
                        items: section.data.map((item: any) => this.mapItem(item))
                    });
                }
            });
        }

        return {
            sliderItems,
            sections
        };
    }

    // map network
    public static mapNetworkResponse(rawResponse: any): IdlixNetworkResponse {
        const rawList = Array.isArray(rawResponse.data) ? rawResponse.data : [];
        const items = rawList.map((item: any) => this.mapItem(item));

        return {
            networkName: rawResponse.meta?.network || 'unknown',
            sortBy: rawResponse.meta?.sort || 'latest',
            pagination: {
                page: rawResponse.pagination?.page || 1,
                limit: rawResponse.pagination?.limit || 36,
                total: rawResponse.pagination?.total || 0,
                totalPages: rawResponse.pagination?.totalPages || 1,
            },
            data: items
        };
    }

    // map movie
    public static mapMoviesResponse(rawResponse: any): IdlixMoviesResponse {
        const rawList = Array.isArray(rawResponse.data) ? rawResponse.data : [];
        const items = rawList.map((item: any) => this.mapItem(item));

        return {
            pagination: {
                page: rawResponse.pagination?.page || 1,
                limit: rawResponse.pagination?.limit || 36,
                total: rawResponse.pagination?.total || 0,
                totalPages: rawResponse.pagination?.totalPages || 1,
            },
            items: items
        };
    }

    // 🔥 FIX: Map Series yang dipastikan contentType-nya "series"
    public static mapSeriesResponse(rawResponse: any): IdlixMoviesResponse {
        const rawList = Array.isArray(rawResponse.data) ? rawResponse.data : [];

        // Memastikan semua item dipaksa jadi series jika helper mapItem meleset
        const items = rawList.map((item: any) => {
            const mapped = this.mapItem(item);
            mapped.contentType = 'tv_series';
            return mapped;
        });

        return {
            pagination: {
                page: rawResponse.pagination?.page || 1,
                limit: rawResponse.pagination?.limit || 36,
                total: rawResponse.pagination?.total || 0,
                totalPages: rawResponse.pagination?.totalPages || 1,
            },
            items: items
        };
    }

    // ==========================================
    // 🎯 HELPER BARU UNTUK MAPPING EPISODE
    // ==========================================
    public static mapEpisodes(rawEpisodes: any[]): IdlixEpisode[] {
        if (!Array.isArray(rawEpisodes)) return [];

        // Tambahin /w500 untuk resolusi thumbnail yang pas (gak terlalu berat)
        const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';

        return rawEpisodes.map((e: any) => ({
            id: e.id,
            tmdbId: e.tmdbId ? parseInt(e.tmdbId, 10) : null,
            episodeNumber: e.episodeNumber || 0,
            title: e.title || e.name || `Episode ${e.episodeNumber}`,
            // 🔥 FIX: Gabungin Base URL dengan stillPath
            thumbnail: e.stillPath ? `${TMDB_IMAGE_BASE}${e.stillPath}` : '',
            overview: e.overview || '',
            airDate: e.airDate || null,
            runtimeMinutes: e.runtime ? parseInt(e.runtime, 10) : (e.runtimeMinutes ? parseInt(e.runtimeMinutes, 10) : null),
            voteAverage: e.voteAverage ? parseFloat(e.voteAverage) : 0,
            hasVideo: !!e.hasVideo
        }));
    }

    // ==========================================
    // 🎯 MAPPING DETAIL UTAMA
    // ==========================================
    public static mapDetailResponse(raw: any): IdlixMediaDetail {
        const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';

        const backdrops: string[] = Array.isArray(raw.backdrops)
            ? raw.backdrops.map((path: string) => `${TMDB_IMAGE_BASE}/original${path}`)
            : [];

        const genres: string[] = Array.isArray(raw.genres)
            ? raw.genres.map((g: any) => typeof g === 'object' ? g.name : g)
            : [];

        const keywords: string[] = Array.isArray(raw.keywords)
            ? raw.keywords.map((k: any) => typeof k === 'object' ? k.name : k)
            : [];

        const productionCompanies: IdlixCompany[] = Array.isArray(raw.productionCompanies)
            ? raw.productionCompanies.map((c: any) => ({
                id: c.id,
                name: c.name,
                logoPath: c.logo_path ? `${TMDB_IMAGE_BASE}/w200${c.logo_path}` : null
            }))
            : [];

        const cast: IdlixCastMember[] = Array.isArray(raw.cast)
            ? raw.cast.map((actor: any) => ({
                id: actor.id,
                name: actor.name,
                character: actor.character || '',
                profilePath: actor.profilePath ? `${TMDB_IMAGE_BASE}/w185${actor.profilePath}` : null,
                order: actor.order ?? 999
            }))
            : [];

        let seasons: IdlixSeason[] = [];
        const rawSeasonsData = raw.seasons || (raw.season ? [raw.season] : null);

        if (Array.isArray(rawSeasonsData)) {
            seasons = rawSeasonsData.map((s: any) => {
                const rawEpisodes = s.episode || s.episodes || (raw.defaultSeason?.id === s.id ? raw.defaultSeason.episodes : []) || [];

                // 🎯 PANGGIL MAPPER EPISODE DI SINI
                const episodes: IdlixEpisode[] = this.mapEpisodes(rawEpisodes);

                return {
                    id: s.id,
                    tmdbId: s.tmdbId ? parseInt(s.tmdbId, 10) : null,
                    seasonNumber: s.seasonNumber || 1,
                    title: s.name || `Season ${s.seasonNumber}`,
                    episodes
                };
            });
        }

        const isSeries = raw.numberOfSeasons !== undefined || raw.firstAirDate !== undefined;
        const contentType = (raw.contentType || (isSeries ? 'tv_series' : 'movie')) as IdlixContentType;
        if (contentType === 'movie' && seasons.length === 0) {
            seasons = [
                {
                    id: `season-1-${raw.id}`,
                    tmdbId: raw.tmdbId ? parseInt(raw.tmdbId, 10) : null,
                    seasonNumber: 1,
                    title: "Season 1",
                    episodes: [
                        {
                            id: raw.id,
                            tmdbId: raw.tmdbId ? parseInt(raw.tmdbId, 10) : null,
                            episodeNumber: 1,
                            title: raw.title || raw.name || 'Full Movie',

                            // 🔥 FIX: Tambahin thumbnail pakai backdrop atau poster dengan size w500
                            thumbnail: raw.backdropPath
                                ? `${TMDB_IMAGE_BASE}/w500${raw.backdropPath}`
                                : (raw.posterPath ? `${TMDB_IMAGE_BASE}/w500${raw.posterPath}` : ''),

                            overview: raw.overview || '',
                            airDate: raw.releaseDate || null,
                            runtimeMinutes: raw.runtime ? parseInt(raw.runtime, 10) : null,
                            voteAverage: raw.voteAverage ? parseFloat(raw.voteAverage) : 0,
                            hasVideo: !!raw.hasVideo
                        }
                    ]
                }
            ];
        }

        return {
            id: raw.id,
            tmdbId: raw.tmdbId ? parseInt(raw.tmdbId, 10) : null,
            imdbId: raw.imdbId || null,
            contentType: contentType,
            title: raw.title || raw.name || '',
            originalTitle: raw.originalTitle || null,
            slug: raw.slug,
            overview: raw.overview || '',
            tagline: raw.tagline || null,
            posterPath: raw.posterPath ? `${TMDB_IMAGE_BASE}/w500${raw.posterPath}` : '',
            backdropPath: raw.backdropPath ? `${TMDB_IMAGE_BASE}/original${raw.backdropPath}` : '',
            logoPath: raw.logoPath || null,
            backdrops,
            releaseDate: raw.releaseDate || raw.firstAirDate || null,
            runtimeMinutes: raw.runtime ? parseInt(raw.runtime, 10) : null,
            voteAverage: raw.voteAverage ? parseFloat(raw.voteAverage) : 0,
            viewCount: raw.viewCount ? parseInt(raw.viewCount, 10) : 0,
            country: raw.country || null,
            status: raw.status || null,
            trailerUrl: raw.trailerUrl || null,
            quality: raw.quality || null,
            director: raw.director ? {
                name: raw.director,
                profilePath: raw.directorProfilePath ? `${TMDB_IMAGE_BASE}/w185${raw.directorProfilePath}` : null
            } : null,
            productionCompanies,
            genres,
            keywords,
            cast,
            hasVideo: !!raw.hasVideo,
            ...(seasons.length > 0 && { seasons })
        };
    }

    public static mapPlayResponse(rawResponse: any): any {
        const raw = rawResponse?.data || rawResponse;

        if (!raw || !raw.url) return null;

        const subtitles = Array.isArray(raw.subtitles)
            ? raw.subtitles.map((sub: any) => {
                const originalSubUrl = sub.path || '';
                return {
                    lang: sub.lang || 'unknown',
                    label: sub.label || 'Unknown',
                    subUrl: originalSubUrl,
                    suburl_proxy: getProxyUrl('idlix', 'sub', originalSubUrl) // 👈 Suntikan Proxy Subtitle
                };
            })
            : [];

        const readableTime = raw.expiresAt
            ? new Date(raw.expiresAt * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
            : '';

        return {
            videoId: raw.videoId || '',
            vidUrl: raw.url,
            vidurl_proxy: getProxyUrl('idlix', 'stream', raw.url), // 👈 Suntikan Proxy Video
            mode: raw.mode || 'cast',
            playbackCode: raw.code || 'ok',
            sessionTimeout: {
                expiresAtUnix: raw.expiresAt || 0,
                expiresAtReadable: readableTime,
                ttlSeconds: raw.ttlSeconds || 0
            },
            subtitles
        };
    }
}