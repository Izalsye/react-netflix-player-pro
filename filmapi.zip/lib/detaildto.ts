import { Subtitles } from "lucide-react";

export function mapResolutionList(d: any) {
  const list = d?.resourceDetectors?.[0]?.resolutionList;
  if (!Array.isArray(list) || list.length === 0) return [];

  return list.map((r: any) => {
    const caps = Array.isArray(r?.extCaptions) ? r.extCaptions : [];

    return {
      episode: Math.max(1, r?.episode ?? r?.ep ?? 0),
      resolution: r?.resolution ?? null,
      url_play: r?.resourceLink ?? null,
      subtitle: caps.map((c: any) => ({
        lang: c?.lan ?? "",
        sub_url: c?.url ?? null,
        name: c?.lanName ?? "",
      })),
    };
  });
}

export function mapDetailDataDTO(upstream: any) {
  if (!upstream || !upstream.data) return upstream;
  const d = upstream.data;

  // Ekstrak detailPath
  const detailPathRaw = typeof d.detailUrl === 'string' 
    ? d.detailUrl.split('/').filter(Boolean).pop() 
    : "";

  return {
    code: upstream.code,
    message: upstream.message,
    data: {
      // 🔥 KITA DEFINE MANUAL SATU-SATU BIAR BERSIH, TANPA SPREAD (...d) 🔥
      subjectId: d.subjectId || "",
      detailPath: detailPathRaw || "",
      subjectType: d.subjectType || 0,
      title: d.title || "",
      description: d.description || "",
      releaseDate: d.releaseDate || "",
      appointmentDate: d.appointmentDate || "",
      genre: d.genre || "",
      cover_url: d.cover?.url || null,
      country: d.countryName || "",
      bahasa: d.language || "",
      rating: parseFloat(d.imdbRatingValue || d.rating || "0"),
      trailer_url: d.trailer?.VideoAddress?.url || null,
      view: d.viewers || d.view || 0,
      
      // Total akan ditimpa ulang di Route nanti biar lebih akurat, 
      // tapi kita kasih nilai default dari upstream dulu
      totalEpisode: d.resourceDetectors?.[0]?.totalEpisode || d.totalEpisode || 0,
      totalSeason: d.seNum || 1,
      
      // Array kosong ini akan diisi oleh Route.ts setelah hit API season-info
      seasons_list: [] 
    },
  };
}
