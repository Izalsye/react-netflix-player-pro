import * as cheerio from 'cheerio';
// 🔥 Import extractor lu di sini
import { resolveAnimekompiServer } from '@/lib/animekompi/extractor';
export class AnimekompiMapper {
    /**
     * Helper untuk mengekstrak path dari URL penuh
     * Contoh: "https://v9.animekompi.sbs/one-piece-episode-1161-subtitle-indonesia/" 
     * Menjadi: "one-piece-episode-1161-subtitle-indonesia"
     */
    private static extractPath(url: string): string {
        if (!url) return '';
        // Hapus slash di paling ujung (jika ada), lalu ambil segmen terakhirnya
        const cleanUrl = url.replace(/\/$/, '');
        return cleanUrl.split('/').pop() || '';
    }
    // 👇 Fungsi baru buat ngebedain mana path, mana episode_id 👇
    private static parseIdsFromUrl(url: string) {
        if (!url) return { path: '', episode_id: '' };

        // Bersihkan slash di belakang dan ambil segmen terakhir
        const cleanUrl = url.replace(/\/$/, '');
        const slug = cleanUrl.split('/').pop() || '';

        // Jika URL mengandung '/anime/', berarti ini link ke halaman Detail (Series)
        if (url.includes('/anime/')) {
            return {
                path: slug,        // contoh: a-day-before-us-2
                episode_id: ''     // Kosong, karena ini bukan link episode spesifik
            };
        }
        // Jika tidak, berarti ini link ke halaman Play (Episode)
        else {
            // Kita bisa tebak 'path' seriesnya dengan membuang kata '-episode-'
            const pathGuess = slug.split('-episode-')[0].split('-ova-')[0];

            return {
                path: pathGuess,   // contoh: a-day-before-us-2
                episode_id: slug   // contoh: a-day-before-us-2-episode-01
            };
        }
    }

    /**
     * Parser khusus untuk halaman Home (Beranda)
     */
    public static mapHome(html: string) {
        const $ = cheerio.load(html);

        const result = {
            sliders: [] as any[],
            trending_today: [] as any[],
            latest_updates: [] as any[]
        };

        // --- MAPPING 1: SLIDER ---
        $('.slidtop .slide-item').each((_, el) => {
            const title = $(el).find('.info-left .title a').text().trim();
            const url = $(el).find('.info-left .title a').attr('href') || '';
            const year = $(el).find('.release-year').text().trim();
            const summary = $(el).find('.excerpt .story').text().trim();

            const imgEl = $(el).find('.slide-bg img');
            const coverUrl = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

            const genres: string[] = [];
            $(el).find('.extra-category a').each((_, genreEl) => {
                genres.push($(genreEl).text().trim());
            });

            // Ekstrak ID pakai fungsi baru
            const ids = this.parseIdsFromUrl(url);

            if (title) {
                result.sliders.push({
                    rank: 0,
                    title: title,
                    cover_url: coverUrl,
                    path: ids.path,             // 👈 Masuk ke sini
                    episode_id: ids.episode_id, // 👈 Masuk ke sini
                    episode: "",
                    jumlah_episode: "",
                    release_year: year,
                    genres: genres,
                    deskripsi: summary,
                    rating: 0,
                    view: 0
                });
            }
        });

        // --- MAPPING 2: TRENDING HARI INI ---
        $('.hot-item').each((_, el) => {
            const title = $(el).find('.hot-tt-fix h2').text().trim();
            const url = $(el).find('a').attr('href') || '';
            const rank = $(el).find('.toprank').text().replace('#', '').trim();
            const episode = $(el).find('.hot-ep-info').text().replace('Ep', '').trim();

            const imgEl = $(el).find('img');
            const coverUrl = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

            // Ekstrak ID pakai fungsi baru
            const ids = this.parseIdsFromUrl(url);

            if (title) {
                result.trending_today.push({
                    rank: parseInt(rank || "0", 10),
                    title: title,
                    cover_url: coverUrl,
                    path: ids.path,             // 👈 Masuk ke sini
                    episode_id: ids.episode_id, // 👈 Masuk ke sini
                    episode: episode,
                    jumlah_episode: "",
                    release_year: "",
                    genres: [],
                    deskripsi: "",
                    rating: 0,
                    view: 0
                });
            }
        });

        // --- MAPPING 3: RILISAN TERBARU ---
        $('.listupd.normal').first().find('.bs').each((_, el) => {
            const title = $(el).find('.tt h2').text().trim();
            const url = $(el).find('a.tip').attr('href') || '';

            const imgEl = $(el).find('img');
            const coverUrl = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

            const episode = $(el).find('.epx').text().replace('Ep', '').trim();

            // Ekstrak ID pakai fungsi baru
            const ids = this.parseIdsFromUrl(url);

            if (title) {
                result.latest_updates.push({
                    rank: 0,
                    title: title,
                    cover_url: coverUrl,
                    path: ids.path,             // 👈 Masuk ke sini
                    episode_id: ids.episode_id, // 👈 Masuk ke sini
                    episode: episode,
                    jumlah_episode: "",
                    release_year: "",
                    genres: [],
                    deskripsi: "",
                    rating: 0,
                    view: 0
                });
            }
        });

        // Hapus duplikat dari slider
        result.sliders = result.sliders.filter((v, i, a) => a.findIndex(t => (t.title === v.title)) === i);

        return result;
    }

    /**
     * Parser khusus untuk halaman A-Z Anime List
     */
    public static mapList(html: string) {
        const $ = cheerio.load(html);
        const result: any[] = [];

        // Setiap grup abjad dibungkus dalam class .blix
        $('.blix').each((_, el) => {
            // Ambil nama abjad/karakter (misal: "A", "B", "#")
            const groupName = $(el).find('span a').text().trim() || $(el).find('span').text().trim();
            const animes: any[] = [];

            // Looping semua list anime di dalam grup abjad tersebut
            $(el).find('ul li a').each((_, aEl) => {
                const title = $(aEl).text().trim();
                const url = $(aEl).attr('href') || '';
                const id = $(aEl).attr('rel') || ''; // ID internal dari webnya
                const path = this.extractPath(url);

                if (title && url) {
                    animes.push({
                        id: id,
                        title: title,
                        path: path,
                    });
                }
            });

            // Hanya masukkan ke result jika grup tersebut ada isinya
            if (animes.length > 0) {
                result.push({
                    group: groupName,
                    total_items: animes.length,
                    animes: animes
                });
            }
        });

        return result;
    }

    /**
     * Parser khusus untuk halaman Detail Anime
     */
    public static mapDetail(html: string) {
        const $ = cheerio.load(html);

        // 1. Ambil Judul & Gambar
        const title = $('.infox h1.entry-title').text().trim();
        const imgEl = $('.thumb img');
        const cover_url = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

        // 2. Ambil Rating & Follower/Viewer
        // Teks asli biasanya "Rating 7.5", kita bersihkan jadi angka
        const ratingText = $('.rating strong').text().replace('Rating', '').trim();
        const rating = parseFloat(ratingText || '0');
        const viewText = $('.bmc').text().replace(/\D/g, '').trim(); // Mengambil angkanya saja, misal "Diikuti 5 orang" jadi "5"
        const view = parseInt(viewText || '0', 10);

        // 3. Ambil Genre
        const genres: string[] = [];
        $('.genxed a').each((_, el) => {
            genres.push($(el).text().trim());
        });

        // 4. Ambil Deskripsi & Sinopsis
        const description = $('.desc').text().trim();
        const synopsis = $('.entry-content[itemprop="description"] p').text().trim();

        // 5. Ekstrak Detail Info (.spe span)
        const info: Record<string, string> = {};
        $('.spe span').each((_, el) => {
            const rawText = $(el).text().trim(); // Contoh: "Status: Completed"
            // Pisahkan berdasarkan titik dua (:) pertama
            const parts = rawText.split(':');
            if (parts.length >= 2) {
                const key = parts[0].trim().toLowerCase().replace(/\s/g, '_');
                const val = parts.slice(1).join(':').trim();
                info[key] = val;
            }
        });

        // 6. Ambil List Episode
        const episodes: any[] = [];
        $('.eplister ul li').each((_, el) => {
            const epNum = $(el).find('.epl-num').text().trim();
            const epTitle = $(el).find('.epl-title').text().trim();
            const epDate = $(el).find('.epl-date').text().trim();
            const epUrl = $(el).find('a').attr('href') || '';
            const epPath = this.extractPath(epUrl);

            episodes.push({
                episode_number: epNum,
                title: epTitle,
                release_date: epDate,
                episode_id: epPath,
            });
        });

        // 7. Ambil Rekomendasi Anime
        const recommendations: any[] = [];
        $('.bixbox:contains("Rekomendasi Series") .bs').each((_, el) => {
            const recTitle = $(el).find('.tt h2').text().trim();
            const recUrl = $(el).find('a.tip').attr('href') || '';
            const recPath = this.extractPath(recUrl);
            const recImgEl = $(el).find('img');
            const recCover = recImgEl.attr('data-lazy-src') || recImgEl.attr('src') || '';

            if (recTitle) {
                recommendations.push({
                    title: recTitle,
                    cover_url: recCover,
                    path: recPath,
                });
            }
        });

        // Struktur akhir DTO
        return {
            title,
            cover_url,
            rating,
            view,
            status: info['status'] || '',
            type: info['tipe'] || '',
            season: info['season'] || '',
            duration: info['durasi'] || '',
            studio: info['studio'] || '',
            release_date: info['dirilis'] || '',
            genres,
            synopsis,
            total_episodes: episodes.length,
            episode_list: episodes,
            recommendations
        };
    }

    /**
         * Parser khusus untuk halaman Play / Streaming (Mendapatkan Video URL & Download)
         * 🔥 UBAH JADI ASYNC BIAR BISA NUNGGU EXTRACTOR 🔥
         */
    // Pastikan pakai async
    public static async mapPlay(html: string) {
        console.log("\n📦 [Mapper] Memulai mapPlay...");
        const $ = cheerio.load(html);

        const title = $('.title-section h1.entry-title').text().trim();
        const episode = $('meta[itemprop="episodeNumber"]').attr('content') || '';
        console.log(`📝 [Mapper] Judul: ${title} | Eps: ${episode}`);

        const rawServers: any[] = [];
        $('select.mirror option').each((_, el) => {
            const serverName = $(el).text().trim();
            const base64Html = $(el).attr('value') || '';

            if (base64Html) {
                try {
                    const decodedHtml = Buffer.from(base64Html, 'base64').toString('utf8');
                    const srcMatch = decodedHtml.match(/src=["'](.*?)["']/);
                    let videoUrl = srcMatch ? srcMatch[1] : '';

                    if (videoUrl.startsWith('//')) videoUrl = 'https:' + videoUrl;

                    if (videoUrl) {
                        rawServers.push({ name: serverName, url: videoUrl });
                    }
                } catch (e) { }
            }
        });

        if (rawServers.length === 0) {
            let defaultIframe = $('#pembed iframe').attr('src') || '';
            if (defaultIframe) {
                if (defaultIframe.startsWith('//')) defaultIframe = 'https:' + defaultIframe;
                rawServers.push({ name: 'Default Server', url: defaultIframe });
            }
        }

        console.log(`🔍 [Mapper] Ditemukan ${rawServers.length} raw servers. Mulai proses Extract...`);

        // 🔥 PROSES EXTRACTION MAGIC
        const servers = await Promise.all(rawServers.map(async (server) => {
            const directUrl = await resolveAnimekompiServer(server.name, server.url);
            return {
                name: server.name,
                embed_url: server.url,
                url: directUrl || ''
            };
        }));

        console.log(`✅ [Mapper] Proses Extract Selesai!`);

        const downloads: any[] = [];
        $('.soraurlx a').each((_, el) => {
            const providerName = $(el).text().trim();
            const downloadUrl = $(el).attr('href') || '';
            if (providerName && downloadUrl) {
                downloads.push({ provider: providerName, url: downloadUrl });
            }
        });

        const prevLink = $('.naveps a[rel="prev"]').attr('href');
        const nextLink = $('.naveps a[rel="next"]').attr('href');

        const navigation = {
            prev_path: prevLink ? prevLink.split('/').filter(Boolean).pop() : null,
            next_path: nextLink ? nextLink.split('/').filter(Boolean).pop() : null,
        };

        const result = { title, episode, servers, downloads, navigation };
        console.log(`🚀 [Mapper] Siap me-return data ke endpoint!\n`);
        return result;
    }

    /**
     * Parser khusus untuk halaman Daftar Genre
     */
    public static mapGenres(html: string) {
        const $ = cheerio.load(html);
        const genres: any[] = [];

        // Looping setiap item genre di dalam .taxindex
        $('.taxindex li a').each((_, el) => {
            const url = $(el).attr('href') || '';
            const name = $(el).find('.name').text().trim();
            const countText = $(el).find('.count').text().trim();

            // Konversi count jadi angka
            const count = parseInt(countText || '0', 10);

            // Ambil path-nya (misal "action" dari "https://v9.animekompi.sbs/genres/action/")
            const genre_id = this.extractPath(url);

            if (name && url) {
                genres.push({
                    name,
                    genre_id,
                    count,
                });
            }
        });

        // Bebas, bisa lu return langsung array-nya atau dibungkus object
        return {
            total_genres: genres.length,
            genres_list: genres
        };
    }

    /**
     * Parser khusus untuk halaman Daftar Anime berdasarkan Genre
     */
    public static mapGenreDetail(html: string) {
        const $ = cheerio.load(html);
        const animes: any[] = [];

        // 1. Ambil Judul Genre dari Header
        const genreName = $('h1 span').text().trim();

        // 2. Looping daftar anime
        $('.listupd article.bs').each((_, el) => {
            // Karena ini list grid biasa, selectornya mirip dengan Latest Updates
            const title = $(el).find('.tt h2').text().trim() || $(el).find('.tt').text().trim();
            const url = $(el).find('a.tip').attr('href') || $(el).find('a').attr('href') || '';
            const imgEl = $(el).find('img');
            const coverUrl = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

            // Info tambahan di pojok thumbnail (misal: "TV", "Completed", "Sub")
            const type = $(el).find('.limit .typez').text().trim();
            const statusOrEp = $(el).find('.limit .epx').text().trim();
            const subType = $(el).find('.limit .sb').text().trim();

            const ids = this.parseIdsFromUrl(url);

            if (title && url) {
                animes.push({
                    title: title,
                    cover_url: coverUrl,
                    path: ids.path || this.extractPath(url),
                    url: url,
                    type: type,
                    status_or_episode: statusOrEp,
                    sub_type: subType
                });
            }
        });

        // 3. Ambil Info Pagination
        let currentPage = 1;
        let hasNextPage = false;

        const currentPageEl = $('.pagination .current');
        if (currentPageEl.length) {
            currentPage = parseInt(currentPageEl.text().trim(), 10);
        }

        // Kalau tombol "Next" ada, berarti halamannya belum mentok
        if ($('.pagination .next').length > 0) {
            hasNextPage = true;
        }

        return {
            genre_name: genreName,
            current_page: currentPage,
            has_next_page: hasNextPage,
            total_items: animes.length,
            animes: animes
        };
    }

    /**
     * Parser khusus untuk halaman Jadwal Rilis Mingguan
     */
    public static mapSchedule(html: string) {
        const $ = cheerio.load(html);
        const schedule: any[] = [];

        // Looping setiap blok hari (.sch_monday, .sch_tuesday, dll)
        $('.schedulepage').each((_, dayEl) => {
            const dayName = $(dayEl).find('.releases h3 span').text().trim();
            const animes: any[] = [];

            // Looping list anime di dalam hari tersebut
            $(dayEl).find('.listupd .bs').each((_, animeEl) => {
                const title = $(animeEl).find('.tt').text().trim();
                const url = $(animeEl).find('a').attr('href') || '';
                const imgEl = $(animeEl).find('img');
                const coverUrl = imgEl.attr('data-lazy-src') || imgEl.attr('src') || '';

                // Ambil info status rilis & nomor episode
                const statusText = $(animeEl).find('.bt .epx').text().trim(); // cth: "sudah rilis" atau "Jam 01:16"
                const episodeNum = $(animeEl).find('.bt .sb').text().trim();  // cth: "07" atau "1162"

                // Ekstrak timestamp rilis (jika ada) biar frontend bisa hitung mundur
                const releaseTimestamp = $(animeEl).find('.bt .cndwn').attr('data-rlsdt') || null;

                const ids = this.parseIdsFromUrl(url);

                if (title && url) {
                    animes.push({
                        title: title,
                        cover_url: coverUrl,
                        path: ids.path || this.extractPath(url),
                        url: url,
                        status: statusText,
                        episode: episodeNum,
                        release_timestamp: releaseTimestamp ? parseInt(releaseTimestamp, 10) : null
                    });
                }
            });

            // Masukkan ke array jika hari tersebut punya list anime
            if (dayName && animes.length > 0) {
                schedule.push({
                    day: dayName,
                    total_items: animes.length,
                    animes: animes
                });
            }
        });

        return schedule;
    }
}