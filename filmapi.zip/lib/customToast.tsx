import toast from 'react-hot-toast';
import { Smile, Meh, Frown, CheckCircle2, MinusCircle, XCircle } from 'lucide-react';

export const notify = {
    // 🟢 SUCCESS
    success: (title: string, message: string) => {
        toast.custom((t) => (
            <div className={`max-w-sm w-full bg-[#ecfcf1] dark:bg-[#06170d] border border-green-200 dark:border-green-900/50 shadow-xl rounded-2xl p-4 flex items-center gap-3.5 pointer-events-auto transition-all duration-300 ${t.visible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 -translate-y-4 scale-95'}`}>
                <div className="shrink-0">
                    <Smile size={44} className="fill-green-500 text-[#ecfcf1] dark:text-[#06170d]" strokeWidth={1.5} />
                </div>
                <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] font-bold text-green-950 dark:text-green-50">{title}</h4>
                    <div className="flex items-start gap-1.5 mt-0.5 text-[13px] font-semibold text-green-600 dark:text-green-500 leading-snug">
                        <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
                        <span className="break-words">{message}</span>
                    </div>
                </div>
            </div>
        ), { duration: 4000 });
    },

    // 🔵 INFO / NEUTRAL
    info: (title: string, message: string) => {
        toast.custom((t) => (
            <div className={`max-w-sm w-full bg-[#eff4ff] dark:bg-[#0a1120] border border-blue-200 dark:border-blue-900/50 shadow-xl rounded-2xl p-4 flex items-center gap-3.5 pointer-events-auto transition-all duration-300 ${t.visible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 -translate-y-4 scale-95'}`}>
                <div className="shrink-0">
                    <Meh size={44} className="fill-blue-500 text-[#eff4ff] dark:text-[#0a1120]" strokeWidth={1.5} />
                </div>
                <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] font-bold text-blue-950 dark:text-blue-50">{title}</h4>
                    <div className="flex items-start gap-1.5 mt-0.5 text-[13px] font-semibold text-blue-600 dark:text-blue-500 leading-snug">
                        <MinusCircle size={15} className="shrink-0 mt-0.5" />
                        <span className="break-words">{message}</span>
                    </div>
                </div>
            </div>
        ), { duration: 4000 });
    },

    // 🔴 ERROR
    error: (title: string, message: string) => {
        toast.custom((t) => (
            <div className={`max-w-sm w-full bg-[#fff0f0] dark:bg-[#1f0b0b] border border-red-200 dark:border-red-900/50 shadow-xl rounded-2xl p-4 flex items-center gap-3.5 pointer-events-auto transition-all duration-300 ${t.visible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 -translate-y-4 scale-95'}`}>
                <div className="shrink-0">
                    <Frown size={44} className="fill-red-500 text-[#fff0f0] dark:text-[#1f0b0b]" strokeWidth={1.5} />
                </div>
                <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] font-bold text-red-950 dark:text-red-50">{title}</h4>
                    <div className="flex items-start gap-1.5 mt-0.5 text-[13px] font-semibold text-red-600 dark:text-red-500 leading-snug">
                        <XCircle size={15} className="shrink-0 mt-0.5" />
                        <span className="break-words">{message}</span>
                    </div>
                </div>
            </div>
        ), { duration: 4000 });
    }
};