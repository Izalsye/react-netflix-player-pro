// lib/vidio/xApiKeyGenerator.ts
import crypto from 'crypto';

export class XApiKeyGenerator {
    private static cachedApiKey: string = '';
    private static apiKeyExpiry: number = 0;

    // 🚀 BONGKAR RAHASIA VIDIO: Hardcoded AES Key & IV dari Frontend mereka!
    private static AES_KEY = "dPr0QImQ7bc5o9LMntNba2DOsSbZcjUh";
    private static AES_IV = "C8RWsrtFsoeyCyPt";

    /**
     * Enkripsi raw JWT Token jadi X-API-Key Base64 (Format CH1ZFs...)
     */
    private static encryptToken(rawToken: string): string {
        const cipher = crypto.createCipheriv(
            'aes-256-cbc', 
            Buffer.from(this.AES_KEY), 
            Buffer.from(this.AES_IV)
        );
        let encrypted = cipher.update(rawToken, 'utf8', 'base64');
        encrypted += cipher.final('base64');
        return encrypted;
    }

    /**
     * Mengambil X-API-Key dinamis dari endpoint /auth Vidio lalu dienkripsi
     */
    public static async get(cookieString: string): Promise<string> {
        // Kasih jarak aman 5 menit (300.000 ms) sebelum benar-benar expired
        if (this.cachedApiKey && Date.now() < this.apiKeyExpiry - 300000) {
            return this.cachedApiKey;
        }

        try {
            const response = await fetch('https://www.vidio.com/auth', {
                method: 'POST',
                headers: {
                    'Accept': '*/*',
                    'Cookie': cookieString,
                    'Origin': 'https://www.vidio.com',
                    'Referer': 'https://www.vidio.com/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
                    'Content-Length': '0'
                },
                cache: 'no-store' // Wajib biar dapet token fresh
            });

            if (!response.ok) {
                console.error("[XApiKeyGenerator] Gagal fetch token. Status:", response.status);
                return process.env.VIDIO_API_KEY || '';
            }

            const data = await response.json();
            
            if (data.api_key && data.api_key_expires_at) {
                // 🚀 ENKRIPSI TOKEN MENTAHNYA DI SINI!
                this.cachedApiKey = this.encryptToken(data.api_key);
                this.apiKeyExpiry = new Date(data.api_key_expires_at).getTime();
                
                console.log(`[XApiKeyGenerator] BINGO! Berhasil cetak kunci baru: ${this.cachedApiKey}`);
                return this.cachedApiKey;
            }
        } catch (error) {
            console.error("[XApiKeyGenerator] Error memproses token:", error);
        }

        // Jaring pengaman terakhir kalau auth gagal
        return process.env.VIDIO_API_KEY || ''; 
    }
}