// lib/vidio/mapping.ts
import {
    HomeResponse,
    Section,
    ItemVideo,
    DetailResponse,
    Tag,
    Subtitle,
    Season,
    EpisodeItem,
    PlayResponse,
    Resolution
} from '@/types/vidio';
import * as cheerio from 'cheerio';

export function mapHomeResponse(rawData: any): HomeResponse {
    if (!rawData || !rawData.data || !Array.isArray(rawData.data)) {
        return { success: false, sections: [] };
    }

    // Buat map cepat untuk pencarian data included
    const includedMap = new Map<string, any>();
    if (Array.isArray(rawData.included)) {
        rawData.included.forEach((item: any) => {
            includedMap.set(item.id, item);
        });
    }

    const sections: Section[] = rawData.data.map((sec: any) => {
        const attrs = sec.attributes || {};
        const contentRefs = sec.relationships?.contents?.data || [];

        const items: ItemVideo[] = contentRefs.map((ref: any) => {
            const detail = includedMap.get(ref.id);
            if (!detail) return null;

            const itemAttrs = detail.attributes || {};
            let title = itemAttrs.title || itemAttrs.name || '';
            const webUrl = itemAttrs.web_url || '';

            // 🧹 1. FILTER SAMPAH & BANNER IKLAN (Kaya promo Aqua)
            if (title.startsWith('api/') || title.includes('?')) return null;
            if (detail.type === 'breakingbanner' || itemAttrs.content_type === 'breakingbanner') return null;

            // Cek ketersediaan gambar
            if (!itemAttrs.cover_url && !itemAttrs.cover_url_16x9 && !itemAttrs.cover_url_2x1 && !itemAttrs.mobile_image && !itemAttrs.desktop_image) return null;

            // 🎯 2. EKSTRAKSI ID ASLI & TYPE ASLI
            let realId = itemAttrs.content_id || itemAttrs.id;
            let realType = itemAttrs.content_type || detail.type;

            // 🚀 BONGKAR HEADLINE (BANNER)
            if (detail.type === 'headline' || realType === 'headline') {
                if (itemAttrs.target_type && itemAttrs.target_id) {
                    realType = itemAttrs.target_type.toLowerCase();
                    realId = itemAttrs.target_id;
                }
            }

            // 🚀 SEDOT ID DARI URL (SUPER CERDAS - PALING AKURAT)
            const urlToParse = itemAttrs.action_url || itemAttrs.web_url || webUrl || '';
            if (!realId || realType === 'headline' || realType === 'content') {
                const liveMatch = urlToParse.match(/\/live\/(\d+)/);
                const watchMatch = urlToParse.match(/\/watch\/(\d+)/);
                const premierMatch = urlToParse.match(/\/premier\/(\d+)/);

                if (liveMatch) {
                    realId = liveMatch[1];
                    realType = 'livestreaming';
                } else if (watchMatch) {
                    realId = watchMatch[1];
                    if (!realType || realType === 'headline') realType = 'video';
                } else if (premierMatch) {
                    realId = premierMatch[1];
                    if (!realType || realType === 'headline') realType = 'content_profile';
                }
            }

            // 🚀 FALLBACK HARDCORE: BEDAH ID PEMBUNGKUS 
            if (!realId || !realType || realType === 'headline' || realType === 'content') {
                // Skenario 1: ID tipe section (contoh: "section-34414-content_profile-2467")
                const parts = detail.id.split('-');
                if (parts.length >= 4) {
                    if (!realId) realId = parts[parts.length - 1];
                    if (!realType || realType === 'headline' || realType === 'content') realType = parts[parts.length - 2];
                } else {
                    // Skenario 2: ID tipe search (contoh: "portrait_grid_content_profile_12008")
                    const parts2 = detail.id.split('_');
                    if (parts2.length >= 3 && (!realId || realType === 'content')) {
                        if (!realId) realId = parts2[parts2.length - 1];
                        if (!realType || realType === 'content') realType = `${parts2[parts2.length - 3]}_${parts2[parts2.length - 2]}`;
                    }
                }
            }

            // 🚀 THE FIX: Normalisasi tipe-tipe aneh bawaan Vidio (film, series, dll)
            const typeToContentProfile = ['content', 'headline', 'film', 'series', 'catchup'];
            if (!realType || typeToContentProfile.includes(realType)) {
                realType = 'content_profile';
            } else if (realType === 'episode') {
                realType = 'video';
            }

            return {
                id: String(realId),
                type: realType,
                title: title,
                altTitle: itemAttrs.alt_title || null,
                coverUrl: itemAttrs.mobile_image || itemAttrs.desktop_image || itemAttrs.cover_url || itemAttrs.cover_url_16x9 || itemAttrs.cover_url_2x1 || '',
                streamUrl: itemAttrs.stream_url || null,
                duration: itemAttrs.duration || null,
                startTime: itemAttrs.start_time || null,
                endTime: itemAttrs.end_time || null,
                contentRating: itemAttrs.content_rating || null,
            } as ItemVideo;
        }).filter(Boolean); // Buang yang null

        // 🧹 BERSIHIN JUDUL SECTION DARI "%title_parameter%"
        let sectionTitle = attrs.title || '';
        sectionTitle = sectionTitle.replace(/%title_parameter%/g, 'Spesial').trim();
        // Kalau judulnya jadi cuma teks "Spesial ‎" karena bug spasi, kita percantik:
        if (sectionTitle === 'Spesial ‎' || sectionTitle === 'Spesial') sectionTitle = 'Spesial Untuk Kamu';

        return {
            id: sec.id,
            title: sectionTitle,
            variation: attrs.variation || 'portrait_horizontal',
            items: items
        };
    });

    // Buang section yang items-nya kosong melompong (gara-gara filter di atas)
    const cleanSections = sections.filter(sec => sec.items.length > 0);

    return {
        success: true,
        sections: cleanSections
    };
}

export function mapDetailResponse(rawData: any): any {
    // -------------------------------------------------------------
    // SKENARIO 1: Response dari endpoint `/content_profiles/[ID]`
    // -------------------------------------------------------------
    if (rawData.data && rawData.data.type === 'content_profile') {
        const data = rawData.data;
        const attrs = data.attributes || {};

        const includedMap = new Map<string, any>();
        if (Array.isArray(rawData.included)) {
            rawData.included.forEach((item: any) => {
                includedMap.set(`${item.type}-${item.id}`, item);
            });
        }

        // Mapping Tag (Aktor, Genre, Sutradara)
        const getTags = (relationName: string): any[] => {
            const rels = data.relationships?.[relationName]?.data || [];
            return rels.map((ref: any) => {
                const tagDetail = includedMap.get(`tag-${ref.id}`);
                return tagDetail ? { id: tagDetail.id, name: tagDetail.attributes?.name || '' } : null;
            }).filter(Boolean);
        };

        // 🌟 PROSES SEASONS AWAL (Mengambil struktur container season dari included)
        const playlistRefs = data.relationships?.playlists?.data || [];
        const seasons: any[] = playlistRefs.map((ref: any) => {
            const playlistDetail = includedMap.get(`playlist-${ref.id}`);
            if (!playlistDetail) return null;

            return {
                id: playlistDetail.id,
                name: playlistDetail.attributes?.name || 'Season',
                totalEpisodes: playlistDetail.attributes?.total_episode || 0,
                episodes: [] // Masih kosong, nanti diroute diisi lewat sub-fetch
            };
        }).filter(Boolean);

        // 🚀 TAMBAHAN LOGIKA MOVIE: Buat Virtual Season khusus Film Lepas
        if (attrs.type === 'Movie' && attrs.play_content_id) {
            seasons.unshift({
                id: 'movie_main',
                name: 'Full Movie',
                totalEpisodes: 1,
                episodes: [
                    {
                        id: String(attrs.play_content_id), // 🔥 Ambil ID Rahasia dari attributes
                        type: 'video',
                        title: attrs.title || '',
                        description: attrs.description || '',
                        duration: attrs.total_duration || 0,
                        coverUrl: attrs.clean_landscape_image_url || attrs.image_landscape_url || '',
                        freeToWatch: attrs.is_premier === false,
                        isPremier: attrs.is_premier || false,
                        isDrm: true, // Berjaga-jaga set true agar DRM termuat
                        publishDate: attrs.release_date || ''
                    }
                ]
            });
        }

        return {
            success: true,
            id: data.id,
            type: 'content_profile',
            title: attrs.title || '',
            description: attrs.description || '',
            coverPortrait: attrs.image_portrait_url || attrs.thumbnail || '',
            coverLandscape: attrs.clean_landscape_image_url || attrs.image_landscape_url || '',
            contentRating: attrs.age_rating || '',
            releaseDate: attrs.release_date || '',
            country: attrs.country_name || '',
            totalEpisodes: attrs.total_episode || 0,
            genres: getTags('genres'),
            actors: getTags('actors'),
            directors: getTags('directors'),
            trailerId: attrs.trailer_video_id ? String(attrs.trailer_video_id) : undefined,
            trailerUrl: attrs.trailer_url || undefined,
            seasons: seasons // Mengembalikan daftar wadah season
        };
    }

    // -------------------------------------------------------------
    // SKENARIO 2: Response dari endpoint `/videos/[ID]/detail`
    // -------------------------------------------------------------
    if (rawData.video) {
        const vid = rawData.video;
        const subs: any[] = (vid.subtitles || []).map((sub: any) => ({
            language: sub.language,
            url: sub.file_url
        }));

        return {
            success: true,
            id: String(vid.id),
            type: 'video',
            title: vid.title || '',
            description: vid.description || '',
            coverPortrait: vid.cover?.image_portrait_url || '',
            coverLandscape: vid.cover?.image_landscape_url || vid.image_url_medium || '',
            contentRating: vid.content_rating || '',
            streamUrl: vid.hls_url || vid.dash_url || null,
            subtitles: subs,
            duration: vid.duration || 0,
            isPremium: vid.is_premium || false,
        };
    }

    // -------------------------------------------------------------
    // SKENARIO 3: LIVESTREAMING
    // -------------------------------------------------------------
    if (rawData.livestreamings && rawData.livestreamings.length > 0) {
        const live = rawData.livestreamings[0];

        return {
            success: true,
            id: live.id.toString(),
            type: "livestreaming",
            title: live.title,
            description: live.description || live.short_description || "",
            coverPortrait: live.image || live.square_image || "",
            coverLandscape: live.cover || live.image || "",
            contentRating: "Semua Umur",
            releaseDate: live.start_time ? live.start_time.split('T')[0] : "",
            country: "Indonesia",
            totalEpisodes: 1,
            genres: [{ id: "live", name: "Live TV" }],
            actors: [],
            directors: [],
            // 👇 THE MAGIC: Bikin Dummy Season & Episode biar frontend aman
            seasons: [
                {
                    id: "live-season",
                    name: "Live Stream",
                    totalEpisodes: 1,
                    episodes: [
                        {
                            id: live.id.toString(), // PENTING: ID-nya harus ID Livestream (205) biar bisa di-play
                            type: "livestreaming",
                            title: `Watch ${live.title} Live`,
                            description: live.description || "",
                            duration: 0, // Live tidak punya durasi pasti
                            coverUrl: live.image || live.square_image || "",
                            freeToWatch: live.access_type === "free",
                            isPremier: live.is_premium || false,
                            isDrm: live.is_drm || false,
                            publishDate: live.start_time
                        }
                    ]
                }
            ]
        };
    }

    return { success: false, id: '', type: 'unknown', title: 'Not Found', description: 'Format tidak dikenal' };
}

// 🎯 FUNGSI BARU: Untuk mapping data array episode mentah dari sub-request playlist Vidio
export function mapEpisodesList(playlistRawData: any): any[] {
    if (!playlistRawData || !playlistRawData.data || !Array.isArray(playlistRawData.data)) {
        return [];
    }

    return playlistRawData.data.map((ep: any) => {
        const attrs = ep.attributes || {};
        return {
            id: String(ep.id),
            type: ep.type || 'video',
            title: attrs.title || '',
            description: attrs.description || '',
            duration: attrs.duration || 0,
            coverUrl: attrs.cover_url || attrs.image_url_medium || '',
            freeToWatch: attrs.free_to_watch || false,
            isPremier: attrs.is_premier || false,
            isDrm: attrs.is_drm || false,
            publishDate: attrs.publish_date || ''
        };
    });
}

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || '';

export function mapPlayResponse(rawData: any): PlayResponse {
    // Helper untuk bikin URL Proxy
    const makeProxy = (url: string | null) => {
        if (!url) return null;
        const proxyPath = `/api/vidio/stream-proxy?url=${encodeURIComponent(url)}`;
        return SITE_URL ? `${SITE_URL}${proxyPath}` : proxyPath;
    };

    // -------------------------------------------------------------
    // SKENARIO 1: Tipe VIDEO VOD
    // -------------------------------------------------------------
    if (rawData.video) {
        const vid = rawData.video;

        const subs = (vid.subtitles || []).map((sub: any) => ({
            language: sub.language,
            url: sub.file_url || null, // 🎯 URL Asli
            url_proxy: makeProxy(sub.file_url) // 🎯 URL Proxy
        }));

        const resos = (vid.resolution_mapping || []).map((r: any) => ({
            name: r.name,
            min: r.min,
            max: r.max
        }));

        return {
            success: true,
            streamUrl: vid.hls_url || null, // 🎯 Ori
            streamUrl_Proxy: makeProxy(vid.hls_url || null), // 🎯 Proxy
            dashUrl: vid.dash_url || null, // 🎯 Ori
            dashUrl_Proxy: makeProxy(vid.dash_url || null), // 🎯 Proxy
            subtitles: subs,
            resolutions: resos,
            isDrm: vid.is_drm || false,
            licenseServers: null,
            customData: null
        };
    }

    // -------------------------------------------------------------
    // SKENARIO 2: Tipe LIVESTREAMING
    // -------------------------------------------------------------
    if (rawData.data && (rawData.data.type === 'livestreamings' || rawData.data.type === 'livestreaming')) {
        const attr = rawData.data.attributes || {};

        const streamUrl = attr.hls || attr.stream_url || null;
        const dashUrl = attr.dash || null;

        const resos = (attr.resolution_mapping || []).map((r: any) => ({
            name: r.name,
            min: r.min,
            max: r.max
        }));

        return {
            success: true,
            streamUrl: streamUrl, // 🎯 Ori
            streamUrl_Proxy: makeProxy(streamUrl), // 🎯 Proxy
            dashUrl: dashUrl, // 🎯 Ori
            dashUrl_Proxy: makeProxy(dashUrl), // 🎯 Proxy
            subtitles: [], // Livestream biasanya gak pake subtitle
            resolutions: resos,
            isDrm: attr.is_drm || false,
            licenseServers: attr.license_servers || null,
            customData: attr.custom_data || null
        };
    }

    return {
        success: false,
        message: "Data stream tidak ditemukan",
        subtitles: [],
        resolutions: []
    };
}

export function mapChannelsResponse(html: string) {
    if (typeof html !== 'string') {
        return { success: false, message: "Gagal membaca HTML", data: [] };
    }

    const $ = cheerio.load(html);
    const categories: any[] = [];
    let totalChannels = 0;
    let categoryIdCounter = 1;

    // 1. Looping setiap block Kategori (Section)
    $('section.grid-module__2FUHIW__container').each((_, sectionEl) => {
        const section = $(sectionEl);

        // 2. Ambil Nama Kategori (Lokal, Sports, dll)
        // Kita pakai regex buat ngebersihin karakter aneh (kayak \u200e yang kadang nyelip di HTML Vidio)
        const rawCategoryName = section.find('h2').text().trim();
        // Nangkep U+200B sampai U+200F sekalian biar bersih total
        const categoryName = rawCategoryName.replace(/[\u200B-\u200F\uFEFF]/g, '');

        if (!categoryName) return; // Lewatin kalau nggak ada judul

        const channels: any[] = [];

        // 3. Looping channel di dalam kategori ini SAJA
        section.find('a[data-testid="circle-card"]').each((_, element) => {
            const el = $(element);

            const href = el.attr('href') || '';
            const idMatch = href.match(/\/live\/(\d+)/);
            const id = idMatch ? idMatch[1] : null;

            const title = el.find('[data-testid="circle-title"]').text().trim();
            const image = el.find('img').attr('src') || '';

            if (id && title) {
                channels.push({
                    id,
                    title,
                    image,
                    type: 'livestreaming',
                    endpoint: `/api/vidio/play?id=${id}&type=livestreaming`
                });
            }
        });

        // 4. Masukkan ke array kategori kalau ada isinya
        if (channels.length > 0) {
            categories.push({
                id: categoryIdCounter++,
                name: categoryName,
                data: channels
            });
            totalChannels += channels.length;
        }
    });

    return {
        success: true,
        total: totalChannels,
        data: categories
    };
}

export function mapSearchResponse(rawData: any): HomeResponse {
    if (!rawData || !rawData.data || !Array.isArray(rawData.data)) {
        return { success: false, sections: [] };
    }

    // Buat map cepat untuk pencarian data included
    const includedMap = new Map<string, any>();
    if (Array.isArray(rawData.included)) {
        rawData.included.forEach((item: any) => {
            includedMap.set(item.id, item);
        });
    }

    const sections: Section[] = rawData.data.map((sec: any) => {
        const attrs = sec.attributes || {};
        const contentRefs = sec.relationships?.contents?.data || [];

        const items: ItemVideo[] = contentRefs.map((ref: any) => {
            const detail = includedMap.get(ref.id);
            if (!detail) return null;

            const itemAttrs = detail.attributes || {};
            const title = itemAttrs.title || itemAttrs.name || '';
            const webUrl = itemAttrs.web_url || '';

            // 🎯 EKSTRAKSI ID ASLI & TYPE ASLI 
            let realId = itemAttrs.content_id || itemAttrs.id;
            let realType = itemAttrs.content_type || detail.type;

            // Fallback: bedah ID pembungkus (Contoh: "portrait_grid_content_profile_12008")
            if (!realId || !realType || realType === 'content') {
                const parts = detail.id.split('_');
                if (parts.length >= 3) {
                    if (!realId) realId = parts[parts.length - 1];
                    if (!realType || realType === 'content') {
                        // Biasanya 2 array terakhir sebelum ID itu tipenya, misal: "content_profile"
                        realType = `${parts[parts.length - 3]}_${parts[parts.length - 2]}`;
                    }
                }
            }

            // Normalisasi tipe-tipe aneh
            const typeToContentProfile = ['content', 'headline', 'film', 'series', 'catchup', 'content_profile'];
            if (!realType || typeToContentProfile.includes(realType)) {
                realType = 'content_profile';
            } else if (realType === 'episode') {
                realType = 'video';
            }

            return {
                id: String(realId),
                type: realType,
                title: title,
                altTitle: itemAttrs.alt_title || null,
                coverUrl: itemAttrs.cover_url || itemAttrs.cover_url_16x9 || itemAttrs.cover_url_2x1 || '',
                streamUrl: itemAttrs.stream_url || null,
                duration: itemAttrs.duration || null,
                startTime: itemAttrs.start_time || null,
                endTime: itemAttrs.end_time || null,
                contentRating: itemAttrs.content_rating || null,
            } as ItemVideo;
        }).filter(Boolean); // Buang yang null

        return {
            id: sec.id,
            title: attrs.title || '',
            variation: attrs.variation || 'portrait_grid',
            items: items
        };
    });

    // Buang section yang items-nya kosong
    const cleanSections = sections.filter(sec => sec.items.length > 0);

    return {
        success: true,
        sections: cleanSections
    };
}