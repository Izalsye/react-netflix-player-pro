import { recordHit } from '../stats';
import { validateApiKey } from '../apiKeyService';
import https from "node:https";
import { URL } from "node:url";
import zlib from "node:zlib";
import { NextResponse } from 'next/server';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { XApiKeyGenerator } from './xApiKeyGenerator';

const VIDIO_BASE = process.env.VIDIO_BASE || 'https://api.vidio.com';
const USE_PROXY = process.env.USE_LOCAL_PROXY === 'true';
const PROXY_URL = process.env.PROXY_URL || '';

// Default cookie & token diambil dari sampel request kamu
const DEFAULT_VIDIO_COOKIE = process.env.VIDIO_COOKIES || 'ahoy_visitor=2c7e47ee-fded-4d95-9c3d-2b40e08340cc; ahoy_visit=439cadb5-00cf-482e-b5f6-7668f0012d2f; country_id=ID; _gcl_au=1.1.560390710.1781884677; _ga=GA1.2.485356854.1781884677; _gid=GA1.2.1467128538.1781884677; _vidio_session=pEVAgA3QUvmx9iVz39h6PhuQvuS%2FMf3APw%2BqjFyMs5mfnLpLZBI5uX60pMC%2BJ7bwDOGrmjsoB0UgZRB7bl4U2eEih2Z8nZNNmKTYLATKjo2pTaGAb%2BwNebEwnJHk%2BuLvnP0vaqWM05XdJJEjsbi0awv6hGds%2F2fX%2FH9r4AH%2BmZrU1n4crl1biZEjvP9AoniwpsPHVk2IncL4JRhvBxSQtwvIogKfOqkF0C8%3D--6ExZvSM0RKTbhPZH--yaHHy5%2F7%2BzzZzX8LGCEilA%3D%3D';

const cache = new Map<string, { val: any, exp: number }>();

// 🚀 FIX: Tambahin parameter dynamicApiKey
function buildVidioHeaders(req: Request, targetHost: string = "api.vidio.com", dynamicApiKey: string): Record<string, string> {
    const incomingHeaders = Object.fromEntries(req.headers.entries());
    const clientCookie = req.headers.get('cookie') || DEFAULT_VIDIO_COOKIE;
    let safeAcceptEncoding = incomingHeaders["accept-encoding"] || "gzip, deflate, br";
    safeAcceptEncoding = safeAcceptEncoding.replace(/,?\s*zstd/gi, '').trim();
    if (safeAcceptEncoding.startsWith(',')) safeAcceptEncoding = safeAcceptEncoding.substring(1).trim();

    return {
        "Accept": incomingHeaders["accept"] || "application/json",
        "Accept-Encoding": safeAcceptEncoding,
        "Accept-Language": incomingHeaders["accept-language"] || "en",
        "Connection": "keep-alive",
        "Content-Type": incomingHeaders["content-type"] || "application/vnd.api+json",
        "Cookie": incomingHeaders["cookie"] || clientCookie,
        "Host": targetHost,
        "Origin": "https://www.vidio.com",
        "Referer": incomingHeaders["referer"] || "https://www.vidio.com/",
        "User-Agent": incomingHeaders["user-agent"] || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
        "sec-ch-ua": incomingHeaders["sec-ch-ua"] || '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
        "sec-ch-ua-mobile": incomingHeaders["sec-ch-ua-mobile"] || "?0",
        "sec-ch-ua-platform": incomingHeaders["sec-ch-ua-platform"] || '"Windows"',
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",

        // Vidio Specific Headers
        "X-API-App-Info": incomingHeaders["x-api-app-info"] || "js/www.vidio.com",
        "X-API-Platform": incomingHeaders["x-api-platform"] || "web-desktop",
        "X-Secure-Level": incomingHeaders["x-secure-level"] || "2",
        "X-VISITOR-ID": incomingHeaders["x-visitor-id"] || "2c7e47ee-fded-4d95-9c3d-2b40e08340cc",

        // 🚀 INI DIA MAGIC-NYA: Pakai API Key hasil sedotan otomatis!
        "X-Api-Key": incomingHeaders["x-vidio-api-key"] || dynamicApiKey,
    };
}

function decompressResponse(buffer: Buffer, encoding: string | undefined): string {
    try {
        if (encoding === 'br') return zlib.brotliDecompressSync(buffer).toString('utf8');
        if (encoding === 'gzip') return zlib.gunzipSync(buffer).toString('utf8');
        if (encoding === 'deflate') return zlib.inflateSync(buffer).toString('utf8');
        return buffer.toString('utf8');
    } catch (e) {
        return buffer.toString('utf8');
    }
}

async function Get(urlStr: string, headers: Record<string, string>, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY
        ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false })
        : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "GET",
                headers,
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);

                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );

        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.end();
    });
}

async function Post(urlStr: string, headers: Record<string, string>, body: string, contentType: string, timeoutMs = 15_000) {
    const u = new URL(urlStr);
    const agent = USE_PROXY ? new (HttpsProxyAgent as any)(PROXY_URL, { rejectUnauthorized: false }) : undefined;

    return new Promise<{ status: number; contentType: string; text: string }>((resolve, reject) => {
        const req = https.request(
            {
                protocol: u.protocol,
                hostname: u.hostname,
                path: u.pathname + u.search,
                method: "POST",
                headers: {
                    ...headers,
                    "Content-Type": contentType,
                    "Content-Length": Buffer.byteLength(body).toString(),
                },
                agent: agent as any,
                rejectUnauthorized: false,
                host: u.hostname,
                servername: u.hostname,
            },
            (res) => {
                const chunks: Buffer[] = [];
                res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
                res.on("end", () => {
                    const buffer = Buffer.concat(chunks);
                    const encoding = res.headers["content-encoding"];
                    const text = decompressResponse(buffer, encoding);
                    resolve({
                        status: res.statusCode || 0,
                        contentType: res.headers["content-type"] || "application/json",
                        text: text,
                    });
                });
            }
        );
        req.setTimeout(timeoutMs, () => req.destroy(new Error(`timeout ${timeoutMs}ms`)));
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

export async function proxyGet(
    req: Request,
    path: string,
    query: Record<string, string>,
    opts: { label: string; cacheTtlMs?: number; send?: boolean; headers?: Record<string, string> } = { label: 'vidio-get' }
) {
    const visitorId = `ip:${req.headers.get('x-forwarded-for') || 'unknown'}`;

    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
        if (v !== undefined && v !== null && v !== "") sp.set(k, v);
    }
    const qs = sp.toString();

    let upstreamUrl = path;
    let targetHost = "api.vidio.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
        upstreamUrl = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
    } else {
        const pathWithQuery = qs ? (path.includes('?') ? `${path}&${qs}` : `${path}?${qs}`) : path;
        upstreamUrl = `${VIDIO_BASE}${pathWithQuery}`;
        const u = new URL(VIDIO_BASE);
        targetHost = u.hostname;
    }

    const cacheKey = opts.cacheTtlMs ? `${visitorId}|${upstreamUrl}` : null;
    if (cacheKey) {
        const hit = cache.get(cacheKey);
        if (hit && hit.exp > Date.now()) {
            if (opts.send === false) return hit.val;
            return new Response(
                typeof hit.val === 'string' ? hit.val : JSON.stringify(hit.val),
                { headers: { 'Content-Type': typeof hit.val === 'string' ? 'text/html' : 'application/json', 'x-cache': 'HIT' } }
            );
        }
    }

    // 🚀 Ambil Kunci Dinamis
    const clientCookie = req.headers.get('cookie') || DEFAULT_VIDIO_COOKIE;
    const dynamicKey = await XApiKeyGenerator.get(clientCookie);

    const headers = {
        ...buildVidioHeaders(req, targetHost, dynamicKey), // 🚀 Masukin kuncinya ke sini
        ...opts.headers
    };

    const reqId = `${opts.label}-${Date.now()}-${Math.random().toString(16).slice(2)}`;

    try {
        const { status, contentType, text } = await Get(upstreamUrl, headers, 15_000);

        if (opts.send === false) {
            if (status !== 200) {
                // 🚀 BONGKAR ISI TEXT ERROR DARI VIDIO!
                console.error(`[ProxyGet Error] Upstream status is ${status}. Vidio says: ${text}`);
                return { error: true, status, message: "Upstream or Proxy failed" };
            }

            if (contentType.includes('text/html')) {
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: text, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return text;
            }

            try {
                const parsedJSON = JSON.parse(text);
                if (cacheKey && opts.cacheTtlMs) {
                    try { cache.set(cacheKey, { val: parsedJSON, exp: Date.now() + opts.cacheTtlMs }); } catch { }
                }
                return parsedJSON;
            } catch (parseError) {
                return text;
            }
        }

        return new Response(text, {
            status,
            headers: { 'Content-Type': contentType }
        });
    } catch (e: any) {
        console.error(`[VidioProxyGet:${reqId}] upstream failed`, { message: e?.message });
        const msg = /timeout/i.test(e?.message) ? "Upstream timeout" : "Bad Gateway";
        return new Response(JSON.stringify({ error: true, message: msg }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}

export async function proxyPost(
    req: Request,
    path: string,
    body: any,
    opts: { label: string; send?: boolean; headers?: Record<string, string> } = { label: 'vidio-post' }
) {
    let upstreamUrl = path;
    let targetHost = "api.vidio.com";

    if (path.startsWith('http://') || path.startsWith('https://')) {
        const u = new URL(path);
        targetHost = u.hostname;
    } else {
        upstreamUrl = `${VIDIO_BASE}${path}`;
        const u = new URL(VIDIO_BASE);
        targetHost = u.hostname;
    }

    // 🚀 Ambil Kunci Dinamis
    const clientCookie = req.headers.get('cookie') || DEFAULT_VIDIO_COOKIE;
    const dynamicKey = await XApiKeyGenerator.get(clientCookie);

    const headers = {
        ...buildVidioHeaders(req, targetHost, dynamicKey), // 🚀 Masukin kuncinya ke sini
        ...opts.headers
    };

    const stringBody = typeof body === 'string' ? body : JSON.stringify(body);
    const reqContentType = headers["Content-Type"] || headers["content-type"] || "application/vnd.api+json";

    try {
        const { status, contentType, text } = await Post(upstreamUrl, headers, stringBody, reqContentType, 15_000);
        if (opts.send === false) {
            try { return JSON.parse(text); } catch { return text; }
        }
        return new Response(text, { status, headers: { 'Content-Type': contentType } });
    } catch (e: any) {
        return new Response(JSON.stringify({ error: true, message: "Bad Gateway" }), { status: 502, headers: { 'Content-Type': 'application/json' } });
    }
}