import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; 
import crypto from 'crypto';

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { firstName, lastName, username, telegramId } = body;

        // Validasi dasar
        if (!firstName) {
            return NextResponse.json(
                { error: 'First name is required' },
                { status: 400 }
            );
        }

        // Cek apakah Telegram ID sudah terdaftar
        if (telegramId) {
            const existingUser = await prisma.user.findUnique({
                where: { telegramId }
            });
            if (existingUser) {
                return NextResponse.json(
                    { error: 'Telegram ID already registered' },
                    { status: 409 }
                );
            }
        }

        // 1. Generate Raw API Key
        const randomString = crypto.randomBytes(24).toString('hex');
        const rawKey = `indocast_${randomString}`;

        // 2. Hash API Key
        const hashedKey = crypto
            .createHash('sha256')
            .update(rawKey)
            .digest('hex');

        // 3. Simpan User dan ApiKey ke Database
        const newUser = await prisma.user.create({
            data: {
                firstName,
                lastName,
                username,
                telegramId,
                role: 'FREE', // Default gratis
                // planId dibiarkan kosong (null) karena user belum beli paket VIP
                apiKey: {
                    create: {
                        rawKey: rawKey, 
                        hashedKey: hashedKey,
                        label: 'Default Key',
                    },
                },
            },
            include: {
                apiKey: true,
            },
        });

        return NextResponse.json({
            success: true,
            message: 'User successfully registered!',
            data: {
                userId: newUser.id,
                firstName: newUser.firstName,
                role: newUser.role,
                apiKey: rawKey,
            }
        }, { status: 201 });

    } catch (error) {
        console.error('REGISTER ERROR:', error);
        return NextResponse.json(
            { error: 'Internal Server Error' },
            { status: 500 }
        );
    }
}