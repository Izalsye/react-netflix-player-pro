// file: app/api/bot/route.ts
import { webhookCallback } from 'grammy';
import { bot } from '@/lib/bot';

// Export method POST karena Telegram selalu mengirim data via POST method
export const POST = webhookCallback(bot, 'std/http');