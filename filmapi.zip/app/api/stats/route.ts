import { NextResponse } from 'next/server';
import { getStatsSummary } from '@/lib/stats';

export const dynamic = 'force-dynamic';

export async function GET() {
  const stats = await getStatsSummary();
  return NextResponse.json(stats);
}
