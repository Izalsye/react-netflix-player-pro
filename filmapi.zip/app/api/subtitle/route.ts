// file: app/api/subtitle/route.ts
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge'; // Pake edge biar enteng & kenceng

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;
    const url = searchParams.get('url');
    const provider = searchParams.get('provider');

    if (!url) {
        return new NextResponse("Missing URL", { status: 400 });
    }

    // Khusus Filmbox & Dramovnime
    const allowedProviders = ['filmbox', 'dramovnime'];
    if (!provider || !allowedProviders.includes(provider)) {
        return new NextResponse("Provider Not Allowed", { status: 403 });
    }

    // 1. Tentukan Origin & Referer Dinamis
    let origin = '';
    let referer = '';

    if (provider === 'filmbox') {
        origin = 'https://123movienow.cc';
        referer = 'https://123movienow.cc/';
    } else if (provider === 'dramovnime') {
        try {
            const parsedUrl = new URL(url);
            origin = parsedUrl.origin;
            referer = parsedUrl.origin + '/';
        } catch (e) {
            origin = 'https://bcdn2.hakunaymatata.com';
            referer = 'https://bcdn2.hakunaymatata.com/';
        }
    }

    try {
        // 2. Tembak Subtitle ke Server Asli
        const upstreamRes = await fetch(url, {
            headers: {
                'Origin': origin,
                'Referer': referer,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
            }
        });

        if (!upstreamRes.ok) {
            return new NextResponse("Failed to fetch subtitle", { status: upstreamRes.status });
        }

        let body = await upstreamRes.text();

        // 3. PROSES SUBTITLE (Translasi dari PHP lu)

        // a. Hapus BOM
        body = body.replace(/^\uFEFF/, '');

        // b. Hapus CSS Style bawaan VTT
        body = body.replace(/STYLE\s*[\s\S]*?::cue\([^)]*\)\s*\{[^}]*\}/g, '');

        // c. Konversi SRT ke VTT jika belum WEBVTT
        if (!body.trim().startsWith('WEBVTT')) {
            // Ubah koma jadi titik di timestamp
            body = body.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');

            const lines = body.split(/\r?\n/);
            const outLines = [];
            for (const line of lines) {
                // Lewati baris yang cuma berisi angka (urutan SRT)
                if (/^\d+$/.test(line.trim())) continue;
                outLines.push(line);
            }
            body = "WEBVTT\n\n" + outLines.join('\n').trim();
        } else if (!body.includes('WEBVTT')) {
            body = "WEBVTT\n\n" + body;
        }

        // d. Suntik Cue Settings & Hapus tag \an (Aegisub)
        const defaultCue = 'line:80% position:50% align:center size:100%';
        const finalLines = body.split(/\r?\n/);
        const processedLines = [];
        let lastTimestampIdx = -1;

        for (let line of finalLines) {
            if (/^\d{2}:\d{2}:\d{2}\.\d{3}\s-->\s\d{2}:\d{2}:\d{2}\.\d{3}/.test(line)) {
                // Bersihkan setting lama, pasang setting baru
                line = line.replace(/\s+(line|position|align|size):.*?(?=\s|$)/gi, '');
                line += ' ' + defaultCue;
                processedLines.push(line);
                lastTimestampIdx = processedLines.length - 1;
            } else {
                if (lastTimestampIdx !== -1 && line.includes('{\\an8}')) {
                    if (!processedLines[lastTimestampIdx].includes('line:10%')) {
                        processedLines[lastTimestampIdx] += ' line:10%';
                    }
                }
                // Hapus tag \an bawaan Aegisub
                line = line.replace(/\{\\an\d\}/g, '');
                processedLines.push(line);
            }
        }

        body = processedLines.join('\n');

        // 4. Return dengan Header Buka Jalur (CORS)
        return new NextResponse(body, {
            headers: {
                'Content-Type': 'text/vtt; charset=UTF-8',
                'Cache-Control': 'public, max-age=86400',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Range, Origin, X-Requested-With, Content-Type, Accept',
            }
        });

    } catch (error: any) {
        return new NextResponse(`Proxy Subtitle Error: ${error.message}`, { status: 500 });
    }
}