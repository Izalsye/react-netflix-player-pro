import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const targetUrl = searchParams.get('url');

    if (!targetUrl) return new NextResponse("Missing url", { status: 400 });

    const headers = new Headers();
    headers.set('User-Agent', req.headers.get('user-agent') || 'Mozilla/5.0');
    headers.set('Referer', 'https://www.primevideo.com/');
    headers.set('Cookie', req.headers.get('cookie') || '');

    // 🚀 WAJIB TAMBAH: Terusin header Range biar video bisa di-skip (seek) maju mundur!
    if (req.headers.has('range')) {
        headers.set('Range', req.headers.get('range')!);
    }

    try {
        const response = await fetch(targetUrl, {
            method: 'GET',
            headers: headers,
            cache: 'no-store' // 👈 Jangan izinkan fetch nyimpen cache
        });

        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        responseHeaders.set('Content-Type', response.headers.get('content-type') || 'application/octet-stream');

        // 🚀 WAJIB TAMBAH: Biar Next.js gak diem-diem nge-cache chunk video di disk/RAM VPS
        responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate');

        // Terusin header penting dari Amazon buat ngedukung streaming
        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (['content-length', 'content-range', 'accept-ranges'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        // 🚀 KUNCI UTAMA: Langsung pipe response.body pakai Response standar!
        // Jangan pakai arrayBuffer() atau NextResponse lagi!
        return new Response(response.body, {
            status: response.status,
            headers: responseHeaders
        });

    } catch (error: any) {
        console.error('Error PrimeVideo Proxy:', error.message);
        return new NextResponse('Upstream error', { status: 502 });
    }
}