import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const targetUrl = searchParams.get('url');

    if (!targetUrl) return new NextResponse("Missing url", { status: 400 });

    // Ambil semua header dari request asli (termasuk cookies/referers)
    const headers = new Headers();
    headers.set('User-Agent', req.headers.get('user-agent') || 'Mozilla/5.0');
    headers.set('Referer', 'https://www.primevideo.com/');
    headers.set('Cookie', req.headers.get('cookie') || '');

    // Tembak ke Amazon CDN
    const response = await fetch(targetUrl, {
        method: 'GET',
        headers: headers
    });

    // Balikin response ke Player lu dengan header CORS yang di-fix
    const body = await response.arrayBuffer();
    return new NextResponse(body, {
        status: response.status,
        headers: {
            'Content-Type': response.headers.get('content-type') || 'application/octet-stream',
            'Access-Control-Allow-Origin': '*', // 🔥 INI PENTING: Fix CORS
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
        }
    });
}