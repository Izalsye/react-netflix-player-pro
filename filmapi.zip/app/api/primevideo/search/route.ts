import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/primevideo/proxy'; // Sesuaikan dengan lokasi file proxy lu
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 🔥 1. PANGGIL VALIDASI API KEY DI PINTU DEPAN 🔥
    const auth = await validateApiKey(req, 'primevideo');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const query = searchParams.get('q') || searchParams.get('phrase');

        if (!query) {
            return NextResponse.json({
                success: false,
                message: "Parameter 'q' wajib ada! Contoh: ?q=batman"
            }, { status: 400 });
        }

        // 1. URL Endpoint Search Prime Video EU (Sama persis kayak hasil inspect network lu)
        const url = `/region/eu/search?ie=UTF8&ref_=atv_nb_sug&phrase=${encodeURIComponent(query)}&dvWebAppClientVersion=1.0.127926.0`;

        // 2. Kita override header dari request asli biar bawa 'x-requested-with'
        // Biar proxyGet tau ini request buat dapet JSON SPA, bukan HTML biasa.
        const customHeaders = new Headers(req.headers);
        customHeaders.set('Accept', 'application/json');
        customHeaders.set('x-requested-with', 'WebAppSPA');

        // Bikin dummy request baru dengan header yang udah dimodif
        const proxyReq = new NextRequest(req.url, {
            headers: customHeaders,
            method: 'GET',
        });

        // 3. Fetch data menggunakan proxyGet
        const response = await proxyGet(
            proxyReq,
            url,
            {},
            { label: 'prime-search', send: false }
        );

        // Jika error dari proxy
        if (response?.error || !response?.body) {
            return NextResponse.json(response, { status: response?.status || 500 });
        }

        const containers = response?.body?.containers || [];

        // Helper function biar format datanya SAMA PERSIS kayak di endpoint Home lu
        const formatItem = (entity: any) => {
            const titleId = entity.titleID || '';

            // Cek status entitlement dari Prime
            const entitlementType = entity.entitlementCues?.entitlementType;
            const isPremium = entitlementType === 'Unentitled';

            // Tambahin keterangan teks SVOD / TVOD
            const premiumLabel = isPremium ? 'Sewa/Beli (TVOD)' : 'Premium (SVOD)';

            // Ekstrak gambar (Prioritas: Cover)
            const landscapeImg = entity.images?.hero?.url || entity.images?.cover?.url || '';
            const portraitImg = entity.images?.poster2x3?.url || entity.images?.cover?.url || landscapeImg;

            return {
                id: titleId,
                seriesId: titleId,
                title: entity.displayTitle || entity.title || '',
                synopsis: entity.synopsis || 'Tidak ada sinopsis.',
                thumbnail: landscapeImg,
                portraitThumbnail: portraitImg,
                isPremium: isPremium,           // Biar FE tetep bisa pake boolean buat logic
                premiumLabel: premiumLabel,     // Nah ini teks siap pakai buat badge/label
                type: entity.entityType === 'TV Show' ? 'tv' : 'movie',
                releaseYear: entity.releaseYear || '',
                runtime: entity.runtime || '',
                maturityRating: entity.maturityRatingBadge?.displayText || 'NR',
                targetid: `${titleId}`
            };
        };

        // 4. Ekstrak data hasil pencarian
        let searchResults: any[] = [];

        // Cari container yang tipenya Grid dan punya entities
        for (const container of containers) {
            if (container.entities && container.entities.length > 0) {
                // Map langsung pakai helper formatItem
                searchResults = container.entities.map((ent: any) => formatItem(ent));
                break; // Ambil container pertama yang isi result aja (film/tv shownya)
            }
        }

        // 5. Kembalikan Response Akhir
        return NextResponse.json({
            success: true,
            query: query,
            total_results: searchResults.length,
            results: searchResults
        }, { status: 200 });

    } catch (error: any) {
        console.error("💥 [PRIME SEARCH ERROR]:", error);
        return NextResponse.json({
            success: false,
            message: error.message || "Internal Server Error"
        }, { status: 500 });
    }
}