import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/primevideo/proxy'; 

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    try {
        // 1. URL Endpoint untuk kategori TV Shows Prime Video EU
        const path = '/region/eu/tv?ref_=atv_hm_hom_c_9zZ8D2_hom&dvWebAppClientVersion=1.0.127926.0';
        const targetUrl = 'https://www.primevideo.com' + path;

        // 🔥 BIKIN HEADER BARU YANG BERSIH TOTAL 🔥
        const customHeaders = new Headers();
        
        // Ambil Cookie dari ENV
        const primeCookie = process.env.PRIME_VIDEO_COOKIE;
        if (primeCookie) customHeaders.set('Cookie', primeCookie);

        // 🔥 BAWA API KEY DARI REQUEST ASLI BIAR LOLOS VALIDASI PROXY 🔥
        if (req.headers.has('x-api-key')) {
            customHeaders.set('x-api-key', req.headers.get('x-api-key') as string);
        }

        // 3. Set Header Custom Penting buat Amazon (Referer disesuaikan untuk TV)
        customHeaders.set('Accept', 'application/json');
        customHeaders.set('x-requested-with', 'WebAppSPA');
        customHeaders.set('Referer', 'https://www.primevideo.com/region/eu/tv?ref_=atv_hm_hom_c_9zZ8D2_hom'); // Referer baru sesuai request
        customHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36');

        // Bikin dummy request biar proxyGet dapet header yang bersih
        const proxyReq = new NextRequest(targetUrl, {
            headers: customHeaders,
            method: 'GET',
        });

        // 4. Fetch data menggunakan proxyGet
        const response = await proxyGet(
            proxyReq,
            path,
            {},
            { label: 'prime-tv', send: false }
        );

        // Jika error dari proxy atau body kosong
        if (response?.error || !response?.body) {
            return NextResponse.json(response, { status: response?.status || 500 });
        }

        const containers = response?.body?.containers || [];

        // 5. Siapkan wadah untuk Banners dan Sections
        const banners: any[] = [];
        const sections: any[] = [];

        // Helper function untuk format item agar sesuai dengan format FE
        const formatItem = (entity: any) => {
            const titleId = entity.titleID || '';
            const entitlementType = entity.entitlementCues?.entitlementType;
            const isPremium = entitlementType === 'Unentitled';
            const premiumLabel = isPremium ? 'Sewa/Beli (TVOD)' : 'Premium (SVOD)';

            // Ekstrak gambar (Prioritas: Hero -> Poster2x3 -> Cover)
            const landscapeImg = entity.images?.hero?.url || entity.images?.cover?.url || '';
            const portraitImg = entity.images?.poster2x3?.url || entity.images?.cover?.url || landscapeImg;

            return {
                id: titleId,
                seriesId: titleId, // Prime menggunakan ID yang sama untuk series/movie di level ini
                title: entity.displayTitle || entity.title || '',
                synopsis: entity.synopsis || '',
                thumbnail: landscapeImg,
                portraitThumbnail: portraitImg,
                isPremium: isPremium,
                premiumLabel: premiumLabel,
                episodeCount: "1", // Default 1, endpoint beranda Amazon jarang ngasih total episode
                type: 'series', // Hardcode 'series' untuk endpoint khusus acara TV
                releaseYear: entity.releaseYear || '',
                runtime: entity.runtime || '',
                maturityRating: entity.maturityRatingBadge?.displayText || '',
                targetid: `${titleId}` // Gue pakein targetid biar sinkron sama model Home/Movie lu
            };
        };

        // 6. Looping data containers dari Amazon
        containers.forEach((container: any, index: number) => {
            const entities = container.entities || container.items || [];
            const type = container.containerType || container.type;

            if (entities.length === 0) return;

            // A. Tentukan Banner (Biasanya bertipe 'StandardHero' atau elemen paling atas)
            if (type === 'StandardHero' || (index === 0 && type === 'SuperCarousel')) {
                entities.forEach((ent: any) => {
                    banners.push(formatItem(ent));
                });
            } 
            // B. Sisanya masuk ke Sections
            else {
                const sectionItems = entities.map((ent: any) => formatItem(ent));

                if (sectionItems.length > 0) {
                    sections.push({
                        sectionId: container.webUid || `prime-sec-${index}`,
                        sectionName: container.text || container.title || container.headerText || 'Acara TV Pilihan',
                        description: container.strings?.DV_WEB_ARIA_MORE_DETAILS || '',
                        items: sectionItems
                    });
                }
            }
        });

        // 7. Kembalikan Response Akhir
        return NextResponse.json({
            status: "success",
            banners: banners,
            sections: sections
        }, { status: 200 });

    } catch (error: any) {
        console.error("💥 [PRIME TV SHOWS ERROR]:", error);
        return NextResponse.json({
            status: "error",
            message: error.message || "Internal Server Error"
        }, { status: 500 });
    }
}