import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/primevideo/proxy';
import { PrimeVideoMapper } from '@/lib/primevideo/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'primevideo');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const titleId = searchParams.get('id');

        if (!titleId) {
            return NextResponse.json({ success: false, message: "Parameter 'id' wajib diisi!" }, { status: 400 });
        }

        const queryParams = Object.fromEntries(searchParams.entries());
        delete queryParams.id;
        if (!queryParams.jic) queryParams.jic = '8%7CEgRzdm9k';

        const upstreamPath = `/region/eu/detail/${titleId}?jic=8%7CEgRzdm9k&ref_=atv_hm_hom_c_mfXhxu_brws_2_2&dvWebAppClientVersion=1.0.127846.0`;

        const myCookie = process.env.PRIME_VIDEO_COOKIE || "";

        const customHeaders = {
            "Accept": "application/json",
            "x-requested-with": "WebAppSPA",
            "Referer": `https://www.primevideo.com${upstreamPath}`,
            "Cookie": myCookie,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"
        };

        const rawData = await proxyGet(req, upstreamPath, queryParams, {
            label: 'prime-detail',
            send: false,
            headers: customHeaders
        });

        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        if (typeof rawData === 'string') {
            console.log("⚠️ Respons HTML terdeteksi!");
            return NextResponse.json({ success: false, message: "Amazon mengembalikan HTML." }, { status: 500 });
        }

        // 🔥 FIX: Pake AWAIT dan ambil object .data nya aja
        const targetData = rawData?.data ? rawData.data : rawData;
        const mappedData = await PrimeVideoMapper.mapDetail(targetData, titleId);

        return NextResponse.json({
            success: true,
            data: mappedData // Return hasil mapping yang udah cakep
        });

    } catch (error: any) {
        console.error("Prime Detail Error:", error);
        return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 });
    }
}