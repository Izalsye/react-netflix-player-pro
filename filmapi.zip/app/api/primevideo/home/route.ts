import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/primevideo/proxy';
import { validateApiKey } from '@/lib/apiKeyService'; // 🔥 Import Satpam
import { recordHit } from '@/lib/stats';              // 🔥 Import Pencatat Hit

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 🔥 1. PANGGIL VALIDASI API KEY DI PINTU DEPAN 🔥
    const apiKey = req.headers.get('x-api-key');
    const auth = await validateApiKey(req, 'primevideo');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const path = '/region/eu/storefront?ref_=atv_hm_hom_c_9zZ8D2_hom&dvWebAppClientVersion=1.0.127846.0';
        const targetUrl = 'https://www.primevideo.com' + path;

        // BIKIN HEADER BARU YANG BERSIH TOTAL
        const customHeaders = new Headers();

        // 1. Ambil Cookie dari ENV
        const primeCookie = process.env.PRIME_VIDEO_COOKIE;
        if (primeCookie) customHeaders.set('Cookie', primeCookie);

        // 2. Bawa API Key biar nggak dicegat sama proxyGet-nya lu
        if (apiKey) {
            customHeaders.set('x-api-key', apiKey);
        }

        // 3. Set Header Custom Penting buat Amazon
        customHeaders.set('Accept', 'application/json');
        customHeaders.set('x-requested-with', 'WebAppSPA');
        customHeaders.set('Referer', 'https://www.primevideo.com/region/eu/storefront?ref_=atv_hm_hom_c_9zZ8D2_hom');
        customHeaders.set('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36');

        // Bikin dummy request
        const proxyReq = new NextRequest(targetUrl, {
            headers: customHeaders,
            method: 'GET',
        });

        // Fetch data
        const response: any = await proxyGet(
            proxyReq,
            path,
            {},
            { label: 'prime-home', send: false }
        );

        // 🔥 FIX 3: KALAU PROXYGET NGE-RETURN "RESPONSE OBJECT" (Misal error 401/502 dari dalem proxy)
        // Kita langsung balikin aja ke user tanpa nanya lagi!
        if (response instanceof Response) {
            return response;
        }

        // Kalau JSON error (misal dari catch di dalem proxyGet)
        if (response?.error || !response?.body) {
            return NextResponse.json(response, { status: response?.status || 502 });
        }

        const containers = response?.body?.containers || [];
        const banners: any[] = [];
        const sections: any[] = [];

        const formatItem = (entity: any) => {
            const titleId = entity.titleID || '';
            const entitlementType = entity.entitlementCues?.entitlementType;
            const isPremium = entitlementType === 'Unentitled';
            const premiumLabel = isPremium ? 'Sewa/Beli (TVOD)' : 'Premium (SVOD)';

            const landscapeImg = entity.images?.hero?.url || entity.images?.cover?.url || '';
            const portraitImg = entity.images?.poster2x3?.url || entity.images?.cover?.url || landscapeImg;

            return {
                id: titleId,
                seriesId: titleId,
                title: entity.displayTitle || entity.title || '',
                synopsis: entity.synopsis || '',
                thumbnail: landscapeImg,
                portraitThumbnail: portraitImg,
                isPremium: isPremium,
                premiumLabel: premiumLabel,
                episodeCount: "1",
                type: 'movie',
                releaseYear: entity.releaseYear || '',
                runtime: entity.runtime || '',
                maturityRating: entity.maturityRatingBadge?.displayText || '',
                targetid: `${titleId}`
            };
        };

        containers.forEach((container: any, index: number) => {
            const type = container.containerType;
            const entities = container.entities || [];

            if (entities.length === 0) return;

            if (type === 'StandardHero' || (index === 0 && type === 'SuperCarousel')) {
                entities.forEach((ent: any) => {
                    banners.push(formatItem(ent));
                });
            } else {
                const sectionItems = entities.map((ent: any) => formatItem(ent));

                if (sectionItems.length > 0) {
                    sections.push({
                        sectionId: container.webUid || `prime-sec-${index}`,
                        sectionName: container.text || container.title || 'Rekomendasi Lainnya',
                        description: container.strings?.DV_WEB_ARIA_MORE_DETAILS || '',
                        items: sectionItems
                    });
                }
            }
        });

        return NextResponse.json({
            status: "success",
            banners: banners,
            sections: sections
        }, { status: 200 });

    } catch (error: any) {
        console.error("💥 [PRIME HOME ERROR]:", error);
        return NextResponse.json({
            status: "error",
            message: error.message || "Internal Server Error"
        }, { status: 500 });
    }
}