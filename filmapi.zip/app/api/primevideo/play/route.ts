import { NextRequest, NextResponse } from 'next/server';
import { proxyPost } from '@/lib/primevideo/proxy';
import prisma from '@/prisma/prisma'; // ⚠️ SESUAIIN PATH PRISMA LU!
import { validateApiKey } from '@/lib/apiKeyService';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'primevideo');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const body = await req.json();
        const { id, shortid } = body;

        if (!id || !shortid) {
            return NextResponse.json({ success: false, message: "Parameter 'id' dan 'shortid' wajib ada!" }, { status: 400 });
        }

        const cachedData = await prisma.primeEnvelope.findUnique({
            where: { shortId: shortid }
        });

        if (!cachedData) {
            return NextResponse.json({ success: false, message: "Data tidak ditemukan. Silakan refresh halaman detail." }, { status: 404 });
        }

        if (new Date() > cachedData.expiresAt) {
            await prisma.primeEnvelope.delete({ where: { shortId: shortid } }).catch(() => { });
            return NextResponse.json({ success: false, message: "Token expired. Silakan refresh halaman detail." }, { status: 401 });
        }

        const realEnvelope = cachedData.envelope;

        // 🚀 SIAPIN PAYLOAD BUAT AMAZON
        const deviceID = process.env.AMAZON_DEVICE_ID || "6faa82cf-596a-4a8b-80e6-3f1faed4df32";
        const deviceTypeID = process.env.AMAZON_DEVICE_TYPE_ID || "AOAGZA014O5RE";
        const marketplaceID = process.env.AMAZON_MARKETPLACE_ID || "A1PA6795UKMFR9";

        const upstreamPath = `/playback/prs/GetVodPlaybackResources?deviceID=${deviceID}&deviceTypeID=${deviceTypeID}&gascEnabled=false&marketplaceID=${marketplaceID}&uxLocale=id_ID&firmware=1&titleId=${id}`;

        const payload = {
            "globalParameters": {
                "deviceCapabilityFamily": "WebPlayer",
                "playbackEnvelope": realEnvelope
            },
            "widevineServiceCertificateRequest": {},
            "playbackDataRequest": {},
            "vodPlaylistedPlaybackUrlsRequest": {
                "device": {
                    "hdcpLevel": "1.4",
                    "maxVideoResolution": "1080p",
                    "supportedStreamingTechnologies": ["DASH"],
                    "streamingTechnologies": {
                        "DASH": {
                            "bitrateAdaptations": ["CBR", "CVBR"],
                            "codecs": ["H264"],
                            "drmKeyScheme": "DualKey",
                            "drmType": "Widevine",
                            "dynamicRangeFormats": ["None"],
                            "edgeDeliveryAuthorizationSchemes": ["PVExchangeV1", "Transparent"],
                            "fragmentRepresentations": ["ByteOffsetRange", "SeparateFile"],
                            "frameRates": ["Standard", "High"],
                            "stitchType": "MultiPeriod",
                            "segmentInfoType": "Base",
                            "timedTextRepresentations": ["NotInManifestNorStream", "SeparateStreamInManifest"],
                            "trickplayRepresentations": ["NotInManifestNorStream"],
                            "variableAspectRatio": "supported"
                        }
                    },
                    "displayWidth": 1920,
                    "displayHeight": 1200
                }
            },
            "timedTextUrlsRequest": {
                "supportedTimedTextFormats": ["TTMLv2", "DFXP"]
            },
            "playbackSettingsRequest": {
                "firmware": "UNKNOWN",
                "playerType": "xp",
                "responseFormatVersion": "1.0.0",
                "titleId": id
            }
        };

        // 🔥 KUNCI BYPASS WAF AMAZON: Content-Type harus text/plain
        const customHeaders = {
            "Content-Type": "text/plain"
        };

        // HIT API
        const targetHost = process.env.PRIME_API_BASE || "https://atv-ps-eu.primevideo.com";
        const proxyResponse = await proxyPost(req, `${targetHost}${upstreamPath}`, payload, {
            label: 'prime-play',
            send: false,
            headers: customHeaders
        });

        if (proxyResponse?.body?.error || proxyResponse?.body?.globalError || !proxyResponse?.body) {
            console.error("Denied/Error by Amazon:", proxyResponse?.body);
            return NextResponse.json({
                success: false,
                message: "Akses ditolak oleh Amazon. Cek log server.",
                error: proxyResponse?.body
            }, { status: proxyResponse?.status || 403 });
        }

        const rawPlay = proxyResponse.body;

        const handoffToken = rawPlay?.sessionization?.sessionHandoffToken;
        if (handoffToken) {
            await prisma.primeEnvelope.update({
                where: { shortId: shortid },
                data: { handoffToken: handoffToken }
            });
        }

        // 🚀 EKSTRAKSI DATA
        const playbackUrlsObj = rawPlay?.vodPlaylistedPlaybackUrls?.result?.playbackUrls || {};
        const firstPlaylist = playbackUrlsObj.intraTitlePlaylist?.[0] || {};
        const playUrls = firstPlaylist.urls || [];
        const streamData = playUrls.find((u: any) => u.cdn === "akamai" || u.cdn === "cloudfront") || playUrls[0];
        const rawMpdUrl = streamData?.url || "";

        const rawSubtitles = rawPlay?.timedTextUrls?.result?.subtitleUrls || [];
        const widevineCertBase64 = rawPlay?.widevineServiceCertificate?.result?.encodedServiceCertificate || "";

        const PROXY_BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

        const rawAudioTracks = firstPlaylist.audioTracks || [];
        const defaultAudioId = firstPlaylist.defaultAudioTrackId || "";
        const defaultAudioObj = rawAudioTracks.find((a: any) => a.audioTrackId === defaultAudioId) || rawAudioTracks[0];

        const audioConf = defaultAudioObj ? {
            audioTrackId: defaultAudioObj.audioTrackId,
            displayName: defaultAudioObj.displayName,
            languageCode: defaultAudioObj.languageCode
        } : null;

        const audioConf_list = rawAudioTracks.map((a: any) => ({
            audioTrackId: a.audioTrackId,
            displayName: a.displayName,
            languageCode: a.languageCode
        }));

        return NextResponse.json({
            success: true,
            streamUrl: rawMpdUrl,
            streamUrl_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(rawMpdUrl)}`,
            dashUrl: rawMpdUrl,
            dashUrl_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(rawMpdUrl)}`,
            audioConf: audioConf,
            audioConf_list: audioConf_list,
            subtitles: rawSubtitles.map((sub: any) => ({
                lang: sub.languageCode ? sub.languageCode.split('-')[0] : 'und',
                label: sub.displayName,
                language: sub.displayName?.toLowerCase() || 'unknown',
                url: sub.url,
                url_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(sub.url)}`,
                format: sub.format || "ttml"
            })),
            isDrm: true,
            licenseServers: {
                drm_license_url: `${PROXY_BASE_URL}/api/primevideo/license?id=${id}&shortid=${shortid}`,
                certificate_base64: widevineCertBase64
            },
            customData: {
                sessionization: rawPlay?.sessionization
            }
        });

    } catch (error: any) {
        console.error("Prime Play Error:", error);
        return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 });
    }
}