import { NextRequest, NextResponse } from 'next/server';
import { proxyPost } from '@/lib/primevideo/proxy';
import prisma from '@/prisma/prisma'; // ⚠️ SESUAIIN PATH PRISMA LU!
import { validateApiKey } from '@/lib/apiKeyService';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'primevideo');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const body = await req.json();
        // Frontend sekarang ngirim "env" (short ID), bukan "envelope" panjang
        const { id, shortid } = body;

        if (!id || !shortid) {
            return NextResponse.json({ success: false, message: "Parameter 'id' dan 'shortid' wajib ada!" }, { status: 400 });
        }

        // 🚀 1. CARI ENVELOPE ASLI DI DATABASE
        const cachedData = await prisma.primeEnvelope.findUnique({
            where: { shortId: shortid }
        });

        if (!cachedData) {
            return NextResponse.json({ success: false, message: "Data tidak ditemukan. Silakan refresh halaman detail." }, { status: 404 });
        }

        if (new Date() > cachedData.expiresAt) {
            // Hapus yang udah expired dari DB biar bersih
            await prisma.primeEnvelope.delete({ where: { shortId: shortid } }).catch(() => { });
            return NextResponse.json({ success: false, message: "Token expired. Silakan refresh halaman detail." }, { status: 401 });
        }

        const realEnvelope = cachedData.envelope;

        // 🚀 2. SIAPIN PAYLOAD BUAT AMAZON (Dari ENV)
        const deviceID = process.env.AMAZON_DEVICE_ID || "1fb88ae2-cc94-45cc-ada1-8dcf0cc290cb";
        const deviceTypeID = process.env.AMAZON_DEVICE_TYPE_ID || "AOAGZA014O5RE";
        const marketplaceID = process.env.AMAZON_MARKETPLACE_ID || "A1PA6795UKMFR9";

        const upstreamPath = `/playback/prs/GetVodPlaybackResources?deviceID=${deviceID}&deviceTypeID=${deviceTypeID}&gascEnabled=false&marketplaceID=${marketplaceID}&uxLocale=id_ID&firmware=1&titleId=${id}`;

        const payload = {
            "globalParameters": {
                "deviceCapabilityFamily": "WebPlayer",
                "playbackEnvelope": realEnvelope
            },
            "widevineServiceCertificateRequest": {},
            "playbackDataRequest": {},
            "vodPlaylistedPlaybackUrlsRequest": {
                "device": {
                    "hdcpLevel": "1.4",
                    "maxVideoResolution": "1080p",
                    "supportedStreamingTechnologies": ["DASH"],
                    "streamingTechnologies": {
                        "DASH": {
                            "bitrateAdaptations": ["CBR", "CVBR"],
                            "codecs": ["H264"],
                            "drmKeyScheme": "DualKey",
                            "drmType": "Widevine",
                            "dynamicRangeFormats": ["None"],
                            "edgeDeliveryAuthorizationSchemes": ["PVExchangeV1", "Transparent"],
                            "fragmentRepresentations": ["ByteOffsetRange", "SeparateFile"],
                            "frameRates": ["Standard", "High"],
                            "stitchType": "MultiPeriod",
                            "segmentInfoType": "Base",
                            "timedTextRepresentations": ["NotInManifestNorStream", "SeparateStreamInManifest"],
                            "trickplayRepresentations": ["NotInManifestNorStream"],
                            "variableAspectRatio": "supported"
                        }
                    },
                    "displayWidth": 1920,
                    "displayHeight": 1200
                }
            },
            "timedTextUrlsRequest": {
                "supportedTimedTextFormats": ["TTMLv2", "DFXP"]
            },
            "playbackSettingsRequest": {
                "firmware": "UNKNOWN",
                "playerType": "xp",
                "responseFormatVersion": "1.0.0",
                "titleId": id
            }
        };

        const proxyResponse = await proxyPost(req, upstreamPath, payload, { label: 'prime-play', send: false });

        if (proxyResponse?.body?.error || !proxyResponse?.body) {
            return NextResponse.json(proxyResponse, { status: proxyResponse?.status || 500 });
        }

        // Buka bungkus body-nya
        const rawPlay = proxyResponse.body;

        // 🔥 SIMPAN HANDOFF TOKEN KE DATABASE UNTUK HIT KEDUA NANTI
        const handoffToken = rawPlay?.sessionization?.sessionHandoffToken;
        if (handoffToken) {
            await prisma.primeEnvelope.update({
                where: { shortId: shortid },
                data: { handoffToken: handoffToken }
            });
        }

        // 🚀 4. EKSTRAKSI DATA URL, SUBTITLE, & AUDIO
        const playbackUrlsObj = rawPlay?.vodPlaylistedPlaybackUrls?.result?.playbackUrls || {};

        // 🔥 INI KUNCINYA: Ambil playlist pertama dulu 🔥
        const firstPlaylist = playbackUrlsObj.intraTitlePlaylist?.[0] || {};

        const playUrls = firstPlaylist.urls || [];
        const streamData = playUrls.find((u: any) => u.cdn === "akamai" || u.cdn === "cloudfront") || playUrls[0];
        const rawMpdUrl = streamData?.url || "";

        // 🔥 PERBAIKAN DI SINI BRE: Hapus .body karena rawPlay udah sejajar posisinya 🔥
        const rawSubtitles = rawPlay?.timedTextUrls?.result?.subtitleUrls || [];
        const widevineCertBase64 = rawPlay?.widevineServiceCertificate?.result?.encodedServiceCertificate || "";

        // Setup base URL untuk proxy stream & subtitle
        const PROXY_BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

        // 🔥 EXTRAKSI AUDIO TRACKS 🔥
        const rawAudioTracks = firstPlaylist.audioTracks || [];
        const defaultAudioId = firstPlaylist.defaultAudioTrackId || "";

        // Cari objek audio default, kalau nggak ketemu ambil yang pertama
        const defaultAudioObj = rawAudioTracks.find((a: any) => a.audioTrackId === defaultAudioId) || rawAudioTracks[0];

        const audioConf = defaultAudioObj ? {
            audioTrackId: defaultAudioObj.audioTrackId,
            displayName: defaultAudioObj.displayName,
            languageCode: defaultAudioObj.languageCode
        } : null;

        const audioConf_list = rawAudioTracks.map((a: any) => ({
            audioTrackId: a.audioTrackId,
            displayName: a.displayName,
            languageCode: a.languageCode
        }));

        // 🚀 5. BENTUK KEMBALIAN KE FRONTEND SESUAI STANDAR
        return NextResponse.json({
            success: true,
            streamUrl: rawMpdUrl,
            streamUrl_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(rawMpdUrl)}`,
            dashUrl: rawMpdUrl,
            dashUrl_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(rawMpdUrl)}`,
            audioConf: audioConf,
            audioConf_list: audioConf_list,
            subtitles: rawSubtitles.map((sub: any) => ({
                // Ambil kode ISO depan (misal 'fr' dari 'fr-fr')
                lang: sub.languageCode ? sub.languageCode.split('-')[0] : 'und',
                // Label asli dari Amazon buat ditampilin di UI
                label: sub.displayName,
                // Fallback (biar FE lu tetep aman kalo masih pake key ini)
                language: sub.displayName.toLowerCase(),
                url: sub.url,
                url_proxy: `${PROXY_BASE_URL}/api/primevideo/stream-proxy?url=${encodeURIComponent(sub.url)}`,
                format: sub.format || "ttml"
            })),
            isDrm: true,
            licenseServers: {
                drm_license_url: `${PROXY_BASE_URL}/api/primevideo/license?id=${id}&shortid=${shortid}`,
                certificate_base64: widevineCertBase64
            },
            customData: {
                sessionization: rawPlay?.sessionization
            }
        });

    } catch (error: any) {
        console.error("Prime Play Error:", error);
        return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 });
    }
}