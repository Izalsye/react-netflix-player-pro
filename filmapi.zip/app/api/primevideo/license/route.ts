import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/prisma/prisma';
import { proxyPost } from '@/lib/primevideo/proxy';

export async function POST(req: NextRequest) {
    try {
        const searchParams = req.nextUrl.searchParams;
        const id = searchParams.get('id');
        const shortid = searchParams.get('shortid');

        if (!id || !shortid) return new NextResponse("Missing id or shortid", { status: 400 });

        // 1. AMBIL CHALLENGE DARI SHAKA PLAYER
        const challengeBuffer = await req.arrayBuffer();
        if (!challengeBuffer || challengeBuffer.byteLength === 0) {
            return new NextResponse("Empty License Challenge", { status: 400 });
        }
        const challengeBase64 = Buffer.from(challengeBuffer).toString('base64');

        // 2. AMBIL TOKEN DARI DATABASE
        const cachedData = await prisma.primeEnvelope.findUnique({
            where: { shortId: shortid }
        });

        if (!cachedData || !cachedData.handoffToken) {
            console.error("❌ [LICENSE ERROR] Handoff Token tidak ditemukan di DB! ID:", shortid);
            return new NextResponse("Token expired", { status: 401 });
        }

        // 3. SIAPIN PAYLOAD BUAT AMAZON
        const payload = {
            "includeHdcpTestKey": true,
            "playbackEnvelope": cachedData.envelope,
            "sessionHandoffToken": cachedData.handoffToken,
            "licenseChallenge": challengeBase64
        };

        const deviceID = process.env.AMAZON_DEVICE_ID || "1fb88ae2-cc94-45cc-ada1-8dcf0cc290cb";
        const deviceTypeID = process.env.AMAZON_DEVICE_TYPE_ID || "AOAGZA014O5RE";
        const marketplaceID = process.env.AMAZON_MARKETPLACE_ID || "A1PA6795UKMFR9";
        const upstreamPath = `/playback/drm-vod/GetWidevineLicense?deviceID=${deviceID}&deviceTypeID=${deviceTypeID}&gascEnabled=false&marketplaceID=${marketplaceID}&uxLocale=id_ID&firmware=1&titleId=${id}`;

        console.log(`🚀 [LICENSE] Meminta lisensi ke Amazon untuk Title: ${id}...`);

        // 4. TEMBAK KE AMAZON PAKAI PROXYPOST
        const rawLicense = await proxyPost(req, upstreamPath, payload, { label: 'prime-license', send: false });

        // 🔍 CEK JIKA PROXY MENGEMBALIKAN ERROR
        if (rawLicense && rawLicense.body?.error) {
            console.error("❌ [LICENSE ERROR] Amazon menolak request lisensi:", rawLicense);
            return new NextResponse(JSON.stringify(rawLicense), { status: 502 });
        }

        const licenseBase64 = rawLicense?.body?.widevineLicense?.license;

        // 🔍 CEK JIKA LISENSI KOSONG / AMAZON NGASIH RESPON LAIN
        if (!licenseBase64) {
            console.error("❌ [LICENSE ERROR] Tidak ada lisensi di respon Amazon! Raw Response:", JSON.stringify(rawLicense).slice(0, 500));
            return new NextResponse("Invalid response from Amazon", { status: 502 });
        }

        console.log("✅ [LICENSE SUCCESS] Berhasil mendapatkan Lisensi dari Amazon! Mengirim ke Player...");

        // 5. KEMBALIKAN BUFFER KE SHAKA PLAYER
        const licenseBuffer = Buffer.from(licenseBase64, 'base64');
        return new NextResponse(licenseBuffer, {
            status: 200,
            headers: {
                'Content-Type': 'application/octet-stream',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-amz-handoff-token, x-amz-envelope'
            }
        });

    } catch (error: any) {
        console.error("💥 [LICENSE ROUTE CRASH]:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}

// 🔥 TAMBAHIN DI SINI BRE (Di bawah fungsi POST) 🔥
// Ini wajib ada biar browser nggak nge-blokir request Shaka Player (CORS Preflight)
export async function OPTIONS(req: NextRequest) {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, x-amz-handoff-token, x-amz-envelope',
        },
    });
}