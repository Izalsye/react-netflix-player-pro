// file: app/api/plans/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path prisma lu

export const dynamic = 'force-dynamic';

export async function GET() {
    try {
        // Ambil semua paket yang aktif, urutkan dari yang termurah
        const plans = await prisma.plan.findMany({
            where: { isActive: true },
            orderBy: { price: 'asc' }
        });

        return NextResponse.json({ success: true, data: plans });
    } catch (error) {
        console.error("GET PLANS ERROR:", error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}