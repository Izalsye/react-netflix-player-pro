import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path
import crypto from 'crypto';

export async function GET(req: Request) {
    try {
        const rawKey = req.headers.get('x-api-key');
        if (!rawKey) return NextResponse.json({ error: 'Missing API Key' }, { status: 401 });

        const hashedKey = crypto.createHash('sha256').update(rawKey).digest('hex');
        const apiKeyData = await prisma.apiKey.findUnique({
            where: { hashedKey },
            include: { user: true },
        });

        if (!apiKeyData || !apiKeyData.user) {
            return NextResponse.json({ error: 'Invalid API Key' }, { status: 401 });
        }

        const user = apiKeyData.user;

        // Cek Expiry VIP (Turunkan ke FREE kalau expired)
        let activeRole = user.role;
        if (activeRole === 'VIP' && user.subEndsAt) {
            if (new Date() > user.subEndsAt) {
                activeRole = 'FREE';
                await prisma.user.update({ where: { id: user.id }, data: { role: 'FREE' } });
            }
        }

        // Ambil Penggunaan Hari Ini
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0);
        const usage = await prisma.dailyUsage.findUnique({
            where: { userId_date: { userId: user.id, date: today } }
        });

        const currentUsage = usage ? usage.count : 0;
        const maxLimit = activeRole === 'VIP' ? 1000000 : 600;

        return NextResponse.json({
            success: true,
            data: {
                firstName: user.firstName,
                lastName: user.lastName,
                role: activeRole,
                subEndsAt: user.subEndsAt,
                usage: currentUsage,
                limit: maxLimit,
                rawKey: apiKeyData.rawKey // Kirim balik untuk ditampilin (opsional)
            }
        });

    } catch (error) {
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}