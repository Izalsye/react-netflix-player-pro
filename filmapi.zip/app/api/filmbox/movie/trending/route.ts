// movie/trending/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats';
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const page = searchParams.get('page') || '1';
    const perPage = searchParams.get('perPage') || '18';

    try {
        // Cache key spesifik untuk trending movie + parameter pagination
        const cacheKey = `filmbox:movie:trending:page:${page}:perPage:${perPage}`;
        const cacheTTL = 600; // 10 menit

        const mappedData = await getOrSetCache(cacheKey, async () => {
            const upstreamUrl = `${API_BASE}/subject/trending?tabId=ONEROOM_MOVIE&page=${page}&perPage=${perPage}`;
            const responseData = await fetchUpstream(upstreamUrl, 'GET');

            const subjectList = responseData.data?.subjectList || [];
            const pager = responseData.data?.pager || null;

            const formattedItems = subjectList.map((item: any) => {
                return {
                    subjectId: item.subjectId || "",
                    detailPath: item.detailPath || "",
                    subjectType: item.subjectType || 1,
                    title: item.title || "",
                    description: item.description || "",
                    releaseDate: item.releaseDate || "",
                    genre: item.genre || "",
                    cover_url: item.cover?.url || "",
                    country: item.countryName || "",
                    bahasa: item.subtitles || "",
                    rating: parseFloat(item.imdbRatingValue || "0"),
                    trailer_url: item.trailer?.videoAddress?.url || "",
                    view: parseInt(item.imdbRatingCount || "0", 10),
                    totalEpisode: 1,
                    totalSeason: 1
                };
            });

            return {
                items: formattedItems,
                pager: pager
            };
        }, cacheTTL);

        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}