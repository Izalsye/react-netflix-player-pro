import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { recordHit } from '@/lib/stats';
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const upstreamUrl = `${API_BASE}/tab-operating?tabId=ONEROOM_MOVIE&host=movieboxhd.net`;
        const responseData = await fetchUpstream(upstreamUrl, 'GET');

        const rawOperatingList = responseData.data?.operatingList || [];
        const banners: any[] = [];
        const contentSections: any[] = [];

        for (const section of rawOperatingList) {
            if (section.type === "BANNER" && section.banner?.items) {
                const bannerItems = section.banner.items.map((item: any) => {
                    const sub = item.subject || {};
                    return {
                        subjectId: sub.subjectId || item.subjectId || item.id || "",
                        detailPath: sub.detailPath || item.detailPath || "",
                        subjectType: sub.subjectType || item.subjectType || 1,
                        title: sub.title || item.title || "",
                        description: sub.description || "",
                        releaseDate: sub.releaseDate || "",
                        appointmentDate: sub.appointmentDate || "",
                        cover_url: item.image?.url || sub.cover?.url || "",
                        genre: sub.genre || "",
                        rating: parseFloat(sub.imdbRatingValue || "0")
                    };
                });
                banners.push(...bannerItems);
            }
            else if (section.title) {
                let rawItems: any[] = [];
                let isSportLive = false;

                if (section.subjects && section.subjects.length > 0) {
                    rawItems = section.subjects;
                } else if (section.customData?.items && section.customData.items.length > 0) {
                    rawItems = section.customData.items;
                } else if (section.liveList && section.liveList.length > 0) {
                    rawItems = section.liveList;
                    isSportLive = true;
                }

                if (rawItems.length > 0) {
                    const categoryItems = rawItems.map((sub: any) => {
                        if (isSportLive) {
                            return {
                                is_live_sport: true,
                                match_id: sub.matchId || "",
                                title: sub.content || `${sub.team1?.name} vs ${sub.team2?.name}`,
                                cover_url: sub.image?.url || sub.team1?.avatar || "",
                                start_time: sub.startTime || "",
                                status: sub.status || "",
                                team1: sub.team1?.name || "",
                                team2: sub.team2?.name || "",
                                sport_type: sub.team1?.type || "Unknown",
                                subjectType: null
                            };
                        }

                        const s = sub.subject ? sub.subject : sub;
                        return {
                            is_live_sport: false,
                            subjectId: s.subjectId || "",
                            detailPath: s.detailPath || "",
                            subjectType: s.subjectType || 1,
                            title: s.title || "",
                            description: s.description || "",
                            releaseDate: s.releaseDate || "",
                            appointmentDate: s.appointmentDate || "",
                            genre: s.genre || "",
                            cover_url: s.cover?.url || "",
                            country: s.countryName || "",
                            bahasa: s.subtitles || "",
                            rating: parseFloat(s.imdbRatingValue || "0"),
                            trailer_url: s.trailer?.videoAddress?.url || "",
                            view: parseInt(s.imdbRatingCount || "0", 10),
                            corner_badge: s.corner || "",
                            totalEpisode: 1,
                            totalSeason: 1
                        };
                    });

                    // --- FILTERING DISINI ---
                    // Hanya ambil item yang memiliki subjectType 1, 2, atau 5
                    const filteredItems = categoryItems.filter((item: any) =>
                        [1, 2].includes(item.subjectType)
                    );

                    // Pastikan section tidak dimasukkan jika datanya kosong setelah difilter
                    if (filteredItems.length > 0) {
                        contentSections.push({
                            section_id: section.genreTopId || section.opId || "", // Ambil ID section
                            section_title: section.title,
                            section_path: section.detailPath || "", // <-- Tambahkan path-nya di sini
                            position: section.position || 0,
                            items: filteredItems
                        });
                    }
                }
            }
        }

        contentSections.sort((a, b) => a.position - b.position);

        return NextResponse.json({
            code: 0,
            message: "ok",
            data: {
                hero_banners: banners,
                content_sections: contentSections
            }
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}