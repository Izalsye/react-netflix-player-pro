// cari/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats';
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';
import { LogIn } from 'lucide-react';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const customHeaders = {
        'Authorization': process.env.FILMBOX_AUTH_TOKEN || '',
    };

    // 2. Ambil Body Payload dari Request
    let reqBody;
    try {
        reqBody = await req.json();
    } catch (e) {
        return NextResponse.json({ code: 400, message: "Invalid JSON body", data: null }, { status: 400 });
    }

    // Set default value kalau user gak kirim lengkap
    const payload = {
        keyword: reqBody.keyword || "",
        page: reqBody.page || "1",
        perPage: reqBody.perPage || 28,
        subjectType: reqBody.subjectType || 0
    };

    // Tolak kalau keyword kosong
    if (!payload.keyword) {
        return NextResponse.json({ code: 400, message: "Keyword is required", data: null }, { status: 400 });
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT SEARCH 🔥
        // Format: filmbox:search:kw:<keyword_encoded>:page:<page>:type:<type>
        const safeKeyword = encodeURIComponent(payload.keyword.toLowerCase().trim());
        const cacheKey = `filmbox:search:kw:${safeKeyword}:page:${payload.page}:perPage:${payload.perPage}:type:${payload.subjectType}`;
        const cacheTTL = 600; // 10 Menit (Biar hasil pencarian tetap lumayan fresh)

        const mappedData = await getOrSetCache(cacheKey, async () => {
            // 4. Fetch Data Search dari Upstream
            const upstreamUrl = `${API_BASE}/subject/search`;
            const responseData = await fetchUpstream(upstreamUrl, 'POST', payload, customHeaders, true);

            const subjectList = responseData.data?.subjectList || responseData.data?.items || [];
            const pager = responseData.data?.pager || null;

            // 5. Mapping (DTO) setiap film
            const formattedItems = subjectList.map((item: any) => {
                return {
                    subjectId: item.subjectId || "",
                    detailPath: item.detailPath || "",
                    subjectType: item.subjectType || 1,
                    title: item.title || "",
                    description: item.description || "",
                    releaseDate: item.releaseDate || "",
                    genre: item.genre || "",
                    cover_url: item.cover?.url || "",
                    country: item.countryName || "",
                    bahasa: item.subtitles || "",
                    rating: parseFloat(item.imdbRatingValue || "0"),
                    trailer_url: item.trailer?.videoAddress?.url || "",
                    view: parseInt(item.imdbRatingCount || "0", 10),
                    totalEpisode: 1,
                    totalSeason: 1
                };
            });

            return {
                items: formattedItems,
                pager: pager
            };
        }, cacheTTL);

        // 6. Return Response Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}