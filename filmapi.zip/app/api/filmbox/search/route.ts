import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { recordHit } from '@/lib/stats';
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';
import { LogIn } from 'lucide-react';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const customHeaders = {
        'Authorization': process.env.FILMBOX_AUTH_TOKEN || '', // Ganti dengan token yang valid
    };

    // 2. Ambil Body Payload dari Request
    let reqBody;
    try {
        reqBody = await req.json();
    } catch (e) {
        return NextResponse.json({ code: 400, message: "Invalid JSON body", data: null }, { status: 400 });
    }

    // Set default value kalau user gak kirim lengkap
    const payload = {
        keyword: reqBody.keyword || "",
        page: reqBody.page || "1",
        perPage: reqBody.perPage || 28,
        subjectType: reqBody.subjectType || 0
    };

    // Tolak kalau keyword kosong
    if (!payload.keyword) {
        return NextResponse.json({ code: 400, message: "Keyword is required", data: null }, { status: 400 });
    }
    try {
        // 4. Fetch Data Search dari Upstream (pakai method POST dan kirim payload)
        const upstreamUrl = `${API_BASE}/subject/search`;
        const responseData = await fetchUpstream(upstreamUrl, 'POST', payload, customHeaders, true);

        console.log("🔍 [Filmbox Search] Response:", responseData);
        // Tergantung dari struktur response aslinya, biasanya ada di data.subjectList atau data.items
        const subjectList = responseData.data?.subjectList || responseData.data?.items || [];
        const pager = responseData.data?.pager || null;

        // 5. Mapping (DTO) setiap film di dalam list (Persis kayak Trending)
        const formattedItems = subjectList.map((item: any) => {
            return {
                subjectId: item.subjectId || "",
                detailPath: item.detailPath || "",
                subjectType: item.subjectType || 1,
                title: item.title || "",
                description: item.description || "",
                releaseDate: item.releaseDate || "",
                genre: item.genre || "",
                cover_url: item.cover?.url || "",
                country: item.countryName || "",
                bahasa: item.subtitles || "",
                rating: parseFloat(item.imdbRatingValue || "0"),
                trailer_url: item.trailer?.videoAddress?.url || "",
                view: parseInt(item.imdbRatingCount || "0", 10),

                totalEpisode: 1,
                totalSeason: 1
            };
        });

        // 6. Return Response Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: {
                items: formattedItems,
                pager: pager
            }
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}