// file: app/api/filmbox/getplay/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { fetchUpstream } from '@/lib/filmboxProxy';

export const dynamic = 'force-dynamic';

// ==========================================
// 🚀 KONFIGURASI PROXY KHUSUS RUTE INI
// ==========================================
const USE_PROXY_FOR_THIS_ROUTE = false;

// ==========================================
// 🚀 HELPER: NORMALISASI KODE BAHASA
// ==========================================
function normalizeLang(lang: string | null | undefined): string {
    if (!lang) return '';
    const cleanLang = lang.toLowerCase().trim();
    const paramMap: Record<string, string> = {
        'id_id': 'id', 'in_id': 'id', 'id': 'id',
        'en_us': 'en', 'en': 'en',
        'zh_cn': 'zh-CN', 'zh_tw': 'zh-TW',
        'ms_my': 'ms'
    };
    return paramMap[cleanLang] || cleanLang;
}

// ==========================================
// 🚀 HELPER: GENERATE PROXY URL (STREAM & SUB)
// ==========================================
function getProxyUrl(provider: string, type: string, originalUrl: string | null): string {
    if (!originalUrl) return '';
    const BASE_DOMAIN = process.env.NEXT_PUBLIC_SITE_URL || '';
    const encodedUrl = encodeURIComponent(originalUrl);

    // Arahkan ke endpoint proxy universal lu, lengkap dengan provider dan type
    return `${BASE_DOMAIN}/api/proxy?url=${encodedUrl}&provider=${provider}&type=${type}`;
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');
    if (!auth.isValid) {
        return NextResponse.json({ code: auth.status, message: auth.message, data: null }, { status: auth.status });
    }

    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');
    const detailPath = searchParams.get('detailPath') || '';
    const se = searchParams.get('se') || '1';
    const ep = searchParams.get('ep') || '1';
    const quality = searchParams.get('quality');
    const lang = normalizeLang(searchParams.get('lang') || 'in_id');

    if (!subjectId) {
        return NextResponse.json({ code: 400, message: "subjectId wajib diisi", data: null }, { status: 400 });
    }

    try {
        // --- STEP A: Fetch Video Info (via H5 API) ---
        const playUrl = `https://movieboxhd.net/wefeed-h5api-bff/subject/play?subjectId=${subjectId}&se=${se}&ep=${ep}&detailPath=${detailPath}&streamSignType=1`;

        // 🔥 BIKIN HEADER REFERER DINAMIS SESUAI FILMNYA 🔥
        const dynamicHeaders = {
            'Referer': `https://movieboxhd.net/id/play/${detailPath}?id=${subjectId}`
        };

        // Panggil fetchUpstream dengan membawa dynamicHeaders di argumen ke-4
        const playData = await fetchUpstream(playUrl, 'GET', null, dynamicHeaders, USE_PROXY_FOR_THIS_ROUTE);

        // ==========================================
        // 🚨 LOGGING DEBUGGING
        // ==========================================
        console.log("\n=== 🐛 DEBUG FILMBOX GETPLAY 🐛 ===");
        console.log("➡️ TARGET URL:", playUrl);
        console.log("➡️ REFERER YG DIGUNAKAN:", dynamicHeaders.Referer);
        console.log("⬅️ RESPONSE DARI SERVER H5:");
        console.log(JSON.stringify(playData, null, 2));
        console.log("=====================================\n");

        const streams = playData.data?.streams || []; // Isinya MP4
        const dashList = playData.data?.dash || [];   // Isinya MPD (DASH)

        console.log(`✅ Terdeteksi: ${streams.length} MP4, ${dashList.length} DASH`);

        if (streams.length === 0 && dashList.length === 0) {
            return NextResponse.json({ code: 404, message: "Stream video kosong (Cek terminal Next.js untuk log detailnya)", data: playData }, { status: 404 });
        }

        // --- STEP B: Saringan Kualitas (Pilih MP4 kalau ada) ---
        let selectedStream: any = null;
        let validMp4 = streams.filter((s: any) => s.url && !s.vipLocked);

        if (validMp4.length > 0) {
            const targetQuality = quality ? String(quality) : '1080';
            selectedStream = validMp4.find((s: any) => String(s.resolutions) === targetQuality);

            // Kalau quality yg diminta gak ada, ambil yang resolusinya paling tinggi
            if (!selectedStream) {
                validMp4.sort((a: any, b: any) => parseInt(b.resolutions || 0) - parseInt(a.resolutions || 0));
                selectedStream = validMp4[0];
            }
        }

        let selectedDash = dashList.find((d: any) => d.url && !d.vipLocked) || null;

        // --- STEP C: Fetch Subtitle (via H5 API) ---
        const refStream = selectedStream || selectedDash;
        const streamId = refStream?.id || '';
        const format = refStream?.format || 'MP4';

        let allSubtitles: any[] = [];
        let finalSubUrl = null;
        let finalSubUrlProxy = null;

        if (streamId) {
            const captionUrl = `https://h5-api.aoneroom.com/wefeed-h5api-bff/subject/caption?format=${format}&id=${streamId}&subjectId=${subjectId}&detailPath=${detailPath}`;

            // Fetch subtitle, tetap lempar dynamicHeaders yang sama
            const subtitleData = await fetchUpstream(captionUrl, 'GET', null, dynamicHeaders, USE_PROXY_FOR_THIS_ROUTE);

            const captions = subtitleData.data?.captions || [];
            if (captions.length > 0) {
                allSubtitles = captions.map((cap: any) => {
                    const originalUrl = cap.url || "";
                    const proxyUrl = getProxyUrl('filmbox', 'sub', originalUrl);
                    return {
                        lang: cap.lan || cap.lanCode || "",
                        label: cap.lanName || cap.lan || "Unknown",
                        id: cap.lan || "",
                        url: originalUrl,
                        url_proxy: proxyUrl,
                        subUrl: proxyUrl // Backward compat
                    };
                });

                // Cocokkan bahasa dari parameter request
                const matchedSub = allSubtitles.find((cap: any) => normalizeLang(cap.lang) === lang);
                const defaultSub = matchedSub || allSubtitles[0];

                finalSubUrl = defaultSub.url;
                finalSubUrlProxy = defaultSub.url_proxy;
            }
        }

        // --- STEP D: Mapping Data ke Format DTO Filmbox ---
        let vid_url = "";
        let vid_url_proxy = "";

        if (selectedStream?.url) {
            vid_url = selectedStream.url;
            vid_url_proxy = getProxyUrl('filmbox', 'stream', vid_url);
        }

        const hlsArray = validMp4.map((s: any) => ({
            resolutions: s.resolutions || "Unknown",
            url: s.url,
            url_proxy: getProxyUrl('filmbox', 'stream', s.url)
        }));

        let dashData = null;
        if (selectedDash?.url) {
            dashData = {
                url: selectedDash.url,
                url_proxy: getProxyUrl('filmbox', 'stream', selectedDash.url),
                signCookie: selectedDash.signCookie || null,
                signHeaderKey: selectedDash.signHeaderKey || null,
                resolutions: selectedDash.resolutions || null
            };
        }

        const finalQuality = selectedStream ? parseInt(selectedStream.resolutions || 0)
            : (selectedDash ? parseInt(selectedDash.resolutions?.split(',')[0] || 0) : 0);

        const dto = {
            subjectId: subjectId,
            se: parseInt(String(se)),
            episode: parseInt(String(ep)),
            quality: finalQuality,
            format: format,
            vid_url: vid_url,
            vid_url_proxy: vid_url_proxy,
            hls: hlsArray.length > 0 ? hlsArray : null,
            dash: dashData,
            sub_url: finalSubUrl,
            sub_url_proxy: finalSubUrlProxy,
            subtitles: allSubtitles
        };

        return NextResponse.json({ code: 0, message: "ok", data: dto });

    } catch (error: any) {
        const statusCode = error.status || 502;
        return NextResponse.json(
            { code: statusCode, message: "H5 Fetch Error: " + (error.message || "Unknown error"), data: error.rawData || null },
            { status: statusCode === 502 ? 400 : statusCode }
        );
    }
}