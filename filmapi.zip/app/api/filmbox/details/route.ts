// detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { API_BASE, fetchUpstream } from '@/lib/filmboxProxy';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats'; 

// IMPORT BUAT FALLBACK KE DRAMOVNIME
import { proxyGet } from '@/lib/proxy';
import { mapDetailDataDTO } from '@/lib/detaildto';

// IMPORT HELPER REDIS
import { getOrSetCache } from '@/lib/redisClient';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 2. Ambil Parameter
    const detailPath = req.nextUrl.searchParams.get('detailPath');
    const fallbackId = req.nextUrl.searchParams.get('id') || req.nextUrl.searchParams.get('subjectId');

    if (!detailPath && !fallbackId) {
        return NextResponse.json({ code: 400, message: "Parameter detailPath atau id wajib diisi", data: null }, { status: 400 });
    }

    try {
        // 🔥 Bikin Cache Key unik berdasarkan detailPath atau fallbackId
        const identifier = detailPath || fallbackId;
        const cacheKey = `filmbox:detail:${identifier}`;
        const cacheTTL = 3600; // 1 Jam (Detail film jarang berubah, aman di-cache lama)

        // Bungkus semua logika fetch & mapping ke dalam getOrSetCache
        const mappedData = await getOrSetCache(cacheKey, async () => {
            let subject = null;
            let resource = null;

            // 4. Fetch ke Filmbox jika ada detailPath
            if (detailPath) {
                const detailData = await fetchUpstream(`${API_BASE}/detail?detailPath=${detailPath}`);
                subject = detailData?.data?.subject;
                resource = detailData?.data?.resource;
            }

            // 🚀 FALLBACK KE DRAMOVNIME KALAU FILMBOX KOSONG / ERROR
            if (!subject) {
                console.log(`[⚠️ WARN] Data Filmbox detailPath (${detailPath}) kosong! Banting setir ke Dramovnime...`);

                const idForWefeed = fallbackId || (detailPath ? detailPath.split('-').pop() : '');

                if (!idForWefeed) {
                    throw { status: 404, message: "Movie details not found and no ID to fallback" };
                }

                // STEP 1 FALLBACK: Hit Detail Utama
                const mainData: any = await proxyGet(
                    req,
                    "/wefeed-mobile-bff/subject-api/get",
                    { se: req.nextUrl.searchParams.get('se') ?? "0", subjectId: idForWefeed },
                    { label: "/detaildata_fallback", transform: mapDetailDataDTO, cacheTtlMs: 3600000, send: false }
                );

                if (mainData?.error || !mainData?.data) {
                    throw { status: 502, message: "Failed fetching fallback main detail" };
                }

                // STEP 2 FALLBACK: Hit Season Info
                const seasonInfo: any = await proxyGet(
                    req,
                    "/wefeed-mobile-bff/subject-api/season-info",
                    { subjectId: idForWefeed },
                    { label: "/info_fallback", cacheTtlMs: 300000, send: false }
                );

                // STEP 3 FALLBACK: Format & Merge Data
                let finalSeasonsList: any[] = [];
                let calculatedTotalEpisodes = 0;

                if (seasonInfo && seasonInfo.data && Array.isArray(seasonInfo.data.seasons)) {
                    finalSeasonsList = seasonInfo.data.seasons.map((s: any) => {
                        const maxEp = s.maxEp || 0;
                        let episodesArray: number[] = [];

                        if (mainData.data.subjectType === 1 && maxEp === 1) {
                            episodesArray = [0];
                        } else {
                            episodesArray = Array.from({ length: maxEp }, (_, i) => i + 1);
                        }

                        calculatedTotalEpisodes += episodesArray.length;

                        return {
                            season: s.se,
                            total_episodes: maxEp,
                            episodes: episodesArray
                        };
                    });
                }

                mainData.data.seasons_list = finalSeasonsList;
                if (calculatedTotalEpisodes > 0) {
                    mainData.data.totalEpisode = calculatedTotalEpisodes;
                }
                if (finalSeasonsList.length > 0) {
                    mainData.data.totalSeason = finalSeasonsList.length;
                }

                // Return data hasil fallback untuk disimpan di Redis
                return mainData.data;
            }

            // 5. Mapping Data Filmbox (Kalau Filmbox Sukses)
            let totalEpisode = 0;
            const seasonsList = [];
            const seasonsRaw = resource?.seasons || [];

            if (seasonsRaw.length > 0) {
                for (const s of seasonsRaw) {
                    let maxFromRes = 0;
                    for (const r of (s.resolutions || [])) {
                        if (r.epNum > maxFromRes) maxFromRes = r.epNum;
                    }

                    const seasonEps = Math.max(s.maxEp || 0, maxFromRes);
                    const epsCount = seasonEps === 0 ? 1 : seasonEps;
                    totalEpisode += epsCount;

                    const epsArray = [];
                    const epStart = (subject.subjectType === 1 && epsCount === 1) ? 0 : 1;

                    for (let i = 0; i < epsCount; i++) {
                        epsArray.push(epStart + i);
                    }

                    seasonsList.push({
                        season: s.se || 1,
                        total_episodes: epsCount,
                        episodes: epsArray
                    });
                }
            } else {
                totalEpisode = 1;
                const epStart = subject.subjectType === 1 ? 0 : 1;
                seasonsList.push({ season: 1, total_episodes: 1, episodes: [epStart] });
            }

            // Mappers DTO Akhir Filmbox
            const dto = {
                subjectId: subject.subjectId || "",
                detailPath: subject.detailPath || detailPath,
                subjectType: subject.subjectType || 1,
                title: subject.title || "",
                description: subject.description || "",
                releaseDate: subject.releaseDate || "",
                appointmentDate: subject.appointmentDate || "",
                genre: subject.genre || "",
                cover_url: subject.cover?.url || null,
                country: subject.countryName || "",
                bahasa: subject.subtitles || "",
                rating: parseFloat(subject.imdbRatingValue || "0"),
                trailer_url: subject.trailer?.videoAddress?.url || null,
                view: parseInt(subject.views || "0", 10),
                totalEpisode: totalEpisode,
                totalSeason: seasonsList.length,
                seasons_list: seasonsList
            };

            // Return data hasil mapping Filmbox untuk disimpan di Redis
            return dto;
        }, cacheTTL);

        // 6. Return Response Bersih dari Redis (atau fresh fetch)
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        // Ambil status dari throw custom kita tadi, kalau gak ada jadikan 502
        const status = error.status || 502;
        return NextResponse.json({ code: status, message: error.message, data: null }, { status });
    }
}