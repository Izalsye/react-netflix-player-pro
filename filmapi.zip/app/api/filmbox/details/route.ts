import { NextRequest, NextResponse } from 'next/server';
import { API_BASE, fetchUpstream } from '@/lib/filmboxProxy'; // pastikan path sesuai
import { validateApiKey } from '@/lib/apiKeyService'; // pastikan path sesuai
import { recordHit } from '@/lib/stats';              // pastikan path sesuai

// 🚀 IMPORT BUAT FALLBACK KE DRAMOVNIME
import { proxyGet } from '@/lib/proxy';
import { mapDetailDataDTO } from '@/lib/detaildto';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 2. Ambil Parameter
    const detailPath = req.nextUrl.searchParams.get('detailPath');
    // Tangkap 'id' juga buat jaga-jaga dipakai Wefeed kalau detailPath gagal
    const fallbackId = req.nextUrl.searchParams.get('id') || req.nextUrl.searchParams.get('subjectId');

    if (!detailPath && !fallbackId) {
        return NextResponse.json({ code: 400, message: "Parameter detailPath atau id wajib diisi", data: null }, { status: 400 });
    }

    try {
        let subject = null;
        let resource = null;

        // 4. Fetch ke Filmbox jika ada detailPath
        if (detailPath) {
            const detailData = await fetchUpstream(`${API_BASE}/detail?detailPath=${detailPath}`);
            subject = detailData?.data?.subject;
            resource = detailData?.data?.resource;
        }

        // 🚀 FITUR BARU: FALLBACK KE DRAMOVNIME KALAU FILMBOX KOSONG / ERROR
        if (!subject) {
            console.log(`[⚠️ WARN] Data Filmbox detailPath (${detailPath}) kosong! Banting setir ke Dramovnime...`);

            // Wefeed butuh ID. Coba ambil dari fallbackId atau ekstrak dari ujung detailPath
            const idForWefeed = fallbackId || (detailPath ? detailPath.split('-').pop() : '');

            if (!idForWefeed) {
                return NextResponse.json({ code: 404, message: "Movie details not found and no ID to fallback", data: null }, { status: 404 });
            }

            // 🔥 STEP 1 FALLBACK: Hit Detail Utama (send: false)
            const mainData: any = await proxyGet(
                req,
                "/wefeed-mobile-bff/subject-api/get",
                { se: req.nextUrl.searchParams.get('se') ?? "0", subjectId: idForWefeed },
                { label: "/detaildata_fallback", transform: mapDetailDataDTO, cacheTtlMs: 3600000, send: false }
            );

            if (mainData?.error || !mainData?.data) {
                return NextResponse.json(mainData ?? { code: 502, message: "Failed fetching fallback main detail", data: null }, { status: 502 });
            }

            // 🔥 STEP 2 FALLBACK: Hit Season Info
            const seasonInfo: any = await proxyGet(
                req,
                "/wefeed-mobile-bff/subject-api/season-info",
                { subjectId: idForWefeed },
                { label: "/info_fallback", cacheTtlMs: 300000, send: false }
            );

            // 🔥 STEP 3 FALLBACK: Format & Merge Data (Sama persis kayak route Dramovnime)
            let finalSeasonsList: any[] = [];
            let calculatedTotalEpisodes = 0;

            if (seasonInfo && seasonInfo.data && Array.isArray(seasonInfo.data.seasons)) {
                finalSeasonsList = seasonInfo.data.seasons.map((s: any) => {
                    const maxEp = s.maxEp || 0;
                    let episodesArray: number[] = [];

                    if (mainData.data.subjectType === 1 && maxEp === 1) {
                        episodesArray = [0];
                    } else {
                        episodesArray = Array.from({ length: maxEp }, (_, i) => i + 1);
                    }

                    calculatedTotalEpisodes += episodesArray.length;

                    return {
                        season: s.se,
                        total_episodes: maxEp,
                        episodes: episodesArray
                    };
                });
            }

            mainData.data.seasons_list = finalSeasonsList;
            if (calculatedTotalEpisodes > 0) {
                mainData.data.totalEpisode = calculatedTotalEpisodes;
            }
            if (finalSeasonsList.length > 0) {
                mainData.data.totalSeason = finalSeasonsList.length;
            }

            // 🔥 STEP 4 FALLBACK: Kembalikan response
            return NextResponse.json(mainData, { headers: { 'Content-Type': 'application/json' } });
        }

        // 5. Mapping Data Filmbox (Kalau Filmbox Sukses)
        let totalEpisode = 0;
        const seasonsList = [];
        const seasonsRaw = resource?.seasons || [];

        if (seasonsRaw.length > 0) {
            for (const s of seasonsRaw) {
                // Cari angka episode tertinggi dari resolutions
                let maxFromRes = 0;
                for (const r of (s.resolutions || [])) {
                    if (r.epNum > maxFromRes) maxFromRes = r.epNum;
                }

                // Tentukan jumlah episode untuk season ini
                const seasonEps = Math.max(s.maxEp || 0, maxFromRes);
                const epsCount = seasonEps === 0 ? 1 : seasonEps;

                totalEpisode += epsCount;

                // Bikin array list episodenya biar frontend/PHP enak bikin tombolnya [1, 2, 3, ...]
                const epsArray = [];
                // Kalau subjectType 1 (Movie) dan eps 1, pake angka 0. Selain itu mulai dari 1
                const epStart = (subject.subjectType === 1 && epsCount === 1) ? 0 : 1;

                for (let i = 0; i < epsCount; i++) {
                    epsArray.push(epStart + i);
                }

                seasonsList.push({
                    season: s.se || 1,
                    total_episodes: epsCount,
                    episodes: epsArray
                });
            }
        } else {
            // Fallback kalau tiba-tiba datanya kosong di Filmbox (asumsikan Movie 1 episode)
            totalEpisode = 1;
            const epStart = subject.subjectType === 1 ? 0 : 1;
            seasonsList.push({ season: 1, total_episodes: 1, episodes: [epStart] });
        }

        // Mappers DTO Akhir Filmbox (Persis struktur Dramovnime)
        const dto = {
            subjectId: subject.subjectId || "",
            detailPath: subject.detailPath || detailPath,
            subjectType: subject.subjectType || 1,
            title: subject.title || "",
            description: subject.description || "",
            releaseDate: subject.releaseDate || "",
            appointmentDate: subject.appointmentDate || "",
            genre: subject.genre || "",
            cover_url: subject.cover?.url || null,
            country: subject.countryName || "",
            bahasa: subject.subtitles || "",
            rating: parseFloat(subject.imdbRatingValue || "0"),
            trailer_url: subject.trailer?.videoAddress?.url || null,
            view: parseInt(subject.views || "0", 10),
            totalEpisode: totalEpisode,
            totalSeason: seasonsList.length,
            seasons_list: seasonsList
        };

        // 6. Return Response Bersih Filmbox
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: dto
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}