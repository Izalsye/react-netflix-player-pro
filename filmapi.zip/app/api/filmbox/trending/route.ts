import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { recordHit } from '@/lib/stats';
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 2. Ambil Parameter (dengan default value)
    const { searchParams } = new URL(req.url);
    const page = searchParams.get('page') || '0';
    const perPage = searchParams.get('perPage') || '18';
    try {
        // 4. Fetch Data Trending dari Upstream
        const upstreamUrl = `${API_BASE}/subject/trending?page=${page}&perPage=${perPage}`;
        const responseData = await fetchUpstream(upstreamUrl, 'GET');

        const subjectList = responseData.data?.subjectList || [];
        const pager = responseData.data?.pager || null;

        // 5. Mapping (DTO) setiap film di dalam list
        const formattedItems = subjectList.map((item: any) => {
            return {
                subjectId: item.subjectId || "",
                detailPath: item.detailPath || "",
                subjectType: item.subjectType || 1,
                title: item.title || "",
                description: item.description || "",
                releaseDate: item.releaseDate || "",
                genre: item.genre || "",
                cover_url: item.cover?.url || "",
                country: item.countryName || "",
                bahasa: item.subtitles || "",
                rating: parseFloat(item.imdbRatingValue || "0"),
                trailer_url: item.trailer?.videoAddress?.url || "",
                view: parseInt(item.imdbRatingCount || "0", 10), // Map imdbRatingCount jadi view

                // Karena data dari list trending gak bawa info jumlah episode/season secara detail,
                // Kita kasih fallback 1. Nanti user bisa tau pastinya pas klik masuk ke /details.
                totalEpisode: 1,
                totalSeason: 1
            };
        });

        // 6. Return Response Bersih
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: {
                items: formattedItems,
                pager: pager // Tetap kirim pager biar frontend tau kapan harus load more
            }
        });

    } catch (error: any) {
        return NextResponse.json({ code: 502, message: error.message, data: null }, { status: 502 });
    }
}