// File: app/api/section/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats'; // Uncomment kalau mau dipake
import { fetchUpstream, API_BASE } from '@/lib/filmboxProxy';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'filmbox');

    // Validasi API Key
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // Ambil query parameters dari URL
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const page = searchParams.get('page') || '1'; // Default page 1
        const perPage = searchParams.get('perPage') || '20'; // Default 20 item

        // Wajib ada ID
        if (!id) {
            return NextResponse.json(
                { code: 400, message: "Parameter 'id' (section_id) is required", data: null },
                { status: 400 }
            );
        }

        // Panggil upstream API (jangan lupa host-nya disamain)
        const upstreamUrl = `${API_BASE}/ranking-list/content?id=${id}&page=${page}&perPage=${perPage}&host=movieboxapp.in`;
        const responseData = await fetchUpstream(upstreamUrl, 'GET');

        const rawSubjectList = responseData.data?.subjectList || [];
        const pager = responseData.data?.pager || {};
        const sectionTitle = responseData.data?.title || "Daftar Konten";

        // Mapping ulang agar formatnya seragam dengan route `/api/home`
        const mappedItems = rawSubjectList.map((s: any) => {
            return {
                is_live_sport: false,
                subjectId: s.subjectId || "",
                detailPath: s.detailPath || "",
                subjectType: s.subjectType || 1,
                title: s.title || "",
                description: s.description || "",
                releaseDate: s.releaseDate || "",
                appointmentDate: s.appointmentDate || "",
                genre: s.genre || "",
                cover_url: s.cover?.url || "",
                country: s.countryName || "",
                bahasa: s.subtitles || "",
                rating: parseFloat(s.imdbRatingValue || "0"),
                trailer_url: s.trailer?.videoAddress?.url || "",
                view: parseInt(s.imdbRatingCount || "0", 10),
                corner_badge: s.corner || "",
                totalEpisode: 1,
                totalSeason: s.season || 1
            };
        });

        // Response balik yang udah rapi
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: {
                section_title: sectionTitle,
                items: mappedItems,
                pagination: {
                    hasMore: pager.hasMore || false,
                    page: parseInt(pager.page || page, 10),
                    nextPage: pager.nextPage ? parseInt(pager.nextPage, 10) : null,
                    perPage: parseInt(pager.perPage || perPage, 10),
                    totalCount: pager.totalCount || 0
                }
            }
        });

    } catch (error: any) {
        return NextResponse.json(
            { code: 502, message: error.message, data: null },
            { status: 502 }
        );
    }
}