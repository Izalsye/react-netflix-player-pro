// file: api/mangaplus/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const lang = req.nextUrl.searchParams.get('lang');
    const clang = req.nextUrl.searchParams.get('lang');
    const titleIdParam = req.nextUrl.searchParams.get('titleId');

    // 1. Validasi parameter ID komik wajib ada
    if (!titleIdParam) {
        return NextResponse.json(
            { code: 400, message: "Missing required parameter: titleId", data: null },
            { status: 400 }
        );
    }

    const titleId = parseInt(titleIdParam);
    if (isNaN(titleId)) {
        return NextResponse.json(
            { code: 400, message: "Parameter titleId must be a valid number", data: null },
            { status: 400 }
        );
    }

    // 2. Inisialisasi client MangaPlus
    const client = new MangaPlusClient({ lang });

    // 3. Eksekusi request lewat proxy dengan label tracking statistik ID komik terkait
    return client.proxy(req, `/mangaplus/detail/${titleId}`, () =>
        client.getTitleDetailClean(titleId)
    );
}