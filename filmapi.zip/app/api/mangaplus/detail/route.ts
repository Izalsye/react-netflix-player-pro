// file: api/mangaplus/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    const lang = searchParams.get('lang') || 'ind';
    // Perbaikan typo: ambil parameter 'clang', kalau kosong fallback ke 'lang'
    const clang = searchParams.get('clang') || lang;
    const titleIdParam = searchParams.get('titleId');

    // 1. Validasi parameter ID komik wajib ada
    if (!titleIdParam) {
        return NextResponse.json(
            { code: 400, message: "Missing required parameter: titleId", data: null },
            { status: 400 }
        );
    }

    const titleId = parseInt(titleIdParam);
    if (isNaN(titleId)) {
        return NextResponse.json(
            { code: 400, message: "Parameter titleId must be a valid number", data: null },
            { status: 400 }
        );
    }

    // 2. Inisialisasi client MangaPlus
    const client = new MangaPlusClient({ lang, clang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT DETAIL KOMIK 🔥
        const cacheKey = `mangaplus:detail:lang:${lang}:clang:${clang}:id:${titleId}`;
        const cacheTTL = 300; // 5 Menit (Biar list chapter baru cepet muncul!)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper proxy, tembak fungsi core-nya langsung
            const data = await client.getTitleDetailClean(titleId);
            return data;
        }, cacheTTL);

        // Kembalikan response JSON super ringan dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}