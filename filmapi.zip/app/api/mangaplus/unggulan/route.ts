// file: api/mangaplus/unggulan/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    const lang = searchParams.get('lang') || 'ind';

    // Inisialisasi client dengan preferensi bahasa
    const client = new MangaPlusClient({ lang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT UNGGULAN MANGAPLUS 🔥
        const cacheKey = `mangaplus:unggulan:lang:${lang}`;
        const cacheTTL = 3600; // 1 Jam (Daftar unggulan sangat jarang berubah)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper .proxy dan tembak langsung
            const data = await client.getFeaturedClean();
            return data;
        }, cacheTTL);

        // Kembalikan response JSON super ringan dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}