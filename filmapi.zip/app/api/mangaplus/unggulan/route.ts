// file: api/mangaplus/unggulan/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');

    // Inisialisasi client dengan preferensi bahasa
    const client = new MangaPlusClient({ lang });

    // Kirim ke proxy wrapper dengan label statistik khusus
    return client.proxy(req, "/mangaplus/unggulan", () => client.getFeaturedClean());
}