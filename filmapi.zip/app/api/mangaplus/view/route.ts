// file: api/mangaplus/view/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pamungkas Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    const lang = searchParams.get('lang') || 'ind';
    const chapterIdParam = searchParams.get('chapterId');

    if (!chapterIdParam) {
        return NextResponse.json({ code: 400, message: "Missing required parameter: chapterId", data: null }, { status: 400 });
    }

    const chapterId = parseInt(chapterIdParam);
    if (isNaN(chapterId)) {
        return NextResponse.json({ code: 400, message: "Parameter chapterId must be a valid number", data: null }, { status: 400 });
    }

    // Cukup lempar parameter 'lang', otomatisasi clang dikelola di dalam constructor client
    const client = new MangaPlusClient({ lang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT VIEWER CHAPTER 🔥
        const cacheKey = `mangaplus:view:lang:${lang}:chapter:${chapterId}`;
        const cacheTTL = 1800; // 30 Menit (Biar URL gambar gak kedaluwarsa)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper .proxy dan hajar langsung Protobuf-nya
            const data = await client.getMangaDataClean(chapterId, { split: true, free: true });
            return data;
        }, cacheTTL);

        // Kembalikan response JSON murni dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}