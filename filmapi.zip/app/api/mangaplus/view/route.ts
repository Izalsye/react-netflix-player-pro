// file: api/mangaplus/view/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');
    const chapterIdParam = req.nextUrl.searchParams.get('chapterId');

    if (!chapterIdParam) {
        return NextResponse.json({ code: 400, message: "Missing required parameter: chapterId", data: null }, { status: 400 });
    }

    const chapterId = parseInt(chapterIdParam);
    if (isNaN(chapterId)) {
        return NextResponse.json({ code: 400, message: "Parameter chapterId must be a valid number", data: null }, { status: 400 });
    }

    // Cukup lempar parameter 'lang', otomatisasi clang dikelola di dalam constructor client
    const client = new MangaPlusClient({ lang });

    return client.proxy(req, `/mangaplus/view/${chapterId}`, () =>
        client.getMangaDataClean(chapterId, { split: true, free: true })
    );
}