// file: api/mangaplus/list/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { TitleType } from '@/lib/mangaplus/constants';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');
    const clang = req.nextUrl.searchParams.get('clang');
    const typeParam = req.nextUrl.searchParams.get('type');

    let titleType = TitleType.SERIALIZING; // Default: SERIALIZING (Ongoing)

    if (typeParam) {
        const lowerType = typeParam.toLowerCase();

        // Aliasing: Kalau user input 'ongoing', belokkan ke 'serializing'
        if (lowerType === 'ongoing') {
            titleType = TitleType.SERIALIZING;
        } else {
            // Cari kecocokan enum biasa untuk 'completed' atau 'one-shot'
            const found = Object.entries(TitleType).find(([_, val]) => val === lowerType);
            if (found) titleType = found[1] as TitleType;
        }
    }

    // Inisialisasi client
    const client = new MangaPlusClient({ lang, clang });

    // Kirim ke proxy wrapper dengan label statistik
    // Kita pakai label 'ongoing' juga biar log stats lu makin rapi dan manusiawi
    const statsLabel = titleType === TitleType.SERIALIZING ? 'ongoing' : typeParam?.toLowerCase();

    return client.proxy(req, `/mangaplus/list/${statsLabel}`, () =>
        client.getAllTitlesClean(titleType)
    );
}