// file: api/mangaplus/list/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { TitleType } from '@/lib/mangaplus/constants';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    const lang = searchParams.get('lang') || 'ind';
    // Fallback clang ke lang kalau user gak ngisi
    const clang = searchParams.get('clang') || lang;
    const typeParam = searchParams.get('type');

    let titleType = TitleType.SERIALIZING; // Default: SERIALIZING (Ongoing)

    if (typeParam) {
        const lowerType = typeParam.toLowerCase();

        // Aliasing: Kalau user input 'ongoing', belokkan ke 'serializing'
        if (lowerType === 'ongoing') {
            titleType = TitleType.SERIALIZING;
        } else {
            // Cari kecocokan enum biasa untuk 'completed' atau 'one-shot'
            const found = Object.entries(TitleType).find(([_, val]) => val === lowerType);
            if (found) titleType = found[1] as TitleType;
        }
    }

    // Inisialisasi client
    const client = new MangaPlusClient({ lang, clang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT LIST MANGAPLUS 🔥
        // Ingat, datanya beda-beda tiap bahasa & tipe, jadi key-nya harus detail
        const cacheKey = `mangaplus:list:lang:${lang}:clang:${clang}:type:${titleType}`;
        const cacheTTL = 3600; // 1 Jam (Katalog manga jarang banget nambah tiap menit)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper .proxy dan tembak langsung fungsi utamanya
            // CPU lu cuma decode Protobuf 1x dalam sejam buat kombinasi filter ini!
            const data = await client.getAllTitlesClean(titleType);
            return data;
        }, cacheTTL);

        // Kembalikan response JSON kilat dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}