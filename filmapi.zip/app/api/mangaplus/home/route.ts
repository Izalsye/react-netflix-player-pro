// file: app/api/mangaplus/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis masuk

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    // Tangkap bahasa, default-kan ke string kosong atau biarkan client.ts yang urus fallback
    const lang = searchParams.get('lang') || 'ind';

    const client = new MangaPlusClient({ lang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT MANGAPLUS HOME BERDASARKAN BAHASA 🔥
        const cacheKey = `mangaplus:home:lang:${lang}`;
        // Set 10 Menit (600 detik) - Sangat aman untuk nunggu chapter baru rilis
        const cacheTTL = 600;

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper .proxy dan langsung ambil eksekutor core-nya
            // Di sini CPU lu kerja keras nge-decode Protobuf (cuma 1x tiap 10 menit)
            const data = await client.getHomeClean();
            return data;
        }, cacheTTL);

        // Kembalikan response JSON super ringan dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}