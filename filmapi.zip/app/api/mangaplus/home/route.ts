// file: api/mangaplus/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');

    // Instansiasi langsung passing string query param mentah, urusan mapping bahasa diatur di dalam client
    const client = new MangaPlusClient({ lang });

    // Tinggal panggil dengan menyertakan label tracking stats
    return client.proxy(req, "/mangaplus/home", () => client.getHomeClean());
}