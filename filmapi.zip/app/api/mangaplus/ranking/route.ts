// file: api/mangaplus/ranking/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { Ranking } from '@/lib/mangaplus/constants';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;
    const lang = searchParams.get('lang') || 'ind';
    // Fallback clang ke lang kalau user gak ngisi
    const clang = searchParams.get('clang') || lang;
    const typeParam = searchParams.get('type');

    // 1. Validasi & mapping query 'type' ke format Enum Ranking internal
    let rankingType = Ranking.HOTTEST; // Default value
    if (typeParam) {
        const found = Object.entries(Ranking).find(([_, val]) => val === typeParam.toLowerCase());
        if (found) rankingType = found[1] as Ranking;
    }

    // 2. Inisialisasi client
    const client = new MangaPlusClient({ lang, clang });

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT RANKING MANGAPLUS 🔥
        const cacheKey = `mangaplus:ranking:lang:${lang}:clang:${clang}:type:${rankingType}`;
        const cacheTTL = 3600; // 1 Jam (Sangat hemat CPU!)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Bypass wrapper .proxy dan tembak langsung fungsi utamanya
            // CPU cuma kerja baca Protobuf 1x sejam buat rute ini
            const data = await client.getRankingClean(rankingType);
            return data;
        }, cacheTTL);

        // Kembalikan response JSON kilat dari Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}