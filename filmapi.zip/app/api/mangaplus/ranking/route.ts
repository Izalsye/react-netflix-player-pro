// file: api/mangaplus/ranking/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { Ranking } from '@/lib/mangaplus/constants';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');
    const clang = req.nextUrl.searchParams.get('clang');
    const typeParam = req.nextUrl.searchParams.get('type');

    // 1. Validasi & mapping query 'type' ke format Enum Ranking internal
    let rankingType = Ranking.HOTTEST; // Default value
    if (typeParam) {
        const found = Object.entries(Ranking).find(([_, val]) => val === typeParam.toLowerCase());
        if (found) rankingType = found[1] as Ranking;
    }

    // 2. Inisialisasi client
    const client = new MangaPlusClient({ lang, clang });

    // 3. Eksekusi ke proxy dengan label statistik ranking
    return client.proxy(req, `/mangaplus/ranking/${rankingType}`, () =>
        client.getRankingClean(rankingType)
    );
}