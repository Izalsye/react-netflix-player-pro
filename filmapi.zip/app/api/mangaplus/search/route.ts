// file: api/mangaplus/search/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { MangaPlusClient } from '@/lib/mangaplus/client';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

/**
 * Helper Fuzzy/Similarity Matcher Minimalis
 * Mengembalikan skor kemiripan antara 0 (beda total) sampai 1 (sama persis)
 */
function hitungKemiripanTeks(str1: string, str2: string): number {
    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();

    if (s1 === s2) return 1.0;
    if (s1.includes(s2) || s2.includes(s1)) return 0.8; // Bobot tinggi jika potongan kata masuk

    // Algoritma Levenshtein Distance buat nangkep typo/kemiripan karakter
    const track = Array(s2.length + 1).fill(null).map(() => Array(s1.length + 1).fill(null));
    for (let i = 0; i <= s1.length; i += 1) track[0][i] = i;
    for (let j = 0; j <= s2.length; j += 1) track[j][0] = j;

    for (let j = 1; j <= s2.length; j += 1) {
        for (let i = 1; i <= s1.length; i += 1) {
            const indicator = s1[i - 1] === s2[j - 1] ? 0 : 1;
            track[j][i] = Math.min(
                track[j][i - 1] + 1, // Penghapusan
                track[j - 1][i] + 1, // Penyisipan
                track[j - 1][i - 1] + indicator // Substitusi
            );
        }
    }

    const distance = track[s2.length][s1.length];
    const maxLength = Math.max(s1.length, s2.length);
    return (maxLength - distance) / maxLength;
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'mangaplus');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const lang = req.nextUrl.searchParams.get('lang');
    const queryParam = req.nextUrl.searchParams.get('q');

    if (!queryParam || queryParam.trim() === "") {
        return NextResponse.json({ code: 400, message: "Missing required parameter: q", data: null }, { status: 400 });
    }

    const searchQuery = queryParam.toLowerCase().trim();
    const client = new MangaPlusClient({ lang });

    return client.proxy(req, `/mangaplus/search/${encodeURIComponent(searchQuery)}`, async () => {
        const allTitlesList = await client.getAllTitlesClean();
        const booksArray = allTitlesList?.daftarBuku || [];

        // 1. Map data komik sambil disisipkan skor kemiripan teks
        const scoredResults = booksArray.map((buku: any) => {
            const skorJudul = hitungKemiripanTeks(buku.judul || "", searchQuery);
            const skorAuthor = hitungKemiripanTeks(buku.author || "", searchQuery);

            // Ambil skor tertinggi antara kecocokan judul atau author
            const skorTertinggi = Math.max(skorJudul, skorAuthor);

            return {
                ...buku,
                _score: skorTertinggi // Property internal sementara buat sorting
            };
        });

        // 2. Filter komik yang skor kemiripannya di atas ambang batas (threshold)
        // Kita pakai threshold 0.25 (Artinya typo dikit atau mirip kata kuncinya tetep lolos saringan)
        const filteredResults = scoredResults.filter((buku: any) => buku._score >= 0.25);

        // 3. Urutkan dari yang PALING MIRIP sampai yang agak mirip (Descending)
        filteredResults.sort((a: any, b: any) => b._score - a._score);

        // 4. Bersihkan property temporary score batiniah tadi biar JSON lu tetep rapi
        const cleanResults = filteredResults.map(({ _score, ...rest }) => rest);

        return {
            query: queryParam,
            totalDitemukan: cleanResults.length,
            daftarBuku: cleanResults
        };
    });
}