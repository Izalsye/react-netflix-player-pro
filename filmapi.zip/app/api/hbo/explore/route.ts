// app/api/hbo/explore/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats'; 
import { hboProxy } from '@/lib/hbo/proxy';
import { HboDataMapper } from '@/lib/hbo/mapper';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 1. Validasi API Key
    const auth = await validateApiKey(req, 'hbo');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 2. Ambil parameter dari URL
    const searchParams = req.nextUrl.searchParams;
    const id = searchParams.get('id');
    const type = searchParams.get('type') || 'collection'; // default collection
    const page = searchParams.get('page') || '1'; // Buat pagination collection

    if (!id) {
        return NextResponse.json(
            { code: 400, message: "Parameter 'id' wajib diisi", data: null },
            { status: 400 }
        );
    }

    // 3. Tentukan Endpoint HBO berdasarkan tipe
    let endpoint = '';
    const queryParams: Record<string, string> = {
        include: 'default',
        decorators: 'viewingHistory,isFavorite,contentAction,badges',
        'page[items.size]': '10',
        'pf[wpo.page]' : 'eyJwYWdlSWQiOiIxNjgwMjk4NzAyNTUzMDU0MTA0ODk1MTIxNjMzNDk5NDczMDM0MTEiLCJjb2hvcnRLZXkiOiI6YjQ0M2U2NjEwMmQ1NTk1YTFkYTJhYWY1N2FkZWNjZWUifQ'
    };

    if (type === 'channel') {
        endpoint = `/cms/routes/channel/${id}`;
    } else if (type === 'genre') {
        endpoint = `/cms/routes/genre/${id}`;
    } else if (type === 'collection') {
        endpoint = `/cms/collections/${id}?include=default&decorators=viewingHistory,isFavorite,contentAction,badges`;
        queryParams['page[items.number]'] = page;  // Pagination khusus collection
    } else {
        return NextResponse.json(
            { code: 400, message: "Type tidak valid. Pilih: channel, genre, atau collection", data: null },
            { status: 400 }
        );
    }

    try {
        // 4. Tembak Proxy HBO
        const proxyResponse = await hboProxy(req as any, endpoint, 'GET', queryParams);

        if (!proxyResponse.ok) {
            const errData = await proxyResponse.json().catch(() => ({}));
            return NextResponse.json(
                { code: proxyResponse.status, message: errData.message || "Gagal narik data dari HBO", data: null },
                { status: proxyResponse.status }
            );
        }

        const rawData = await proxyResponse.json();

        // 5. Cek tipe data balikan buat nentuin Mapper mana yang dipakai
        let mappedData = null;
        const rootType = rawData?.data?.type;

        // Channel dan Genre biasanya ngembaliin tipe "route" (mirip Home)
        if (rootType === 'route' || rootType === 'page') {
            mappedData = HboDataMapper.mapHomepage(rawData);
        }
        // Collection ngembaliin tipe "collection"
        else if (rootType === 'collection') {
            mappedData = HboDataMapper.mapSingleCollection(rawData);
        }

        if (!mappedData) {
            return NextResponse.json(
                { code: 404, message: "Struktur data HBO berubah / data kosong", data: null },
                { status: 404 }
            );
        }

        // 6. Return data yang udah dimapping
        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error('[HBO Explore API Error]:', error.message);
        return NextResponse.json(
            { code: 502, message: error.message || "Internal Server Error", data: null },
            { status: 502 }
        );
    }
}