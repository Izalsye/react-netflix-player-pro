// app/api/hbo/movies/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { hboProxy } from '@/lib/hbo/proxy';
import { HboDataMapper } from '@/lib/hbo/mapper';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'hbo');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // Cuma butuh 'default' biar HBO ngasih susunan ID rak-nya
        const queryParams = { include: 'default' };

        const proxyResponse = await hboProxy(req as any, '/cms/routes/movies', 'GET', queryParams);

        if (!proxyResponse.ok) {
            const errData = await proxyResponse.json();
            return NextResponse.json(
                { code: proxyResponse.status, message: errData.message || "Gagal narik data movies HBO", data: null },
                { status: proxyResponse.status }
            );
        }

        const rawData = await proxyResponse.json();

        // Panggil mapSeriesPage yang baru kita buat
        const mappedData = HboDataMapper.mapSeriesPage(rawData);

        if (!mappedData) {
            return NextResponse.json({ code: 404, message: "Struktur data kosong", data: null }, { status: 404 });
        }

        // Return datanya dipisah sesuai desain UI Halaman Series
        return NextResponse.json(
            mappedData
        );

    } catch (error: any) {
        console.error('[HBO movies API Error]:', error.message);
        return NextResponse.json(
            { code: 502, message: error.message || "Internal Server Error", data: null },
            { status: 502 }
        );
    }
}