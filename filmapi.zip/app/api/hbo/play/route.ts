// app/api/hbo/play/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { hboProxy } from '@/lib/hbo/proxy';
import { HboDataMapper } from '@/lib/hbo/mapper';
import { getFreshHboSession } from '@/lib/hbo/authService'; // 🔥 Import layanan Auto-Refresh

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 1. Validasi API Key
    const auth = await validateApiKey(req, 'hbo');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 2. Tangkap query param 'id'
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
        return NextResponse.json(
            { code: 400, message: "Parameter 'id' wajib dikirim", data: null },
            { status: 400 }
        );
    }

    try {
        // ==========================================
        // STEP A: Resolves ID ke Edit ID
        // ==========================================
        const queryParams = {
            include: 'default',
            decorators: 'viewingHistory,isFavorite,contentAction,badges',
            'page[items.size]': 10
        };

        const routeResponse = await hboProxy(
            req as any,
            `/cms/routes/video/watch/${id}`,
            'GET',
            queryParams
        );

        if (!routeResponse.ok) {
            return NextResponse.json(
                { code: routeResponse.status, message: "Video/Route ID tidak ditemukan di HBO", data: null },
                { status: routeResponse.status }
            );
        }

        const routeData = await routeResponse.json();
        let targetEditId = id;

        if (routeData.included && Array.isArray(routeData.included)) {
            const editItem = routeData.included.find((item: any) => item.type === 'edit');
            if (editItem) {
                targetEditId = editItem.id;
            } else {
                const videoItem = routeData.included.find((item: any) => item.type === 'video' && item.relationships?.edit?.data?.id);
                if (videoItem) {
                    targetEditId = videoItem.relationships.edit.data.id;
                }
            }
        }

        // ==========================================
        // STEP B: Rakit Payload POST
        // ==========================================
        const payload = {
            "appBundle": "hbomax",
            "advertisingInfo": {
                "adBlockerDetection": false,
                "debug": {},
                "device": {},
                "googlePALNonce": "",
                "server": {
                    "deviceId": "",
                    "iabTCFString": "CQp8-lAQp8-lAAcABBDECuFgAPLAAAAAABpYKPMB3C58DWFDaSZ1IIskeYQX0RABxkQhAgLAAiABiBKAKIQAkCAAIAQANCACEAIAMHBBAAFEDAAAAEAAIAAAIBBMIAAQABBIIABAAAABAAAQCAgAAABAAQAYAmAUAAcAmQAFgVIsAFAAAABCAACBIAAAEAAFAAEAAAAAAAIAAQAAoiwABQAAjAAAAAAAABgQEAAAAAAAAIIAAAAAAAAAAAAAAAAAEAAAB4KACBHYIAEAAcAJwBiwEKwkCgABYAFQAOAAeABAADIAGgAPAAigBMACkAFUAN4AfgBCACGAEcAJoAYYAygBzgDuAH6AP8AkoBaQC-gGKAOIAe0BIgCdgFDgLYAXmAwgBlwDYwIMAQvEQAQC0ioAgATABHAGKAPaMgCABMAEcAYoA9o4ARAA4ADwALgBoAEcAQgBMQDFgIVjoFoACwAKgAcABAADIAGgAPAAigBMACkAFUAMQAbwA_ACGAE0AJwAYYAygBogDnAHcAP0Af4BFgCOgElAMUAcQA9oB9gEWAIvASIAnYBQ4C2AF5gL6AZYAy4B_YEAQIMASrIAAwAHgBoAhWQgIgALACYAFUAMQAbwBHADnAHcAP8AtIBfQDFAHtAQsAiwB_YEGCQAUAC4A7gExAMWAZYSgKgALAA4ADwAJgAUgAqgBiAEMAI4AtIBigD2gIWARYAi8BIgC2AF5gQBAgwBKsoALAAuAI4ATgA7gD_gJiAVIArIBiwEKwIXlIEwACwAKgAcABAADIAGgAPAAigBMACkAFUAMQAfgBDADKAGiAOcAfoBFgCOgElALqAYoA9oB9gELAIvASIAnYBQ4C2AF5gL6AZYAy4B_YEGAJVlgDYADwAMgAqABYAEIAJAAbABHACkAHcAUUApoBdgDCAGcANOAdUA9oB9gECgIWATEAtgBj4DYwICgQwA.IKPMB3C58DWFDaSZ1IIskeYQX0RABxkQhAgLAAiABiBKAKIQAkCAAIAQANCACEAIAMHBBAAFEDAAAAEAAIAAAIBBMIAAQABBIIABAAAABAAAQCAgAAABAAQAYAmAUAAcAmQAFgVIsAFAAAABCAACBIAAAEAAFAAEAAAAAAAIAAQAAoiwABQAAjAAAAAAAABgQEAAAAAAAAIIAAAAAAAAAAAAAAAAAEA.YAAAAAAAAAAA",
                    "isLimitedAdTracking": 0,
                    "nielsenAppId": ""
                },
                "ssaiProvider": {
                    "version": "2.3.0"
                }
            },
            "consumptionType": "streaming",
            "deviceInfo": {
                "deviceId": "a4647383-ccb5-4163-9239-d5afde4d0dbd", // <-- Pastikan sinkron dengan proxy.ts
                "browser": { "name": "Chrome", "version": "151.0.0.0" },
                "make": "desktop",
                "model": "desktop",
                "os": { "name": "Windows", "version": "NT 10.0" },
                "platform": "WEB",
                "deviceType": "web",
                "player": {
                    "sdk": { "name": "Beam Player Desktop", "version": "7.10.0" },
                    "mediaEngine": {
                        "name": "GLUON_BROWSER",
                        "version": "9.2.0",
                        "labsConfigVersion": "playback_engine_gluon@web-1.3.0,playback_engine_gluon_disable_network_request_event@1.0.0,playback_engine_gluon_segment_download_during_drminit@1.0.0,playback_engine_gluon_abr_protocol_hybrid@1.0.0,playback_engine_gluon_initial_track_selection@1.0.0,playback_engine_gluon_disable_video_element_dom_check@1.0.0,playback_engine_gluon_cmcd@default-1.1.0,"
                    },
                    "playerView": { "height": 800, "width": 1280 }
                }
            },
            "editId": targetEditId,
            "capabilities": {
                "manifests": { "formats": { "dash": {} } },
                "contentProtection": {
                    "contentDecryptionModules": [
                        { "drmKeySystem": "clearkey" },
                        { "drmKeySystem": "widevine", "maxSecurityLevel": "l3" }
                    ]
                }
            },
            "gdpr": false,
            "firstPlay": false,
            "playbackSessionId": crypto.randomUUID(),
            "applicationSessionId": crypto.randomUUID(),
            "userPreferences": {
                "videoQuality": "best",
                "uiLanguage": "en-US",
                "text": { "language": "id", "type": "subtitles", "enabled": true }
            },
            "features": ["mlp"],
            "playbackContext": "watch"
        };

        // ==========================================
        // STEP C: Fungsi Helper Hit API Playback
        // ==========================================
        const fetchPlaybackInfo = async () => {
            const proxyResponse = await hboProxy(req as any, '/any/playback/v1/playbackInfo', 'POST', {}, payload);

            let data = null;
            try { data = await proxyResponse.json(); } catch (e) { }

            return { ok: proxyResponse.ok, status: proxyResponse.status, data };
        };

        // Tembakan Pertama
        let playbackResponse = await fetchPlaybackInfo();

        // ==========================================
        // 🚀 STEP D: LOGIKA AUTO-REFRESH (LAZY REFRESH)
        // ==========================================
        const mainVideo = playbackResponse.data?.videos?.find((v: any) => v.type === 'main') || playbackResponse.data?.videos?.[0];

        // Deteksi apakah kena limitasi (Tidak ada DRM & Durasi < 5 Menit) ATAU Auth Error
        const isFreeTierDetected = playbackResponse.ok && (!playbackResponse.data?.drm && mainVideo?.duration < 300);
        const isAuthError = !playbackResponse.ok && (playbackResponse.status === 401 || playbackResponse.status === 403);

        if (isFreeTierDetected || isAuthError) {
            console.warn("[HBO Play API] ⚠️ Session Kadaluarsa atau Terdeteksi Free Tier! Menjalankan Auto-Refresh...");

            const masterCookie = process.env.HBO_COOKIE || '';
            const refreshResult = await getFreshHboSession(masterCookie);

            if (refreshResult.success && refreshResult.sessionState) {
                // Update environment variables di memori proses NodeJS
                process.env.HBO_COOKIE = refreshResult.activeCookie;
                process.env.HBO_SESSION_STATE = refreshResult.sessionState;

                console.log("[HBO Play API] ✅ Auto-Refresh Berhasil! Mengulang request playback...");

                // Tembakan Kedua (Retry) dengan session yang baru
                playbackResponse = await fetchPlaybackInfo();
            } else {
                console.error("[HBO Play API] ❌ Auto-Refresh Gagal:", refreshResult.error);
            }
        }

        // ==========================================
        // STEP E: Tangani Error Final & Mapping
        // ==========================================
        const rawData = playbackResponse.data;

        if (!playbackResponse.ok || rawData?.errors || rawData?.code >= 400) {
            console.error("[HBO Play API] HBO Backend Error:", JSON.stringify(rawData));
            return NextResponse.json(
                { code: playbackResponse.status, message: rawData?.message || "Gagal mengambil data Playback dari HBO", data: rawData },
                { status: playbackResponse.status === 200 ? 400 : playbackResponse.status }
            );
        }

        const mappedData = HboDataMapper.mapPlaybackData(rawData);

        if (!mappedData) {
            console.error("[HBO Mapper] Playback manifest not found in response.");
            return NextResponse.json(
                { code: 404, message: "Data stream tidak ditemukan atau struktur JSON berubah", data: null },
                { status: 404 }
            );
        }

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error(`[HBO Play API Error | ID: ${id}]:`, error.message);
        return NextResponse.json(
            { code: 502, message: error.message || "Internal Server Error", data: null },
            { status: 502 }
        );
    }
}