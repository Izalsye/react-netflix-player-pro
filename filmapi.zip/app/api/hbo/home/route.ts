// app/api/hbo/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
// import { recordHit } from '@/lib/stats'; // Buka komen kalau lu udh ada file ini
import { hboProxy } from '@/lib/hbo/proxy';
import { HboDataMapper } from '@/lib/hbo/mapper';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 1. Validasi API Key (Kayak di Filmbox)
    const auth = await validateApiKey(req, 'hbo');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // 2. Siapkan parameter untuk nge-hit Home HBO Max
        // Param ini wajib dikirim biar balikan JSON-nya lengkap
        const queryParams = {
            include: 'default',
            decorators: 'viewingHistory,isFavorite,contentAction,badges',
            'page[items.size]': 10
        };

        // 3. Tembak Proxy HBO
        // Kita manfaatin fungsi proxy yang otomatis nerusin Cookie & Auth headers
        const proxyResponse = await hboProxy(
            req as any, // casting kalau typescript protes
            '/cms/routes/home',
            'GET',
            queryParams
        );

        // Kalau HTTP status error, lempar ke frontend
        if (!proxyResponse.ok) {
            const errData = await proxyResponse.json();
            return NextResponse.json(
                { code: proxyResponse.status, message: errData.message || "Gagal narik data HBO", data: null },
                { status: proxyResponse.status }
            );
        }

        const rawData = await proxyResponse.json();

        // 4. MAP DATA PAKE MAPPER JENIUS LU
        const mappedData = HboDataMapper.mapHomepage(rawData);

        if (!mappedData) {
            return NextResponse.json(
                { code: 404, message: "Struktur data HBO berubah / kosong", data: null },
                { status: 404 }
            );
        }

        // 5. Kembalikan data dengan format seragam kayak Filmbox
        // (Biar frontend lu nggak pusing ngolah datanya)
        return NextResponse.json(
            mappedData);

    } catch (error: any) {
        console.error('[HBO Home API Error]:', error.message);
        return NextResponse.json(
            { code: 502, message: error.message || "Internal Server Error", data: null },
            { status: 502 }
        );
    }
}