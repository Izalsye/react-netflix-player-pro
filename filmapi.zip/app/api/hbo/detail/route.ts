import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { hboProxy } from '@/lib/hbo/proxy';
import { HboDataMapper } from '@/lib/hbo/mapper';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 1. Validasi API Key
    const auth = await validateApiKey(req, 'hbo');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 2. Tangkap query param 'id'
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    // Validasi kalau ID kosong
    if (!id) {
        return NextResponse.json(
            { code: 400, message: "Parameter 'id' wajib dikirim", data: null },
            { status: 400 }
        );
    }

    try {
        // 3. Siapkan parameter wajib dari HBO
        const queryParams = {
            include: 'default',
            decorators: 'viewingHistory,isFavorite,contentAction,badges',
            'page[items.size]': 10
        };

        // 4. Tembak Proxy HBO (Coba sebagai SHOW / Series dulu)
        let proxyResponse = await hboProxy(
            req as any,
            `/cms/routes/show/${id}`,
            'GET',
            queryParams
        );

        // 🔥 FALLBACK: Kalau ternyata 404, berarti ini MOVIE, bukan SHOW
        if (proxyResponse.status === 404) {
            proxyResponse = await hboProxy(
                req as any,
                `/cms/routes/movie/${id}`,
                'GET',
                queryParams
            );
        }

        if (!proxyResponse.ok) {
            const errData = await proxyResponse.json().catch(() => ({}));
            return NextResponse.json(
                { code: proxyResponse.status, message: errData.message || "Gagal narik data HBO (Pastikan ID Valid)", data: null },
                { status: proxyResponse.status }
            );
        }

        const rawData = await proxyResponse.json();

        // 5. MAP DATA PAKAI MAPPER (Sekarang kirim ID ke dalam mapper)
        const mappedData = HboDataMapper.mapDetailPage(rawData, id);

        if (!mappedData) {
            return NextResponse.json(
                { code: 404, message: "Struktur data HBO berubah / kosong", data: null },
                { status: 404 }
            );
        }

        // 6. Kembalikan data clean
        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error(`[HBO Detail API Error | ID: ${id}]:`, error.message);
        return NextResponse.json(
            { code: 502, message: error.message || "Internal Server Error", data: null },
            { status: 502 }
        );
    }
}