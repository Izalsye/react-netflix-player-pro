// series/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';
const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);

        const page = searchParams.get('page') || '1';
        const limit = searchParams.get('limit') || '36';
        const sort = searchParams.get('sort') || 'createdAt';

        const genre = searchParams.get('genre') || '';
        const country = searchParams.get('country') || '';
        const year = searchParams.get('year') || '';

        const query: Record<string, string> = { page, limit, sort };
        if (genre) query.genre = genre;
        if (country) query.country = country;
        if (year) query.year = year;

        // 🔥 CACHE KEY KHUSUS SERIES BESERTA FILTERNYA 🔥
        const cacheKey = `idlix:series:page:${page}:limit:${limit}:sort:${sort}:genre:${genre || 'all'}:country:${country || 'all'}:year:${year || 'all'}`;
        const cacheTTL = 600; // 10 Menit

        const mappedData = await getOrSetCache(cacheKey, async () => {
            // 🚀 Ganti path targetnya jadi /api/series
            const responseData = await proxyGet(req, "/api/series", query, {
                label: '/idlix/series',
                cacheTtlMs: 120000,
                send: false,
                headers: {
                    'Referer': `https://z2.idlixku.com/series`,
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            // Proteksi jika terjadi error pada proxy
            if (!responseData || responseData.error) {
                throw {
                    status: responseData?.status || 502,
                    message: responseData?.message || "Failed to fetch series from Idlix"
                };
            }

            // 🎯 MAP DATA SERIES:
            return IdlixDataMapper.mapSeriesResponse
                ? IdlixDataMapper.mapSeriesResponse(responseData)
                : IdlixDataMapper.mapMoviesResponse(responseData);
        }, cacheTTL);

        return NextResponse.json(mappedData);
    } catch (error: any) {
        console.error("[Route Series Error]:", error?.message);
        const status = error.status || 500;
        return NextResponse.json(
            { error: true, message: error?.message || "Internal Server Error" },
            { status }
        );
    }
}