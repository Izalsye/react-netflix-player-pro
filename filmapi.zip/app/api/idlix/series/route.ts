import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';

export const dynamic = 'force-dynamic';
const USE_PROXY_FOR_THIS_ROUTE = false;
export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);

        const query: Record<string, string> = {
            page: searchParams.get('page') || '1',
            limit: searchParams.get('limit') || '36',
            sort: searchParams.get('sort') || 'createdAt', // 👈 Default sort disamakan dengan contoh lu
        };

        const genre = searchParams.get('genre');
        const country = searchParams.get('country');
        const year = searchParams.get('year');

        if (genre) query.genre = genre;
        if (country) query.country = country;
        if (year) query.year = year;

        // 🚀 Ganti path targetnya jadi /api/series
        const responseData = await proxyGet(req, "/api/series", query, {
            label: '/idlix/series',
            cacheTtlMs: 120000,
            send: false,
            headers: {
                'Referer': `https://z2.idlixku.com/series`, // 👈 Referer wajib ngikutin halaman series
            },
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });

        // Proteksi jika terjadi error pada proxy
        if (!responseData || responseData.error) {
            return NextResponse.json(responseData, { status: responseData?.status || 502 });
        }

        // 🎯 MAP DATA SERIES:
        // Catatan: Kalau format JSON series dari Idlix beda sama movies, pake fungsi map khusus series.
        // Kalau formatnya sama persis (misal cuma list title, poster, id), bisa pake mapMoviesResponse juga.
        const cleanSeriesData = IdlixDataMapper.mapSeriesResponse 
            ? IdlixDataMapper.mapSeriesResponse(responseData) 
            : IdlixDataMapper.mapMoviesResponse(responseData);

        return NextResponse.json(cleanSeriesData);
    } catch (error: any) {
        console.error("[Route Series Error]:", error?.message);
        return NextResponse.json(
            { error: true, message: error?.message || "Internal Server Error" },
            { status: 500 }
        );
    }
}