import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const slug = searchParams.get('slug');
        const type = searchParams.get('type') || 'movie';

        if (!slug) {
            return NextResponse.json({ success: false, message: "slug wajib diisi" }, { status: 400 });
        }

        const isSeries = type.toLowerCase() === 'series';
        const targetPath = isSeries ? `/api/series/${slug}` : `/api/movies/${slug}`;
        const refererPath = isSeries ? `series/${slug}` : `movie/${slug}`;

        // 1. Fetch data detail utama
        const responseData = await proxyGet(req, targetPath, {}, {
            label: `/idlix/detail-${type}`,
            cacheTtlMs: 300000,
            send: false,
            headers: {
                'Referer': `https://z2.idlixku.com/${refererPath}`
            },
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });

        // Proteksi jika terjadi error pada proxy/upstream
        if (!responseData || responseData.error) {
            return NextResponse.json(responseData, { status: responseData?.status || 502 });
        }

        // 2. 🎯 MAP DATA DETAIL AWAL AGAR BERSIH DAN SIAP DIKONSUMSI FRONTEND
        const cleanDetailData = IdlixDataMapper.mapDetailResponse(responseData);

        // 3. 🎯 FETCH MISSING EPISODES JIKA ITU SERIES 
        if (isSeries && cleanDetailData.seasons && Array.isArray(cleanDetailData.seasons)) {

            const fetchEpisodesPromises = cleanDetailData.seasons.map(async (season, index) => {

                // Kalau array episodenya kosong, kita tembak endpoint season-nya
                if (!season.episodes || season.episodes.length === 0) {
                    try {
                        const seasonPath = `/api/series/${slug}/season/${season.seasonNumber}`;

                        const seasonData = await proxyGet(req, seasonPath, {}, {
                            label: `/idlix/season-${season.seasonNumber}`,
                            cacheTtlMs: 300000,
                            send: false,
                            headers: {
                                'Referer': `https://z2.idlixku.com/${refererPath}`
                            },
                            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
                        });

                        if (seasonData && !seasonData.error) {
                            // 🎯 FIX: Deteksi path "season.episodes" sesuai struktur JSON terbaru lu
                            let rawMissingEpisodes = [];
                            if (seasonData?.season?.episodes) {
                                rawMissingEpisodes = seasonData.season.episodes;
                            } else if (seasonData?.episodes) {
                                rawMissingEpisodes = seasonData.episodes;
                            } else if (Array.isArray(seasonData)) {
                                rawMissingEpisodes = seasonData;
                            }

                            // Map dan pasang ke object detail kita
                            cleanDetailData.seasons![index].episodes = IdlixDataMapper.mapEpisodes(rawMissingEpisodes);
                        }
                    } catch (err: any) {
                        console.error(`[Fetch Season ${season.seasonNumber} Error]:`, err?.message);
                    }
                }
            });

            // Tunggu semua fetch kelar
            await Promise.all(fetchEpisodesPromises);
        }

        // 4. Return data utuh
        return NextResponse.json(cleanDetailData);

    } catch (error: any) {
        console.error("[Detail Target Error]:", error?.message);
        return NextResponse.json(
            { error: true, message: error?.message || "Internal Server Error" },
            { status: 500 }
        );
    }
}