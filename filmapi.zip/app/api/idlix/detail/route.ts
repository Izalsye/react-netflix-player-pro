// detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const slug = searchParams.get('slug');
        const type = searchParams.get('type') || 'movie';

        if (!slug) {
            return NextResponse.json({ success: false, message: "slug wajib diisi" }, { status: 400 });
        }

        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT DETAIL 🔥
        const cacheKey = `idlix:detail:type:${type}:slug:${slug}`;
        const cacheTTL = 3600; // 1 Jam (Aman banget buat halaman detail)

        const mappedData = await getOrSetCache(cacheKey, async () => {
            const isSeries = type.toLowerCase() === 'series';
            const targetPath = isSeries ? `/api/series/${slug}` : `/api/movies/${slug}`;
            const refererPath = isSeries ? `series/${slug}` : `movie/${slug}`;

            // 1. Fetch data detail utama
            const responseData = await proxyGet(req, targetPath, {}, {
                label: `/idlix/detail-${type}`,
                cacheTtlMs: 300000,
                send: false,
                headers: {
                    'Referer': `https://z2.idlixku.com/${refererPath}`
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            // Proteksi jika terjadi error pada proxy/upstream
            if (!responseData || responseData.error) {
                // Lempar error biar gak disimpen ke Redis
                throw {
                    status: responseData?.status || 502,
                    message: responseData?.message || "Gagal fetch detail dari Upstream"
                };
            }

            // 2. 🎯 MAP DATA DETAIL AWAL
            const cleanDetailData = IdlixDataMapper.mapDetailResponse(responseData);

            // 3. 🎯 FETCH MISSING EPISODES JIKA ITU SERIES 
            if (isSeries && cleanDetailData.seasons && Array.isArray(cleanDetailData.seasons)) {

                const fetchEpisodesPromises = cleanDetailData.seasons.map(async (season, index) => {
                    // Kalau array episodenya kosong, kita tembak endpoint season-nya
                    if (!season.episodes || season.episodes.length === 0) {
                        try {
                            const seasonPath = `/api/series/${slug}/season/${season.seasonNumber}`;

                            const seasonData = await proxyGet(req, seasonPath, {}, {
                                label: `/idlix/season-${season.seasonNumber}`,
                                cacheTtlMs: 300000,
                                send: false,
                                headers: {
                                    'Referer': `https://z2.idlixku.com/${refererPath}`
                                },
                                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
                            });

                            if (seasonData && !seasonData.error) {
                                let rawMissingEpisodes = [];
                                if (seasonData?.season?.episodes) {
                                    rawMissingEpisodes = seasonData.season.episodes;
                                } else if (seasonData?.episodes) {
                                    rawMissingEpisodes = seasonData.episodes;
                                } else if (Array.isArray(seasonData)) {
                                    rawMissingEpisodes = seasonData;
                                }

                                // Map dan pasang ke object detail kita
                                cleanDetailData.seasons![index].episodes = IdlixDataMapper.mapEpisodes(rawMissingEpisodes);
                            }
                        } catch (err: any) {
                            console.error(`[Fetch Season ${season.seasonNumber} Error]:`, err?.message);
                            // Sengaja gak di-throw biar gak gagal total cuma karena 1 season nyangkut
                        }
                    }
                });

                // Tunggu semua fetch kelar
                await Promise.all(fetchEpisodesPromises);
            }

            // 4. Return data utuh yang udah dirakit buat disimpen ke Redis
            return cleanDetailData;

        }, cacheTTL);

        // Langsung lempar hasilnya (dari Cache atau Upstream)
        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error("[Detail Target Error]:", error?.message);
        const status = error.status || 500;
        return NextResponse.json(
            { error: true, message: error?.message || "Internal Server Error" },
            { status }
        );
    }
}