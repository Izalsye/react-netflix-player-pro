// home/network/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {
    const url = new URL(req.url);

    // 1. Ambil semua query parameters
    const query = Object.fromEntries(url.searchParams.entries());

    if (!query.network) {
        return NextResponse.json({ success: false, message: "network must be fill" }, { status: 400 });
    }

    // Ekstrak parameter dengan default value biar cache key-nya konsisten
    const network = query.network;
    const page = query.page || '1';
    const limit = query.limit || '20';
    const sort = query.sort || 'latest'; // asumsikan default sort kalau kosong

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT NETWORK & PAGINATION 🔥
        const cacheKey = `idlix:network:${network}:page:${page}:limit:${limit}:sort:${sort}`;
        const cacheTTL = 600; // 10 menit

        const mappedData = await getOrSetCache(cacheKey, async () => {
            const rawResponse = await proxyGet(req, `/api/browse?page=${page}&limit=${limit}&sort=${sort}&network=${network}`, {}, {
                label: '/idlix/network', // Label dirapikan
                cacheTtlMs: 300000,
                send: false,
                headers: {
                    'Referer': `https://z2.idlixku.com/network/${network}`,
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            // Jika proxy gagal / melempar error
            if (!rawResponse || rawResponse.error) {
                throw {
                    status: rawResponse?.status || 502,
                    message: rawResponse?.message || "Failed to fetch network data from Idlix"
                };
            }

            // 🎯 MAPPING DATA FLAT LIST DISINI:
            return IdlixDataMapper.mapNetworkResponse(rawResponse);

        }, cacheTTL);

        return NextResponse.json(mappedData);

    } catch (error: any) {
        const status = error.status || 502;
        return NextResponse.json(
            { code: status, message: error.message || "Internal Server Error", data: null },
            { status }
        );
    }
}