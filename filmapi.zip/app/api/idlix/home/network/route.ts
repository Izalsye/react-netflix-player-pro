import { NextRequest } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { NextResponse } from 'next/server';
import { IdlixDataMapper } from '@/lib/idlix/mapper';

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {

    const url = new URL(req.url);

    // 1. Ambil semua query parameters yang dikirim dari client (frontend)
    const query = Object.fromEntries(url.searchParams.entries());
    if (!query.network) {
        return NextResponse.json({ success: false, message: "network must be fill" }, { status: 400 });
    }

    // 🎯 PERBAIKAN: Gunakan backticks (`) dan ${query.network} untuk string injection
    const rawResponse = await proxyGet(req, `/api/browse?page=${query.page}&limit=${query.limit}&sort=${query.sort}&network=${query.network}`, {},
        {
            label: '/idlix/homepage',
            cacheTtlMs: 300000,
            send: false,
            headers: {
                'Referer': `https://z2.idlixku.com/network/${query.network}`,
            },
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });
    if (!rawResponse || rawResponse.error) {
        return NextResponse.json(rawResponse, { status: rawResponse?.status || 502 });
    }

    // 🎯 MAPPING DATA FLAT LIST DISINI:
    const cleanNetworkData = IdlixDataMapper.mapNetworkResponse(rawResponse);
    return NextResponse.json(cleanNetworkData);
}