// File: app/api/idlix/home/route.ts (sesuaikan path-nya ya)
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis kita

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

export async function GET(req: NextRequest) {
    try {
        const cacheKey = 'idlix:home';
        const cacheTTL = 600; // 10 menit (600 detik) untuk homepage cukup aman

        const mappedData = await getOrSetCache(cacheKey, async () => {
            const defaultCookie = process.env.IDLIX_COOKIES || '';
            const rawResponse = await proxyGet(req, "/api/homepage", {}, {
                label: '/idlix/homepage',
                cacheTtlMs: 300000, // Biarkan settingan asli proxyGet lu (ini kayanya cache internal yg lama)
                send: false,
                headers: {
                    'Cookie': defaultCookie,
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            // Jika proxy gagal / melempar error handling objek bawaan
            if (!rawResponse || rawResponse.error) {
                // Lempar sebagai error agar masuk ke catch dan TIDAK di-cache oleh Redis
                throw {
                    status: rawResponse?.status || 502,
                    message: rawResponse?.message || "Gagal mengambil data dari Upstream Idlix"
                };
            }

            // 🎯 MAPPING DATA:
            // Proses mapping ini cuma akan jalan kalau Redis kosong (misal tiap 10 menit)
            const cleanData = IdlixDataMapper.mapHomepage(rawResponse);

            return cleanData; // Hasil ini yang bakal dikunci di dalam memori Redis

        }, cacheTTL);

        // Kembalikan data yang sudah bersih total dari memori (100ms speed!)
        return NextResponse.json(mappedData);

    } catch (error: any) {
        // Tangkap error jika Idlix lagi down atau koneksi putus
        const status = error.status || 502;
        return NextResponse.json(
            { code: status, message: error.message || "Internal Server Error", data: null },
            { status }
        );
    }
}