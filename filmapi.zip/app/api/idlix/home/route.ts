import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper'; // Import mappers lu

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {

    const defaultCookie = process.env.IDLIX_COOKIES || '';
    const rawResponse = await proxyGet(req, "/api/homepage", {}, {
        label: '/idlix/homepage',
        cacheTtlMs: 300000,
        send: false,
        headers: {
            'Cookie': defaultCookie,
        }
    });

    // Jika proxy gagal / melempar error handling objek bawaan
    if (!rawResponse || rawResponse.error) {
        return NextResponse.json(rawResponse, { status: rawResponse?.status || 502 });
    }

    // 🎯 SEKARANG MAPPING DATA DISINI:
    const cleanData = IdlixDataMapper.mapHomepage(rawResponse);

    // Kembalikan data yang sudah bersih total dari iklan dan properti berlapis
    return NextResponse.json(cleanData);
}