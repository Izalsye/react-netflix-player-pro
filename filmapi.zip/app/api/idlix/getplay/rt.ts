import { NextRequest, NextResponse } from 'next/server';
import { proxyGet, proxyPost } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const type = searchParams.get('type') || 'movie';
        const slug = searchParams.get('slug') || 'default-slug';

        if (!id) {
            return NextResponse.json({ success: false, message: "Parameter 'id' wajib diisi" }, { status: 400 });
        }

        // 🚀 STEP 1: Ambil Play Info
        const step1Data = await proxyGet(req, `/api/watch/play-info/${type}/${id}`, {}, {
            label: '/idlix/getplay-info',
            send: false,
            headers:{
            }
        });

        const gateToken = step1Data?.gateToken;
        if (!gateToken) throw new Error("Gagal mendapatkan gateToken di Step 1");

        // 🚀 HITUNG DURASI TUNGGU DINAMIS SESUAI KEMAUAN SERVER (Biar gak mental di Step 2)
        const serverNow = step1Data?.serverNow || Date.now();
        const unlockAt = step1Data?.unlockAt || serverNow;
        const countdownSec = step1Data?.preroll?.ad?.config?.duration || step1Data?.preroll?.countdownSec || 7;

        let msToWait = unlockAt - serverNow;

        // Jika selisihnya minus atau tidak wajar, gunakan countdown default dari preroll iklan
        if (msToWait <= 0) {
            msToWait = countdownSec * 1000;
        }

        // Tambahkan safety buffer wajib 1,5 detik (1500ms) agar clock server lu dan server target singkron pas unlock
        msToWait += 1500;

        console.log(`[IdlixGetPlay] Menunggu gate asli selesai selama ${msToWait / 1000} detik...`);
        await new Promise(resolve => setTimeout(resolve, msToWait));

        let dynamicCookie = "NEXT_LOCALE=en";
        try {
            const tokenParts = gateToken.split('.');
            if (tokenParts.length > 0) {
                // 🎯 KEMBALIKAN KE INDEKS 0: Karena IDLIX menaruh data owner di bagian header/unencrypted part
                let base64Header = tokenParts[0];

                // Helper untuk menormalisasi Base64URL menjadi Base64 Standar Node.js
                base64Header = base64Header.replace(/-/g, '+').replace(/_/g, '/');
                while (base64Header.length % 4) {
                    base64Header += '=';
                }

                const decodedPayload = JSON.parse(Buffer.from(base64Header, 'base64').toString('utf8'));
                if (decodedPayload?.owner) {
                    const dynamicDid = decodedPayload.owner.replace('d:', '');
                    dynamicCookie = `NEXT_LOCALE=en; did=${dynamicDid}`;
                    console.log(`[IdlixGetPlay] Dynamic DID Synchronized: ${dynamicDid}`);
                }
            }
        } catch (e) {
            console.error("[IdlixGetPlay] Gagal melakukan token extraction (Bypass ke default cookie):", e);
        }

        // 🚀 STEP 2: Claim Session
        const step2Data = await proxyPost(req, "/api/watch/session/claim", { "gateToken": gateToken }, {
            label: '/idlix/getplay-claim',
            send: false,
            headers: {
                'Origin': 'https://z2.idlixku.com',
                'Referer': `https://z2.idlixku.com/${type}/${slug}`,
                'Cookie': dynamicCookie
            }
        });

        const claim = step2Data?.claim;
        const redeemUrl = step2Data?.redeemUrl;

        if (!claim || !redeemUrl) {
            throw new Error("Gagal mendapatkan claim token di Step 2");
        }

        // 🚀 STEP 3: Ambil Video Config Akhir dari Majorplay
        const finalStreamData = await proxyPost(req, redeemUrl, { "claim": claim }, {
            label: '/idlix/getplay-redeem',
            send: false,
            headers: {
                "Origin": "https://z2.idlixku.com",
                "Referer": "https://z2.idlixku.com/",
                'Cookie': dynamicCookie
            }
        });

        // 🎯 MAP DATA PLAY AKHIR
        const cleanPlayConfig = IdlixDataMapper.mapPlayResponse(finalStreamData);

        if (!cleanPlayConfig) {
            return NextResponse.json({ success: false, message: "Stream configuration is empty" }, { status: 404 });
        }

        return NextResponse.json({
            success: true,
            data: cleanPlayConfig
        });

    } catch (error: any) {
        console.error("[GetPlay Proxy Chain Error]:", error?.message);
        return NextResponse.json({ success: false, message: error?.message || "Internal Server Error" }, { status: 500 });
    }
}