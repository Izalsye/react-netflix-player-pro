// file: app/api/idlix/getplay/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet, proxyPost } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

// 🔥 ANTI-CACHE LEVEL 1
export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

// ==========================================
// 🔥 HELPER: SANITIZE STATUS UNTUK NGINX 🔥
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 400;
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400;
    }
    return status;
}

export async function GET(req: NextRequest) {
    const noCacheHeaders = {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
    };

    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const type = searchParams.get('type') || 'movie';
        const slug = searchParams.get('slug') || 'default-slug';

        if (!id) {
            return NextResponse.json(
                { success: false, message: "ID wajib disertakan" },
                { status: 400, headers: noCacheHeaders }
            );
        }

        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT IDLIX GETPLAY 🔥
        const cacheKey = `idlix:play:${type}:${slug}:id:${id}`;

        // Default TTL (misal 50 menit), tapi nanti kita OVERRIDE pakai TTL asli dari Idlix
        const defaultTTL = 3000;

        const mappedData = await getOrSetCache(cacheKey, async () => {
            const apiType = type === 'series' ? 'episode' : type;

            // 🚀 STEP 1: GET PLAY INFO
            const step1Data = await proxyGet(req, `/api/watch/play-info/${apiType}/${id}`, {}, {
                label: '/idlix/getplay-info',
                send: false,
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            if (step1Data?.error) {
                // Lempar ke catch biar gak kesimpen Redis
                throw { status: step1Data.status || 500, message: "Gagal dapat Play Info" };
            }

            const gateToken = step1Data?.gateToken;
            if (!gateToken) {
                console.error("[IdlixGetPlay] Gagal dapat gateToken. RAW Response:", step1Data);
                throw { status: 400, message: "Gagal mendapatkan gateToken dari response upstream", raw_idlix_response: step1Data };
            }

            // ⏳ TUNGGU DELAY DARI SERVER
            const unlockTime = step1Data?.unlockAt || Date.now();
            const serverTime = step1Data?.serverNow || Date.now();
            const msToWait = Math.max(0, unlockTime - serverTime);

            console.log(`[IdlixGetPlay] Menunggu gate asli ${msToWait / 1000} detik...`);
            if (msToWait > 0) {
                await new Promise(resolve => setTimeout(resolve, msToWait));
            }

            let dynamicCookie = "NEXT_LOCALE=id";
            try {
                const tokenParts = gateToken.split('.');
                if (tokenParts.length > 0) {
                    const base64Header = tokenParts[0].replace(/-/g, '+').replace(/_/g, '/');
                    const decodedPayload = JSON.parse(Buffer.from(base64Header, 'base64').toString('utf8'));

                    if (decodedPayload?.owner) {
                        const did = decodedPayload.owner.replace('d:', '');
                        dynamicCookie = `NEXT_LOCALE=id; did=${did}`;
                    }
                }
            } catch (e) {
                console.warn("[IdlixGetPlay] Gagal decode token JWT");
            }

            // 🚀 STEP 2: CLAIM SESSION
            const step2Data = await proxyPost(req, "/api/watch/session/claim", { gateToken }, {
                label: '/idlix/getplay-claim',
                send: false,
                headers: {
                    'Origin': 'https://z2.idlixku.com',
                    'Referer': `https://z2.idlixku.com/${type}/${slug}`,
                    'Cookie': dynamicCookie
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            if (step2Data?.error || !step2Data?.redeemUrl) {
                console.error("[IdlixGetPlay] Step 2 Gagal:", step2Data);
                throw { status: 400, message: step2Data?.message || "Gagal claim session. Cek Cookie lu bre!" };
            }

            // 🚀 STEP 3: REDEEM
            const finalStreamData = await proxyPost(req, step2Data.redeemUrl, {
                claim: step2Data.claim,
                mode: "browser"
            }, {
                label: '/idlix/getplay-redeem',
                send: false,
                headers: {
                    "Origin": "https://z2.idlixku.com",
                    "Referer": "https://z2.idlixku.com/",
                    "Content-Type": "application/json"
                },
                useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
            });

            if (finalStreamData?.error) {
                console.error("[IdlixGetPlay] Step 3 (Redeem) Gagal:", finalStreamData);
                throw { status: 502, message: finalStreamData?.message || "Gagal melakukan redeem URL Stream" };
            }

            // 🎯 MAP DATA KE FORMAT DTO KITA
            const cleanPlayConfig = IdlixDataMapper.mapPlayResponse(finalStreamData);
            if (!cleanPlayConfig) {
                console.error("[IdlixGetPlay] Mapping Gagal. Data Asli:", finalStreamData);
                throw { status: 500, message: "Stream configuration empty or invalid format" };
            }

            // Return hasil yang akan disimpan di Redis
            return cleanPlayConfig;

        }, defaultTTL); // <-- Kita pakai default TTL, tapi kalau perlu bisa dimodif di getOrSetCache

        // (OPSIONAL) Karena kita pakai `getOrSetCache` yang TTL-nya tetap per request pertama,
        // Default TTL 3000 detik (50 Menit) yang kita set di atas udah sangat aman kok 
        // buat nangani rentang expired dari Idlix (biasanya 1 jam).

        return NextResponse.json({ success: true, data: mappedData });

    } catch (error: any) {
        console.error("[IdlixGetPlay] Error:", error.message);
        const statusCode = error.status || 500;

        return NextResponse.json(
            { success: false, message: error?.message || "Internal Server Error", data: error.raw_idlix_response || null },
            {
                status: sanitizeStatus(statusCode),
                headers: noCacheHeaders
            }
        );
    }
}