// file: app/api/idlix/getplay/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet, proxyPost } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper';

// 🔥 ANTI-CACHE LEVEL 1: Paksa Next.js biar gak nge-cache rute ini secara statis
export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

const globalPlayCache = new Map<string, { config: any; expiresAt: number }>();

// ==========================================
// 🔥 HELPER: SANITIZE STATUS UNTUK NGINX 🔥
// ==========================================
function sanitizeStatus(status: number): number {
    if (!status) return 400;
    if ([403, 404, 500, 502, 503, 504].includes(status)) {
        return 400;
    }
    return status;
}

export async function GET(req: NextRequest) {
    // 🔥 Header khusus kalau error, biar Cloudflare / Nginx / Browser GAK NGE-CACHE
    const noCacheHeaders = {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
    };

    try {
        // 💥 SIAPKAN COOKIES
        const envCookie = process.env.IDLIX_COOKIES || "";
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const type = searchParams.get('type') || 'movie';
        const slug = searchParams.get('slug') || 'default-slug';

        if (!id) {
            return NextResponse.json(
                { success: false, message: "ID wajib disertakan" },
                { status: 400, headers: noCacheHeaders } // 👈 Pasang anti-cache
            );
        }

        // ⚡ CEK CACHE LOKAL (Hanya sukses yang dicache lokal)
        const cachedData = globalPlayCache.get(id);
        if (cachedData && cachedData.expiresAt > Date.now()) {
            console.log(`[IdlixGetPlay] ⚡ BYPASS TOTAL! Data ditemukan di Cache Lokal.`);
            return NextResponse.json({ success: true, data: cachedData.config });
        }

        const apiType = type === 'series' ? 'episode' : type;
        console.log("CEK ENV COOKIE:", process.env.IDLIX_COOKIES ? "ADA ISINYA" : "KOSONG/UNDEFINED");

        // 🚀 STEP 1: GET PLAY INFO
        const step1Data = await proxyGet(req, `/api/watch/play-info/${apiType}/${id}`, {}, {
            label: '/idlix/getplay-info',
            send: false,
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });

        if (step1Data?.error) {
            const safeStatus = sanitizeStatus(step1Data.status || 500);
            return NextResponse.json(step1Data, {
                status: safeStatus,
                headers: noCacheHeaders // 👈 Pasang anti-cache
            });
        }

        const gateToken = step1Data?.gateToken;
        // 🔥 KITA UBAH BAGIAN INI BUAT NGINTIP BALESAN ASLI IDLIX 🔥
        if (!gateToken) {
            console.error("[IdlixGetPlay] Gagal dapat gateToken. RAW Response:", step1Data);
            return NextResponse.json({
                success: false,
                message: "Gagal mendapatkan gateToken dari response upstream",
                raw_idlix_response: step1Data
            }, {
                status: 400,
                headers: noCacheHeaders // 👈 Pasang anti-cache
            });
        }

        // ⏳ TUNGGU DELAY DARI SERVER (SESUAI IDLIX, TANPA TAMBAHAN)
        const unlockTime = step1Data?.unlockAt || Date.now();
        const serverTime = step1Data?.serverNow || Date.now();
        const msToWait = Math.max(0, unlockTime - serverTime);

        console.log(`[IdlixGetPlay] Menunggu gate asli ${msToWait / 1000} detik...`);
        if (msToWait > 0) {
            await new Promise(resolve => setTimeout(resolve, msToWait));
        }

        let dynamicCookie = "NEXT_LOCALE=id";

        try {
            const tokenParts = gateToken.split('.');
            if (tokenParts.length > 0) {
                const base64Header = tokenParts[0].replace(/-/g, '+').replace(/_/g, '/');
                const decodedPayload = JSON.parse(Buffer.from(base64Header, 'base64').toString('utf8'));

                if (decodedPayload?.owner) {
                    const did = decodedPayload.owner.replace('d:', '');
                    dynamicCookie = `NEXT_LOCALE=id; did=${did}`;
                }
            }
        } catch (e) {
            console.warn("[IdlixGetPlay] Gagal decode token JWT");
        }

        // 🚀 STEP 2: CLAIM SESSION
        const step2Data = await proxyPost(req, "/api/watch/session/claim", { gateToken }, {
            label: '/idlix/getplay-claim',
            send: false,
            headers: {
                'Origin': 'https://z2.idlixku.com',
                'Referer': `https://z2.idlixku.com/${type}/${slug}`,
                'Cookie': dynamicCookie
            },
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });

        if (step2Data?.error || !step2Data?.redeemUrl) {
            console.error("[IdlixGetPlay] Step 2 Gagal:", step2Data);
            throw new Error(step2Data?.message || "Gagal claim session, redeemUrl tidak ditemukan. Cek Cookie lu bre!");
        }

        // 🚀 STEP 3: REDEEM
        const finalStreamData = await proxyPost(req, step2Data.redeemUrl, { claim: step2Data.claim }, {
            label: '/idlix/getplay-redeem',
            send: false,
            headers: {
                "Origin": "https://z2.idlixku.com",
                "Referer": "https://z2.idlixku.com/",
                "Cookie": envCookie,
                "Content-Type": "text/plain"
            },
            useProxyOverride: USE_PROXY_FOR_THIS_ROUTE
        });

        const cleanPlayConfig = IdlixDataMapper.mapPlayResponse(finalStreamData);
        if (!cleanPlayConfig) {
            throw new Error("Stream configuration empty");
        }

        // 💾 SIMPAN KE CACHE (Yang di-cache LOKAL cuma kalau 100% SUKSES)
        const ttlMs = (cleanPlayConfig.sessionTimeout?.ttlSeconds || 3600 - 600) * 1000;
        globalPlayCache.set(id, {
            config: cleanPlayConfig,
            expiresAt: Date.now() + ttlMs
        });

        return NextResponse.json({ success: true, data: cleanPlayConfig });

    } catch (error: any) {
        console.error("[IdlixGetPlay] Error:", error.message);

        return NextResponse.json(
            { success: false, message: error?.message || "Internal Server Error" },
            {
                status: sanitizeStatus(500),
                headers: noCacheHeaders // 👈 Pasang anti-cache
            }
        );
    }
}