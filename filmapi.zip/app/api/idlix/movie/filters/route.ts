import { NextResponse } from 'next/server';

export const dynamic = 'force-static';

export async function GET() {
    const filterOptions = {
        sort: [
            { id: 1, code: "releaseDate", name: "Release Date" },
            { id: 2, code: "popularity", name: "Popularity" },
            { id: 3, code: "views", name: "Most Viewed" },
            { id: 4, code: "rating", name: "Rating" },
            { id: 5, code: "createdAt", name: "Recently Added" }
        ],
        genres: [
            { id: 1, code: "action", name: "Action" },
            { id: 2, code: "adventure", name: "Adventure" },
            { id: 3, code: "animation", name: "Animation" },
            { id: 4, code: "comedy", name: "Comedy" },
            { id: 5, code: "crime", name: "Crime" },
            { id: 6, code: "documentary", name: "Documentary" },
            { id: 7, code: "drama", name: "Drama" },
            { id: 8, code: "family", name: "Family" },
            { id: 9, code: "fantasy", name: "Fantasy" },
            { id: 10, code: "history", name: "History" },
            { id: 11, code: "horror", name: "Horror" },
            { id: 12, code: "kids", name: "Kids" },
            { id: 13, code: "music", name: "Music" },
            { id: 14, code: "mystery", name: "Mystery" },
            { id: 15, code: "reality", name: "Reality" },
            { id: 16, code: "romance", name: "Romance" },
            { id: 17, code: "science-fiction", name: "Science Fiction" },
            { id: 18, code: "soap", name: "Soap" },
            { id: 19, code: "talk", name: "Talk" },
            { id: 20, code: "thriller", name: "Thriller" },
            { id: 21, code: "tv-movie", name: "TV Movie" },
            { id: 22, code: "war", name: "War" },
            { id: 23, code: "western", name: "Western" }
        ],
        countries: [
            { id: 1, code: "US", name: "United States" },
            { id: 2, code: "ID", name: "Indonesia" },
            { id: 3, code: "KR", name: "South Korea" },
            { id: 4, code: "JP", name: "Japan" },
            { id: 5, code: "CN", name: "China" },
            { id: 6, code: "HK", name: "Hong Kong" },
            { id: 7, code: "TW", name: "Taiwan" },
            { id: 8, code: "TH", name: "Thailand" },
            { id: 9, code: "IN", name: "India" },
            { id: 10, code: "GB", name: "United Kingdom" },
            { id: 11, code: "FR", name: "France" },
            { id: 12, code: "DE", name: "Germany" },
            { id: 13, code: "IT", name: "Italy" },
            { id: 14, code: "ES", name: "Spain" },
            { id: 15, code: "AU", name: "Australia" },
            { id: 16, code: "CA", name: "Canada" },
            { id: 17, code: "BR", name: "Brazil" },
            { id: 18, code: "MX", name: "Mexico" },
            { id: 19, code: "PH", name: "Philippines" },
            { id: 20, code: "MY", name: "Malaysia" },
            { id: 21, code: "SG", name: "Singapore" },
            { id: 22, code: "VN", name: "Vietnam" }
        ],
        years: [
            { id: 1, code: "2026", name: "2026" },
            { id: 2, code: "2025", name: "2025" }, // Fix typo bawaan (tadi nulisnya 2024)
            { id: 3, code: "2024", name: "2024" },
            { id: 4, code: "2023", name: "2023" },
            { id: 5, code: "2022", name: "2022" },
            { id: 6, code: "2021", name: "2021" },
            { id: 7, code: "2020", name: "2020" },
            { id: 8, code: "2019", name: "2019" },
            { id: 9, code: "2018", name: "2018" },
            { id: 10, code: "2017", name: "2017" },
            { id: 11, code: "2016", name: "2016" },
            { id: 12, code: "2015", name: "2015" },
            { id: 13, code: "2014", name: "2014" },
            { id: 14, code: "2013", name: "2013" },
            { id: 15, code: "2012", name: "2012" },
            { id: 16, code: "2011", name: "2011" },
            { id: 17, code: "2010", name: "2010" }
        ],
        qualities: [
            { id: 1, code: "WEB-DL", name: "WEB-DL" },
            { id: 2, code: "HD", name: "HD" },
            { id: 3, code: "BLU-RAY", name: "BluRay" },
            { id: 4, code: "4K", name: "4K Ultra HD" }
        ]
    };

    return NextResponse.json({
        success: true,
        message: "Filter options fetched successfully",
        data: filterOptions
    });
}