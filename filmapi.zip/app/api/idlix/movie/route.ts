import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/idlix/proxy';
import { IdlixDataMapper } from '@/lib/idlix/mapper'; // 🎯 Impor mapper lu disini

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);

        const query: Record<string, string> = {
            page: searchParams.get('page') || '1',
            limit: searchParams.get('limit') || '36',
            sort: searchParams.get('sort') || 'releaseDate',
        };

        const genre = searchParams.get('genre');
        const country = searchParams.get('country');
        const year = searchParams.get('year');
        const quality = searchParams.get('quality');

        if (genre) query.genre = genre;
        if (country) query.country = country;
        if (year) query.year = year;
        if (quality) query.quality = quality;

        const responseData = await proxyGet(req, "/api/movies", query, {
            label: '/idlix/movies',
            cacheTtlMs: 120000,
            send: false,
            headers: {
                'Referer': `https://z2.idlixku.com/movie`,
            }
        });

        // Proteksi jika terjadi error pada proxy
        if (!responseData || responseData.error) {
            return NextResponse.json(responseData, { status: responseData?.status || 502 });
        }

        // 🎯 MAP DATA MOVIES KITA DISINI BIAR BERSIH TOTAL:
        const cleanMoviesData = IdlixDataMapper.mapMoviesResponse(responseData);

        return NextResponse.json(cleanMoviesData);
    } catch (error: any) {
        console.error("[Route Movies Error]:", error?.message);
        return NextResponse.json(
            { error: true, message: error?.message || "Internal Server Error" },
            { status: 500 }
        );
    }
}