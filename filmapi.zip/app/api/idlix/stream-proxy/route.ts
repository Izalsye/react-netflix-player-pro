// file: app/api/idlix/stream-proxy/route.ts
import { NextRequest, NextResponse } from 'next/server';

// 🚀 DOSA BESAR DIHAPUS: Balik ke Node.js murni biar RAM gak gampang OOM
// export const runtime = 'edge'; 

export async function GET(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    const isSub = req.nextUrl.searchParams.get('isSub') === 'true';

    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    const envCookie = process.env.IDLIX_COOKIES || '';

    const fetchHeaders: HeadersInit = {
        'Referer': 'https://z2.idlixku.com/',
        'Origin': 'https://z2.idlixku.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Accept-Encoding': 'identity',
        'sec-ch-ua': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
    };

    if (envCookie) {
        (fetchHeaders as any)['Cookie'] = envCookie;
    }

    // 🚀 INI UDAH BAGUS: Nerusin header Range biar video bisa di-skip/seek
    if (req.headers.has('range')) {
        (fetchHeaders as any)['Range'] = req.headers.get('range')!;
    }

    try {
        const response = await fetch(url, {
            headers: fetchHeaders,
            cache: 'no-store'
        });

        const contentType = response.headers.get('content-type') || '';
        const status = response.status;

        if (!response.ok && status !== 206) {
            console.error(`[STREAM PROXY] Upstream Error ${status} for URL: ${url}`);
            return NextResponse.json({ error: "Upstream rejected", status }, { status });
        }

        // --- 1. LOGIKA SUBTITLE ---
        if (isSub || url.includes('.vtt') || url.includes('.srt')) {
            let subText = await response.text();
            if (!subText.trim().startsWith('WEBVTT')) {
                subText = 'WEBVTT\n\n' + subText.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
            }
            return new NextResponse(subText, {
                status,
                headers: { 'Content-Type': 'text/vtt; charset=utf-8', 'Access-Control-Allow-Origin': '*' }
            });
        }

        // --- 2. REWRITE M3U8 ---
        const isM3U8 = contentType.toLowerCase().includes('mpegurl') || url.includes('.m3u8') || url.includes('.json');

        if (isM3U8) {
            const buffer = await response.arrayBuffer();
            const textContent = new TextDecoder().decode(buffer);

            if (textContent.trim().startsWith('#EXTM3U')) {
                const proxyPath = '/api/idlix/stream-proxy?url=';
                const baseUrlObj = new URL(url);

                const wrapUrl = (rawUrl: string) => {
                    if (rawUrl.includes('/api/idlix/stream-proxy')) return rawUrl;

                    let targetObj: URL;
                    if (rawUrl.startsWith('http')) {
                        targetObj = new URL(rawUrl);
                    } else {
                        targetObj = new URL(rawUrl, url);

                        baseUrlObj.searchParams.forEach((val, key) => {
                            if (!targetObj.searchParams.has(key)) {
                                targetObj.searchParams.set(key, val);
                            }
                        });
                    }
                    return `${proxyPath}${encodeURIComponent(targetObj.toString())}`;
                };

                const rewrittenContent = textContent.split('\n').map(line => {
                    const trimmed = line.trim();
                    if (trimmed === '') return line;
                    if (trimmed.startsWith('#') && trimmed.includes('URI="')) {
                        return trimmed.replace(/URI="([^"]+)"/g, (match, keyUrl) => `URI="${wrapUrl(keyUrl)}"`);
                    }
                    if (!trimmed.startsWith('#')) {
                        return wrapUrl(trimmed);
                    }
                    return line;
                }).join('\n');

                return new NextResponse(rewrittenContent, {
                    headers: {
                        'Content-Type': 'application/vnd.apple.mpegurl',
                        'Access-Control-Allow-Origin': '*'
                    }
                });
            } else {
                const responseHeaders = new Headers();
                responseHeaders.set('Access-Control-Allow-Origin', '*');
                responseHeaders.set('Content-Type', contentType || 'application/octet-stream');
                return new NextResponse(buffer, { status, headers: responseHeaders });
            }
        }

        // --- 3. PASSTHROUGH CHUNKS (VIDEO SEGMEN) ---
        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate');

        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (!['transfer-encoding', 'content-encoding', 'connection', 'keep-alive', 'access-control-allow-origin'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        if (!responseHeaders.has('content-type')) {
            responseHeaders.set('Content-Type', contentType || 'application/octet-stream');
        }

        // 🚀 GANTI NextResponse JADI Response STANDAR:
        // Ini mastiin Next.js memperlakukan response.body murni sebagai selang air (Streaming / Piping)
        return new Response(response.body, { status, headers: responseHeaders });

    } catch (e: any) {
        console.error("[STREAM PROXY] Network Error:", e.message);
        return new NextResponse(JSON.stringify({ error: "Network Timeout" }), { status: 502 });
    }
}