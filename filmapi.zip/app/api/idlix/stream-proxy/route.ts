import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

export async function GET(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    const isSub = req.nextUrl.searchParams.get('isSub') === 'true';

    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    const fetchHeaders: HeadersInit = {
        'Referer': 'https://z2.idlixku.com/',
        'Origin': 'https://z2.idlixku.com',
        'User-Agent': req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept-Encoding': 'identity'
    };

    if (req.headers.has('range')) {
        fetchHeaders['Range'] = req.headers.get('range')!;
    }

    try {
        const response = await fetch(url, {
            headers: fetchHeaders,
            cache: 'no-store'
        });

        const contentType = response.headers.get('content-type') || '';
        const status = response.status;

        if (!response.ok && status !== 206) {
            return NextResponse.json({ error: "Upstream rejected", status }, { status });
        }

        // --- 1. LOGIKA SUBTITLE ---
        if (isSub || url.includes('.vtt') || url.includes('.srt')) {
            let subText = await response.text();
            if (!subText.trim().startsWith('WEBVTT')) {
                subText = 'WEBVTT\n\n' + subText.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
            }
            return new NextResponse(subText, {
                status,
                headers: { 'Content-Type': 'text/vtt; charset=utf-8', 'Access-Control-Allow-Origin': '*' }
            });
        }

        // --- 2. REWRITE M3U8 (Majorplay / Idlix pake .json buat file M3U8) ---
        const isM3U8 = contentType.toLowerCase().includes('mpegurl') || url.includes('.m3u8') || url.includes('.json');

        if (isM3U8) {
            // Ambil sebagai ArrayBuffer agar file biner (video chunk) tidak corrupt jika salah tebak
            const buffer = await response.arrayBuffer();
            const textContent = new TextDecoder().decode(buffer);

            // Validasi ketat: Pastikan ini BENAR-BENAR playlist M3U8, bukan chunk video yang menyamar
            if (textContent.trim().startsWith('#EXTM3U')) {
                const proxyPath = '/api/idlix/stream-proxy?url=';

                const wrapUrl = (rawUrl: string) => {
                    if (rawUrl.includes('/api/idlix/stream-proxy')) return rawUrl;
                    let target = rawUrl.startsWith('http') ? rawUrl : new URL(rawUrl, url).toString();
                    return `${proxyPath}${encodeURIComponent(target)}`;
                };

                const rewrittenContent = textContent.split('\n').map(line => {
                    const trimmed = line.trim();
                    if (trimmed === '') return line;

                    // 🎯 TANGKAP SEMUA tag HLS yang memiliki URI="..." (contoh: Map, Key, Media)
                    if (trimmed.startsWith('#') && trimmed.includes('URI="')) {
                        return trimmed.replace(/URI="([^"]+)"/g, (match, keyUrl) => `URI="${wrapUrl(keyUrl)}"`);
                    }

                    // Baris segment video biasa (tidak diawali #)
                    if (!trimmed.startsWith('#')) {
                        return wrapUrl(trimmed);
                    }

                    return line;
                }).join('\n');

                return new NextResponse(rewrittenContent, {
                    headers: {
                        'Content-Type': 'application/vnd.apple.mpegurl',
                        'Access-Control-Allow-Origin': '*'
                    }
                });
            } else {
                // Ternyata ini chunk video biner (walaupun URL-nya .json), kita passthrough buffernya secara aman!
                const responseHeaders = new Headers();
                responseHeaders.set('Access-Control-Allow-Origin', '*');
                responseHeaders.set('Content-Type', contentType || 'application/octet-stream');

                return new NextResponse(buffer, { status, headers: responseHeaders });
            }
        }

        // --- 3. PASSTHROUGH CHUNKS (Untuk file TS / MP4 biasa) ---
        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');

        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (!['transfer-encoding', 'content-encoding', 'connection', 'keep-alive', 'access-control-allow-origin'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        if (!responseHeaders.has('content-type')) {
            responseHeaders.set('Content-Type', contentType || 'application/octet-stream');
        }

        return new NextResponse(response.body, { status, headers: responseHeaders });

    } catch (e: any) {
        return new NextResponse(JSON.stringify({ error: "Network Timeout" }), { status: 502 });
    }
}