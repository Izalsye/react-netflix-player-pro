import { NextResponse } from "next/server";
import { proxyGet } from "@/lib/india/proxy";
// Import fungsi mapping
import { mapSearchData } from "@/lib/india/mapping";

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const query = Object.fromEntries(searchParams.entries());

    const currentYear = new Date().getFullYear().toString();

    const searchQuery = {
        q: query.q || "",
        type: query.type || "movietvserieslive",
        range_to: query.range_to || currentYear,
        range_from: query.range_from || "1900",
        tv_category_id: query.tv_category_id || "0",
        genre_id: query.genre_id || "0",
        country_id: query.country_id || "0",
        ...query,
    };

    const targetPath = "/rest-api/v130/search";

    try {
        // Ambil data mentah (send: false)
        const rawData = await proxyGet(req, targetPath, searchQuery, {
            label: "sinetron-search",
            cacheTtlMs: 2 * 60 * 1000,
            send: false // 👈 Jangan lupa ini
        });

        if (rawData?.error) {
            return NextResponse.json(rawData, { status: rawData.status || 400 });
        }

        // Rapikan data pencarian
        const mappedData = mapSearchData(rawData);

        return NextResponse.json(mappedData, { status: mappedData.code });
    } catch (error: any) {
        console.error("[Route: Sinetron Search Error]", error?.message);
        return NextResponse.json(
            { code: 500, message: "Internal Server Error", data: null },
            { status: 500 }
        );
    }
}