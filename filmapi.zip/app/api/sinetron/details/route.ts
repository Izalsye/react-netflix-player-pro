import { NextResponse } from "next/server";
import { proxyGet } from "@/lib/india/proxy";
// Import fungsi mapping
import { mapDetailData } from "@/lib/india/mapping";

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const query = Object.fromEntries(searchParams.entries());

    if (!query.id) {
        return NextResponse.json(
            { code: 400, message: "Parameter 'id' wajib dikirim.", data: null },
            { status: 400 }
        );
    }

    if (!query.type) {
        query.type = "tvseries";
    }

    const targetPath = "/rest-api/v130/single_details";

    try {
        // Ambil data mentah (send: false)
        const rawData = await proxyGet(req, targetPath, query, {
            label: `sinetron-detail-${query.id}`,
            cacheTtlMs: 5 * 60 * 1000,
            send: false // 👈 Penting
        });

        if (rawData?.error) {
            return NextResponse.json(
                { code: rawData.status || 400, message: rawData.message, data: null },
                { status: rawData.status || 400 }
            );
        }

        // Rapikan data
        const mappedData = mapDetailData(rawData);

        return NextResponse.json(mappedData, { status: mappedData.code });
    } catch (error: any) {
        console.error(`[Route: Sinetron Detail Error | ID: ${query.id}]`, error?.message);
        return NextResponse.json(
            { code: 500, message: "Internal Server Error", data: null },
            { status: 500 }
        );
    }
}