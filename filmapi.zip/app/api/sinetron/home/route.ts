import { NextResponse } from "next/server";
import { proxyGet } from "@/lib/india/proxy";
// Import fungsi mapping yang baru aja kita buat
import { mapHomeData } from "@/lib/india/mapping";

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const query = Object.fromEntries(searchParams.entries());

    const targetPath = "/rest-api/v130/home_content_for_android";

    try {
        // Tambahkan opsi `send: false` agar proxyGet me-return JSON object
        const rawData = await proxyGet(req, targetPath, query, {
            label: "sinetron-home",
            cacheTtlMs: 5 * 60 * 1000,
            send: false, // 👈 PENTING: Jangan langsung dikirim ke client
        });

        // Kalau ada error dari target (misal API Key invalid)
        if (rawData?.error) {
            return NextResponse.json(rawData, { status: rawData.status || 400 });
        }

        // Jalankan mapping untuk ngerapiin datanya
        const mappedData = mapHomeData(rawData);

        // Kirim hasil akhir ke frontend
        return NextResponse.json(mappedData, { status: 200 });

    } catch (error: any) {
        console.error("[Route: Sinetron Home Error]", error?.message);
        return NextResponse.json(
            { error: true, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}