import { NextResponse } from "next/server";
import { proxyGet } from "@/lib/india/proxy";
// Import fungsi mapping
import { mapSeriesData } from "@/lib/india/mapping";

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const query = Object.fromEntries(searchParams.entries());

    if (!query.page) {
        query.page = "1";
    }

    const targetPath = "/rest-api/v130/tvseries";

    try {
        // Ambil data mentah (send: false)
        const rawData = await proxyGet(req, targetPath, query, {
            label: "sinetron-series",
            cacheTtlMs: 5 * 60 * 1000,
            send: false // 👈 Wajib pakai ini
        });

        if (rawData?.error) {
            return NextResponse.json(rawData, { status: rawData.status || 400 });
        }

        // Rapikan data pakai mapping
        const mappedData = mapSeriesData(rawData);

        // Kirim hasil akhir ke client
        return NextResponse.json(mappedData, { status: mappedData.code });
    } catch (error: any) {
        console.error("[Route: Sinetron Series Error]", error?.message);
        return NextResponse.json(
            { code: 500, message: "Internal Server Error", data: null },
            { status: 500 }
        );
    }
}