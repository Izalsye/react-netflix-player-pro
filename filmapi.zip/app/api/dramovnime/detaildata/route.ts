// file: api/dramovnime/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { API_BASE, fetchUpstream } from '@/lib/filmboxProxy'; // Pastikan pakai proxy Filmbox
import { mapDetailDataDTO } from '@/lib/detaildto'; // Tetap pakai formatter lama

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  // 1. Validasi API Key Dramovnime (Tetap dipertahankan biar frontend lama gak bocor)
  const auth = await validateApiKey(req, 'dramovnime');
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  // 2. Tangkap Parameter (Gaya client lama Dramovnime)
  const sp = req.nextUrl.searchParams;
  const id = sp.get('id') || sp.get('subjectId');
  let detailPath = sp.get('detailPath');

  // Wajib ada ID. detailPath opsional, bisa digenerate kalau kosong
  if (!id) {
    return NextResponse.json({ error: true, message: "Missing query: id (subjectId)" }, { status: 400 });
  }

  try {
    // 🔥 3. Hit Data Detail dari Engine FILMBOX (Menggantikan proxy Dramovnime lama)
    // Filmbox butuh detailPath. Kalau frontend lama cuma ngasih ID, kita akalin formatnya.
    // Asumsi detailPath filmbox biasanya "judul-film-ID". Kalau judul gak ada, tembak pakai ID aja
    const targetDetailPath = detailPath || `dramovnime-fallback-${id}`;

    // Kita hit ke Filmbox API
    const rawFilmboxData = await fetchUpstream(`${API_BASE}/detail?detailPath=${targetDetailPath}`);

    // Cek jika API Filmbox nolak atau data tidak ditemukan
    if (!rawFilmboxData || rawFilmboxData.code !== 0 || !rawFilmboxData.data || !rawFilmboxData.data.subject) {
      return NextResponse.json(
        { code: 404, message: rawFilmboxData?.message || "Detail not found in Filmbox engine", data: null },
        { status: 404 }
      );
    }

    const subject = rawFilmboxData.data.subject;
    const resource = rawFilmboxData.data.resource;

    // 🔥 4. Kita Bikin Object Mirip "rawDetailData" Dramovnime biar mapDetailDataDTO lu tetep jalan!
    // DTO lu (mapDetailDataDTO) expect format tertentu dari Dramovnime lama. Kita tipu (mock) datanya di sini.
    const mockDramovnimeRawData = {
      code: 0,
      message: "ok",
      data: {
        subjectId: subject.subjectId || id,
        subjectType: subject.subjectType || 1,
        title: subject.title || "",
        description: subject.description || "",
        releaseDate: subject.releaseDate || "",
        appointmentDate: subject.appointmentDate || "",
        genre: subject.genre || "",
        cover: subject.cover || { url: "" },
        countryName: subject.countryName || "",
        subtitles: subject.subtitles || "",
        imdbRatingValue: subject.imdbRatingValue || "0",
        trailer: subject.trailer || { videoAddress: { url: "" } },
        views: subject.views || "0",
        detailPath: subject.detailPath || targetDetailPath,
      }
    };

    // Transform Data Detail menggunakan DTO Dramovnime Asli
    let mainData = mapDetailDataDTO(mockDramovnimeRawData);

    if (!mainData || !mainData.data) {
      return NextResponse.json({ code: 500, message: "Gagal memproses DTO mapping", data: null }, { status: 500 });
    }

    // 🔥 5. Format dan Gabungkan Seasons dari Data Filmbox (Persis Logic Lama)
    let finalSeasonsList: any[] = [];
    let calculatedTotalEpisodes = 0;
    const seasonsRaw = resource?.seasons || [];

    if (seasonsRaw.length > 0) {
      finalSeasonsList = seasonsRaw.map((s: any) => {
        // Filmbox punya resolusi untuk nebak jumlah episode
        let maxFromRes = 0;
        for (const r of (s.resolutions || [])) {
          if (r.epNum > maxFromRes) maxFromRes = r.epNum;
        }

        // Tentukan jumlah episode untuk season ini
        const seasonEps = Math.max(s.maxEp || 0, maxFromRes);
        const epsCount = seasonEps === 0 ? 1 : seasonEps;

        let episodesArray: number[] = [];

        // Logika Khusus: Kalau ini Movie (subjectType === 1) dan max ep 1, jadikan [0]
        if (mainData.data.subjectType === 1 && epsCount === 1) {
          episodesArray = [0];
        } else {
          episodesArray = Array.from({ length: epsCount }, (_, i) => i + 1);
        }

        calculatedTotalEpisodes += episodesArray.length;

        return {
          season: s.se || 1,
          total_episodes: epsCount,
          episodes: episodesArray
        };
      });
    } else {
      // Fallback kalau tiba-tiba datanya kosong di Filmbox (asumsikan Movie 1 episode)
      calculatedTotalEpisodes = 1;
      const epStart = mainData.data.subjectType === 1 ? 0 : 1;
      finalSeasonsList.push({ season: 1, total_episodes: 1, episodes: [epStart] });
    }

    // 🔥 6. Update data ke mainData sebelum di-return
    mainData.data.seasons_list = finalSeasonsList;
    mainData.data.totalEpisode = calculatedTotalEpisodes;
    mainData.data.totalSeason = finalSeasonsList.length;

    // 🔥 7. Kembalikan response bersih yang 100% kompatibel sama Frontend lama Dramovnime
    return NextResponse.json(mainData, {
      headers: { 'Content-Type': 'application/json' },
      status: 200
    });

  } catch (error: any) {
    return NextResponse.json(
      { code: 500, message: "Terjadi kesalahan pada mesin backend Filmbox: " + error.message, data: null },
      { status: 500 }
    );
  }
}