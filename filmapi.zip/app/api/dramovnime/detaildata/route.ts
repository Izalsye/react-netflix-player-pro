// file: api/dramovnime/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { API_BASE, fetchUpstream } from '@/lib/filmboxProxy';
import { mapDetailDataDTO } from '@/lib/detaildto';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  // 1. Validasi API Key Dramovnime 
  const auth = await validateApiKey(req, 'dramovnime');
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  // 2. Tangkap Parameter 
  const sp = req.nextUrl.searchParams;
  const id = sp.get('id') || sp.get('subjectId');
  let detailPath = sp.get('detailPath');

  if (!id) {
    return NextResponse.json({ error: true, message: "Missing query: id (subjectId)" }, { status: 400 });
  }

  try {
    const targetDetailPath = detailPath || `dramovnime-fallback-${id}`;

    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT DRAMOVNIME DETAIL VIA FILMBOX 🔥
    const cacheKey = `dramovnime:detail:${id}:path:${targetDetailPath}`;
    const cacheTTL = 3600; // 1 Jam (Detail jarang berubah)

    const finalData = await getOrSetCache(cacheKey, async () => {
      // Kita hit ke Filmbox API
      const rawFilmboxData = await fetchUpstream(`${API_BASE}/detail?detailPath=${targetDetailPath}`);

      // Cek jika API Filmbox nolak atau data tidak ditemukan
      if (!rawFilmboxData || rawFilmboxData.code !== 0 || !rawFilmboxData.data || !rawFilmboxData.data.subject) {
        throw { status: 404, message: rawFilmboxData?.message || "Detail not found in Filmbox engine" };
      }

      const subject = rawFilmboxData.data.subject;
      const resource = rawFilmboxData.data.resource;

      // Bikin Object Mirip "rawDetailData" Dramovnime
      const mockDramovnimeRawData = {
        code: 0,
        message: "ok",
        data: {
          subjectId: subject.subjectId || id,
          subjectType: subject.subjectType || 1,
          title: subject.title || "",
          description: subject.description || "",
          releaseDate: subject.releaseDate || "",
          appointmentDate: subject.appointmentDate || "",
          genre: subject.genre || "",
          cover: subject.cover || { url: "" },
          countryName: subject.countryName || "",
          subtitles: subject.subtitles || "",
          imdbRatingValue: subject.imdbRatingValue || "0",
          trailer: subject.trailer || { videoAddress: { url: "" } },
          views: subject.views || "0",
          detailPath: subject.detailPath || targetDetailPath,
        }
      };

      // Transform Data Detail menggunakan DTO Dramovnime Asli
      let mainData = mapDetailDataDTO(mockDramovnimeRawData);

      if (!mainData || !mainData.data) {
        throw { status: 500, message: "Gagal memproses DTO mapping" };
      }

      // Format dan Gabungkan Seasons
      let finalSeasonsList: any[] = [];
      let calculatedTotalEpisodes = 0;
      const seasonsRaw = resource?.seasons || [];

      if (seasonsRaw.length > 0) {
        finalSeasonsList = seasonsRaw.map((s: any) => {
          let maxFromRes = 0;
          for (const r of (s.resolutions || [])) {
            if (r.epNum > maxFromRes) maxFromRes = r.epNum;
          }

          const seasonEps = Math.max(s.maxEp || 0, maxFromRes);
          const epsCount = seasonEps === 0 ? 1 : seasonEps;
          let episodesArray: number[] = [];

          if (mainData.data.subjectType === 1 && epsCount === 1) {
            episodesArray = [0];
          } else {
            episodesArray = Array.from({ length: epsCount }, (_, i) => i + 1);
          }

          calculatedTotalEpisodes += episodesArray.length;

          return {
            season: s.se || 1,
            total_episodes: epsCount,
            episodes: episodesArray
          };
        });
      } else {
        calculatedTotalEpisodes = 1;
        const epStart = mainData.data.subjectType === 1 ? 0 : 1;
        finalSeasonsList.push({ season: 1, total_episodes: 1, episodes: [epStart] });
      }

      mainData.data.seasons_list = finalSeasonsList;
      mainData.data.totalEpisode = calculatedTotalEpisodes;
      mainData.data.totalSeason = finalSeasonsList.length;

      return mainData; // Return hasil yang sudah di mapping

    }, cacheTTL);

    // Kembalikan response bersih
    return NextResponse.json(finalData, {
      headers: { 'Content-Type': 'application/json' },
      status: 200
    });

  } catch (error: any) {
    // Ambil status asli dari throw
    const originalStatus = error.status || 500;

    // 🛡️ ANTI-NGINX HTML
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: null
    }, {
      status: safeHttpStatus
    });
  }
}