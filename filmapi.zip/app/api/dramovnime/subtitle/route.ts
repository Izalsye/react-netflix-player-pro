import { NextRequest, NextResponse } from 'next/server';
import { proxyGetRaw } from '@/lib/proxy'; // 👈 Pakai proxyGetRaw
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  // 🔥 Panggil validasi API Key (sebelumnya kelupaan dipanggil)
  const auth = await validateApiKey(req, 'dramovnime');

  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  const sp = req.nextUrl.searchParams;
  const id = sp.get('id');       // Map ke subjectId
  const resId = sp.get('resId'); // Map ke resourceId/streamId
  const ep = sp.get('ep');       // Map ke episode

  if (!id || !resId || !ep) {
    return NextResponse.json(
      { error: true, message: "Missing query: id, resId, or ep" },
      { status: 400 }
    );
  }

  try {
    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT SUBTITLE 🔥
    const cacheKey = `dramovnime:subtitle:id:${id}:resId:${resId}:ep:${ep}`;
    const cacheTTL = 3600; // 1 Jam (Subtitle sangat jarang berubah)

    const rawData = await getOrSetCache(cacheKey, async () => {
      const data = await proxyGetRaw(
        req,
        "/wefeed-mobile-bff/subject-api/get-ext-captions",
        {
          episode: ep,
          resourceId: resId,
          subjectId: id,
        },
        { label: "/dramovnime/subtitle" }
      );

      return data;
    }, cacheTTL);

    // Langsung kembalikan datanya
    return NextResponse.json(rawData);

  } catch (error: any) {
    // Ambil status asli dari error
    const originalStatus = error.status || 502;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: error.raw || null
    }, {
      status: safeHttpStatus
    });
  }
}