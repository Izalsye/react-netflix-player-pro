import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const id = sp.get('id');       // Map ke subjectId
  const resId = sp.get('resId'); // Map ke resourceId/streamId
  const ep = sp.get('ep');       // Map ke episode
  if (!id || !resId || !ep) return NextResponse.json({ error: true, message: "Missing query: id, resId, or ep" }, { status: 400 });
  return proxyGet(req, "/wefeed-mobile-bff/subject-api/get-ext-captions", {
    episode: ep ?? 0,
    resourceId: resId,
    subjectId: id,
  }, { label: "/subtitle", cacheTtlMs: 60000 });
}
