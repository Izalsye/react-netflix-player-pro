import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }
  const id = req.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: true, message: "Missing query: id" }, { status: 400 });
  return proxyGet(req, "/wefeed-mobile-bff/subject-api/season-info", { subjectId: id }, { label: "/info", cacheTtlMs: 300000 });
}
