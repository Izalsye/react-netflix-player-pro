import { NextRequest, NextResponse } from 'next/server';
import { proxyGetRaw } from '@/lib/proxy'; // 👈 Pakai proxyGetRaw
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  const id = req.nextUrl.searchParams.get('id');
  if (!id) {
    return NextResponse.json(
      { error: true, message: "Missing query: id" },
      { status: 400 }
    );
  }

  try {
    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT INFO ANIME/SERIES 🔥
    const cacheKey = `dramovnime:info:${id}`;
    const cacheTTL = 300; // 5 Menit (300 detik)

    const rawData = await getOrSetCache(cacheKey, async () => {
      // Panggil proxyGetRaw dengan mengirimkan subjectId
      const data = await proxyGetRaw(
        req,
        "/wefeed-mobile-bff/subject-api/season-info",
        { subjectId: id },
        { label: "/dramovnime/info" }
      );

      return data;
    }, cacheTTL);

    // Langsung kembalikan datanya
    return NextResponse.json(rawData);

  } catch (error: any) {
    // Ambil status asli dari error
    const originalStatus = error.status || 502;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: error.raw || null
    }, {
      status: safeHttpStatus
    });
  }
}