import { NextRequest, NextResponse } from 'next/server';
import { proxyGetRaw } from '@/lib/proxy'; // 👈 Pakai proxyGetRaw
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  const sp = req.nextUrl.searchParams;
  const id = sp.get('id');
  const ep = sp.get('ep') ?? "1";
  const se = sp.get('se') ?? "1";

  if (!id) {
    return NextResponse.json(
      { error: true, message: "Missing query: id" },
      { status: 400 }
    );
  }

  try {
    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT PLAY INFO 🔥
    const cacheKey = `dramovnime:play:${id}:se:${se}:ep:${ep}`;
    const cacheTTL = 60; // 60 detik (1 menit) biar URL video gak keburu basi

    const rawData = await getOrSetCache(cacheKey, async () => {
      // Panggil proxyGetRaw dengan query parameters ep, se, subjectId
      const data = await proxyGetRaw(
        req,
        "/wefeed-mobile-bff/subject-api/play-info",
        { ep, se, subjectId: id },
        { label: "/dramovnime/play" }
      );

      return data;
    }, cacheTTL);

    // Langsung kembalikan datanya
    return NextResponse.json(rawData);

  } catch (error: any) {
    // Ambil status asli dari error
    const originalStatus = error.status || 502;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: error.raw || null
    }, {
      status: safeHttpStatus
    });
  }
}