import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'dramovnime');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const sp = req.nextUrl.searchParams;
    const tabId = sp.get('tabId');

    // Validasi tabId
    if (!tabId) {
        return NextResponse.json(
            { error: true, message: "Missing query: tabId" },
            { status: 400 }
        );
    }

    return proxyGet(
        req,
        "/wefeed-mobile-bff/subject-api/filter-items",
        {
            filterItemVer: sp.get('filterItemVer') ?? "v3", // Default v3 kalau kosong
            tabId: tabId,
        },
        {
            label: "/filter-items",
            cacheTtlMs: 300000
        }
    );
}