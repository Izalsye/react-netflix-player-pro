// file: app/api/dramovnime/getplay/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';
import { fetchUpstream } from '@/lib/filmboxProxy'; // Engine utama (Filmbox)
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

// 🚀 IMPORT BUAT FALLBACK KE DRAMOVNIME
import { movieboxGet } from '@/lib/moviebox/proxy';
import { MovieboxMapper } from '@/lib/moviebox/mapping';

export const dynamic = 'force-dynamic';

const USE_PROXY_FOR_THIS_ROUTE = false;

// ==========================================
// 🚀 HELPER: NORMALISASI KODE BAHASA
// ==========================================
function normalizeLang(lang: string | null | undefined): string {
  if (!lang) return '';
  const cleanLang = lang.toLowerCase().trim();
  const paramMap: Record<string, string> = {
    'id_id': 'id', 'in_id': 'id', 'id': 'id',
    'en_us': 'en', 'en': 'en',
    'zh_cn': 'zh-CN', 'zh_tw': 'zh-TW',
    'ms_my': 'ms'
  };
  return paramMap[cleanLang] || cleanLang;
}

// ==========================================
// 🚀 HELPER: GENERATE PROXY URL (STREAM & SUB)
// ==========================================
function getProxyUrl(provider: string, type: string, originalUrl: string | null): string {
  if (!originalUrl) return '';
  const BASE_DOMAIN = process.env.NEXT_PUBLIC_SITE_URL || '';
  const encodedUrl = encodeURIComponent(originalUrl);
  return `${BASE_DOMAIN}/api/proxy?url=${encodedUrl}&provider=${provider}&type=${type}`;
}

// ==========================================
// HELPER: TEMPLATE KOSONG (ANTI-CRASH)
// ==========================================
function getEmptyData(id: string, se: string | number, ep: string | number) {
  return {
    subjectId: id || '',
    se: Number(se) || 1,
    episode: Number(ep) || 1,
    actual_episode_used: null,
    quality: 0,
    format: '',
    vid_url: '',
    vid_url_proxy: '',
    hls: null,
    dash: null,
    sub_url: null,
    sub_url_proxy: null,
    subtitles: []
  };
}

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  // Tangkap parameter
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id') || searchParams.get('subjectId') || '';
  const se = searchParams.get('se') ?? '1';
  const ep = searchParams.get('ep') ?? '1';
  const rawLang = searchParams.get('lang') ?? 'in_id';
  const targetLang = normalizeLang(rawLang);
  const detailPath = searchParams.get('detailPath') || `fallback-${id}`;

  if (!id) {
    return NextResponse.json({
      code: 400,
      message: 'Missing query: id atau subjectId',
      data: getEmptyData(id, se, ep)
    }, { status: 400 });
  }

  console.log(`\n======================================================`);
  console.log(`[🚀 DRAMOVNIME (via FILMBOX ENGINE)] ID: ${id} | SE: ${se} | EP: ${ep}`);
  console.log(`======================================================`);

  try {
    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT GETPLAY + LANGUAGE 🔥
    const cacheKey = `dramovnime:getplay:${id}:se:${se}:ep:${ep}:lang:${targetLang}`;
    const cacheTTL = 60; // 60 detik aja biar URL Video gak basi!

    const playDataResponse = await getOrSetCache(cacheKey, async () => {
      // --- STEP 1: Fetch Video Info via Engine FILMBOX (H5 API) ---
      const playUrl = `https://movieboxhd.net/wefeed-h5api-bff/subject/play?subjectId=${id}&se=${se}&ep=${ep}&detailPath=${detailPath}&streamSignType=1`;
      const dynamicHeaders = { 'Referer': `https://movieboxhd.net/id/play/${detailPath}?id=${id}` };

      const playData = await fetchUpstream(playUrl, 'GET', null, dynamicHeaders, USE_PROXY_FOR_THIS_ROUTE);

      const streams = playData.data?.streams || [];
      const dashList = playData.data?.dash || [];

      console.log(`✅ FILMBOX: Terdeteksi ${streams.length} MP4, ${dashList.length} DASH`);

      // 🔥 FALLBACK LOGIC: Banting ke Dramovnime Lama!
      if (streams.length === 0 && dashList.length === 0) {
        console.log(`[⚠️ WARN] Stream Filmbox kosong! Banting setir ke Engine Dramovnime lama...`);

        const playInfoRes = await movieboxGet(req, '/wefeed-mobile-bff/subject-api/play-info', { subjectId: id, se, ep }, { send: false, useProxy: true });

        if (playInfoRes?.error || !playInfoRes?.data?.streams) {
          throw { status: 404, message: "Stream tidak ditemukan di kedua engine" };
        }

        const streamId = playInfoRes?.data?.streams?.[0]?.id;
        const [captionsRes, resourceRes] = await Promise.all([
          streamId ? movieboxGet(req, '/wefeed-mobile-bff/subject-api/get-stream-captions', { subjectId: id, streamId }, { send: false, useProxy: true }) : Promise.resolve(null),
          movieboxGet(req, '/wefeed-mobile-bff/subject-api/resource', { subjectId: id, se, epFrom: ep, epTo: ep, page: '1', perPage: '10', all: '0', resolution: '0' }, { send: false, useProxy: true })
        ]);

        const rawCombinedData = { code: 0, message: "ok", data: { playInfo: playInfoRes?.data, captions: captionsRes?.data, resource: resourceRes?.data } };
        const mappedData = MovieboxMapper.mapPlayDataToFilmboxFormat(rawCombinedData, se, ep);

        if (mappedData.code !== 0 || !mappedData.data) {
          throw { status: 404, message: "Gagal mapping data fallback" };
        }

        if (mappedData.data.subtitles && mappedData.data.subtitles.length > 0) {
          const matchedSub = mappedData.data.subtitles.find((sub: any) => normalizeLang(sub.lang) === targetLang);
          const finalSub = matchedSub || mappedData.data.subtitles[0];
          mappedData.data.sub_url = finalSub.url;
          mappedData.data.sub_url_proxy = finalSub.url_proxy;
        }

        return mappedData.data; // Return pure data
      }
      // 🔥 END OF FALLBACK LOGIC 🔥

      // --- STEP 2 (Jika Filmbox Sukses): Saringan Kualitas ---
      let selectedStream: any = null;
      let validMp4 = streams.filter((s: any) => s.url && !s.vipLocked);

      if (validMp4.length > 0) {
        validMp4.sort((a: any, b: any) => parseInt(b.resolutions || 0) - parseInt(a.resolutions || 0));
        selectedStream = validMp4[0];
      }

      let selectedDash = dashList.find((d: any) => d.url && !d.vipLocked) || null;
      const refStream = selectedStream || selectedDash;
      const streamId = refStream?.id || '';
      const format = refStream?.format || 'MP4';

      // --- STEP 3: Fetch Subtitle via Filmbox H5 ---
      let allSubtitles: any[] = [];
      let finalSubUrl = null;
      let finalSubUrlProxy = null;

      if (streamId) {
        const captionUrl = `https://h5-api.aoneroom.com/wefeed-h5api-bff/subject/caption?format=${format}&id=${streamId}&subjectId=${id}&detailPath=${detailPath}`;
        const subtitleData = await fetchUpstream(captionUrl, 'GET', null, dynamicHeaders, USE_PROXY_FOR_THIS_ROUTE);

        const captions = subtitleData.data?.captions || [];
        if (captions.length > 0) {
          allSubtitles = captions.map((cap: any) => {
            const originalUrl = cap.url || "";
            const proxyUrl = getProxyUrl('filmbox', 'sub', originalUrl);
            return {
              lang: cap.lan || cap.lanCode || "",
              label: cap.lanName || cap.lan || "Unknown",
              id: cap.lan || "",
              url: originalUrl,
              url_proxy: proxyUrl,
              subUrl: proxyUrl
            };
          });

          const matchedSub = allSubtitles.find((cap: any) => normalizeLang(cap.lang) === targetLang);
          const defaultSub = matchedSub || allSubtitles[0];

          finalSubUrl = defaultSub.url;
          finalSubUrlProxy = defaultSub.url_proxy;
        }
      }

      // --- STEP 4: MAPPING DATA KE FORMAT DRAMOVNIME LAMA ---
      let vid_url = "";
      let vid_url_proxy = "";

      if (selectedStream?.url) {
        vid_url = selectedStream.url;
        vid_url_proxy = getProxyUrl('filmbox', 'stream', vid_url);
      }

      const hlsArray = validMp4.map((s: any) => ({
        resolutions: s.resolutions || "Unknown",
        url: s.url,
        url_proxy: getProxyUrl('filmbox', 'stream', s.url)
      }));

      let dashData = null;
      if (selectedDash?.url) {
        dashData = {
          url: selectedDash.url,
          url_proxy: getProxyUrl('filmbox', 'stream', selectedDash.url),
          signCookie: selectedDash.signCookie || null,
          signHeaderKey: selectedDash.signHeaderKey || null,
          resolutions: selectedDash.resolutions || null
        };
      }

      const finalQuality = selectedStream ? parseInt(selectedStream.resolutions || 0)
        : (selectedDash ? parseInt(selectedDash.resolutions?.split(',')[0] || 0) : 0);

      const dto = {
        subjectId: id,
        se: parseInt(String(se)),
        episode: parseInt(String(ep)),
        actual_episode_used: parseInt(String(ep)),
        quality: finalQuality,
        format: format,
        vid_url: vid_url,
        vid_url_proxy: vid_url_proxy,
        hls: hlsArray.length > 0 ? hlsArray : null,
        dash: dashData,
        sub_url: finalSubUrl,
        sub_url_proxy: finalSubUrlProxy,
        subtitles: allSubtitles
      };

      return dto;
    }, cacheTTL);

    // Return final JSON
    return NextResponse.json({ code: 0, message: "ok", data: playDataResponse });

  } catch (error: any) {
    console.log(`[🔥 CRASH] -> ${error.message}`);

    // Ambil status asli dari error
    const originalStatus = error.status || 500;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: "H5 Fetch Error: " + (error.message || "Unknown error"),
      data: getEmptyData(id, se, ep)
    }, {
      status: safeHttpStatus
    });
  }
}