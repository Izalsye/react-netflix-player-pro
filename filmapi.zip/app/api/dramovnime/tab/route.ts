import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }
  return proxyGet(req, "/wefeed-mobile-bff/subject-api/bottom-tab", {}, { label: "/dramovnime/tab", cacheTtlMs: 300000 });
}
