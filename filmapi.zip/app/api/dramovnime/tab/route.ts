import { NextRequest, NextResponse } from 'next/server';
import { proxyGetRaw } from '@/lib/proxy'; // 👈 Pakai proxyGetRaw yang baru dibikin
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  try {
    // 🔥 BIKIN CACHE KEY BUAT DRAMOVNIME TAB 🔥
    const cacheKey = `dramovnime:tab`;
    const cacheTTL = 300; // 5 Menit (Standar buat halaman home/tab biar fresh)

    const rawData = await getOrSetCache(cacheKey, async () => {
      // Panggil proxyGetRaw tanpa perlu ngirim object req, karena kita pakai default headers
      const data = await proxyGetRaw(
        req,
        "/wefeed-mobile-bff/subject-api/bottom-tab",
        {},
        { label: "/dramovnime/tab" }
      );

      return data;
    }, cacheTTL);

    // Langsung kembalikan datanya (Dramovnime udah punya format JSON {code, msg, data} sendiri dari sananya)
    return NextResponse.json(rawData);

  } catch (error: any) {
    // Ambil status asli dari error
    const originalStatus = error.status || 502;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: error.raw || null
    }, {
      status: safeHttpStatus
    });
  }
}