import { NextRequest, NextResponse } from 'next/server';
import { proxyPost } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'dramovnime');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        // 1. Ambil body dari request yang datang (client)
        const body = await req.json();

        // 2. Susun payload dengan default value jika client tidak mengirimkannya
        // Ini supaya API kamu lebih fleksibel
        const payload = {
            page: body.page || 1,
            perPage: body.perPage || 12,
            channelId: body.channelId || "2",
            country: body.country || "All",
            classify: body.classify || "All",
            year: body.year || "All",
            rate: body.rate || ["0", "10"],
            genre: body.genre || "All",
            sort: body.sort || "ForYou",
        };

        // 3. Tembak ke upstream menggunakan proxyPost
        return await proxyPost(
            req,
            "/wefeed-mobile-bff/subject-api/list",
            payload,
            { label: "subject-list" }
        );

    } catch (error) {
        return NextResponse.json(
            { error: true, message: "Invalid JSON body" },
            { status: 400 }
        );
    }
}