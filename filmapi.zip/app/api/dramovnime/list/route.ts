import { NextRequest, NextResponse } from 'next/server';
import { proxyPostRaw } from '@/lib/proxy'; // 👈 Pakai proxyPostRaw
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'dramovnime');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const body = await req.json();

        const payload = {
            page: body.page || 1,
            perPage: body.perPage || 12,
            channelId: body.channelId || "2",
            country: body.country || "All",
            classify: body.classify || "All",
            year: body.year || "All",
            rate: body.rate || ["0", "10"],
            genre: body.genre || "All",
            sort: body.sort || "ForYou",
        };

        // 🔥 BIKIN CACHE KEY SPESIFIK BERDASARKAN PAYLOAD POST 🔥
        // Format rate kita gabung (join) biar aman jadi string
        const rateStr = Array.isArray(payload.rate) ? payload.rate.join('-') : payload.rate;
        const cacheKey = `dramovnime:list:ch:${payload.channelId}:p:${payload.page}:c:${payload.country}:cl:${payload.classify}:y:${payload.year}:r:${rateStr}:g:${payload.genre}:s:${payload.sort}`;
        const cacheTTL = 300; // 5 Menit

        const rawData = await getOrSetCache(cacheKey, async () => {
            const data = await proxyPostRaw(
                req,
                "/wefeed-mobile-bff/subject-api/list",
                payload,
                { label: "subject-list" }
            );
            return data;
        }, cacheTTL);

        return NextResponse.json(rawData);

    } catch (error: any) {
        // Cek kalau error karena gagal parse JSON body dari request client
        if (error.name === 'SyntaxError') {
            return NextResponse.json(
                { error: true, message: "Invalid JSON body" },
                { status: 400 }
            );
        }

        // Ambil status asli dari error upstream
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: error.raw || null
        }, {
            status: safeHttpStatus
        });
    }
}