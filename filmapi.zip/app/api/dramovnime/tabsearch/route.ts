import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }
  const sp = req.nextUrl.searchParams;
  return proxyGet(req, "/wefeed-mobile-bff/tab-operating", {
    page: sp.get('page') ?? "1",
    tabId: sp.get('tabId') ?? "0",
    version: sp.get('version') ?? process.env.TABSEARCH_VERSION ?? "195dac7047d7b01b17c6951db7a0f23c"
  }, { label: "/dramovnime/tabsearch", cacheTtlMs: 300000 });
}
