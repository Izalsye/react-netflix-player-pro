import { NextRequest, NextResponse } from 'next/server';
import { proxyGetRaw } from '@/lib/proxy'; // 👈 Pakai proxyGetRaw
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const auth = await validateApiKey(req, 'dramovnime');

  // Kalau API Key ngasal atau limit abis, langsung tendang!
  if (!auth.isValid) {
    return NextResponse.json(
      { code: auth.status, message: auth.message, data: null },
      { status: auth.status }
    );
  }

  const sp = req.nextUrl.searchParams;
  const page = sp.get('page') ?? "1";
  const tabId = sp.get('tabId') ?? "0";
  const version = sp.get('version') ?? process.env.TABSEARCH_VERSION ?? "195dac7047d7b01b17c6951db7a0f23c";

  try {
    // 🔥 BIKIN CACHE KEY SPESIFIK BUAT TABSEARCH + PAGINATION 🔥
    const cacheKey = `dramovnime:tabsearch:tabId:${tabId}:page:${page}:version:${version}`;
    const cacheTTL = 300; // 5 Menit (sama kayak 300000ms lu sebelumnya)

    const rawData = await getOrSetCache(cacheKey, async () => {
      // Panggil proxyGetRaw dengan membawa query parameters
      const data = await proxyGetRaw(
        req,
        "/wefeed-mobile-bff/tab-operating",
        { page, tabId, version },
        { label: "/dramovnime/tabsearch" }
      );

      return data;
    }, cacheTTL);

    // Langsung kembalikan datanya
    return NextResponse.json(rawData);

  } catch (error: any) {
    // Ambil status asli dari error
    const originalStatus = error.status || 502;

    // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
    let safeHttpStatus = originalStatus;
    if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
      safeHttpStatus = 400;
    }

    return NextResponse.json({
      code: originalStatus,
      message: error.message || "Internal Server Error",
      data: error.raw || null
    }, {
      status: safeHttpStatus
    });
  }
}