import { NextRequest, NextResponse } from 'next/server';
import { proxyGetHtml } from '@/lib/komiku/proxy';
import { mapKomikuDetail } from '@/lib/komiku/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'komiku');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        // 1. Ambil slug dari query parameter
        const { searchParams } = new URL(req.url);
        const slug = searchParams.get('slug');

        if (!slug) {
            return NextResponse.json({ success: false, message: "Parameter 'slug' wajib diisi" }, { status: 400 });
        }

        // 2. Tembak halaman detail komiknya
        const path = `/manga/${slug}/`;
        const htmlOrError = await proxyGetHtml(req, path, {
            label: 'komiku-detail',
            send: false
        });

        // 3. Tangkap error API Key / Proxy
        if (typeof htmlOrError === 'object' && htmlOrError !== null && 'error' in htmlOrError) {
            return NextResponse.json(htmlOrError, { status: htmlOrError.status || 502 });
        }

        if (typeof htmlOrError !== 'string') {
            throw new Error("Gagal fetch HTML: Format respons tidak valid");
        }

        // 4. Ubah HTML Mentah jadi JSON Detail
        const mappedData = mapKomikuDetail(htmlOrError, slug);

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error("Komiku Detail Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error saat memproses Detail" },
            { status: 500 }
        );
    }
}