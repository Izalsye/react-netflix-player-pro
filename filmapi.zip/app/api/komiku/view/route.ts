// file: api/komiku/view/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGetHtml } from '@/lib/komiku/proxy';
import { mapKomikuView } from '@/lib/komiku/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

// 🚀 MEMORY CACHE: Ingat pola URL per komik biar gak nebak terus!
const pathPatternCache = new Map<string, string>();

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'komiku');
    if (!auth.isValid) {
        return NextResponse.json({ code: auth.status, message: auth.message, data: null }, { status: auth.status });
    }

    try {
        const { searchParams } = new URL(req.url);
        const slug = searchParams.get('slug');
        const chapter = searchParams.get('chapter');

        if (!slug || !chapter) {
            return NextResponse.json({ success: false, message: "Parameter 'slug' dan 'chapter' wajib diisi" }, { status: 400 });
        }

        const customHeaders = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Host": "komiku.org",
            "Referer": "https://komiku.org/",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
        };

        const rawChapter = chapter.trim();
        // Hapus nol di depan kalau ada (01 -> 1)
        const unpaddedChapter = rawChapter.replace(/^0+/, '') || rawChapter;
        const normalizedChapter = unpaddedChapter.replace(/\./g, "-");
        const altSlug = slug.replace(/^komik-/i, '').replace(/-indo$/i, '');

        let htmlOrError: any = null;

        // 1️⃣ CEK CACHE POLA URL (Jalan Pintas)
        if (pathPatternCache.has(slug)) {
            const pattern = pathPatternCache.get(slug)!;

            // Rakit URL pakai pola yang udah terbukti berhasil
            const exactPath = pattern
                .replace('{slug}', slug)
                .replace('{altSlug}', altSlug)
                .replace('{ch}', normalizedChapter)
                .replace('{rawCh}', rawChapter);

            htmlOrError = await proxyGetHtml(req, exactPath, { label: 'komiku-view', send: false, headers: customHeaders });

            // Di bagian CEK CACHE
            if (typeof htmlOrError === 'object' && htmlOrError !== null && 'status' in htmlOrError && htmlOrError.status === 404) {
                pathPatternCache.delete(slug);
                return NextResponse.json({ success: false, message: "URL sumber berubah format" }, { status: 404 });
            }
        }

        // 2️⃣ KALAU BELUM ADA DI CACHE: Tembak Barengan (Tanpa Loop)
        else {
            // Siapkan blueprint tebakan
            const patterns = [
                `/${slug}-chapter-{ch}/`,
                `/${altSlug}-chapter-{ch}/`,
                `/${slug}-chapter-{rawCh}/`,
                `/chapter/{ch}/`
            ];

            // Map menjadi promise. Tolak (reject) yang 404.
            const fetchPromises = patterns.map(async (pattern) => {
                const testPath = pattern
                    .replace('{slug}', slug)
                    .replace('{altSlug}', altSlug)
                    .replace('{ch}', normalizedChapter)
                    .replace('{rawCh}', rawChapter);

                const res = await proxyGetHtml(req, testPath, { label: 'komiku-view', send: false, headers: customHeaders });

                // Type Guarding buat res
                if (typeof res === 'object' && res !== null && 'status' in res && res.status === 404) {
                    throw new Error("404 Not Found");
                }
                return { pattern, res };
            });

            try {
                // Promise.any = Langsung ambil request PERTAMA yang berhasil 200 (Gak peduli yang lain gagal)
                const firstSuccess = await Promise.any(fetchPromises);
                htmlOrError = firstSuccess.res;

                // Simpan blueprint yang menang ke memory!
                pathPatternCache.set(slug, firstSuccess.pattern);
            } catch (e) {
                // Akan masuk ke sini cuma kalau SEMUA tebakan URL ngasilin 404
                return NextResponse.json({ success: false, message: "Gagal menemukan chapter dengan semua kombinasi URL" }, { status: 404 });
            }
        }

        // 3️⃣ ERROR HANDLING & PARSING (Sama seperti sebelumnya)
        if (typeof htmlOrError === 'object' && htmlOrError !== null && 'error' in htmlOrError) {
            return NextResponse.json(htmlOrError, { status: htmlOrError.status || 502 });
        }

        if (typeof htmlOrError !== 'string') {
            throw new Error("Gagal fetch HTML: Format respons tidak valid");
        }

        const mappedData = mapKomikuView(htmlOrError, slug, chapter);

        if (!mappedData.images || mappedData.images.length === 0) {
            return NextResponse.json({ success: false, message: "Gagal menemukan gambar untuk chapter ini" }, { status: 404 });
        }

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error(`Komiku View Error:`, error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error saat memproses baca chapter" },
            { status: 500 }
        );
    }
}