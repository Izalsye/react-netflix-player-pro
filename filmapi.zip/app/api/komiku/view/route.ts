import { NextRequest, NextResponse } from 'next/server';
import { proxyGetHtml } from '@/lib/komiku/proxy';
import { mapKomikuView } from '@/lib/komiku/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'komiku');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const slug = searchParams.get('slug');
        const chapter = searchParams.get('chapter');

        if (!slug || !chapter) {
            return NextResponse.json({ success: false, message: "Parameter 'slug' dan 'chapter' wajib diisi" }, { status: 400 });
        }

        // Tembus proteksi
        const customHeaders = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Host": "komiku.org",
            "Referer": "https://komiku.org/",
            "Origin": "https://komiku.org",
            "sec-ch-ua": '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
        };

        const rawChapter = chapter.trim();
        const normalizedChapter = rawChapter.replace(/\./g, "-");

        // 🎯 NORMALISASI CHAPTER (Buat variasi dengan dan tanpa angka 0 di depan)
        const chapterVariations: string[] = [rawChapter, normalizedChapter];

        // Kalau chapter bisa di-parse jadi angka, kita bikin variasi stringnya
        const chapterNum = parseFloat(rawChapter);
        if (!isNaN(chapterNum)) {
            // Misal: kalau dikasih '1' atau '1.5', variasi padding: '01' atau '01.5'
            if (chapterNum < 10) {
                const padded = rawChapter.startsWith("0") ? rawChapter : `0${rawChapter}`;
                const unpadded = rawChapter.replace(/^0+/, ''); // Hapus nol di depan kalau ada

                // Tambahkan variasi ke array (Set nanti yg urus duplikat)
                chapterVariations.push(padded, unpadded);
                chapterVariations.push(padded.replace(/\./g, "-"), unpadded.replace(/\./g, "-"));
            }
        }

        // 🎯 Fallback cerdas: Hapus "komik-" dan "-indo" kalau ada
        const altSlug = slug.replace(/^komik-/i, '').replace(/-indo$/i, '');

        // Bikin daftar kemungkian URL dari SEMUA variasi chapter
        let candidatePaths: string[] = [];

        // Loop setiap variasi chapter (misal: "1", "01", "1-5", "01-5")
        for (const ch of chapterVariations) {
            candidatePaths.push(
                `/${slug}-chapter-${ch}/`,
                `/${altSlug}-chapter-${ch}/`,
                `/chapter/${ch}/`
            );
        }

        // Hapus duplikat path biar looping gak kelamaan
        candidatePaths = [...new Set(candidatePaths)];

        let htmlOrError: any = null;
        let successPath = "";

        // Loop untuk mencoba URL satu per satu
        for (const path of candidatePaths) {
            htmlOrError = await proxyGetHtml(req, path, {
                label: 'komiku-view',
                send: false,
                headers: customHeaders
            });

            // Kalau proxy merespon status 404, coba format URL selanjutnya
            if (typeof htmlOrError === 'object' && htmlOrError !== null && htmlOrError.status === 404) {
                continue;
            }

            // Kalau berhasil atau error selain 404 (misal 401 API Key), stop looping
            successPath = path;
            break;
        }

        // Cek error setelah looping selesai
        if (typeof htmlOrError === 'object' && htmlOrError !== null && 'error' in htmlOrError) {
            return NextResponse.json(htmlOrError, { status: htmlOrError.status || 502 });
        }

        if (typeof htmlOrError !== 'string') {
            throw new Error("Gagal fetch HTML: Format respons tidak valid");
        }

        // Mapping Data HTML Jadi JSON
        const mappedData = mapKomikuView(htmlOrError, slug, chapter);

        if (!mappedData.images || mappedData.images.length === 0) {
            return NextResponse.json({ success: false, message: "Gagal menemukan gambar untuk chapter ini" }, { status: 404 });
        }

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error(`Komiku View Error:`, error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error saat memproses baca chapter" },
            { status: 500 }
        );
    }
}