import { NextRequest, NextResponse } from 'next/server';
import { proxyGetHtml } from '@/lib/komiku/proxy';
import { mapKomikuPagination } from '@/lib/komiku/mapping'; // Pake fungsi yang udah di-rename
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'komiku');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);

        // 🎯 1. Tambahkan cookie dari route terbaru biar konsisten nembus anti-bot
        const cookie = '__ddg9_=103.191.92.38; __ddgid_=TZaAiYstCsVBTk28; __ddgmark_=x7B7KmhtgEu1XVdo; __ddg5_=u4mQPS9SARRR2JOo; __ddg1_=DPjM1E6WInKd8mGpfq5v; _ga_ZEY1BX76ZS=GS2.1.s1782234346$o1$g0$t1782234346$j60$l0$h0; _ga=GA1.1.2052208920.1782234346; __ddg8_=CmRdGRqldRLm9Rf4; __ddg10_=1782234349';

        const pageStr = searchParams.get('page') || '1';
        const page = parseInt(pageStr, 10);
        searchParams.delete('page');

        const queryString = searchParams.toString();
        const queryPart = queryString ? `?${queryString}` : '';

        // 🎯 2. Tentukan Worker URL
        const workerBase = 'https://indocast-manga.veifaisal16.workers.dev';

        // 🎯 3. Pola URL untuk halaman Populer (Hot) diarahkan ke Worker
        const targetUrl = page > 1
            ? `${workerBase}/other/hot/page/${page}/${queryPart}`
            : `${workerBase}/other/hot/${queryPart}`;

        // 🎯 4. Siapkan header bypass (samain dengan yg 'terbaru')
        const customHeaders = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Cookie": cookie, // 👈 Masukkan cookie
            "Origin": "https://komiku.org",
            "Referer": `https://komiku.org/other/hot/${queryPart}`,
            "sec-ch-ua": '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"', // 👈 Update sinkron Chrome 126
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        };

        const htmlOrError = await proxyGetHtml(req, targetUrl, {
            label: `komiku-populer-p${page}`,
            send: false,
            headers: customHeaders
        });

        if (typeof htmlOrError === 'object' && htmlOrError !== null && 'error' in htmlOrError) {
            return NextResponse.json(htmlOrError, { status: htmlOrError.status || 502 });
        }

        if (typeof htmlOrError !== 'string') {
            throw new Error("Gagal fetch HTML: Format respons tidak valid");
        }

        // Mapping HTML ke JSON
        const mappedData = mapKomikuPagination(htmlOrError, page);

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error(`Komiku Populer Error:`, error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error saat memproses Populer" },
            { status: 500 }
        );
    }
}