import { NextRequest, NextResponse } from 'next/server';
import { proxyGetHtml } from '@/lib/komiku/proxy';
import { mapKomikuFilters } from '@/lib/komiku/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'komiku');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        // 🎯 Pakai header Chrome buat nembus proteksi
        const customHeaders = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Host": "komiku.org",
            "sec-ch-ua": '"Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
        };

        // Kita tembak halaman pustaka utama
        const htmlOrError = await proxyGetHtml(req, '/pustaka/', {
            label: 'komiku-filters',
            send: false,
            headers: customHeaders
        });

        // Cek Error API Key / Proxy
        if (typeof htmlOrError === 'object' && htmlOrError !== null && 'error' in htmlOrError) {
            return NextResponse.json(htmlOrError, { status: htmlOrError.status || 502 });
        }

        if (typeof htmlOrError !== 'string') {
            throw new Error("Gagal fetch HTML: Format respons tidak valid");
        }

        // Sedot opsi filternya
        const mappedData = mapKomikuFilters(htmlOrError);

        return NextResponse.json(mappedData);

    } catch (error: any) {
        console.error("Komiku Filters Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error saat memproses Opsi Filter" },
            { status: 500 }
        );
    }
}