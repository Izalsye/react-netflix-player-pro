import { validateApiKey } from '@/lib/apiKeyService';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    try {
        const { searchParams } = new URL(req.url);
        const imageUrl = searchParams.get('url');

        if (!imageUrl) {
            return new NextResponse('Parameter url wajib diisi', { status: 400 });
        }

        // 🎯 KUNCI UTAMA: Tembus proteksi Hotlink Cloudflare
        const customHeaders = {
            // Referer ini WAJIB ada, ngasih tau Cloudflare seolah kita buka gambar dari web aslinya
            "Referer": "https://komiku.org/",
            "Origin": "https://komiku.org",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
            "Sec-Fetch-Dest": "image",
            "Sec-Fetch-Mode": "no-cors",
            "Sec-Fetch-Site": "cross-site",
        };

        const response = await fetch(imageUrl, {
            method: 'GET',
            headers: customHeaders,
        });

        // Kalau Cloudflare tetep ngeblokir (biasanya ngasih status 403 Forbidden)
        if (!response.ok) {
            console.error(`Gagal fetch gambar: ${response.status} ${response.statusText}`);
            return new NextResponse('Gagal memuat gambar', { status: response.status });
        }

        // Ubah response ke dalam bentuk Buffer agar bisa dirender sebagai gambar
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        // Ambil tipe konten asli dari sumber (misal: image/jpeg atau image/png)
        const contentType = response.headers.get('content-type') || 'image/jpeg';

        // Kembalikan buffer ke client frontend sebagai gambar
        return new NextResponse(buffer, {
            headers: {
                'Content-Type': contentType,
                // Cache gambar di browser client agar tidak berat nge-hit API terus
                'Cache-Control': 'public, max-age=31536000, immutable',
            },
        });

    } catch (error) {
        console.error('Error Proxy Gambar:', error);
        return new NextResponse('Internal Server Error', { status: 500 });
    }
}