import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy'; // Sesuaikan path library lu
import { formatIqiyiTrending } from '@/lib/iqiyi/mapper'; // Asumsi mapper-nya sama
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const path = 'https://api.iq.com/page/pcw_common';

    // Ambil page dari query string, default ke 1
    const { searchParams } = new URL(req.url);
    const pgNum = searchParams.get('page') || '1';

    // User Agent harus konsisten biar gak kena blok
    const userAgent = req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';

    const query: Record<string, string> = {
        app_k: 'appk_pcw',
        app_lm: 'id',
        app_t: 'i18nvideo',
        app_v: '3.1.5',
        card_v: 'v1',
        att_id: 'null',
        dev_os: 'pc',
        dev_ua: userAgent,
        lang: 'id_id',
        mod: 'id',
        net_sts: '1',
        // 🎯 KUNCI TRENDING:
        page_st: 'ranking_web',
        platform_id: '47',
        psp_cki: '',
        psp_status: '1',
        psp_uid: '30125299091', // Sesuaikan UID jika perlu (atau biarkan dinamis)
        qyid: '089ef02376449fb1ed033d0113734804',
        req_sn: String(Date.now()),
        req_times: '1',
        secure_p: 'pcw',
        secure_v: '1',
        sid: String(Date.now()),
        timezone: 'GMT+7:00',
        pg_size: '20', // Ambil 20 biar banyak
        channel_id: '0',
        customized: '1',
        pg_num: pgNum,
        cache_flag: ''
    };

    // Panggil proxy (pastikan fungsi proxyGet lu nerima header/cookie dengan benar)
    const rawData = await proxyGet(req, path, query, {
        label: 'iqiyi-trending-api',
        send: false,
        cacheTtlMs: 300_000 // Cache 5 menit
    });

    if (rawData.error) {
        return NextResponse.json(rawData, { status: rawData.status || 502 });
    }

    try {
        const pcwResponse = rawData as any;

        if (pcwResponse && pcwResponse.code === 0 && pcwResponse.cards) {
            // Pake mapper yang baru kita buat
            const formattedData = formatIqiyiTrending(pcwResponse.cards);
            return NextResponse.json({
                success: true,
                data: formattedData,
                meta: { page: pgNum }
            });
        } else {
            return NextResponse.json({
                error: true,
                message: "Format tidak dikenali dari iQIYI",
                raw: rawData
            }, { status: 502 });
        }

    } catch (e: any) {
        console.error("Trending Mapping Error:", e);
        return NextResponse.json({
            error: true,
            message: "Kesalahan saat memproses data trending",
            err: e.message
        }, { status: 500 });
    }
}