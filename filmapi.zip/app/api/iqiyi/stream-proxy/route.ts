import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge'; // Wajib Edge biar gaspol & gak error chunked

export async function GET(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    const fetchHeaders: HeadersInit = {
        'Referer': 'https://www.iq.com/',
        'Origin': 'https://www.iq.com',
        'User-Agent': req.headers.get('user-agent') || 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',
        'Accept-Encoding': 'identity' // 🔥 Cegah ukuran file corrupt
    };

    if (req.headers.has('range')) {
        fetchHeaders['Range'] = req.headers.get('range')!;
    }

    try {
        const response = await fetch(url, {
            headers: fetchHeaders,
            cache: 'no-store'
        });

        if (!response.ok && response.status !== 206) {
            return NextResponse.json({ error: "Upstream rejected", status: response.status }, { status: response.status });
        }

        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');

        // Copy header ori, buang yang bikin NextJS bingung
        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (!['transfer-encoding', 'content-encoding', 'connection', 'keep-alive', 'access-control-allow-origin'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        if (!responseHeaders.has('content-type')) {
            responseHeaders.set('Content-Type', 'video/MP2T');
        }

        // Passthrough video segment ke player FE
        return new NextResponse(response.body, {
            status: response.status,
            headers: responseHeaders
        });

    } catch (e: any) {
        console.warn(`⚠️ [iQIYI Proxy Dead] ${url}`);
        return NextResponse.json({ error: "Upstream network failed" }, { status: 502 });
    }
}