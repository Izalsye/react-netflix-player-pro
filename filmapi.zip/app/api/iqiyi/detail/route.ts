import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { extractNextData, mapIqiyiDetail } from '@/lib/iqiyi/mapper';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const { searchParams } = new URL(req.url);
    const pathplay = searchParams.get('pathplay');
    const lang = searchParams.get('lang');

    if (!pathplay) {
        return NextResponse.json({ error: true, message: "Parameter 'pathplay' wajib diisi" }, { status: 400 });
    }

    const path = `https://www.iq.com/play/${pathplay}?lang=${lang}`;

    // 🎯 MAGIC: Kita kasih header palsu biar server lu dikira Browser Manusia!

    // Pastikan proxyGet lu bisa nerima parameter headers tambahan (tergantung kode proxy lu)
    const htmlResponse = await proxyGet(req, path, {}, {
        label: 'iqiyi-detail-html',
        send: false,
        cacheTtlMs: 300_000,
    });

    // 🎯 1. TANGKAP ERROR DARI PROXY DULU (Termasuk error API Key Invalid)
    if (typeof htmlResponse === 'object' && htmlResponse !== null && 'error' in htmlResponse) {
        return NextResponse.json(htmlResponse, { status: htmlResponse.status || 502 });
    }

    // 🎯 2. BARU CEK APAKAH DIA BENARAN STRING HTML
    if (typeof htmlResponse !== 'string') {
        return NextResponse.json({ error: true, message: "Gagal fetch, respons dari proxy tidak berformat teks", details: htmlResponse }, { status: 502 });
    }

    try {
        const nextData = extractNextData(htmlResponse);

        if (!nextData || !nextData.props?.initialState) {
            return NextResponse.json({ error: true, message: "Tag __NEXT_DATA__ tidak valid" }, { status: 500 });
        }

        const formattedDetail = mapIqiyiDetail(nextData.props);

        return NextResponse.json(formattedDetail);

    } catch (e: any) {
        console.error("Detail Route Error:", e);
        return NextResponse.json({ error: true, message: "Terjadi kesalahan saat mapping data detail", err: e.message }, { status: 500 });
    }
}