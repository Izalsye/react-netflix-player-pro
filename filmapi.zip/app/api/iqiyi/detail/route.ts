import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { extractNextData, mapIqiyiDetail } from '@/lib/iqiyi/mapper';
import { validateApiKey } from '@/lib/apiKeyService';

// 🎯 FUNGSI TRANSLATE ALTERNATIF: Bebas blokir IP Server
async function autoTranslate(text: string, targetLang: string): Promise<string> {
    if (!text || targetLang.toLowerCase().includes('id')) return text;

    try {
        const gLang = targetLang.split('_')[0]; // Ubah th_th jadi th

        const email = "veifaisal16@gmail.com";
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=id|${gLang}&de=${email}`;

        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        const contentType = response.headers.get("content-type");
        if (!response.ok || !contentType?.includes("application/json")) {
            console.warn(`[AutoTranslate] Gagal fetch dari API.`);
            return text;
        }

        const data = await response.json();

        // MyMemory mengembalikan hasil di data.responseData.translatedText
        if (data && data.responseData && data.responseData.translatedText) {
            // Hindari hasil terjemahan limit kuota (MyMemory kadang merespon limit text)
            if (!data.responseData.translatedText.includes("MYMEMORY WARNING")) {
                return data.responseData.translatedText;
            }
        }

        return text;
    } catch (error: any) {
        console.error("[AutoTranslate] Error:", error.message);
        return text; // Fallback ke teks asli jika error
    }
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const pathplay = searchParams.get('pathplay');
    const lang = searchParams.get('lang') || 'id_id'; // Default ke indo kalau kosong

    if (!pathplay) {
        return NextResponse.json({ error: true, message: "Parameter 'pathplay' wajib diisi" }, { status: 400 });
    }

    const path = `https://www.iq.com/play/${pathplay}?lang=${lang}`;

    // 🎯 SOLUSI 1: Bikin Header & Cookie Palsu biar iQIYI ngira ini browser dari negara target
    const baseLang = lang.split('_')[0];
    const fakeHeaders = {
        'Accept-Language': `${baseLang},en-US;q=0.9,en;q=0.8`,
        'Cookie': `lang=${lang}; QC005=b89b88302061214088424177728f3319;`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    };

    const htmlResponse = await proxyGet(req, path, fakeHeaders, {
        label: 'iqiyi-detail-html',
        send: false,
        cacheTtlMs: 300_000,
    });

    if (typeof htmlResponse === 'object' && htmlResponse !== null && 'error' in htmlResponse) {
        return NextResponse.json(htmlResponse, { status: htmlResponse.status || 502 });
    }

    if (typeof htmlResponse !== 'string') {
        return NextResponse.json({ error: true, message: "Gagal fetch, respons dari proxy tidak berformat teks", details: htmlResponse }, { status: 502 });
    }

    try {
        const nextData = extractNextData(htmlResponse);

        if (!nextData || !nextData.props?.initialState) {
            return NextResponse.json({ error: true, message: "Tag __NEXT_DATA__ tidak valid" }, { status: 500 });
        }

        let formattedDetail = mapIqiyiDetail(nextData.props);

        // 🎯 EKSEKUSI SOLUSI 2
        if (!lang.toLowerCase().includes('id')) {
            // 1. Translate sinopsis/overview (1 Request)
            formattedDetail.overview = await autoTranslate(formattedDetail.overview, lang);

            // 2. Translate Genres (1 Request saja! Gabungkan array jadi string, lalu pecah lagi)
            // Ini akan merubah: ["Aksi", "Komedi"] -> "Aksi | Komedi" -> ditranslate -> di-split lagi
            if (formattedDetail.genres && formattedDetail.genres.length > 0) {
                const joinedGenres = formattedDetail.genres.join(" | ");
                const translatedGenres = await autoTranslate(joinedGenres, lang);
                formattedDetail.genres = translatedGenres.split("|").map(g => g.trim());
            }
        }

        return NextResponse.json(formattedDetail);

    } catch (e: any) {
        console.error("Detail Route Error:", e);
        return NextResponse.json({ error: true, message: "Terjadi kesalahan saat mapping data detail", err: e.message }, { status: 500 });
    }
}