import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(request: NextRequest) {
    // 1. Validasi API Key (Biar aman dan seragam dengan endpoint lain)
    const auth = await validateApiKey(request, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // 2. Daftar bahasa yang didukung iQIYI (Format kode menyesuaikan param 'lang' iQIYI)
        const languages = [
            { code: 'id_id', label: 'Indonesia', native: 'Bahasa Indonesia' },
            { code: 'en_us', label: 'English', native: 'English' },
            { code: 'zh_cn', label: 'Chinese (Simplified)', native: '简体中文' },
            { code: 'zh_tw', label: 'Chinese (Traditional)', native: '繁體中文' },
            { code: 'ms_my', label: 'Malay', native: 'Bahasa Melayu' },
            { code: 'th_th', label: 'Thai', native: 'ภาษาไทย' },
            { code: 'vi_vn', label: 'Vietnamese', native: 'Tiếng Việt' },
            { code: 'ko_kr', label: 'Korean', native: '한국어' },
            { code: 'ja_jp', label: 'Japanese', native: '日本語' },
            { code: 'es_la', label: 'Spanish', native: 'Español' },
            { code: 'ar_me', label: 'Arabic', native: 'العربية' }
        ];

        // 3. Return JSON
        return NextResponse.json({
            success: true,
            data: languages
        });

    } catch (error: any) {
        return NextResponse.json(
            { error: true, message: "Internal Server Error", err: error.message },
            { status: 500 }
        );
    }
}