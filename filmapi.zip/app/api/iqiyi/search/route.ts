// file: api/iqiyi/search/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { extractNextData, formatIqiyiSearch } from '@/lib/iqiyi/mapper';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const query = searchParams.get('q');

    if (!query || query.trim() === "") {
        return NextResponse.json({ code: 400, message: "Parameter 'q' (query) diperlukan", data: null }, { status: 400 });
    }

    const searchQuery = query.toLowerCase().trim();

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT IQIYI SEARCH 🔥
        const cacheKey = `iqiyi:search:q:${encodeURIComponent(searchQuery)}`;
        const cacheTTL = 3600; // 1 Jam (Biar CPU gak capek bedah HTML raksasa)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // 🎯 1. GUNAKAN PROXYGET (Matikan cache internal proxyGet)
            const rawResponse = await proxyGet(req, 'https://www.iq.com/search', { query: searchQuery }, {
                label: 'iqiyi-search',
                send: false,
                cacheTtlMs: 0 // <--- Matiin cache bawaan proxy
            });

            // 🎯 2. TANGKAP ERROR DARI PROXY
            if (typeof rawResponse === 'object' && rawResponse !== null && 'error' in rawResponse) {
                // Lempar ke block catch biar Nginx Blocker yang handle
                throw { status: rawResponse.status || 502, message: rawResponse.message || "Iqiyi Upstream Error" };
            }

            // Pastikan yang direturn beneran string HTML
            if (typeof rawResponse !== 'string') {
                throw { status: 502, message: "Format respons tidak valid (bukan HTML)" };
            }

            // 3. Ekstrak JSON dari script __NEXT_DATA__
            const nextData = extractNextData(rawResponse);

            // 4. Akses data yang benar sesuai struktur
            const searchResult = nextData?.props?.initialState?.search?.result;

            if (!searchResult || !searchResult.videos || searchResult.videos.length === 0) {
                return {
                    sections: [],
                    message: "Tidak ada hasil ditemukan"
                };
            }

            // 5. Transform ke format standar
            return formatIqiyiSearch(searchResult.videos);
        }, cacheTTL);

        // Kembalikan response JSON murni dari memori Redis
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}