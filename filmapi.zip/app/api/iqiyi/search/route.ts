import { NextRequest, NextResponse } from 'next/server';
import { extractNextData, formatIqiyiSearch } from '@/lib/iqiyi/mapper';
import { proxyGet } from '@/lib/iqiyi/proxy'; // 🎯 IMPORT PROXY-NYA
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const { searchParams } = new URL(req.url);
    const query = searchParams.get('q');

    if (!query) {
        return NextResponse.json({
            error: "Parameter 'q' (query) diperlukan"
        }, { status: 400 });
    }

    try {
        // 🎯 1. GUNAKAN PROXYGET (Sudah Include Validasi API Key & Hitungan Stats)
        const rawResponse = await proxyGet(req, 'https://www.iq.com/search', { query: query }, {
            label: 'iqiyi-search',
            send: false,
            cacheTtlMs: 300_000 // Cache 5 menit biar enteng
        });

        // 🎯 2. TANGKAP ERROR DARI PROXY (Kalo API Key Invalid)
        if (typeof rawResponse === 'object' && rawResponse !== null && 'error' in rawResponse) {
            return NextResponse.json(rawResponse, { status: rawResponse.status || 502 });
        }

        // Pastikan yang direturn beneran string HTML
        if (typeof rawResponse !== 'string') {
            throw new Error("Format respons tidak valid (bukan HTML)");
        }

        // 3. Ekstrak JSON dari script __NEXT_DATA__
        const nextData = extractNextData(rawResponse);

        // 4. Akses data yang benar sesuai struktur log lu
        const searchResult = nextData?.props?.initialState?.search?.result;

        if (!searchResult || !searchResult.videos || searchResult.videos.length === 0) {
            return NextResponse.json({
                sections: [],
                message: "Tidak ada hasil ditemukan"
            });
        }

        // 5. Transform ke format standar
        const formattedData = formatIqiyiSearch(searchResult.videos);

        return NextResponse.json(formattedData);

    } catch (error) {
        console.error('Search API Error:', error);
        return NextResponse.json(
            { error: "Internal Server Error saat memproses pencarian" },
            { status: 500 }
        );
    }
}