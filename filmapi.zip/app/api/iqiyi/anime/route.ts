import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { formatIqiyiHome } from '@/lib/iqiyi/mapper';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const pgNum = searchParams.get('page') || '1';
    const lang = searchParams.get('lang') || 'id_id';

    const path = 'https://api.iq.com/page/pcw_common';
    const userAgent = req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';

    const query: Record<string, string> = {
        app_k: 'appk_pcw',
        app_lm: 'id',
        app_t: 'i18nvideo',
        app_v: '3.1.5',
        card_v: 'v1',
        att_id: 'null',
        dev_os: 'pc',
        dev_ua: userAgent,
        lang: lang,
        mod: 'id',
        net_sts: '1',
        page_st: 'anime_web', // 🎯 KUNCI ROUTE ANIME
        platform_id: '47',
        psp_cki: '',
        psp_status: '-1',
        psp_uid: '',
        qyid: 'e9ef298b37c57d23daf8f34edeecb2e9',
        req_sn: String(Date.now()),
        req_times: '1',
        secure_p: 'pcw',
        secure_v: '1',
        sid: String(Date.now()),
        timezone: 'GMT+7:00',
        pg_size: '20', // Tarik 20 section sekaligus
        channel_id: '4', // 🎯 KODE CHANNEL 4 UNTUK ANIME
        customized: '1',
        pg_num: pgNum,
        cache_flag: ''
    };

    const rawData = await proxyGet(req, path, query, {
        label: 'iqiyi-anime-api',
        send: false,
        cacheTtlMs: 300_000
    });

    if (rawData.error) {
        return NextResponse.json(rawData, { status: rawData.status || 502 });
    }

    try {
        const pcwResponse = rawData as any;

        if (pcwResponse && pcwResponse.code === 0 && pcwResponse.cards) {
            const formattedData = formatIqiyiHome(pcwResponse.cards, pcwResponse.base);
            return NextResponse.json({
                success: true,
                data: formattedData
            });
        } else {
            return NextResponse.json({ error: true, message: "Format tidak dikenali dari iQIYI", raw: rawData }, { status: 502 });
        }

    } catch (e: any) {
        return NextResponse.json({ error: true, message: "Kesalahan saat memproses data Anime", err: e.message }, { status: 500 });
    }
}