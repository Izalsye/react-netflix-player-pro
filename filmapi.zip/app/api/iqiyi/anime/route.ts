// file: api/iqiyi/anime/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { formatIqiyiHome } from '@/lib/iqiyi/mapper';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const pgNum = searchParams.get('page') || '1';
    const lang = searchParams.get('lang') || 'id_id';

    const path = 'https://api.iq.com/page/pcw_common';
    const userAgent = req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT IQIYI ANIME 🔥
        const cacheKey = `iqiyi:anime:lang:${lang}:page:${pgNum}`;
        const cacheTTL = 300; // 5 Menit (Biar update episode anime cepet masuk)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Taruh query dengan Date.now() di SINI biar nggak ngerusak cache!
            const query: Record<string, string> = {
                app_k: 'appk_pcw',
                app_lm: 'id',
                app_t: 'i18nvideo',
                app_v: '3.1.5',
                card_v: 'v1',
                att_id: 'null',
                dev_os: 'pc',
                dev_ua: userAgent,
                lang: lang,
                mod: 'id',
                net_sts: '1',
                page_st: 'anime_web', // 🎯 KUNCI ROUTE ANIME
                platform_id: '47',
                psp_cki: '',
                psp_status: '-1',
                psp_uid: '',
                qyid: 'e9ef298b37c57d23daf8f34edeecb2e9',
                req_sn: String(Date.now()), // Ter-generate pas cache miss aja
                req_times: '1',
                secure_p: 'pcw',
                secure_v: '1',
                sid: String(Date.now()),
                timezone: 'GMT+7:00',
                pg_size: '20',
                channel_id: '4', // 🎯 KODE CHANNEL 4 UNTUK ANIME
                customized: '1',
                pg_num: pgNum,
                cache_flag: ''
            };

            // Matikan cache bawaan proxy karena kita pakai Redis
            const rawIqiyiData = await proxyGet(req, path, query, {
                label: 'iqiyi-anime-api',
                send: false,
                cacheTtlMs: 0 
            });

            if (rawIqiyiData.error) {
                // Lempar ke catch block biar disamarkan Anti-Nginx
                throw { status: rawIqiyiData.status || 502, message: rawIqiyiData.message || "Iqiyi Upstream Error" };
            }

            const pcwResponse = rawIqiyiData as any;

            if (pcwResponse && pcwResponse.code === 0 && pcwResponse.cards) {
                const formattedData = formatIqiyiHome(pcwResponse.cards, pcwResponse.base);
                return formattedData;
            } else {
                throw { status: 502, message: "Format tidak dikenali dari iQIYI" };
            }
        }, cacheTTL);

        // Kembalikan response JSON murni dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;
        
        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400; 
        }

        return NextResponse.json({
            code: originalStatus, 
            message: error.message || "Internal Server Error",
            data: null
        }, { 
            status: safeHttpStatus 
        });
    }
}