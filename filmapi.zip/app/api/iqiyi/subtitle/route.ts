import { validateApiKey } from '@/lib/apiKeyService';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const targetUrl = searchParams.get('url');

    if (!targetUrl) return new NextResponse("Missing URL", { status: 400 });

    try {
        // Fetch ke iQIYI
        const response = await fetch(decodeURIComponent(targetUrl));
        let text = await response.text();

        // 🎯 KONVERSI SRT KE VTT
        // SRT pake koma (00:00:01,000), VTT pake titik (00:00:01.000)
        // Kita tambah header WEBVTT di awal
        const vtt = "WEBVTT\n\n" + text.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');

        return new NextResponse(vtt, {
            headers: {
                'Content-Type': 'text/vtt; charset=utf-8',
                'Access-Control-Allow-Origin': '*' // Biar CORS lolos
            }
        });
    } catch (e: any) {
        return new NextResponse(e.message, { status: 500 });
    }
}