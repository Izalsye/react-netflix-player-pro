// file: api/iqiyi/play/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { extractNextData, mapIqiyiPlayUrl } from '@/lib/iqiyi/mapper';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Redis jadi tameng utama
import prisma from '@/prisma/prisma';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
    const auth = await validateApiKey(request, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');
    const lang = searchParams.get('lang') || 'id_id';

    if (!slug) {
        return NextResponse.json({ code: 400, message: "Slug wajib diisi!", data: null }, { status: 400 });
    }

    const myCookies = process.env.IQIYI_COOKIES || '';
    // Prioritaskan ENV, jika tidak ada baru gunakan request origin
    const urlku = process.env.NEXT_PUBLIC_SITE_URL || request.nextUrl.origin || '';
    const MOBILE_USER_AGENT = 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT PLAY VIDEO IQIYI 🔥
        const cacheKey = `iqiyi:play:lang:${lang}:slug:${slug}`;
        const cacheTTL = 1800; // 30 Menit (Waktu paling aman sebelum token m3u8 expired)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // 1. Ambil HTML (Matikan cache internal proxyGet)
            const htmlContent = await proxyGet(
                request,
                `https://www.iq.com/play/${slug}`,
                { lang },
                {
                    label: 'iqiyi-html',
                    send: false,
                    cacheTtlMs: 0, // Bypass Map cache
                    headers: {
                        'User-Agent': MOBILE_USER_AGENT,
                        'Cookie': myCookies,
                        'Referer': 'https://www.iq.com/?lang=id_id'
                    }
                }
            );

            if (typeof htmlContent === 'object' && htmlContent !== null && 'error' in htmlContent) {
                throw { status: htmlContent.status || 502, message: htmlContent.message || "Iqiyi Upstream Error" };
            }

            if (typeof htmlContent !== 'string') {
                throw { status: 502, message: "Format respons bukan HTML" };
            }

            const nextData = extractNextData(htmlContent);
            const ssrlog = nextData?.props?.initialProps?.pageProps?.prePlayerData?.ssrlog || "";

            const match = ssrlog.match(/dash\?([^\s"']+)/);
            if (!match || !match[1]) throw { status: 502, message: "Gagal ekstrak token dari log." };

            const queryString = match[1].replace(/\\"/g, '').replace(/"/g, '');
            const dashApiUrl = `https://intl-api.iq.com/3f4/cache-video.iq.com/dash?${queryString}`;

            // 2. Tembak API Dash
            const streamData = await proxyGet(
                request,
                dashApiUrl,
                {},
                {
                    label: 'iqiyi-dash',
                    send: false,
                    cacheTtlMs: 0,
                    headers: {
                        'User-Agent': MOBILE_USER_AGENT,
                        'Cookie': myCookies,
                        'Referer': 'https://www.iq.com/'
                    }
                }
            );

            if (typeof streamData === 'object' && streamData !== null && 'error' in streamData) {
                throw { status: streamData.status || 502, message: streamData.message || "Iqiyi Dash Error" };
            }

            // 3. Mapping Data
            const mappedData = mapIqiyiPlayUrl(streamData, urlku);

            if (mappedData.error) {
                throw { status: 404, message: mappedData.message };
            }

            // 🎯 4. SIMPAN M3U8 KE DATABASE PRISMA
            // Cuma jalan 1x tiap 30 menit saat cache Redis miss! DB lu bakal santai banget.
            if (mappedData.streamType === 'raw_hls' && mappedData.m3u8) {
                try {
                    await prisma.iqiyiCache.upsert({
                        where: { slug: slug },
                        update: {
                            m3u8: mappedData.m3u8,
                            expiresAt: new Date(Date.now() + 3 * 60 * 60 * 1000) // 3 Jam
                        },
                        create: {
                            slug: slug,
                            m3u8: mappedData.m3u8,
                            expiresAt: new Date(Date.now() + 3 * 60 * 60 * 1000) // 3 Jam
                        }
                    });
                } catch (dbError) {
                    console.error("Gagal simpan ke DB:", dbError);
                    // Jalan terus meskipun gagal save ke DB
                }
            }

            // 🎯 5. BANGUN HLS URL PURE
            const hlsUrl = mappedData.streamType === 'raw_hls'
                ? `${urlku}/api/iqiyi/indocast-stream?slug=${slug}`
                : null;

            // Return data matang untuk disimpan ke Redis
            return {
                subtitles: mappedData.subtitles,
                streamType: mappedData.streamType,
                m3u8: mappedData.m3u8,
                dashData: mappedData.dashData,
                quality: mappedData.quality,
                hls_url: hlsUrl
            };
        }, cacheTTL);

        // Kembalikan response JSON murni dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}