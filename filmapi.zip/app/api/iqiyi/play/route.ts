import { NextRequest, NextResponse } from 'next/server';
import { extractNextData, mapIqiyiPlayUrl } from '@/lib/iqiyi/mapper';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(request: NextRequest) {
    const auth = await validateApiKey(request, 'iqiyi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(request.url);
        const slug = searchParams.get('slug');
        const lang = searchParams.get('lang') || 'id_id';

        if (!slug) {
            return NextResponse.json({ error: true, message: "Slug wajib diisi!" }, { status: 400 });
        }
        const myCookies = process.env.IQIYI_COOKIES || '';
        const urlku = process.env.NEXT_PUBLIC_SITE_URL || '';

        // 🎯 DEFINISIKAN USER AGENT HP DI SINI (Pake Android 10 Samsung)
        const MOBILE_USER_AGENT = 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

        // 1. Ambil HTML dan ekstrak log
        const htmlContent = await proxyGet(
            request,
            `https://www.iq.com/play/${slug}`,
            { lang },
            {
                label: 'iqiyi-html',
                send: false,
                headers: {
                    'User-Agent': MOBILE_USER_AGENT, // <-- PASANG DI SINI
                    'Cookie': myCookies,
                    'Referer': 'https://www.iq.com/?lang=id_id'
                }
            }
        );

        // 🎯 1. TANGKAP ERROR API KEY / PROXY DULU DISINI
        if (typeof htmlContent === 'object' && htmlContent !== null && 'error' in htmlContent) {
            return NextResponse.json(htmlContent, { status: htmlContent.status || 502 });
        }

        // 🎯 2. CEK VALIDASI HTML
        if (typeof htmlContent !== 'string') {
            throw new Error("Error Pathplay id: Format respons bukan HTML");
        }

        const nextData = extractNextData(htmlContent);
        const ssrlog = nextData?.props?.initialProps?.pageProps?.prePlayerData?.ssrlog || "";

        // 2. Ekstrak token dari log
        const match = ssrlog.match(/dash\?([^\s"']+)/);
        if (!match || !match[1]) throw new Error("Gagal ekstrak token dari log.");

        const queryString = match[1].replace(/\\"/g, '').replace(/"/g, '');

        // 3. Bangun URL API Dash
        const dashApiUrl = `https://intl-api.iq.com/3f4/cache-video.iq.com/dash?${queryString}`;

        // 4. Tembak API Dash MENGGUNAKAN proxyGet AGAR LEWAT PROXY
        const streamData = await proxyGet(
            request,
            dashApiUrl,
            {}, // Kosongkan query karena sudah tergabung di dashApiUrl
            {
                label: 'iqiyi-dash',
                send: false, // Wajib false agar langsung return object JSON
                headers: {
                    'User-Agent': MOBILE_USER_AGENT, // <-- PASANG DI SINI JUGA BRE
                    'Cookie': myCookies,
                    'Referer': 'https://www.iq.com/'
                }
            }
        );

        // 🎯 Tangkap error jika proxyGet ke Dash gagal
        if (typeof streamData === 'object' && streamData !== null && 'error' in streamData) {
            return NextResponse.json(streamData, { status: streamData.status || 502 });
        }

        // Tambahin request.nextUrl.origin biar dapet http://localhost:3000
        const mappedData = mapIqiyiPlayUrl(streamData, urlku);

        if (mappedData.error) {
            return NextResponse.json({ error: true, message: mappedData.message }, { status: 404 });
        }

        return NextResponse.json({
            success: true,
            data: mappedData
        });

    } catch (error: any) {
        return NextResponse.json({ error: true, message: error.message }, { status: 500 });
    }
}