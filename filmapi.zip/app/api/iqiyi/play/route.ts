import { NextRequest, NextResponse } from 'next/server';
import { extractNextData, mapIqiyiPlayUrl } from '@/lib/iqiyi/mapper';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { validateApiKey } from '@/lib/apiKeyService';
import prisma from '@/prisma/prisma'; // 👈 Sesuaikan path ke file prisma.ts kamu

export async function GET(request: NextRequest) {
    const auth = await validateApiKey(request, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const { searchParams } = new URL(request.url);
        const slug = searchParams.get('slug');
        const lang = searchParams.get('lang') || 'id_id';

        if (!slug) {
            return NextResponse.json({ error: true, message: "Slug wajib diisi!" }, { status: 400 });
        }

        const myCookies = process.env.IQIYI_COOKIES || '';
        // Prioritaskan ENV, jika tidak ada baru gunakan request origin
        const urlku = process.env.NEXT_PUBLIC_SITE_URL || request.nextUrl.origin || '';
        const MOBILE_USER_AGENT = 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36';

        // 1. Ambil HTML
        const htmlContent = await proxyGet(
            request,
            `https://www.iq.com/play/${slug}`,
            { lang },
            {
                label: 'iqiyi-html',
                send: false,
                headers: {
                    'User-Agent': MOBILE_USER_AGENT,
                    'Cookie': myCookies,
                    'Referer': 'https://www.iq.com/?lang=id_id'
                }
            }
        );

        if (typeof htmlContent === 'object' && htmlContent !== null && 'error' in htmlContent) {
            return NextResponse.json(htmlContent, { status: htmlContent.status || 502 });
        }

        if (typeof htmlContent !== 'string') {
            throw new Error("Format respons bukan HTML");
        }

        const nextData = extractNextData(htmlContent);
        const ssrlog = nextData?.props?.initialProps?.pageProps?.prePlayerData?.ssrlog || "";

        const match = ssrlog.match(/dash\?([^\s"']+)/);
        if (!match || !match[1]) throw new Error("Gagal ekstrak token dari log.");

        const queryString = match[1].replace(/\\"/g, '').replace(/"/g, '');
        const dashApiUrl = `https://intl-api.iq.com/3f4/cache-video.iq.com/dash?${queryString}`;

        // 2. Tembak API Dash
        const streamData = await proxyGet(
            request,
            dashApiUrl,
            {},
            {
                label: 'iqiyi-dash',
                send: false,
                headers: {
                    'User-Agent': MOBILE_USER_AGENT,
                    'Cookie': myCookies,
                    'Referer': 'https://www.iq.com/'
                }
            }
        );

        if (typeof streamData === 'object' && streamData !== null && 'error' in streamData) {
            return NextResponse.json(streamData, { status: streamData.status || 502 });
        }

        // 3. Mapping Data
        // PENTING: Untuk siteOrigin, lempar origin asli agar URL .ts nya absolut. 
        // HLS.js kadang bingung kalau URL ts-nya relatif terhadap m3u8.
        const mappedData = mapIqiyiPlayUrl(streamData, urlku);

        if (mappedData.error) {
            return NextResponse.json({ error: true, message: mappedData.message }, { status: 404 });
        }

        // 🎯 4. SIMPAN M3U8 KE DATABASE PRISMA
        if (mappedData.streamType === 'raw_hls' && mappedData.m3u8) {
            try {
                await prisma.iqiyiCache.upsert({
                    where: { slug: slug },
                    update: {
                        m3u8: mappedData.m3u8,
                        expiresAt: new Date(Date.now() + 3 * 60 * 60 * 1000) // 3 Jam
                    },
                    create: {
                        slug: slug,
                        m3u8: mappedData.m3u8,
                        expiresAt: new Date(Date.now() + 3 * 60 * 60 * 1000) // 3 Jam
                    }
                });
            } catch (dbError) {
                console.error("Gagal simpan ke DB:", dbError);
                // Kita biarin jalan terus meskipun gagal save ke DB, supaya user tetep bisa nonton pakai raw m3u8
            }
        }

        // 🎯 5. BANGUN HLS URL PURE
        const hlsUrl = mappedData.streamType === 'raw_hls'
            ? `${urlku}/api/iqiyi/indocast-stream?slug=${slug}`
            : null;

        return NextResponse.json({
            success: true,
            data: {
                subtitles: mappedData.subtitles,
                streamType: mappedData.streamType,
                m3u8: mappedData.m3u8,
                dashData: mappedData.dashData,
                quality: mappedData.quality,
                hls_url: hlsUrl // 🔥 URL untuk direct play
            }
        });

    } catch (error: any) {
        return NextResponse.json({ error: true, message: error.message }, { status: 500 });
    }
}