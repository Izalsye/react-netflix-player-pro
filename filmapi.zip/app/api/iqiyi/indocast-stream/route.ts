import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // 👈 Sesuaikan path

// Gunakan nodejs karena Prisma query builder kadang bermasalah di Edge runtime
export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');

    if (!slug) {
        return new NextResponse("Missing slug", { status: 400 });
    }

    try {
        // 1. Cari M3U8 di Database
        const cache = await prisma.iqiyiCache.findUnique({
            where: { slug }
        });

        // 2. Cek eksistensi dan masa aktif (3 jam)
        if (!cache) {
            return new NextResponse("Playlist tidak ditemukan. Silakan request ulang API play.", { status: 404 });
        }

        if (cache.expiresAt < new Date()) {
            // Opsional: Hapus cache yang expired sekalian bersih-bersih
            await prisma.iqiyiCache.delete({ where: { slug } }).catch(() => { });
            return new NextResponse("Playlist expired. Silakan request ulang API play.", { status: 410 });
        }

        // 3. Return M3U8 murni
        return new NextResponse(cache.m3u8, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.apple.mpegurl',
                'Access-Control-Allow-Origin': '*', // Wajib buat player frontend
                'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0'
            }
        });

    } catch (error: any) {
        console.error("Indocast Stream DB Error:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}