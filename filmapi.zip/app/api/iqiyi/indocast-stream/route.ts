// file: api/iqiyi/indocast-stream/route.ts
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/prisma/prisma';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Redis turun tangan lindungi DB!

// Gunakan nodejs karena Prisma query builder kadang bermasalah di Edge runtime
export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');

    if (!slug) {
        return new NextResponse("Missing slug", { status: 400 });
    }

    try {
        // 🔥 CACHE KEY SPESIFIK BUAT STREAM M3U8 🔥
        const cacheKey = `iqiyi:stream:slug:${slug}`;
        const cacheTTL = 600; // 10 Menit (Udah sangat cukup buat ngistirahatin Database)

        // Kita simpan string M3U8 murni di dalam Redis
        const m3u8String = await getOrSetCache(cacheKey, async () => {
            // 1. Cari M3U8 di Database (Prisma cuma kerja 1x tiap 10 menit)
            const cache = await prisma.iqiyiCache.findUnique({
                where: { slug }
            });

            // 2. Cek eksistensi dan masa aktif
            if (!cache) {
                // Lempar error khusus biar gak di-cache sama Redis
                throw new Error("NOT_FOUND");
            }

            if (cache.expiresAt < new Date()) {
                // Hapus cache yang expired sekalian bersih-bersih (background task, gak usah di-await)
                prisma.iqiyiCache.delete({ where: { slug } }).catch(() => { });
                throw new Error("EXPIRED");
            }

            // Return string-nya buat disimpen di Redis
            return cache.m3u8;
        }, cacheTTL);

        // 3. Return M3U8 murni dari RAM Redis (Secepat kilat!)
        return new NextResponse(m3u8String, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.apple.mpegurl',
                'Access-Control-Allow-Origin': '*', // Wajib buat player frontend
                'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0'
            }
        });

    } catch (error: any) {
        console.error("Indocast Stream DB Error:", error.message);

        // Tangkap pesan error lemparan dari dalam blok cache tadi
        if (error.message === "NOT_FOUND") {
            // Kita samarkan jadi 400 (bukan 404/500) buat hindari Nginx Blocker
            return new NextResponse("Playlist tidak ditemukan. Silakan request ulang API play.", { status: 400 });
        }

        if (error.message === "EXPIRED") {
            // Kita samarkan jadi 400 juga
            return new NextResponse("Playlist expired. Silakan request ulang API play.", { status: 400 });
        }

        // Error gak terduga lainnya
        return new NextResponse("Internal Server Error", { status: 400 });
    }
}