// file: api/iqiyi/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/iqiyi/proxy';
import { formatIqiyiHome } from '@/lib/iqiyi/mapper';
import { PcwCommonResponse } from '@/types/iqiyi';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis mendarat

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'iqiyi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 🎯 TANGKAP QUERY PARAMETER LANG & PAGE
    const { searchParams } = new URL(req.url);
    const lang = searchParams.get('lang') || 'id_id'; // Default Indonesia
    const page = searchParams.get('page') || '1';     // Default halaman 1

    const path = 'https://api.iq.com/page/pcw_common';
    const userAgent = req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT IQIYI HOME 🔥
        // Nggak terpengaruh parameter timestamp yang selalu berubah!
        const cacheKey = `iqiyi:home:lang:${lang}:page:${page}`;
        const cacheTTL = 300; // 5 Menit (Biar banner dan film terbaru cepet update)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Karena parameter timestamp (req_sn, sid) ada di DALAM fungsi ini,
            // dia bakal tetep ke-generate unik saat nembak iQiyi buat bikin cache baru.
            const query: Record<string, string> = {
                app_k: 'appk_pcw',
                app_lm: 'id',
                app_t: 'i18nvideo',
                app_v: '3.1.5',
                card_v: 'v1',
                att_id: 'null',
                dev_os: 'pc',
                dev_ua: userAgent,
                lang: lang,
                mod: 'id',
                net_sts: '1',
                page_st: 'home_web',
                platform_id: '47',
                psp_cki: '',
                psp_status: '-1',
                psp_uid: '',
                qyid: 'f971e9014d294e888c7bac8daca7170e',
                req_sn: String(Date.now()), // Ter-generate saat cache miss aja
                req_times: '1',
                secure_p: 'pcw',
                secure_v: '1',
                sid: String(Date.now()),
                timezone: 'GMT+7:00',
                pg_size: '20',
                channel_id: '0',
                customized: '1',
                pg_num: page
            };

            // Karena kita udah pake Redis, cache bawaan di proxyGet kita bypass aja (set cacheTtlMs ke 0 atau buang sekalian)
            const rawIqiyiData = await proxyGet(req, path, query, {
                label: 'iqiyi-home-api',
                send: false,
                cacheTtlMs: 0 // <--- Matiin cache bawaan proxy
            });

            if (rawIqiyiData.error) {
                // Lempar ke catch block biar disamarkan Anti-Nginx
                throw { status: rawIqiyiData.status || 502, message: rawIqiyiData.message || "Iqiyi Upstream Error" };
            }

            const pcwResponse = rawIqiyiData as PcwCommonResponse;

            if (pcwResponse && pcwResponse.code === 0 && pcwResponse.cards) {
                const formattedData = formatIqiyiHome(pcwResponse.cards, pcwResponse.base);
                return formattedData;
            } else {
                throw { status: 502, message: "Format tidak dikenali dari iQIYI" };
            }
        }, cacheTTL);

        // Kembalikan response JSON murni dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}