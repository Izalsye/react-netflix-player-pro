// app/api/vidio/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapDetailResponse, mapEpisodesList } from '@/lib/vidio/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const type = searchParams.get('type') || 'content_profile';

        if (!id) {
            return NextResponse.json({ success: false, message: "Parameter 'id' wajib diisi" }, { status: 400 });
        }

        let upstreamPath = '';
        if (type === 'video') upstreamPath = `/api/videos/${id}/detail`;
        else if (type === 'livestreaming') upstreamPath = `/api/livestreamings/${id}/detail`;
        else upstreamPath = `/content_profiles/${id}`;

        const rawData = await proxyGet(req, upstreamPath, {}, { label: 'vidio-detail', send: false });

        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        // 🚀 BONGKAR RAW DATA DI SINI
        console.log("\n=== 🕵️ INVESTIGASI STRUKTUR UTAMA ===");
        if (rawData?.data) {
            console.log("Cek Attributes:", JSON.stringify(rawData.data.attributes, null, 2));
            console.log("Cek Relationships Full:", JSON.stringify(rawData.data.relationships, null, 2));
        }

        if (rawData?.included) {
            const rawPlaylists = rawData.included.filter((item: any) => item.type === 'playlists');
            console.log("Daftar Playlist Asli:", JSON.stringify(rawPlaylists, null, 2));

            const rawVideos = rawData.included.filter((item: any) => item.type === 'videos');
            console.log(`Ada ${rawVideos.length} Video di dalam Included Array`);
        } else {
            console.log("Tidak ada 'included' array.");
        }
        console.log("=====================================\n");

        const mappedData = mapDetailResponse(rawData);
        if (!mappedData.success) {
            return NextResponse.json({ success: false, message: "Konten tidak ditemukan" }, { status: 404 });
        }

        if (mappedData.type === 'content_profile' && mappedData.seasons && mappedData.seasons.length > 0) {
            const episodePromises = mappedData.seasons.map(async (season: any) => {
                const subPath = `/content_profiles/${id}/playlists/${season.id}/videos`;
                try {
                    const rawEpisodes = await proxyGet(req, subPath, { 'page[size]': '30' }, { label: 'vidio-episodes', send: false });

                    // 🚀 BONGKAR RAW EPISODES DI SINI
                    console.log(`\n=== 🎬 BONGKAR EPISODE UNTUK SEASON / PLAYLIST ID: ${season.id} ===`);
                    console.log(JSON.stringify(rawEpisodes, null, 2));
                    console.log("==============================================================\n");

                    if (rawEpisodes && !rawEpisodes.error) {
                        season.episodes = mapEpisodesList(rawEpisodes);
                    }
                } catch (err) {
                    console.error(`Gagal fetch episode season ${season.id}:`, err);
                }
            });

            await Promise.all(episodePromises);
        }

        return NextResponse.json(mappedData, { status: 200 });

    } catch (error: any) {
        console.error("Detail Route Error:", error);
        return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 });
    }
}