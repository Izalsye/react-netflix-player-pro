// app/api/vidio/play/route.ts

import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapPlayResponse } from '@/lib/vidio/mapping';
import { XApiKeyGenerator } from '@/lib/vidio/xApiKeyGenerator'; // 🚀 IMPORT GENERATORNYA
import { validateApiKey } from '@/lib/apiKeyService';

// 🚀 FIX: Paksa Next.js untuk selalu render ulang halaman ini (DILARANG CACHE)
export const dynamic = 'force-dynamic';
export const revalidate = 0;

// 🚀 1. FUNGSI GENERATOR SIGNATURE VIDIO (HASIL REVERSE ENGINEERING)
function generateVidioSignature() {
    // Vidio pake timestamp dalam detik (ada desimalnya kayak 1781922911.438)
    const timestamp = (Date.now() / 1000).toString();
    const secretKey = `V1d10D3v:${timestamp}`;
    const signature = crypto.createHmac('sha256', secretKey).update(timestamp).digest('hex');

    return { timestamp, signature };
}

// 🚀 2. FUNGSI GENERATOR LUWS (Live User Watch Session)
function generateLuws(userId: string = "") {
    let t = "";
    let r = 0;
    while (r < 32) {
        t += (~[8, 12, 16, 20].indexOf(r++) ? "-" : "") + Math.floor(16 * Math.random()).toString(16).toUpperCase();
    }
    return `${t}_${userId}`;
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Cookie standar lu (usahakan selalu dapet yang fresh kalau bisa)
    const VIDIO_COOKIE = process.env.VIDIO_COOKIES || 'ahoy_visitor=2c7e47ee-fded-4d95-9c3d-2b40e08340cc; ahoy_visit=439cadb5-00cf-482e-b5f6-7668f0012d2f; country_id=ID; _gcl_au=1.1.560390710.1781884677; _ga=GA1.2.485356854.1781884677; _gid=GA1.2.1467128538.1781884677; _fbp=fb.1.1781884678266.210796854164255730; cebs=1; _ce.clock_data=-118%2C103.191.92.38%2C1%2C16fee37559dbd42b448204446d02089f%2CChrome%2CID; afUserId=78ee6743-b937-482b-a6fc-19061678b79b-p; _ce.seg.targeting=NoRgNA3gRALFBcwCcBWEB2AumK6HQDsBXAWwCMBTAJwQAYcBjIqqighgTwSgFUBlACJQAvsLDEANhPFEpMqZiA%3D%3D; AF_SYNC=1781884680435; _ga_JBTBSESXVN=GS2.1.s1781884677$o1$g1$t1781885202$j60$l0$h0; _dc_gtm_UA-47200845-12=1; g_state={"i_l":0,"i_ll":1781885203051,"i_b":"sYtIHbsiRmwGWzE3BQUu5tXhzVqrJyuxMuM9fGKBAh8","i_e":{"enable_itp_optimization":24},"i_et":1781885203051}; _vidio_session=JIpkAGKSw5G1EEV2owZElZ%2B6uAedtEEdeFkGuW8AlLbHq%2B9Rh9lHHzjdWEViHYU%2Fna7V%2FO1JfqEJD3%2BRLvmH01nAsBZ9xRf%2F9HD6oD17rDvsRMYD3UYP2M3r17jTp4gU0db6zM5nShUAiK%2BptU9RlhTrkvfctWRPaY3UT9V6bhVSRBT9QQzhGxtgqjhOKGImznikPKRRIAlmEdZNHdakvfAz1FyDTntnbpM%3D--PYKbMa3VLztqohvW--vGKLES0%2FSqCYCE1pgDmNhQ%3D%3D; _ce.s=v~1958e66fbe3a93ec41da3560f1c72732e577677f~vir~new~lva~1781884679048~vpv~0~v11.cs~265059~v11.s~a52278f0-6bf7-11f1-a95c-b3a42ded4c46~v11.vs~1958e66fbe3a93ec41da3560f1c72732e577677f~v11.sla~1781884679680~v11.ss~1781884679682~v11ls~a52278f0-6bf7-11f1-a95c-b3a42ded4c46~gtrk.ngv~e30%3D~gtrk.cnv~7cd~gtrk.la~mql4fskx~lcw~1781885203427; cebsp_=5';

    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');
        const type = searchParams.get('type') || 'video';

        if (!id) {
            return NextResponse.json({ success: false, message: "Parameter 'id' wajib diisi" }, { status: 400 });
        }

        let upstreamPath = '';

        // 🚀 TENTUKAN PATH SESUAI TIPE
        if (type === 'video') {
            upstreamPath = `/api/videos/${id}/detail`;
        } else if (type === 'livestreaming') {
            // Gunakan path khusus untuk Live TV/Streaming
            upstreamPath = `/livestreamings/${id}/stream?initialize=true`;
        } else {
            upstreamPath = `/api/videos/${id}/detail`;
        }

        // 🚀 AMBIL API KEY DINAMIS DARI GENERATOR KITA
        const dynamicApiKey = await XApiKeyGenerator.get(VIDIO_COOKIE);

        // 🚀 BIKIN HEADERS DINAMIS KHUSUS LIVESTREAMING (Bypass 403 Forbidden)
        const { timestamp, signature } = generateVidioSignature();
        const luwsToken = generateLuws(); // Generate UUID acak buat session nonton

        const liveHeaders: HeadersInit = {
            'Cookie': VIDIO_COOKIE,
            'Referer': 'https://www.vidio.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
            'X-API-Key': dynamicApiKey, // 👈 PAKE KEY YANG UDAH DISEDOT
            'X-API-Platform': 'web-desktop',
            'X-Secure-Level': '2',
            'X-Client': timestamp,
            'X-Signature': signature,
            'luws': luwsToken,
            'X-User-Email': 'user_2973_adf428_4070-phone@fake-vidio.com'
        };

        const vodHeaders: HeadersInit = {
            'Cookie': VIDIO_COOKIE,
            'Referer': 'https://www.vidio.com/'
        };

        // 3. Fetch Data Pertama (Ngambil M3U8 Dasar / DASH Stream)
        const rawData = await proxyGet(req, upstreamPath, {}, {
            label: `vidio-play-${type}`,
            send: false,
            cacheTtlMs: 0, // 🚀 FIX: Jangan di-cache sama sekali di proxy lu
            headers: type === 'livestreaming' ? liveHeaders : vodHeaders
        });

        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        // 4. Mapping data
        let mappedData = mapPlayResponse(rawData);

        if (!mappedData.success) {
            return NextResponse.json(mappedData, { status: 404 });
        }

        // 🔐 5. LOGIKA DRM (HANYA UNTUK VOD / video)
        if (mappedData.isDrm && type === 'video') {
            const drmData = await proxyGet(req, `/api/stream/v1/video_data/${id}`, {}, {
                label: 'vidio-play-drm',
                send: false,
                cacheTtlMs: 0,
                headers: {
                    'Cookie': VIDIO_COOKIE,
                    'Referer': 'https://www.vidio.com/',
                    'luws': generateLuws()
                }
            });

            if (drmData && !drmData.error) {
                const makeProxy = (url: string | null) => url ? `${process.env.NEXT_PUBLIC_SITE_URL || ''}/api/vidio/stream-proxy?url=${encodeURIComponent(url)}` : null;

                // 🎯 Tentukan URL final (prioritas dari drmData, fallback ke mappedData awal)
                const finalHlsUrl = drmData.stream_hls_url || mappedData.streamUrl;
                const finalDashUrl = drmData.stream_dash_url || mappedData.dashUrl;

                // 🎯 Override data ori & proxy
                mappedData.streamUrl = finalHlsUrl;
                mappedData.streamUrl_Proxy = makeProxy(finalHlsUrl);

                mappedData.dashUrl = finalDashUrl;
                mappedData.dashUrl_Proxy = makeProxy(finalDashUrl);

                mappedData.licenseServers = drmData.license_servers || null;
                mappedData.customData = drmData.custom_data || null;
            }
        }

        // 🚀 FIX: Set Header Cache-Control biar browser gak nyimpen JSON ini
        return NextResponse.json(mappedData, {
            status: 200,
            headers: {
                'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0',
            }
        });

    } catch (error: any) {
        console.error("Play Route Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}