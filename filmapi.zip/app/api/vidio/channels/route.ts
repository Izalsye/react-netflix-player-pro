import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapChannelsResponse } from '@/lib/vidio/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        // 1. Fetch HTML pakai proxyGet lu!
        const rawHtml = await proxyGet(
            req,
            'https://www.vidio.com/categories/daftar-channel-tv-live-sports',
            {},
            {
                label: 'vidio-channels',
                send: false,
                cacheTtlMs: 3600 * 1000 // Cache 1 jam biar hemat request
            }
        );

        // Kalau proxyGet kena error 403/500, langsung balikin errornya
        if (rawHtml && typeof rawHtml === 'object' && rawHtml.error) {
            return NextResponse.json(rawHtml, { status: rawHtml.status || 500 });
        }

        // 2. Oper string HTML mentah ke mapping lu
        const mappedData = mapChannelsResponse(rawHtml as string);

        return NextResponse.json(mappedData, { status: 200 });

    } catch (error: any) {
        console.error("Channels Route Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}