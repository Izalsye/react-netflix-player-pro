// app/api/vidio/search/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapSearchResponse } from '@/lib/vidio/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const q = searchParams.get('q'); // Ambil kata kunci pencarian

        if (!q) {
            return NextResponse.json({
                success: false,
                message: "Parameter 'q' wajib diisi untuk pencarian"
            }, { status: 400 });
        }

        // Tembak endpoint fluid_search Vidio
        const rawData = await proxyGet(
            req,
            `/fluid_search`,
            { q: q, qt: '', ua: '1' },
            {
                label: 'vidio-search',
                send: false,
                cacheTtlMs: 3600 * 1000 // Opsional: Cache 1 jam hasil pencarian biar enteng
            }
        );

        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        // Mapping datanya
        const mappedData = mapSearchResponse(rawData);

        return NextResponse.json(mappedData, { status: 200 });

    } catch (error: any) {
        console.error("Search Route Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}