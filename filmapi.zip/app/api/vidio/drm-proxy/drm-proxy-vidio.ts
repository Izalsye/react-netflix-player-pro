import { NextRequest, NextResponse } from 'next/server';
// 🚀 OPTIMASI 1: Pindah ke Edge Runtime.
// Jauh lebih ringan dan cepat untuk streaming/piping data besar dibanding Node.js standar.
export const runtime = 'edge';
export async function POST(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    try {
        // Ambil payload binary / challenge dari Shaka Player
        const body = await req.arrayBuffer();

        const fetchHeaders: HeadersInit = {
            'Referer': 'https://www.vidio.com/',
            'Origin': 'https://www.vidio.com',
            'User-Agent': req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Content-Type': req.headers.get('content-type') || 'application/octet-stream',
        };

        // 🚀 Teruskan token rahasia pallycon dari Shaka ke Vidio
        if (req.headers.has('pallycon-customdata-v2')) {
            fetchHeaders['pallycon-customdata-v2'] = req.headers.get('pallycon-customdata-v2')!;
        }

        // Tembak server lisensi Vidio dari backend (Bypass CORS 100%)
        const response = await fetch(url, {
            method: 'POST',
            headers: fetchHeaders,
            body: body
        });

        const data = await response.arrayBuffer();

        // Balikin kunci lisensinya ke Shaka Player
        return new NextResponse(data, {
            status: response.status,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': response.headers.get('content-type') || 'application/octet-stream'
            }
        });
    } catch (e) {
        console.error("DRM Proxy Error:", e);
        return NextResponse.json({ error: "DRM proxy failed" }, { status: 500 });
    }
}

// Wajib untuk melayani preflight request CORS dari browser
export async function OPTIONS(req: NextRequest) {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, pallycon-customdata-v2',
        }
    });
}