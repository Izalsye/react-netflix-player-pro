// app/api/vidio/series/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapHomeResponse } from '@/lib/vidio/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        const { searchParams } = new URL(req.url);
        const page = searchParams.get('page') || '1'; // Default page 1

        // Tembak endpoint kategori series Vidio
        const rawData = await proxyGet(
            req,
            `/categories/series/sections`,
            {
                'page[number]': page,
                'page[size]': '10',
                'included': 'contents'
            },
            {
                label: 'vidio-series',
                send: false,
                cacheTtlMs: 5 * 60 * 1000 // Cache 5 menit
            }
        );

        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        // PAKE ULANG mapHomeResponse KARENA STRUKTURNYA SAMA! 🚀
        const mappedData = mapHomeResponse(rawData);

        // Tambahin metadata pagination biar frontend lu bisa infinite scroll
        const nextLink = rawData.links?.next;
        const nextPage = nextLink ? parseInt(page) + 1 : null;

        return NextResponse.json({
            success: true,
            page: parseInt(page),
            nextPage: nextPage,
            sections: mappedData.sections
        }, { status: 200 });

    } catch (error: any) {
        console.error("Series Route Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}