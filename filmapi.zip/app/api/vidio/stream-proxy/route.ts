import { NextRequest, NextResponse } from 'next/server';

// 🚀 PENYAKIT UTAMA DIHAPUS: 
// Buang runtime edge biar kita balik pakai engine Node.js murni!
// export const runtime = 'edge';

export async function OPTIONS() {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
            'Access-Control-Allow-Headers': '*',
        },
    });
}

export async function GET(req: NextRequest) {
    return handleProxy(req);
}

export async function HEAD(req: NextRequest) {
    return handleProxy(req);
}

function resolveUrlPreserveQuery(relativePath: string, baseUrlStr: string) {
    if (relativePath.startsWith('http')) return relativePath;

    const resolvedUrlObj = new URL(relativePath, baseUrlStr);
    const finalPath = resolvedUrlObj.origin + resolvedUrlObj.pathname;

    const baseQueryStr = baseUrlStr.includes('?') ? baseUrlStr.substring(baseUrlStr.indexOf('?')) : '';
    const relativeQueryStr = relativePath.includes('?') ? relativePath.substring(relativePath.indexOf('?')) : '';

    if (!relativeQueryStr) return finalPath + baseQueryStr;

    const existingKeys = new Set(relativeQueryStr.substring(1).split('&').map(p => p.split('=')[0]));
    const toAppend: string[] = [];

    const hasAkamaiToken = existingKeys.has('hdntl') || existingKeys.has('hdnts');

    if (baseQueryStr) {
        const basePairs = baseQueryStr.substring(1).split('&');
        for (const pair of basePairs) {
            const key = pair.split('=')[0];
            if (hasAkamaiToken && (key === 'hdntl' || key === 'hdnts')) continue;
            if (!existingKeys.has(key)) toAppend.push(pair);
        }
    }

    let mergedSearch = relativeQueryStr;
    if (toAppend.length > 0) {
        mergedSearch += (mergedSearch.endsWith('?') ? '' : '&') + toAppend.join('&');
    }

    return finalPath + mergedSearch;
}

function encodeDashUrl(absoluteUrl: string) {
    let encodedUrl = encodeURIComponent(absoluteUrl).replace(/%24/g, '$');
    encodedUrl = encodedUrl.replace(/\$([^$]+)\$/g, (match) => {
        return match.replace(/%25/g, '%');
    });
    return encodedUrl;
}

async function handleProxy(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    try {
        const fetchHeaders = new Headers();
        fetchHeaders.set('Referer', 'https://www.vidio.com/');
        fetchHeaders.set('Origin', 'https://www.vidio.com');
        fetchHeaders.set('User-Agent', req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');

        fetchHeaders.set('Accept-Encoding', 'identity');

        const isRangeRequest = req.headers.has('range');
        if (isRangeRequest) fetchHeaders.set('Range', req.headers.get('range')!);
        if (req.headers.has('authorization')) fetchHeaders.set('Authorization', req.headers.get('authorization')!);

        const response = await fetch(url, {
            headers: fetchHeaders,
            cache: 'no-store',
            method: req.method
        });

        const contentType = response.headers.get('content-type') || '';
        const cleanUrl = url.split('?')[0].toLowerCase();

        const isManifest = !isRangeRequest && (
            contentType.includes('dash+xml') ||
            contentType.includes('mpegurl') ||
            cleanUrl.endsWith('.mpd') ||
            cleanUrl.endsWith('.m3u8')
        );

        const responseHeaders = new Headers(response.headers);
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Access-Control-Expose-Headers', '*');
        // 🚀 TAMBAHAN WAJIB: Cegah Next.js nyimpen file chunk video ke disk/RAM
        responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate');
        responseHeaders.delete('transfer-encoding');

        if (isManifest && req.method === 'GET') {
            let text = await response.text();

            if (cleanUrl.endsWith('.mpd') || contentType.includes('dash+xml')) {
                let mpdBaseUrl = url;
                const globalBaseMatch = text.match(/<BaseURL[^>]*>(http.*?)<\/BaseURL>/);
                if (globalBaseMatch && globalBaseMatch[1]) {
                    mpdBaseUrl = globalBaseMatch[1].trim();
                }

                let periodBaseUrl = mpdBaseUrl;
                let asBaseUrl = mpdBaseUrl;
                let repBaseUrl = mpdBaseUrl;
                let currentScope = 'mpd';

                text = text.replace(/(<Period[^>]*>|<\/Period>|<AdaptationSet[^>]*>|<\/AdaptationSet>|<Representation[^>]*>|<\/Representation>|<BaseURL[^>]*>[\s\S]*?<\/BaseURL>|media=['"][^'"]+['"]|initialization=['"][^'"]+['"])/g, (match) => {

                    if (match.startsWith('<Period')) {
                        currentScope = 'period';
                        periodBaseUrl = mpdBaseUrl;
                        asBaseUrl = periodBaseUrl;
                        repBaseUrl = asBaseUrl;
                        return match;
                    }
                    if (match.startsWith('</Period>')) {
                        currentScope = 'mpd';
                        return match;
                    }
                    if (match.startsWith('<AdaptationSet')) {
                        currentScope = 'as';
                        asBaseUrl = periodBaseUrl;
                        repBaseUrl = asBaseUrl;
                        return match;
                    }
                    if (match.startsWith('</AdaptationSet>')) {
                        currentScope = 'period';
                        return match;
                    }
                    if (match.startsWith('<Representation')) {
                        currentScope = 'rep';
                        repBaseUrl = asBaseUrl;
                        return match;
                    }
                    if (match.startsWith('</Representation>')) {
                        currentScope = 'as';
                        return match;
                    }

                    if (match.startsWith('<BaseURL')) {
                        const inner = match.replace(/<BaseURL[^>]*>/, '').replace(/<\/BaseURL>/, '').trim();
                        if (inner.includes('/api/vidio/stream-proxy')) return match;

                        let resolveAgainst = mpdBaseUrl;
                        if (currentScope === 'period') resolveAgainst = mpdBaseUrl;
                        else if (currentScope === 'as') resolveAgainst = periodBaseUrl;
                        else if (currentScope === 'rep') resolveAgainst = asBaseUrl;

                        const resolved = resolveUrlPreserveQuery(inner, resolveAgainst);

                        if (currentScope === 'mpd') mpdBaseUrl = resolved;
                        else if (currentScope === 'period') periodBaseUrl = resolved;
                        else if (currentScope === 'as') asBaseUrl = resolved;
                        else if (currentScope === 'rep') repBaseUrl = resolved;

                        const encodedUrl = encodeDashUrl(resolved);
                        const prefix = match.match(/<BaseURL[^>]*>/)?.[0] || '<BaseURL>';
                        return `${prefix}/api/vidio/stream-proxy?url=${encodedUrl}</BaseURL>`;
                    }

                    let activeBaseUrl = repBaseUrl;
                    if (currentScope === 'as') activeBaseUrl = asBaseUrl;
                    if (currentScope === 'period') activeBaseUrl = periodBaseUrl;

                    if (match.startsWith('media=')) {
                        const path = match.match(/media=['"]([^'"]+)['"]/)?.[1];
                        if (!path || path.includes('/api/vidio/stream-proxy')) return match;

                        const absoluteUrl = resolveUrlPreserveQuery(path, activeBaseUrl);
                        const encodedUrl = encodeDashUrl(absoluteUrl);
                        return `media="/api/vidio/stream-proxy?url=${encodedUrl}"`;
                    }
                    if (match.startsWith('initialization=')) {
                        const path = match.match(/initialization=['"]([^'"]+)['"]/)?.[1];
                        if (!path || path.includes('/api/vidio/stream-proxy')) return match;

                        const absoluteUrl = resolveUrlPreserveQuery(path, activeBaseUrl);
                        const encodedUrl = encodeDashUrl(absoluteUrl);
                        return `initialization="/api/vidio/stream-proxy?url=${encodedUrl}"`;
                    }

                    return match;
                });
            } else {
                const lines = text.split('\n');
                text = lines.map(line => {
                    const trimmed = line.trim();
                    if (trimmed && !trimmed.startsWith('#')) {
                        if (trimmed.includes('/api/vidio/stream-proxy')) return line;
                        const absoluteUrl = resolveUrlPreserveQuery(trimmed, url);
                        return `/api/vidio/stream-proxy?url=${encodeURIComponent(absoluteUrl)}`;
                    }
                    if (trimmed.startsWith('#EXT')) {
                        return line.replace(/URI=['"]([^'"]+)['"]/g, (m, p1) => {
                            if (p1.includes('/api/vidio/stream-proxy')) return m;
                            const absoluteUrl = resolveUrlPreserveQuery(p1, url);
                            return `URI="/api/vidio/stream-proxy?url=${encodeURIComponent(absoluteUrl)}"`;
                        });
                    }
                    return line;
                }).join('\n');
            }

            responseHeaders.delete('content-length');
            responseHeaders.delete('content-encoding');

            // Ini buat balikin file teks (.mpd / .m3u8), tetep pake NextResponse gak masalah karena enteng
            return new NextResponse(text, {
                status: response.status,
                headers: responseHeaders
            });
        }

        // 🚀 KUNCI PERUBAHAN DI SINI:
        // Buat file chunk video (m4s / ts), ganti pakai Response standar biar di-pipe langsung!
        return new Response(response.body, {
            status: response.status,
            headers: responseHeaders
        });

    } catch (e: any) {
        console.warn(`⚠️ [Proxy Failed] ${url}`, e.message);
        return NextResponse.json({ error: "Upstream network failed" }, { status: 502 });
    }
}