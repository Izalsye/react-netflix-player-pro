// app/api/vidio/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyGet } from '@/lib/vidio/proxy';
import { mapHomeResponse } from '@/lib/vidio/mapping';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'vidio');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    try {
        // Ambil query param (misal user mau akses page 2)
        const { searchParams } = new URL(req.url);
        const pageNumber = searchParams.get('page') || '1';
        const pageSize = searchParams.get('size') || '10';

        // Susun query untuk dilempar ke Vidio
        const query = {
            'page[number]': pageNumber,
            'page[size]': pageSize,
            'included': 'contents'
        };

        // Panggil proxyGet
        // PERHATIKAN: kita set `send: false` agar mendapatkan Object Data mentah,
        // bukan Response object, sehingga bisa kita mapping.
        const rawData = await proxyGet(req, '/categories/home/sections', query, {
            label: 'vidio-home',
            send: false,
            cacheTtlMs: 60 * 1000 // Opsional: Cache 1 Menit agar cepat
        });

        // Jika proxy mendeteksi error (misal API Key salah/expired)
        if (rawData && rawData.error) {
            return NextResponse.json(rawData, { status: rawData.status || 500 });
        }

        // Remapping data dari format JSON:API yang ribet jadi format yang rapi
        const mappedData = mapHomeResponse(rawData);

        // Kembalikan response yang rapi
        return NextResponse.json(mappedData, { status: 200 });

    } catch (error: any) {
        console.error("Home Route Error:", error);
        return NextResponse.json(
            { success: false, message: "Internal Server Error" },
            { status: 500 }
        );
    }
}