import { proxyPost } from '@/lib/cinemaid/proxy';

export async function GET(req: Request) {
    // Endpoint upstream asli dari CinemaID untuk mengambil list filter
    const path = '/api/type/get_list';

    // Karena ini endpoint tipe "get_list" sama kayak tab kemarin, request_body-nya kosong ("")
    const body = "";

    // Tembak menggunakan proxyPost
    return proxyPost(req, path, body, {
        label: 'cinemaid/filter',
        // Berhubung data genre dan tahun rilis film ginian jarang banget berubah,
        // kita kasih cache super panjang yaitu 24 jam (86.400.000 ms).
        // Biar kalau user buka halaman filter langsung instan 0ms!
        cacheTtlMs: 86400000
    });
}