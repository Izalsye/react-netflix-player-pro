import { proxyPost } from '@/lib/cinemaid/proxy';
import { NextRequest } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);

    // 1. Ambil parameter filter dari URL frontend
    const typeId = searchParams.get('typeId') || '1';     // 1 = Film, 2 = Serial TV
    const year = searchParams.get('year') || '';         // Contoh: 2026, 2025, atau kosong (Semua)
    const sort = searchParams.get('sort') || 'Terkini';   // Terkini, Kepopuleran, Populer saat ini
    const genre = searchParams.get('genre') || '';       // Petualangan, Komedi, atau kosong (Semua)
    const lang = searchParams.get('lang') || '';         // Kosongkan aja kalau default
    const page = searchParams.get('page') || '1';         // Halaman ke-berapa

    // Endpoint asli CinemaID
    const path = '/api/search/screen';

    // 2. Gunakan URLSearchParams biar otomatis ter-encode dengan aman (mengatasi spasi/karakter unik)
    const payload = new URLSearchParams();
    payload.set('audio_lang', lang);
    payload.set('year', year);
    payload.set('type_id', typeId);
    payload.set('sort', sort);
    payload.set('type', genre);
    payload.set('pn', page);

    const bodyString = payload.toString();

    // 3. Tembak menggunakan proxyPost kita yang sakti
    return proxyPost(req, path, bodyString, {
        label: `cinemaid/filter/detail`,
        // Karena hasil filter dinamis tergantung input user, kita kasih cache 5 menit (300.000 ms)
        // Biar kalau user bolak-balik klik filter yang sama, load-nya instan!
        cacheTtlMs: 300000
    });
}