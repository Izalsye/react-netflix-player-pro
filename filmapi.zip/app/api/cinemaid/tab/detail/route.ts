import { proxyPost } from '@/lib/cinemaid/proxy';
import { NextRequest } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);

    // Ambil parameter dari URL frontend dengan penamaan yang sync (tabId)
    const tabId = searchParams.get('id') || '358';
    const page = searchParams.get('page') || '1';
    const size = searchParams.get('size') || '20';

    // Endpoint asli CinemaID
    const path = '/api/channel/get_info';

    // Mapping variabel frontend ke body string x-www-form-urlencoded upstream
    const bodyString = `psize=${size}&channel_id=${tabId}&pn=${page}`;

    // Tembak pakai proxyPost
    return proxyPost(req, path, bodyString, {
        label: `cinemaid/tab/detail`,
        // Cache konten film selama 15 menit
        cacheTtlMs: 900000
    });
}