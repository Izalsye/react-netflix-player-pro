import { proxyPost } from '@/lib/cinemaid/proxy';

export async function GET(req: Request) {
    // Endpoint upstream sesuai log
    const path = '/api/channel/get_list';

    // Sesuai dengan log lu: "request_body": ""
    const body = "";

    // Panggil helper proxyPost kita
    return proxyPost(req, path, body, {
        label: 'cinemaid/tab',
        // Karena list channel/tab jarang banget berubah, 
        // kita kasih cache 1 jam (3.600.000 ms) biar responsenya ngebut
        cacheTtlMs: 3600000
    });
}