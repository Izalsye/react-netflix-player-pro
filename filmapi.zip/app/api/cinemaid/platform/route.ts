import { NextResponse } from 'next/server';

// Data mentah dari log lu
const rawBlockList = [
    {
        "topic_id": 5145,
        "block_name": "Netflix",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241022/828e01c6905a11ef8aa600163e064820.jpg"
    },
    {
        "topic_id": 5150,
        "block_name": "Vidio",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241022/9ce18934905b11efbe2a00163e064820.png"
    },
    {
        "topic_id": 5162,
        "block_name": "Vivamax",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20251229/ebc14284e46911f093d200163e064820.jpg"
    },
    {
        "topic_id": 5153,
        "block_name": "Amazon Prime",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241022/88c1ff24905b11ef97f800163e064820.jpg"
    },
    {
        "topic_id": 5148,
        "block_name": "Hotstar",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241022/15c59bf6905c11ef895100163e064820.png"
    },
    {
        "topic_id": 5146,
        "block_name": "iflix",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241022/752c2c82905b11efa67300163e064820.png"
    },
    {
        "topic_id": 5147,
        "block_name": "Viu",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241101/f012ff4a982e11ef931100163e064820.jpg"
    },
    {
        "topic_id": 5149,
        "block_name": "Apple TV",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241101/f83f4958982e11ef9ca200163e064820.png"
    },
    {
        "topic_id": 5151,
        "block_name": "Apple TV+",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241104/155129909a9511efadd300163e064820.jpg"
    },
    {
        "topic_id": 5152,
        "block_name": "Crunchyroll",
        "banner_pic": "https://phdd.zpmwi.com/static/upload/banner/20241104/2c3b348e9a9511ef90be00163e064820.jpg"
    }
];

export async function GET() {
    // Proses mapping/transformasi sesuai request lu bre
    const transformedList = rawBlockList.map((item) => ({
        id: item.topic_id,
        name: item.block_name,
        image: item.banner_pic // Lu bisa ganti jadi 'icon' kalau di frontend lebih sreg pake nama itu
    }));

    return NextResponse.json({
        code: 10000,
        message: "Kesuksesan",
        result: transformedList
    });
}