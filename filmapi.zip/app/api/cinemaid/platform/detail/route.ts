import { proxyPost } from '@/lib/cinemaid/proxy';
import { NextRequest } from 'next/server';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);

    // Ambil parameter dari URL frontend (id platform & halaman)
    const platformId = searchParams.get('id') || '5145'; // Default ke 5145 (Netflix) kalau gak diisi
    const page = searchParams.get('page') || '1';        // Default halaman 1

    // Endpoint asli CinemaID
    const path = '/api/topic/vod_list';

    // Susun body string x-www-form-urlencoded sesuai log lu bre
    const bodyString = `topic_id=${platformId}&pn=${page}`;

    // Kirim menggunakan proxyPost kita yang sakti
    return proxyPost(req, path, bodyString, {
        label: `cinemaid/platform/detail`,
        // Konten per platform biasanya gak berubah tiap detik, kita kasih cache 15 menit
        cacheTtlMs: 900000
    });
}