import { proxyPost } from '@/lib/cinemaid/proxy';
import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

import { generateCinemaSignature } from '@/lib/cinemaid/signature';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const vodId = searchParams.get('id');
    const curTime = Date.now().toString();

    //     Lu bisa coba nge-bruteforce rumusnya di lokal. Kombinasinya kemungkinan seperti:
    // MD5( "7ed871981e6d22b6be65049b8b3a9aad" + Device_ID + VOD_ID + Timestamp )
    // atau
    // MD5( Device_ID + VOD_ID + "7ed871981e6d22b6be65049b8b3a9aad" + Timestamp )
    // Salt yang lu dapet dari log Frida (Prefix)
    const secretKey = "7ed871981e6d22b6be65049b8b3a9aad";
    const secretKeygaid = "8c20cbbc-0d79-483e-b448-2cdc0568633d";
    // HexString yang lu dapet dari log Frida (Nonce)
    const Device_ID = "ab07cb36f3b71841";

    // RUMUS ASLI DARI LOG FRIDA: SecretKey + HexString + Timestamp
    const rawData = secretKey + Device_ID + vodId + curTime;

    // Hash MD5
    const calculatedSign = crypto.createHash('md5').update(rawData).digest('hex').toUpperCase();

    // BODY REQUEST (Tetap harus ada tanda & dan = karena ini format POST body)
    // Urutan parameter di body harus disesuaikan kalau server masih rewel
    const movieBodyString = `sign=${calculatedSign}&vod_id=${vodId}&cur_time=${curTime}&audio_type=0`;

    console.log(`🔍 [Fix] Raw: ${rawData} | Sign: ${calculatedSign}`);

    try {
        const response = await proxyPost(req, '/api/vod/info_new', movieBodyString, {
            label: `final-${vodId}`,
        });

        const rawText = await response.text();
        return new NextResponse(rawText, {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (e) {
        return NextResponse.json({ error: true, message: "Network Error" }, { status: 500 });
    }
}