import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVSearchJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

// 🔥 FUNGSI SAKTI BUAT NGAMBIL BUILD ID OTOMATIS
let cachedBuildId = '';
let lastFetchTime = 0;

async function getLatestBuildId() {
    // Cache build ID selama 1 jam biar server lu gak capek
    if (cachedBuildId && (Date.now() - lastFetchTime < 3600000)) {
        return cachedBuildId;
    }
    
    try {
        const res = await fetch('https://wetv.vip/id', {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
        });
        const html = await res.text();
        
        // Cari pola "buildId":"wetv_prod_xxxx" secara otomatis
        const match = html.match(/"buildId":"([^"]+)"/);
        if (match && match[1]) {
            cachedBuildId = match[1];
            lastFetchTime = Date.now();
            return cachedBuildId;
        }
    } catch (e) {
        console.error("Gagal ambil Build ID, pakai fallback");
    }
    
    // Fallback darurat ke 5040
    return process.env.WETV_BUILD_ID || 'wetv_prod_5040';
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const queryParams = Object.fromEntries(url.searchParams.entries());

    // Tangkap bahasa
    const lang = queryParams.lang || 'id';
    delete queryParams.lang; // Jangan kirim lang sebagai URL query

    // Tangkap keyword pencarian
    const keyword = queryParams.q || queryParams.query;
    if (!keyword) {
        return NextResponse.json({
            success: false,
            message: "Parameter 'q' atau 'query' wajib diisi"
        }, { status: 400 });
    }

    // Hapus parameter q/query yang dari user biar gak dobel,
    // karena WeTV nerimanya 'query=keyword'
    delete queryParams.q;
    delete queryParams.query;

    const proxyQuery = {
        ...queryParams,
        query: keyword // Inject keyword dengan key 'query' sesuai format WeTV
    };

    // Inject bahasa ke cookie
    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        // 🔥 AMBIL BUILD ID TERBARU SECARA DINAMIS
        const currentBuildId = await getLatestBuildId();
        const encodedKeyword = encodeURIComponent(keyword);
        const targetPath = `/_next/data/${currentBuildId}/search/${encodedKeyword}.json`;

        const rawResponse = await proxyGet(req, targetPath, proxyQuery, {
            label: 'wetv-search',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse || rawResponse.error) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon atau salah Build ID" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        
        // 🔥 PELINDUNG ANTI CRASH: Cek kalau WeTV malah balikin HTML
        if (typeof parsedData === 'string') {
            try {
                parsedData = JSON.parse(parsedData);
            } catch (parseErr) {
                console.error("❌ Gagal Parse JSON di Pencarian. WeTV merespon dengan HTML.");
                return NextResponse.json({ success: false, message: "Respons tidak valid dari WeTV" }, { status: 502 });
            }
        }

        // Map data hasil pencarian
        const cleanResult = mapWeTVSearchJson(parsedData);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Catch Error fetching search proxy:", error.message);
        return NextResponse.json({ success: false, message: `Internal Server Error: ${error.message}` }, { status: 500 });
    }
}