import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVSearchJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

const BUILD_ID = process.env.WETV_BUILD_ID || 'wetv_prod_5020';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const queryParams = Object.fromEntries(url.searchParams.entries());

    // Tangkap bahasa
    const lang = queryParams.lang || 'id';
    delete queryParams.lang; // Jangan kirim lang sebagai URL query

    // Tangkap keyword pencarian
    const keyword = queryParams.q || queryParams.query;
    if (!keyword) {
        return NextResponse.json({
            success: false,
            message: "Parameter 'q' atau 'query' wajib diisi"
        }, { status: 400 });
    }

    // Hapus parameter q/query yang dari user biar gak dobel,
    // karena WeTV nerimanya 'query=keyword'
    delete queryParams.q;
    delete queryParams.query;

    const proxyQuery = {
        ...queryParams,
        query: keyword // Inject keyword dengan key 'query' sesuai format WeTV
    };

    // Inject bahasa ke cookie
    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        // Target format URL: /_next/data/wetv_prod_5020/search/keyword.json?query=keyword
        const encodedKeyword = encodeURIComponent(keyword);
        const targetPath = `/_next/data/${BUILD_ID}/search/${encodedKeyword}.json`;

        const rawResponse = await proxyGet(req, targetPath, proxyQuery, {
            label: 'wetv-search',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') {
            parsedData = JSON.parse(parsedData);
        }

        // Map data hasil pencarian
        const cleanResult = mapWeTVSearchJson(parsedData);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Error fetching search proxy:", error);
        return NextResponse.json({ success: false, message: error?.message || "Internal Server Error" }, { status: 500 });
    }
}