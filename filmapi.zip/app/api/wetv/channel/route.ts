import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVApiChannelJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);

    // 1. Ambil semua query parameters
    const query = Object.fromEntries(url.searchParams.entries());

    // 2. Beri default id = '1001' jika client gak kirim ID (1001 = Halaman Untukmu/Home)
    if (!query.id) {
        query.id = '1001';
    }

    // 3. TANGKAP LANG: Ambil dari query, lalu hapus agar tidak dikirim sbg URL Query
    const lang = query.lang || 'id';
    delete query.lang;

    // 4. PAGINATION LOGIC:
    // Param 'pageCtx' otomatis ada di dalam object `query` jika dikirim oleh frontend.
    // Tidak perlu logic khusus, karena akan langsung di-forward oleh proxyGet.

    const targetPath = '/api/channel';

    try {
        // 🔥 INJECT BAHASA KE COOKIE: API WeTV baca bahasa dari cookie `language=`
        const customHeaders = {
            "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
        };

        const rawResponse = await proxyGet(req, targetPath, query, {
            label: 'wetv-channel',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') {
            parsedData = JSON.parse(parsedData);
        }

        // 5. Masukkan ke Mapper
        const cleanResult = mapWeTVApiChannelJson(parsedData, query.id);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Error mapping channel proxy:", error);
        return NextResponse.json({ success: false, message: error?.message || "Internal Server Error" }, { status: 500 });
    }
}