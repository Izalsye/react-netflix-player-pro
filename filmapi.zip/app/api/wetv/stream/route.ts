export const dynamic = 'force-dynamic';

import { WeTVCore } from '@/lib/wetv/core';

// 🔥 WAJIB ADA: Tangani CORS preflight dari Player
export async function OPTIONS() {
    return new Response(null, {
        status: 204,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
        },
    });
}

export async function GET(req: Request) {
    const url = new URL(req.url);
    const vid = url.searchParams.get('vid');
    const cid = url.searchParams.get('cid');
    const defn = url.searchParams.get('defn') || 'shd';

    if (!vid || !cid) {
        return new Response(JSON.stringify({ success: false, message: "vid dan cid required" }), {
            status: 400,
            headers: { 'Content-Type': 'application/json' }
        });
    }

    // 🔥 PERBAIKAN: Baca domain asli dari Header (Nginx/Vercel/Cloudflare)
    const protocol = req.headers.get('x-forwarded-proto') || 'https';
    const host = req.headers.get('x-forwarded-host') || req.headers.get('host') || url.host;
    const proxyBase = `${protocol}://${host}`;
    const wetv = new WeTVCore();

    try {
        const m3u8Text = await wetv.getFullM3u8(vid, cid, req, defn, proxyBase);

        if (!m3u8Text) {
            return new Response("Failed to generate m3u8 bypass", { status: 500 });
        }

        // 🔥 KEMBALIKAN KE EXPRESS: Hanya kirim Content-Type dan CORS
        return new Response(m3u8Text, {
            status: 200,
            headers: {
                "Content-Type": "application/vnd.apple.mpegurl",
                "Access-Control-Allow-Origin": "*"
            }
        });
    } catch (error: any) {
        return new Response(error.message, { status: 500 });
    }
}