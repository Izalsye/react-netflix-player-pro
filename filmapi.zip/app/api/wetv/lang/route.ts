import { NextResponse } from 'next/server';

export async function GET() {
    const languages = [
        { code: "en", name: "English", isDefault: true },
        { code: "id", name: "Indonesian", isDefault: false },
        { code: "ja", name: "Japanese", isDefault: false },
        { code: "ko", name: "Korean", isDefault: false },
        { code: "hi", name: "Hindi", isDefault: false },
        { code: "ar", name: "Arabic", isDefault: false },
        { code: "bn", name: "Bengali", isDefault: false },
        { code: "fr", name: "French", isDefault: false },
        { code: "es", name: "Spanish", isDefault: false },
        { code: "ru", name: "Russian", isDefault: false },
        { code: "ta", name: "Tamil", isDefault: false },
        { code: "te", name: "Telugu", isDefault: false },
        { code: "ml", name: "Malayalam", isDefault: false },
        { code: "pt", name: "Portuguese", isDefault: false },
        { code: "de", name: "German", isDefault: false },
        { code: "th", name: "Thai", isDefault: false },
        { code: "vi", name: "Vietnamese", isDefault: false },
        { code: "zh", name: "Chinese", isDefault: false }
    ];

    return NextResponse.json({
        success: true,
        message: "Daftar bahasa berhasil diambil",
        total: languages.length,
        data: languages
    });
}