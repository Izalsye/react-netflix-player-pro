// app/api/wetv/init.ts/route.ts

const PAT_PMT = Buffer.from("R0AAEAAAsA0AAcEAAAAB8AAqsQSy//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9HUAAQAAKwFwABwQAA4QDwABvhAPAAD+EB8AAvRLmb/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////w==", "base64");

// 🔥 JANGAN DIHAPUS: Wajib untuk meloloskan pengecekan CORS (Preflight) dari Video Player
export async function OPTIONS() {
    return new Response(null, {
        status: 204,
        headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type",
        },
    });
}

export async function GET() {
    const binaryData = new Uint8Array(PAT_PMT);

    return new Response(binaryData, {
        status: 200,
        headers: {
            "Content-Type": "video/mp2t",
            "Content-Length": PAT_PMT.length.toString(),
            "Access-Control-Allow-Origin": "*",
            "Cache-Control": "public, max-age=86400"
        }
    });
}