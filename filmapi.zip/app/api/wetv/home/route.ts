import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVHomeJson, extractNextDataFromHtml } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());

    // 💡 AMBIL LANG: Ambil parameter lang dari query, default ke 'id' (Indonesian)
    const lang = query.lang || 'id';
    const targetPath = `/${lang}`;

    // bypass opt.send = false supaya proxyGet langsung return data mentah berupa string/object
    const rawResponse = await proxyGet(req, targetPath, query, { label: 'wetv-home', send: false });

    let finalJson: any;

    // 1. Jika responsenya string, cek apakah bentuknya HTML atau JSON String
    if (typeof rawResponse === 'string') {
        if (rawResponse.trim().startsWith('<!DOCTYPE') || rawResponse.trim().startsWith('<html')) {
            // Ekstrak objek __NEXT_DATA__ dari script HTML
            const extracted = extractNextDataFromHtml(rawResponse);
            finalJson = mapWeTVHomeJson(extracted);
        } else {
            // Jika string JSON biasa
            try {
                finalJson = mapWeTVHomeJson(JSON.parse(rawResponse));
            } catch {
                finalJson = { error: true, message: "Gagal memproses string JSON" };
            }
        }
    } else {
        // 2. Jika responsenya sudah otomatis berbentuk object JSON dari proxyGet
        finalJson = mapWeTVHomeJson(rawResponse);
    }

    // Kirim balik ke client hasil JSON yang udah dimapping rapi pol!
    return NextResponse.json(finalJson);
}