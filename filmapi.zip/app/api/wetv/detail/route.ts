import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVPlayDetailJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
        const auth = await validateApiKey(req, 'wetv');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());

    if (!query.cid) {
        return NextResponse.json(
            { success: false, message: "Parameter 'cid' (Content ID) wajib diisi bre." },
            { status: 400 }
        );
    }

    const targetPath = '/api/play';
    const proxyQuery = {
        cid: query.cid,
        lang_code: query.lang || 'id',
        country_code: query.country || 'ID'
    };

    try {
        const rawResponse = await proxyGet(req, targetPath, proxyQuery, {
            label: 'wetv-detail',
            send: false
        });

        if (!rawResponse) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') {
            try { parsedData = JSON.parse(parsedData); } catch { }
        }

        // 🔥 FIX STRUKTUR DATA: WeTV API naruh datanya di "playData"
        // mapping.ts lu butuh datanya ada di properti "data"
        const payloadForMapping = {
            data: parsedData?.playData || parsedData
        };

        const cleanResult = mapWeTVPlayDetailJson(payloadForMapping);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Error mapping detail proxy:", error);
        return NextResponse.json(
            { success: false, message: error?.message || "Internal Server Error" },
            { status: 500 }
        );
    }
}