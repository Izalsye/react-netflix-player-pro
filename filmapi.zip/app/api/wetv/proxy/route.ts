import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const url = new URL(req.url);
    const targetUrl = url.searchParams.get('url');

    if (!targetUrl) return new NextResponse("Parameter 'url' wajib diisi", { status: 400 });

    try {
        const HARDCODED_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        const fetchHeaders = new Headers();
        fetchHeaders.set('User-Agent', HARDCODED_UA);
        fetchHeaders.set('Accept', '*/*');
        fetchHeaders.set('Referer', 'https://wetv.vip/');

        // 🚀 WAJIB TAMBAH: Terusin Range biar video WeTV bisa di-seek (skip) maju mundur
        if (req.headers.has('range')) {
            fetchHeaders.set('Range', req.headers.get('range')!);
        }

        const response = await fetch(targetUrl, {
            method: 'GET',
            headers: fetchHeaders,
            cache: 'no-store',
        });

        // Toleransi status 206 (Partial Content) karena kita pakai Range header
        if (!response.ok && response.status !== 206) {
            const errorBody = await response.text();
            console.error("=========================================");
            console.error(`❌ PROXY GAGAL - STATUS: ${response.status}`);
            console.error(`URL TARGET: ${targetUrl}`);
            console.error(`RESPON CDN: ${errorBody.substring(0, 200)}`);
            console.error("=========================================");
            throw new Error(`CDN menolak request dengan status ${response.status}`);
        }

        const contentType = response.headers.get('content-type') || 'application/octet-stream';
        const isM3u8 = targetUrl.includes('.m3u8') || contentType.includes('mpegurl');

        if (isM3u8) {
            const text = await response.text();
            const targetUrlObj = new URL(targetUrl);
            const baseUrl = targetUrl.substring(0, targetUrl.lastIndexOf('/') + 1);

            const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://indocast.site';
            const myProxyBase = `${siteUrl}/api/wetv/proxy?url=`;

            const lines = text.split('\n');
            const rewrittenLines = lines.map(line => {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#')) return line;

                let absoluteSegmentUrl = trimmed;
                if (!trimmed.startsWith('http')) {
                    absoluteSegmentUrl = trimmed.startsWith('/') ? targetUrlObj.origin + trimmed : baseUrl + trimmed;
                }

                // WeTV ketat, jadi tetap proxy segmen .ts lewat VPS tapi dengan mode piping
                return myProxyBase + encodeURIComponent(absoluteSegmentUrl);
            });

            return new NextResponse(rewrittenLines.join('\n'), {
                status: 200,
                headers: {
                    'Content-Type': 'application/vnd.apple.mpegurl',
                    'Access-Control-Allow-Origin': '*',
                    'Cache-Control': 'no-store, no-cache, must-revalidate' // 👈 Jangan biarkan Next.js nyimpen cache file playlist
                }
            });
        }

        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Content-Type', contentType);

        // 🚀 KUNCI RAM IRIT: Haramkan Next.js menyimpan cache pecahan video WeTV ke dalam RAM!
        responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate');

        // 🚀 Terusin header panjang video dari CDN WeTV ke player frontend
        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (['content-length', 'content-range', 'accept-ranges'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        // 🚀 GANTI JADI Response STANDAR (Bukan NextResponse)
        // Biar file .ts WeTV cuma "lewat doang" tanpa ngotorin memori VPS
        return new Response(response.body, {
            status: response.status,
            headers: responseHeaders
        });

    } catch (error: any) {
        console.error("❌ Catch Error:", error.message);
        return new NextResponse(`Internal Server Error: ${error.message}`, { status: 500 });
    }
}