import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    // 2. Tangkap URL target dari query parameter
    const url = new URL(req.url);
    const targetUrl = url.searchParams.get('url');

    if (!targetUrl) {
        return new NextResponse("Parameter 'url' wajib diisi", { status: 400 });
    }

    try {
        // 3. Request ke server WeTV menggunakan Fetch
        const response = await fetch(targetUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://wetv.vip/',
                'Origin': 'https://wetv.vip',
                'Accept': '*/*'
            }
        });

        if (!response.ok) {
            throw new Error(`Failed to fetch from target. Status: ${response.status}`);
        }

        // 4. Ambil tipe data dari WeTV
        const contentType = response.headers.get('content-type') || 'application/octet-stream';

        // 🔥 PERUBAHAN: Gunakan Streams (response.body) alih-alih ArrayBuffer 🔥
        // Ini bikin server lu nggak bakal jebol memorinya walau nge-proxy file video 2GB
        return new NextResponse(response.body, {
            status: 200,
            headers: {
                'Content-Type': contentType,
                'Access-Control-Allow-Origin': '*',
                // Opsional: Boleh ditambahkan Cache kalau perlu, tapi untuk video lebih baik di-streaming saja
            }
        });

    } catch (error: any) {
        console.error("❌ Proxy Error:", error.message);
        return new NextResponse("Internal Server Error: Gagal proxy data", { status: 500 });
    }
}