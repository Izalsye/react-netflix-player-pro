import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const url = new URL(req.url);
    const targetUrl = url.searchParams.get('url');

    if (!targetUrl) return new NextResponse("Parameter 'url' wajib diisi", { status: 400 });

    try {
        // 🔥 Ganti ini dengan User-Agent yang SAMA PERSIS dipakai oleh WeTVCore milikmu
        const HARDCODED_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

        const response = await fetch(targetUrl, {
            method: 'GET',
            headers: {
                'User-Agent': HARDCODED_UA,
                'Accept': '*/*',
                'Referer': 'https://wetv.vip/', // Kadang WeTV wajib ada referer ini
            },
            cache: 'no-store',
        });

        // DEBUGGING LOG (Cek terminal VSCode/Node.js kamu)
        if (!response.ok) {
            const errorBody = await response.text();
            console.error("=========================================");
            console.error(`❌ PROXY GAGAL - STATUS: ${response.status}`);
            console.error(`URL TARGET: ${targetUrl}`);
            console.error(`RESPON CDN: ${errorBody.substring(0, 200)}`);
            console.error("=========================================");
            throw new Error(`CDN menolak request dengan status ${response.status}`);
        }

        const contentType = response.headers.get('content-type') || 'application/octet-stream';
        const isM3u8 = targetUrl.includes('.m3u8') || contentType.includes('mpegurl');

        if (isM3u8) {
            const text = await response.text();
            const targetUrlObj = new URL(targetUrl);
            const baseUrl = targetUrl.substring(0, targetUrl.lastIndexOf('/') + 1);

            // ✅ GANTI JADI INI BRE (Sama kayak yang di file stream sebelumnya)
            const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://indocast.site';
            const myProxyBase = `${siteUrl}/api/wetv/proxy?url=`;

            const lines = text.split('\n');
            const rewrittenLines = lines.map(line => {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#')) return line;

                let absoluteSegmentUrl = trimmed;
                if (!trimmed.startsWith('http')) {
                    absoluteSegmentUrl = trimmed.startsWith('/') ? targetUrlObj.origin + trimmed : baseUrl + trimmed;
                }
                return myProxyBase + encodeURIComponent(absoluteSegmentUrl);
            });

            return new NextResponse(rewrittenLines.join('\n'), {
                status: 200,
                headers: {
                    'Content-Type': 'application/vnd.apple.mpegurl',
                    'Access-Control-Allow-Origin': '*',
                }
            });
        }

        return new NextResponse(response.body, {
            status: 200,
            headers: {
                'Content-Type': contentType,
                'Access-Control-Allow-Origin': '*',
                'Cache-Control': 'public, max-age=3600'
            }
        });

    } catch (error: any) {
        console.error("❌ Catch Error:", error.message);
        return new NextResponse(`Internal Server Error: ${error.message}`, { status: 500 });
    }
}