import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVExploreJson, mapWeTVApiChannelJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

// 🔥 FUNGSI SAKTI BUAT NGAMBIL BUILD ID OTOMATIS
let cachedBuildId = '';
let lastFetchTime = 0;

async function getLatestBuildId() {
    // Cache build ID selama 1 jam biar gak spam request ke WeTV
    if (cachedBuildId && (Date.now() - lastFetchTime < 3600000)) {
        return cachedBuildId;
    }

    try {
        const res = await fetch('https://wetv.vip/id', {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
        });
        const html = await res.text();

        // Cari pola "buildId":"wetv_prod_xxxx" di dalam HTML
        const match = html.match(/"buildId":"([^"]+)"/);
        if (match && match[1]) {
            cachedBuildId = match[1];
            lastFetchTime = Date.now();
            console.log("✅ Berhasil dapat Build ID baru:", cachedBuildId);
            return cachedBuildId;
        }
    } catch (e) {
        console.error("Gagal ambil Build ID, pakai fallback");
    }

    // Kalau gagal, balik ke fallback
    return process.env.WETV_BUILD_ID || 'wetv_prod_5040';
}


export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());

    const lang = query.lang || 'id';
    delete query.lang;

    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        if (query.pageCtx) {
            const pageCtx = query.pageCtx;
            const rawResponse = await proxyGet(req, '/api/channel', { pageCtx, id: '1001' }, {
                label: 'wetv-explore-scroll',
                send: false,
                headers: customHeaders
            });

            let parsedData = rawResponse?.data || rawResponse;
            if (typeof parsedData === 'string') parsedData = JSON.parse(parsedData);

            const cleanResult = mapWeTVApiChannelJson(parsedData);
            return NextResponse.json(cleanResult);
        }

        // 🔥 PANGGIL FUNGSI DINAMIS DISINI
        const currentBuildId = await getLatestBuildId();
        const targetPath = `/_next/data/${currentBuildId}/explorar.json`;

        const rawResponse = await proxyGet(req, targetPath, query, {
            label: 'wetv-explore-init',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse || rawResponse.error) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon atau salah Build ID" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') {
            parsedData = JSON.parse(parsedData);
        }

        const cleanResult = mapWeTVExploreJson(parsedData);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Error mapping explore proxy:", error);
        return NextResponse.json({ success: false, message: error?.message || "Internal Server Error" }, { status: 500 });
    }
}