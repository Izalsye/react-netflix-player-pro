import { proxyGet } from '@/lib/wetv/proxy';
import { mapWeTVExploreJson, mapWeTVApiChannelJson } from '@/lib/wetv/mapping';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

// ⚠️ PENTING: WeTV sering ganti Build ID ini tiap kali mereka update web.
// Mending lu taro di .env biar gampang diganti kalau tiba-tiba error 404 dari WeTV.
// Contoh di .env: WETV_BUILD_ID=wetv_prod_5020
const BUILD_ID = process.env.WETV_BUILD_ID || 'wetv_prod_5020';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const query = Object.fromEntries(url.searchParams.entries());

    // Tangkap bahasa
    const lang = query.lang || 'id';
    delete query.lang;

    // Inject bahasa ke cookie
    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        // 🔥 LOGIC CABANG 1: PAGINATION (INFINITE SCROLL)
        // Kalau frontend kirim 'pageCtx', berarti user lagi scroll ke bawah.
        // Di WeTV, data selanjutnya itu ada di /api/channel, bukan di explorar.json
        if (query.pageCtx) {
            const pageCtx = query.pageCtx;

            // Panggil API Channel dengan membawa pageCtx
            const rawResponse = await proxyGet(req, '/api/channel', { pageCtx, id: '1001' }, {
                label: 'wetv-explore-scroll',
                send: false,
                headers: customHeaders
            });

            let parsedData = rawResponse?.data || rawResponse;
            if (typeof parsedData === 'string') parsedData = JSON.parse(parsedData);

            // Karena kita nembak /api/channel, kita pakai mapper Channel!
            const cleanResult = mapWeTVApiChannelJson(parsedData);
            return NextResponse.json(cleanResult);
        }

        // 🔥 LOGIC CABANG 2: LOAD AWAL / GANTI FILTER
        // Kalau nggak ada 'pageCtx', berarti user lagi ganti filter atau baru buka menu Explore
        const targetPath = `/_next/data/${BUILD_ID}/explorar.json`;

        const rawResponse = await proxyGet(req, targetPath, query, {
            label: 'wetv-explore-init',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') {
            parsedData = JSON.parse(parsedData);
        }

        // Pakai mapper Explore yang udah kita buat sebelumnya
        const cleanResult = mapWeTVExploreJson(parsedData);

        return NextResponse.json(cleanResult);

    } catch (error: any) {
        console.error("❌ Error mapping explore proxy:", error);
        return NextResponse.json({ success: false, message: error?.message || "Internal Server Error" }, { status: 500 });
    }
}