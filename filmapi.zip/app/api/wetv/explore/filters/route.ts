import { proxyGet } from '@/lib/wetv/proxy';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

const BUILD_ID = process.env.WETV_BUILD_ID || 'wetv_prod_5020';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const lang = url.searchParams.get('lang') || 'id';

    // Inject bahasa ke cookie
    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        // Nembak tanpa query parameter apa-apa (default load)
        const targetPath = `/_next/data/${BUILD_ID}/explorar.json`;

        const rawResponse = await proxyGet(req, targetPath, {}, {
            label: 'wetv-explore-filters',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;
        if (typeof parsedData === 'string') parsedData = JSON.parse(parsedData);

        const pageData = parsedData?.pageProps?.data;
        if (!pageData?.filter?.dimensions) {
            return NextResponse.json({ success: false, message: "Filter tidak ditemukan", data: [] });
        }

        // Mapping cuma buat ambil filternya aja
        const filters = pageData.filter.dimensions.map((dim: any) => ({
            paramKey: dim.key,
            name: dim.name,
            options: dim.options.map((opt: any) => ({
                name: opt.name,
                value: opt.value,
                // Kita gausah bawa isSelected karena ini master data
            }))
        }));

        return NextResponse.json({
            success: true,
            message: "Berhasil mengambil daftar filter",
            data: filters
        });

    } catch (error: any) {
        console.error("❌ Error fetch explore filters:", error);
        return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 });
    }
}