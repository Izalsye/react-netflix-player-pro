import { proxyGet } from '@/lib/wetv/proxy';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

// 🔥 FUNGSI SAKTI BUAT NGAMBIL BUILD ID OTOMATIS
let cachedBuildId = '';
let lastFetchTime = 0;

async function getLatestBuildId() {
    // Cache build ID selama 1 jam biar server lu gak capek
    if (cachedBuildId && (Date.now() - lastFetchTime < 3600000)) {
        return cachedBuildId;
    }

    try {
        const res = await fetch('https://wetv.vip/id', {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
        });
        const html = await res.text();

        // Cari pola "buildId":"wetv_prod_xxxx" secara otomatis
        const match = html.match(/"buildId":"([^"]+)"/);
        if (match && match[1]) {
            cachedBuildId = match[1];
            lastFetchTime = Date.now();
            return cachedBuildId;
        }
    } catch (e) {
        console.error("Gagal ambil Build ID, pakai fallback");
    }

    // Fallback darurat ke 5040
    return process.env.WETV_BUILD_ID || 'wetv_prod_5040';
}

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { error: true, code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const lang = url.searchParams.get('lang') || 'id';

    // Inject bahasa ke cookie
    const customHeaders = {
        "Cookie": `language=${lang}; ${req.headers.get('cookie') || ''}`
    };

    try {
        // 🔥 AMBIL BUILD ID TERBARU SECARA DINAMIS
        const currentBuildId = await getLatestBuildId();
        const targetPath = `/_next/data/${currentBuildId}/explorar.json`;

        const rawResponse = await proxyGet(req, targetPath, {}, {
            label: 'wetv-explore-filters',
            send: false,
            headers: customHeaders
        });

        if (!rawResponse || rawResponse.error) {
            return NextResponse.json({ success: false, message: "Upstream tidak merespon atau salah Build ID" }, { status: 502 });
        }

        let parsedData = rawResponse?.data || rawResponse;

        // 🔥 PELINDUNG ANTI CRASH: Cek kalau WeTV malah balikin HTML
        if (typeof parsedData === 'string') {
            try {
                parsedData = JSON.parse(parsedData);
            } catch (parseErr) {
                console.error("❌ Gagal Parse JSON. WeTV merespon dengan HTML/Teks biasa.");
                return NextResponse.json({ success: false, message: "Respons tidak valid dari WeTV" }, { status: 502 });
            }
        }

        const pageData = parsedData?.pageProps?.data;
        if (!pageData?.filter?.dimensions || !Array.isArray(pageData.filter.dimensions)) {
            return NextResponse.json({ success: false, message: "Filter tidak ditemukan. Mungkin struktur API berubah.", data: [] });
        }

        // 🔥 Mapping dengan pelindung Optional Chaining (?.) biar gak crash
        const filters = pageData.filter.dimensions.map((dim: any) => ({
            paramKey: dim.key,
            name: dim.name,
            options: Array.isArray(dim.options) ? dim.options.map((opt: any) => ({
                name: opt.name,
                value: opt.value,
            })) : []
        }));

        return NextResponse.json({
            success: true,
            message: "Berhasil mengambil daftar filter",
            data: filters
        });

    } catch (error: any) {
        console.error("❌ Catch Error fetch explore filters:", error.message);
        return NextResponse.json({ success: false, message: `Internal Server Error: ${error.message}` }, { status: 500 });
    }
}