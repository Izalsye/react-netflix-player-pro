import { NextRequest, NextResponse } from 'next/server';
import { WeTVCore } from '@/lib/wetv/core';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'wetv');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const url = new URL(req.url);
    const vid = url.searchParams.get('vid');
    const cid = url.searchParams.get('cid');
    const defn = url.searchParams.get('defn') || 'shd';

    if (!vid || !cid) {
        return NextResponse.json({ code: 400, message: "Parameter 'vid' dan 'cid' wajib diisi", data: null }, { status: 400 });
    }

    const wetv = new WeTVCore();
    const data = await wetv.getPlayUrl(vid, cid, req, defn);

    // 1. Error dari HTTP / Network
    if (data.error) {
        return NextResponse.json({ code: 500, message: data.error, data: null }, { status: 500 });
    }

    // 2. CEGAT ERROR DARI WETV
    if (!data.url) {
        return NextResponse.json({
            code: data.em || 403,
            message: data.msg || "Gagal mendapatkan izin stream. Video mungkin Strict VIP / Fast Track / Region Locked.",
            data: data
        }, { status: 403 });
    }

    // ✅ Ganti jadi ini:
    const baseProxyUrl = process.env.NEXT_PUBLIC_SITE_URL || req.nextUrl.origin;

    const preview = parseFloat(data.preview) || 0;
    const duration = parseFloat(data.duration) || 0;
    const isVipBypass = preview > 0 && preview < duration - 30;

    // 🔥 INJECT URL PROXY UNTUK SUBTITLES 🔥
    if (data.subtitles) {
        data.subtitles = data.subtitles.map((sub: any) => ({
            ...sub,
        }));
    }

    let finalUrl = data.url;
    let finalUrlProxy = `${baseProxyUrl}/api/wetv/proxy?url=${encodeURIComponent(data.url)}`;

    // JIKA VIP, BELOKAN URL KE LOCAL STREAM BYPASS KITA
    if (isVipBypass) {
        finalUrl = `${baseProxyUrl}/api/wetv/stream?vid=${vid}&cid=${cid}&defn=${defn}`;
        finalUrlProxy = finalUrl; // VIP bypass udah bertindak sebagai proxy stream
    }

    // 🔥 INJECT URL PROXY UNTUK RESOLUTIONS 🔥
    let finalResolutions = data.resolutions || [];
    if (finalResolutions.length > 0) {
        finalResolutions = finalResolutions.map((f: any) => {
            const bypassUrl = `${baseProxyUrl}/api/wetv/stream?vid=${vid}&cid=${cid}&defn=${f.name}`;
            return {
                ...f,
                // Pastikan f.url juga dilempar ke proxy jika bukan VIP
                url: isVipBypass ? bypassUrl : `${baseProxyUrl}/api/wetv/proxy?url=${encodeURIComponent(f.url)}`,
            };
        });
    }

    return NextResponse.json({
        code: 0,
        message: "Berhasil mengambil URL streaming WeTV",
        data: {
            ...data,
            url: finalUrlProxy, // 🔥 UBAH INI: Gunakan finalUrlProxy, bukan finalUrl
            resolutions: finalResolutions,
            subtitles: data.subtitles || []
        }
    });
}