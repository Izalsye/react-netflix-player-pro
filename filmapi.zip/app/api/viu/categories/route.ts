import { NextRequest, NextResponse } from 'next/server'; // 🎯 Import NextRequest
import { ViuCategory } from '@/types/viu';
import { validateApiKey } from '@/lib/apiKeyService'; // 🎯 Import Satpam

export async function GET(req: NextRequest) { // 🎯 Tambahin req: NextRequest

    // 🔥 1. PANGGIL VALIDASI API KEY (Satpam) 🔥
    // Kita cek akses untuk provider 'viu'
    const auth = await validateApiKey(req, 'viu');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // Data hasil ekstrak dari navigasi Viu
    const categories: ViuCategory[] = [
        { id: "579", name: "Trailers" },
        { id: "571", name: "Viu Original" },
        { id: "549", name: "Drama Korea" },
        { id: "550", name: "Variety Show Korea" },
        { id: "553", name: "Drama Cina" },
        { id: "552", name: "Drama Thailand" },
        { id: "546", name: "Dub Bahasa Indonesia" },
        { id: "551", name: "Film Korea" },
        { id: "308", name: "Film" },
        { id: "574", name: "Anime" },
        { id: "548", name: "Drama Indonesia" },
        { id: "557", name: "Drama Turki" },
        { id: "573", name: "Variety Show" },
        { id: "775", name: "Drama Korea Romantis" }
    ];

    return NextResponse.json({
        status: "success",
        data: categories
    });
}