import { proxyGet } from '@/lib/viu/proxy';
import { NextResponse } from 'next/server';

// Cegah Next.js melakukan caching pada error
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
    const query = {
        platform_flag_label: 'web',
        area_id: '1000',
        language_flag_id: '8',
        platformFlagLabel: 'web',
        areaId: '1000',
        languageFlagId: '8',
        countryCode: 'ID',
        ut: '2',
        byPassOffer: 'false'
    };

    // Ambil token dari env, kalau kosong langsung tembak token panjangmu buat testing
    const token = process.env.VIU_DEFAULT_TOKEN || "eyJhbGciOiJBMTI4S1ciLCJlbmMiOiJBMTI4Q0JDLUhTMjU2In0.p2lxRZ08dRcxkpnJ2QnNElGDq48qvzfWv02YZL1SA6UiYR37rrQ_Zg.taXTv3wR6KNw4hgrlfS4iQ.pDS2DqlRlfyl26Igv9buYHsN0Gu81JFLs3SWqAIqSDowzSVD-KLPbvpr060xygNAOadu_qCE6-iTs6oYANVMwtZnYlFXfBHztcHQDRTR27l_0syWZGPiC2X8I2SL_esp7dAyE-_M6NzCW1G82HKCldpczdqSUsgo7rJsDLGAdMZdysozkSrDcfgB6OqEHw5Y8I1V4CnDZQdqrwgHdOBP4mJaz9LZ3CCgqsmMOGm8C3_AgWEWxGQ5aD6PRp3VStQXKES9MjGjHUNRq8XmWsV1Yg.8Cb6uFKXgHvGVD1-8fjrSw";

    // Kita paksa injek header Authorization dari sini
    const customHeaders = {
        "Authorization": `Bearer ${token}`,
        "Cache-Control": "no-cache, no-store, max-age=0"
    };

    const rawData = await proxyGet(
        req, 
        '/api/subscription/status', 
        query, 
        { 
            label: 'viu-status', 
            send: false,
            headers: customHeaders 
        }
    );

    if (rawData?.error) {
        // Tampilkan full response kalau error biar kelihatan pesan dari Viu-nya
        return NextResponse.json(rawData, { status: rawData.status || 500 });
    }

    return NextResponse.json(rawData);
}