import { NextRequest, NextResponse } from 'next/server';
import { ViuLanguage } from '@/types/viu';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'viu');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const languages: ViuLanguage[] = [
        { code: "id", label: "Bahasa Indonesia" },
        { code: "en", label: "English" }
    ];

    return NextResponse.json({
        status: "success",
        data: languages
    });
}