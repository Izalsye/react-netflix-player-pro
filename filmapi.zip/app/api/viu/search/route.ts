import { proxyGet } from '@/lib/viu/proxy';
import { mapViuSearchData } from '@/lib/viu/mapper';
import { NextRequest, NextResponse } from 'next/server';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'viu');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const { searchParams } = new URL(req.url);

    const keyword = searchParams.get('q') || '';
    const field = searchParams.get('field') || ''; // 'series', 'movie', 'product', atau kosong (semua)
    const page = searchParams.get('page') || '1';
    const limit = searchParams.get('limit') || '16';

    const query: Record<string, string> = {
        platform_flag_label: 'web',
        area_id: '1000',
        language_flag_id: '8',
        platformFlagLabel: 'web',
        areaId: '1000',
        languageFlagId: '8',
        countryCode: 'ID',
        ut: '2',
        r: '/search/video',
        keyword: keyword,
        page: page,
        limit: limit
    };

    // Tambahkan field hanya jika user memilih salah satu tab
    if (field) {
        query.field = field;
    }

    const rawData = await proxyGet(
        req,
        '/api/mobile',
        query,
        { label: 'viu-search', send: false }
    );

    if (rawData?.error) {
        return NextResponse.json(rawData, { status: rawData.status || 500 });
    }

    // Kamu bisa buat mapper khusus search kalau mau, atau pakai mapper home
    const mappedData = mapViuSearchData(rawData); 
    // karena strukturnya biasanya mirip (list of items)
    return NextResponse.json(mappedData);
}