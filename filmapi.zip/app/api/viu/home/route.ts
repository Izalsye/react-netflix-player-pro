import { proxyGet } from '@/lib/viu/proxy';
import { mapViuHomeData } from '@/lib/viu/mapper';
import { NextRequest, NextResponse } from 'next/server'; // 🎯 1. Import NextRequest
import { validateApiKey } from '@/lib/apiKeyService'; // 🎯 2. Import Satpam

// Fungsi penerjemah kode negara ke Area ID Viu
function getViuAreaId(country: string) {
    const map: Record<string, string> = {
        'ID': '1000', // Indonesia
        'MY': '4',    // Malaysia (Contoh)
        'SG': '2',    // Singapore (Contoh)
        // Tambahin region lain nanti kalau nemu
    };
    return map[country.toUpperCase()] || '1000'; // Default ID
}

// Fungsi penerjemah bahasa ke Language Flag ID Viu
function getViuLanguageId(lang: string) {
    const map: Record<string, string> = {
        'id': '8', // Bahasa Indonesia
        'en': '3', // English
        'ms': '5', // Melayu
    };
    return map[lang.toLowerCase()] || '8'; // Default ID
}

// 🎯 3. Ganti tipe req dari Request jadi NextRequest
export async function GET(req: NextRequest) {
    // 🎯 4. Pasang satpam penjaga kuota
    const auth = await validateApiKey(req, 'viu');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);

    // Ambil param human-readable dari user
    const country = searchParams.get('country') || 'ID';
    const lang = searchParams.get('lang') || 'id';

    // Terjemahkan ke bahasa alien Viu
    const areaId = getViuAreaId(country);
    const languageFlagId = getViuLanguageId(lang);

    const query = {
        platform_flag_label: 'web',
        area_id: areaId,
        language_flag_id: languageFlagId,
        platformFlagLabel: 'web',
        areaId: areaId,
        languageFlagId: languageFlagId,
        countryCode: country.toUpperCase(),
        ut: '2',
        r: '/home/index'
    };

    const rawData = await proxyGet(
        req,
        '/api/mobile',
        query,
        { label: 'viu-home', send: false }
    );

    if (rawData?.error) {
        return NextResponse.json(rawData, { status: rawData.status || 500 });
    }

    const mappedData = mapViuHomeData(rawData);

    return NextResponse.json(mappedData);
}