import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    const token = req.nextUrl.searchParams.get('token');
    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    try {
        const body = await req.arrayBuffer();

        const fetchHeaders: HeadersInit = {
            // 'Host': 'drmproxy.viu.com',
            'Referer': 'https://www.viu.com/',
            'Origin': 'https://www.viu.com',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'x-client': 'web',
            'User-Agent': req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Content-Type': req.headers.get('content-type') || 'application/octet-stream',
        };

        // 🚀 Teruskan token authorization (Untuk Viu)
        if (req.headers.has('authorization')) {
            fetchHeaders['authorization'] = req.headers.get('authorization')!;
        }

        const response = await fetch(url, {
            method: 'POST',
            headers: fetchHeaders,
            body: body
        });

        const data = await response.arrayBuffer();

        return new NextResponse(data, {
            status: response.status,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': response.headers.get('content-type') || 'application/octet-stream'
            }
        });
    } catch (e) {
        console.error("DRM Proxy Error:", e);
        return NextResponse.json({ error: "DRM proxy failed" }, { status: 500 });
    }
}

export async function OPTIONS(req: NextRequest) {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization, pallycon-customdata-v2', // 🎯 Pastikan header diizinkan
        }
    });
}