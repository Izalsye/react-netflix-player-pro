import { NextRequest, NextResponse } from 'next/server';

// 🚀 DOSA TERAKHIR DIHAPUS: Balikin ke Node.js murni!
// export const runtime = 'edge';

export async function GET(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');
    const isSub = req.nextUrl.searchParams.get('isSub') === 'true';

    if (!url) return NextResponse.json({ error: "Missing url" }, { status: 400 });

    const fetchHeaders: HeadersInit = {
        'Referer': 'https://www.viu.com/',
        'Origin': 'https://www.viu.com',
        'User-Agent': req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept-Encoding': 'identity'
    };

    try {
        const response = await fetch(url, { headers: fetchHeaders, cache: 'no-store' });
        const contentType = response.headers.get('content-type') || '';
        const status = response.status;

        if (!response.ok && status !== 206) {
            return NextResponse.json({ error: "Upstream rejected", status }, { status });
        }

        const proxyPath = '/api/viu/bikinsendirijing?url=';
        const wrapUrl = (rawUrl: string) => {
            let target = rawUrl.startsWith('http') ? rawUrl : new URL(rawUrl, url).toString();
            return `${proxyPath}${encodeURIComponent(target)}`;
        };

        // --- SUBTITLE LOGIC ---
        if (isSub) {
            let subText = await response.text();
            let finalContentType = 'text/vtt; charset=utf-8';
            if (url.includes('.ttml') || url.includes('.xml') || subText.includes('<tt')) {
                finalContentType = 'application/ttml+xml; charset=utf-8';
            } else if (!subText.trim().startsWith('WEBVTT')) {
                subText = 'WEBVTT\n\n' + subText.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
            }
            return new NextResponse(subText, { status, headers: { 'Content-Type': finalContentType, 'Access-Control-Allow-Origin': '*' } });
        }

        const isM3U8 = contentType.toLowerCase().includes('mpegurl') || url.includes('.m3u8');
        const isMPD = contentType.toLowerCase().includes('dash+xml') || url.includes('.mpd');

        // --- HLS (.M3U8) REWRITE ---
        if (isM3U8) {
            let m3u8Content = await response.text();
            const rewrittenContent = m3u8Content.split('\n').map(line => {
                const trimmed = line.trim();
                if (trimmed === '') return line;

                if (trimmed.startsWith('#')) {
                    if (trimmed.includes('URI="')) {
                        return trimmed.replace(/URI="([^"]+)"/g, (match, uri) => {
                            if (trimmed.toLowerCase().includes('com.apple.streamingkeydelivery')) {
                                return `URI="${uri.replace(/^https?:\/\//i, 'skd://')}"`;
                            }
                            if (uri.startsWith('skd://') || uri.startsWith('urn:') || uri.startsWith('data:')) return match;

                            // Jika ini playlist anak (.m3u8), proxy-kan
                            if (uri.includes('.m3u8')) return `URI="${wrapUrl(uri)}"`;

                            // Jika ini audio/subtitle track, ARAHKAN LANGSUNG KE CDN
                            return `URI="${new URL(uri, url).toString()}"`;
                        });
                    }
                    return line;
                }

                // INI ADALAH SEGMEN VIDEO (.ts). ARAHKAN LANGSUNG KE CDN!
                return new URL(trimmed, url).toString();
            }).join('\n');

            return new NextResponse(rewrittenContent, {
                headers: {
                    'Content-Type': 'application/vnd.apple.mpegurl',
                    'Access-Control-Allow-Origin': '*',
                    'Cache-Control': 'no-store, no-cache, must-revalidate' // 👈 Tambahin ini biar next.js gak usil nge-cache file text ini
                }
            });
        }

        // --- DASH (.MPD) REWRITE ---
        if (isMPD) {
            let mpdContent = await response.text();

            const baseUrl = new URL('.', url).toString();
            if (!mpdContent.includes('<BaseURL>')) {
                mpdContent = mpdContent.replace(/(<MPD[^>]*>)/i, `$1\n    <BaseURL>${baseUrl}</BaseURL>`);
            }

            return new NextResponse(mpdContent, {
                headers: {
                    'Content-Type': 'application/dash+xml',
                    'Access-Control-Allow-Origin': '*',
                    'Cache-Control': 'no-store, no-cache, must-revalidate' // 👈 Tambahin ini juga
                }
            });
        }

        // --- PASSTHROUGH (BUAT JAGA-JAGA) ---
        const responseHeaders = new Headers();
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Cache-Control', 'no-store, no-cache, must-revalidate'); // 👈 Anti nyangkut RAM

        response.headers.forEach((value, key) => {
            const lowerKey = key.toLowerCase();
            if (!['transfer-encoding', 'content-encoding', 'connection', 'keep-alive', 'access-control-allow-origin'].includes(lowerKey)) {
                responseHeaders.set(key, value);
            }
        });

        if (!responseHeaders.has('content-type')) {
            responseHeaders.set('Content-Type', contentType || 'application/octet-stream');
        }

        // 🚀 GANTI JADI Response STANDAR biar murni Piping
        return new Response(response.body, { status, headers: responseHeaders });

    } catch (e: any) {
        return new NextResponse(JSON.stringify({ error: "Upstream network failed" }), { status: 502, headers: { 'Access-Control-Allow-Origin': '*' } });
    }
}