import { proxyGet } from '@/lib/viu/proxy';
import { mapViuDetailData } from '@/lib/viu/mapper';
import { NextRequest, NextResponse } from 'next/server'; // 🎯 1. Import NextRequest
import { validateApiKey } from '@/lib/apiKeyService'; // 🎯 2. Import Satpam

export const dynamic = 'force-dynamic';

// 🎯 3. Ganti Request jadi NextRequest
export async function GET(req: NextRequest) {
    // 🎯 4. Tambahin validasi API Key biar nggak jebol
    const auth = await validateApiKey(req, 'viu');
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const { searchParams } = new URL(req.url);
    const seriesId = searchParams.get('series_id') || '';

    if (!seriesId) {
        return NextResponse.json({ error: "series_id is required" }, { status: 400 });
    }

    // 1. Hit Data List Episode DULU
    const episodeQuery = {
        r: '/vod/product-list',
        series_id: seriesId,
        size: '-1',
        sort: 'desc',
        area_id: '1000',
        language_flag_id: '8'
    };

    const episodeRes = await proxyGet(req, '/api/mobile', episodeQuery, { label: 'viu-episodes', send: false });

    if (episodeRes?.error) {
        return NextResponse.json({ error: "Failed to fetch episodes" }, { status: 502 });
    }

    // 2. Ambil product_id dari episode pertama
    const episodes = episodeRes?.data?.product_list || [];
    const productId = episodes.length > 0 ? episodes[0].product_id : '';


    // 3. Hit Data Detail (menggunakan product_id yang didapat)
    // Kalau productId kosong (misal series belum ada episode), kita tetap tembak series_id
    const detailQuery: any = {
        platform_flag_label: 'web',
        area_id: '1000',
        language_flag_id: '8',
        platformFlagLabel: 'web',
        areaId: '1000',
        languageFlagId: '8',
        countryCode: 'ID',
        ut: '2',
        r: '/vod/detail',
        product_id: '',
        os_flag_id: '1'
    };

    if (productId) detailQuery.product_id = productId;
    else detailQuery.product_id = seriesId;

    const detailRes = await proxyGet(req, '/api/mobile', detailQuery, { label: 'viu-detail', send: false });

    if (detailRes?.error) {
        return NextResponse.json({ error: "Failed to fetch detail" }, { status: 502 });
    }

    // 4. Mapping
    const data = mapViuDetailData(detailRes, episodeRes);
    return NextResponse.json({
        data
    });
}