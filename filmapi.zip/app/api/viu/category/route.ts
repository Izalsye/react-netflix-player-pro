import { proxyGet } from '@/lib/viu/proxy';
import { mapViuTabCategoriData } from '@/lib/viu/mapper';
import { NextRequest, NextResponse } from 'next/server'; // 🎯 1. Tambahin NextRequest di sini
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

// 🎯 2. Ganti tipe req dari Request jadi NextRequest
export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'viu');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // Karena req udah NextRequest, ngambil searchParams sebenarnya bisa lebih gampang pakai req.nextUrl.searchParams
    // Tapi pakai cara lu yang new URL(req.url) juga tetep aman dan jalan normal.
    const { searchParams } = new URL(req.url);

    // Ambil param dari user, kasih default biar aman
    const categoryId = searchParams.get('category_id') || '549'; // Default Drama Korea
    const length = searchParams.get('length') || '44';
    const offset = searchParams.get('offset') || '0';

    const query = {
        platform_flag_label: 'web',
        area_id: '1000',
        language_flag_id: '8',
        platformFlagLabel: 'web',
        areaId: '1000',
        languageFlagId: '8',
        countryCode: 'ID',
        ut: '2',
        r: '/category/series', // 🎯 Endpoint untuk list category
        length: length,
        offset: offset,
        category_id: categoryId
    };

    const rawData = await proxyGet(
        req,
        '/api/mobile',
        query,
        { label: 'viu-category', send: false }
    );

    if (rawData?.error) {
        return NextResponse.json(rawData, { status: rawData.status || 500 });
    }

    const mappedData = mapViuTabCategoriData(rawData);
    return NextResponse.json(mappedData);
}