import { proxyGet } from '@/lib/viu/proxy';
import { NextRequest, NextResponse } from 'next/server';
import { refreshViuToken } from '@/lib/viu/auth';
import { mapViuPlayData } from '@/lib/viu/mapper'; //  mapper.ts
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // const auth = await validateApiKey(req, 'viu');
    // if (!auth.isValid) {
    //     return NextResponse.json(
    //         { code: auth.status, message: auth.message, data: null },
    //         { status: auth.status }
    //     );
    // }
    const { searchParams } = new URL(req.url);
    const productId = searchParams.get('product_id') || '';

    const lang = searchParams.get('lang')?.toLowerCase() || 'id';
    const qualityParam = searchParams.get('quality') || '720';

    if (!productId) {
        return NextResponse.json({ error: "product_id is required" }, { status: 400 });
    }

    const token = await refreshViuToken();

    const commonParams = {
        platform_flag_label: 'web',
        area_id: '1000',
        language_flag_id: '8',
        platformFlagLabel: 'web',
        areaId: '1000',
        languageFlagId: '8',
        countryCode: 'ID',
        ut: '2'
    };

    // 1. Fetch Detail
    const detailRes = await proxyGet(req, '/api/mobile', {
        ...commonParams,
        r: '/vod/detail',
        product_id: productId,
        os_flag_id: '1'
    }, { label: 'viu-play-detail', send: false,
        headers: {
            'Authorization': `Bearer ${token}`,
            'User-Agent': 'Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://www.viu.com/',
            'Origin': 'https://www.viu.com',
            'Accept': 'application/json, text/plain, */*',
            'Host': 'api-gateway-global.viu.com'
        }
     });

    if (detailRes?.error || !detailRes?.data?.current_product) {
        console.log(detailRes);
        return NextResponse.json({ error: "Failed to fetch detail", raw: detailRes }, { status: 502 });
    }
    console.log(detailRes);
    const ccsProductId = detailRes.data.current_product.ccs_product_id;

    // 2. Fetch Playback
    const playRes = await proxyGet(req, '/api/playback/distribute', {
        ...commonParams,
        ccs_product_id: ccsProductId
    }, {
        label: 'viu-playback',
        send: false,
        headers: {
            'Authorization': `Bearer ${token}`,
            'User-Agent': 'Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://www.viu.com/',
            'Origin': 'https://www.viu.com',
            'Accept': 'application/json, text/plain, */*',
            'Host': 'api-gateway-global.viu.com'
        }
    });

    if (playRes?.error || playRes?.status?.code !== 0) {
        return NextResponse.json({ error: "Failed to play", raw: playRes }, { status: 502 });
    }

    // 3. Panggil Mapper-nya!
    const mappedData = mapViuPlayData(detailRes, playRes, lang, qualityParam);

    return NextResponse.json(mappedData);
}