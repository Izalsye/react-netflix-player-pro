import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path prisma lu
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // Keamanan standar
    const auth = await validateApiKey(req, 'payment-status', true); // 🎯 Tambahin true
    if (!auth.isValid) {
        return NextResponse.json({ error: auth.message }, { status: auth.status });
    }

    const { searchParams } = new URL(req.url);
    const orderId = searchParams.get('orderId');

    if (!orderId) {
        return NextResponse.json({ error: "orderId required" }, { status: 400 });
    }

    try {
        const transaction = await prisma.transaction.findUnique({
            where: { id: orderId }
        });

        if (!transaction) {
            return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
        }

        return NextResponse.json({ status: transaction.status });

    } catch (error) {
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}