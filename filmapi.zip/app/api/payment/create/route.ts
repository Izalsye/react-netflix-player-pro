import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path
import crypto from 'crypto';

// Gunakan URL Sandbox untuk testing, ganti ke api.midtrans.com kalau udah production
const MIDTRANS_API_URL = process.env.NODE_ENV === 'production'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';

export async function POST(req: Request) {
    try {
        // 1. Ambil API Key dari header buat identifikasi user
        const rawKey = req.headers.get('x-api-key');
        if (!rawKey) {
            return NextResponse.json({ error: 'Missing API Key' }, { status: 401 });
        }

        const hashedKey = crypto.createHash('sha256').update(rawKey).digest('hex');
        const apiKeyData = await prisma.apiKey.findUnique({
            where: { hashedKey },
            include: { user: true },
        });

        if (!apiKeyData || !apiKeyData.user) {
            return NextResponse.json({ error: 'Invalid API Key' }, { status: 401 });
        }

        const user = apiKeyData.user;

        // 2. Parse request body dari frontend
        const body = await req.json();
        const { planType } = body; // Frontend ngirim code plan, cth: "1_MONTH"

        // 3. CARI HARGA DI DATABASE (Bye-bye hardcode!)
        // Kita cari plan berdasarkan 'code' yang dikirim frontend
        const plan = await prisma.plan.findUnique({
            where: { code: planType }
        });

        // Validasi kalau plan-nya nggak ada atau lagi dinonaktifkan
        if (!plan || !plan.isActive) {
            return NextResponse.json({ error: 'Paket tidak ditemukan atau tidak aktif' }, { status: 400 });
        }

        // Ambil harga asli dari database
        const amount = plan.price;

        // 4. Bikin data transaksi "PENDING" di database kita
        const transaction = await prisma.transaction.create({
            data: {
                userId: user.id,
                planId: plan.id, // SEKARANG PAKE RELASI ID KE TABEL PLAN
                amount: amount,
                status: 'PENDING',
                paymentMethod: 'QRIS',
            }
        });

        // 5. Tembak Core API Midtrans untuk request QRIS
        const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
        const authString = Buffer.from(`${serverKey}:`).toString('base64');

        const midtransPayload = {
            payment_type: 'qris',
            transaction_details: {
                order_id: transaction.id,
                gross_amount: amount,
            },
            customer_details: {
                first_name: user.firstName,
                last_name: user.lastName || '',
            }
        };

        const response = await fetch(MIDTRANS_API_URL, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Basic ${authString}`
            },
            body: JSON.stringify(midtransPayload)
        });

        const midtransData = await response.json();

        // 6. Handle response dari Midtrans
        if (midtransData.status_code !== '201') {
            console.error('[MIDTRANS ERROR]', midtransData);
            return NextResponse.json({ error: 'Failed to create QRIS via Midtrans' }, { status: 500 });
        }

        const qrisUrl = midtransData.actions?.find((action: any) => action.name === 'generate-qr-code')?.url;

        if (!qrisUrl) {
            return NextResponse.json({ error: 'QRIS URL not found in Midtrans response' }, { status: 500 });
        }

        // 7. Update database dengan URL QRIS
        await prisma.transaction.update({
            where: { id: transaction.id },
            data: { qrisUrl: qrisUrl }
        });

        // 8. Balikin ke frontend
        return NextResponse.json({
            success: true,
            message: 'QRIS generated successfully',
            data: {
                orderId: transaction.id,
                amount: amount,
                qrisUrl: qrisUrl
            }
        }, { status: 201 });

    } catch (error) {
        console.error('CREATE PAYMENT ERROR:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}