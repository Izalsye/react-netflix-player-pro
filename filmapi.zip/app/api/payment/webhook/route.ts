import { NextResponse } from 'next/server';
import crypto from 'crypto';
import prisma from '@/prisma/prisma'; // Sesuaikan path

// Fungsi bantuan untuk menghitung perpanjangan VIP berdasarkan HARI (durationDays)
function calculateSubEndsAt(currentEndsAt: Date | null, durationDays: number) {
    const now = new Date();

    // Kalau user masih VIP dan belum expired, kita tambahin sisa harinya (akumulasi)
    // Tapi kalau udah expired atau baru beli, patokannya dari hari ini
    const baseDate = (currentEndsAt && currentEndsAt > now) ? currentEndsAt : now;

    const newEndsAt = new Date(baseDate);
    // Tambahkan jumlah hari dari database ke tanggal
    newEndsAt.setDate(newEndsAt.getDate() + durationDays);

    return newEndsAt;
}

export async function POST(req: Request) {
    try {
        const body = await req.json();

        // Ambil data penting dari payload Midtrans
        const {
            order_id,             // Ini adalah id Transaction di database kita
            status_code,
            gross_amount,
            signature_key,
            transaction_status,
            fraud_status
        } = body;

        // 1. Validasi Keamanan (Wajib!)
        const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
        const rawString = `${order_id}${status_code}${gross_amount}${serverKey}`;
        const hashed = crypto.createHash('sha512').update(rawString).digest('hex');

        if (hashed !== signature_key) {
            console.error(`[WEBHOOK] Invalid signature for order: ${order_id}`);
            return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
        }

        // 2. Cari transaksi di Database kita (PLUS tarik data Plan-nya)
        const transaction = await prisma.transaction.findUnique({
            where: { id: order_id },
            include: { plan: true } // WAJIB: Tarik data plan biar tau ini paket berapa hari
        });

        if (!transaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }

        // 3. Proses Status Pembayaran
        if (transaction_status === 'capture' || transaction_status === 'settlement') {
            if (transaction_status === 'capture' && fraud_status === 'challenge') {
                console.log(`[WEBHOOK] Order ${order_id} challenged by FDS`);
            } else {
                // --- PEMBAYARAN SUKSES! ---

                // a. Ubah status transaksi jadi LUNAS (SETTLEMENT)
                await prisma.transaction.update({
                    where: { id: order_id },
                    data: {
                        status: 'SETTLEMENT',
                        paidAt: new Date()
                    }
                });

                // b. Upgrade User ke VIP dan setel masa aktifnya
                const user = await prisma.user.findUnique({ where: { id: transaction.userId } });

                if (user) {
                    // Hitung kadaluarsa pakai data durationDays dari database Plan
                    const newEndsAt = calculateSubEndsAt(user.subEndsAt, transaction.plan.durationDays);

                    await prisma.user.update({
                        where: { id: user.id },
                        data: {
                            role: 'VIP',
                            subStartsAt: user.subStartsAt || new Date(),
                            subEndsAt: newEndsAt,
                            planId: transaction.planId // Update planId sesuai yang dibeli
                        }
                    });
                    console.log(`[WEBHOOK] User ${user.id} upgraded to VIP until ${newEndsAt}`);
                }
            }
        }
        else if (transaction_status === 'cancel' || transaction_status === 'deny' || transaction_status === 'expire') {
            // --- PEMBAYARAN GAGAL / KEDALUWARSA ---
            await prisma.transaction.update({
                where: { id: order_id },
                data: { status: 'EXPIRE' }
            });
            console.log(`[WEBHOOK] Order ${order_id} expired/canceled`);
        }

        // Midtrans butuh 200 OK
        return NextResponse.json({ success: true, message: 'Webhook processed successfully' });

    } catch (error) {
        console.error('WEBHOOK ERROR:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}