// file: app/api/payment/webhook/route.ts
import { NextResponse } from 'next/server';
import crypto from 'crypto';
import prisma from '@/prisma/prisma';
import { bot } from '@/lib/bot';
import { AdminController } from '@/lib/admin';
// 🔥 Tambahan: Import config biar rapi
import { BANNER_URL, EFFECTS } from '@/lib/bot/config';

// Fungsi bantuan untuk menghitung perpanjangan VIP berdasarkan HARI
function calculateSubEndsAt(currentEndsAt: Date | null, durationDays: number) {
    const now = new Date();
    const baseDate = (currentEndsAt && currentEndsAt > now) ? currentEndsAt : now;
    const newEndsAt = new Date(baseDate);
    newEndsAt.setDate(newEndsAt.getDate() + durationDays);
    return newEndsAt;
}

export async function POST(req: Request) {
    try {
        const body = await req.json();

        // Ambil data penting dari payload Midtrans
        const {
            order_id,
            status_code,
            gross_amount,
            signature_key,
            transaction_status,
            fraud_status
        } = body;

        // 1. Validasi Keamanan
        const serverKey = process.env.MIDTRANS_SERVER_KEY || '';
        const rawString = `${order_id}${status_code}${gross_amount}${serverKey}`;
        const hashed = crypto.createHash('sha512').update(rawString).digest('hex');

        if (hashed !== signature_key) {
            console.error(`[WEBHOOK] Invalid signature for order: ${order_id}`);
            return NextResponse.json({ error: 'Invalid signature' }, { status: 403 });
        }

        // 2. Cari transaksi di Database kita
        const transaction = await prisma.transaction.findUnique({
            where: { id: order_id },
            include: { plan: true }
        });

        if (!transaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }

        // 3. Proses Status Pembayaran
        if (transaction_status === 'capture' || transaction_status === 'settlement') {
            if (transaction_status === 'capture' && fraud_status === 'challenge') {
                console.log(`[WEBHOOK] Order ${order_id} challenged by FDS`);
            } else {
                // --- PEMBAYARAN SUKSES! ---

                // Cegah double-hit
                if (transaction.status === 'SETTLEMENT') {
                    return NextResponse.json({ success: true, message: 'Already processed' });
                }

                // a. Ubah status transaksi jadi LUNAS (SETTLEMENT)
                await prisma.transaction.update({
                    where: { id: order_id },
                    data: {
                        status: 'SETTLEMENT',
                        paidAt: new Date()
                    }
                });

                // b. Upgrade User ke VIP
                const user = await prisma.user.findUnique({ where: { id: transaction.userId } });

                if (user) {
                    const newEndsAt = calculateSubEndsAt(user.subEndsAt, transaction.plan.durationDays);

                    await prisma.user.update({
                        where: { id: user.id },
                        data: {
                            role: 'VIP',
                            subStartsAt: user.subStartsAt || new Date(),
                            subEndsAt: newEndsAt,
                            planId: transaction.planId
                        }
                    });

                    // 🔥 NOTIFIKASI KE OWNER TRIGGER DI SINI 🔥
                    await AdminController.notifyOwner(user, transaction.plan.name, transaction.amount);

                    // 🔥 MAGIC: HAPUS QRIS LAMA & KIRIM PESAN OTOMATIS + EFEK API 🔥
                    if (user.telegramId) {
                        try {
                            // 🧹 HAPUS PESAN QRIS LAMA
                            if (transaction.telegramMsgId) {
                                try {
                                    await bot.api.deleteMessage(user.telegramId, transaction.telegramMsgId);
                                } catch (delErr) {
                                    console.log("Pesan QRIS mungkin udah kehapus user duluan.");
                                }
                            }

                            const msgSelamat = `🎉 <b>PEMBAYARAN BERHASIL!</b> 🎉\n\n` +
                                `Terima kasih! Akun kamu kini telah resmi menjadi <b>VIP PREMIUM</b> selama <b>${transaction.plan.durationDays} hari</b> ke depan.\n\n` +
                                `Silakan buka menu <b>🔑 Kelola API</b> untuk melihat perubahan limit harian kamu.`;

                            // Ngirim foto beserta animasi (Sekarang panggil dari variabel import)
                            await bot.api.sendPhoto(user.telegramId, BANNER_URL, {
                                caption: msgSelamat,
                                parse_mode: "HTML",
                                message_effect_id: EFFECTS.PARTY, // 🔥 Ganti jadi efek PARTY dari config
                                reply_markup: {
                                    inline_keyboard: [[{ text: "🔙 Kembali ke Beranda", callback_data: "menu_main" }]]
                                }
                            });
                        } catch (botErr) {
                            console.error("[WEBHOOK BOT ERROR] Gagal ngirim pesan sukses ke user:", botErr);
                        }
                    }
                    console.log(`[WEBHOOK] User ${user.id} upgraded to VIP! Message sent.`);
                }
            }
        }
        else if (transaction_status === 'cancel' || transaction_status === 'deny' || transaction_status === 'expire') {
            // --- PEMBAYARAN GAGAL / KEDALUWARSA ---
            await prisma.transaction.update({
                where: { id: order_id },
                data: { status: 'EXPIRE' }
            });
            console.log(`[WEBHOOK] Order ${order_id} expired/canceled`);
        }

        return NextResponse.json({ success: true, message: 'Webhook processed successfully' });

    } catch (error) {
        console.error('WEBHOOK ERROR:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}