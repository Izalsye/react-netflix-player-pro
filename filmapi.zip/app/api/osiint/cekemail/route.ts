// file: app/api/osiint/cekemail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchOsint } from '@/lib/osint';
import { withAuth } from '@/lib/withAuth';

async function handler(req: NextRequest) {
    try {
        const { email } = await req.json();

        if (!email) {
            return NextResponse.json({ status: "error", message: "Email is required" }, { status: 400 });
        }
      // Ambil hash dari env
        const currentActionHash = process.env.BLACKBIRD_ACTION_HASH;

        // Validasi jaga-jaga kalau env kosong atau lupa diisi
        if (!currentActionHash) {
            return NextResponse.json({ 
                status: "error", 
                message: "System Error: BLACKBIRD_ACTION_HASH is missing in .env" 
            }, { status: 500 });
        }

        const rawResult = await fetchOsint({
            path: "/search",
            // ⚠️ PASTIKAN urutan ini sesuai dengan Request Body di web target
            payloadArray: ["email", email],
            // ⚠️ PASTIKAN hash ini khusus untuk fungsi search email
            actionHash: currentActionHash
        });

        // Pakai filter yang sama kayak cekpos tadi
        if (rawResult.error) {
            return NextResponse.json({
                status: "error",
                message: rawResult.error
            }, { status: 404 });
        }

        return NextResponse.json({
            status: "success",
            data: rawResult
        });

    } catch (error: any) {
        return NextResponse.json({
            status: "error",
            message: error.message || "Internal Server Error"
        }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    return withAuth(req, handler);
}