// file: app/api/osiint/cekpos/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchOsint } from '@/lib/osint';
import { withAuth } from '@/lib/withAuth'; // Satpam lu

async function handler(req: NextRequest) {
    try {
        const { resi } = await req.json();

        if (!resi) {
            return NextResponse.json({ status: "error", message: "resi is required" }, { status: 400 });
        }

        // Ambil hash dari env
        const currentActionHash = process.env.BLACKBIRD_ACTION_HASH;

        // Validasi jaga-jaga kalau env kosong atau lupa diisi
        if (!currentActionHash) {
            return NextResponse.json({ 
                status: "error", 
                message: "System Error: BLACKBIRD_ACTION_HASH is missing in .env" 
            }, { status: 500 });
        }

        const rawResult = await fetchOsint({
            path: "/search",
            // ⚠️ PASTIKAN urutan ini sesuai dengan Request Body di web target
            payloadArray: ["resi", resi],
            // ⚠️ PASTIKAN hash ini khusus untuk fungsi search email
            actionHash: currentActionHash
        });

        // 1. Cek kalau ada field 'error' (ini biasanya dari target Blackbird)
        if (rawResult.error) {
            return NextResponse.json({
                status: "error",
                message: rawResult.error
            }, { status: 404 });
        }

        // 2. Cek kalau logic success-nya explicit false
        if (rawResult.success === false) {
            return NextResponse.json({
                status: "error",
                message: rawResult.message || "Operation failed"
            }, { status: 400 });
        }

        // 3. Berhasil! Kirim data mentah yang sudah bersih
        return NextResponse.json({
            status: "success",
            data: rawResult
        });

    } catch (error: any) {
        console.error("[API Cekpos] Crash:", error.message);
        return NextResponse.json({
            status: "error",
            message: "Internal Server Error / Target Down"
        }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    return withAuth(req, handler);
}