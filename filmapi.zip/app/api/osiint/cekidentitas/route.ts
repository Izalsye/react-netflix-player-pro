// file: app/api/osiint/cekemail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchOsint } from '@/lib/osint';
import { withAuth } from '@/lib/withAuth';

async function handler(req: NextRequest) {
    try {
        const { identity } = await req.json();

        if (!identity) {
            return NextResponse.json({ 
                status: "error", 
                message: "nik is required" 
            }, { status: 400 });
        }

              // Ambil hash dari env
        const currentActionHash = process.env.BLACKBIRD_ACTION_HASH;

        // Validasi jaga-jaga kalau env kosong atau lupa diisi
        if (!currentActionHash) {
            return NextResponse.json({ 
                status: "error", 
                message: "System Error: BLACKBIRD_ACTION_HASH is missing in .env" 
            }, { status: 500 });
        }

        const rawResult = await fetchOsint({
            path: "/search",
            // ⚠️ PASTIKAN urutan ini sesuai dengan Request Body di web target
            payloadArray: ["identity", identity],
            // ⚠️ PASTIKAN hash ini khusus untuk fungsi search email
            actionHash: currentActionHash
        });

        // Tangkap error langsung dari payload target
        if (rawResult.error) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.error 
            }, { status: 404 });
        }

        // Tangkap kalau success explicit false
        if (rawResult.success === false) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.message || "Operation failed" 
            }, { status: 400 });
        }

        // Kalau aman, balikin datanya
        return NextResponse.json({
            status: "success",
            data: rawResult
        });

    } catch (error: any) {
        console.error("[API Cek Identity] Crash:", error.message);
        return NextResponse.json({ 
            status: "error", 
            message: "Internal Server Error / Target Down" 
        }, { status: 500 });
    }
}

export async function POST(req: NextRequest) { 
    return withAuth(req, handler); 
}