// file: app/api/osiint/cekleaks/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { fetchOsint } from '@/lib/osint';
import { withAuth } from '@/lib/withAuth';

async function handler(req: NextRequest) {
    try {
        const { leaks } = await req.json();

        // Validasi input
        if (!leaks) {
            return NextResponse.json({ 
                status: "error", 
                message: "Target 'leaks' is required" 
            }, { status: 400 });
        }

              // Ambil hash dari env
        const currentActionHash = process.env.BLACKBIRD_ACTION_HASH;

        // Validasi jaga-jaga kalau env kosong atau lupa diisi
        if (!currentActionHash) {
            return NextResponse.json({ 
                status: "error", 
                message: "System Error: BLACKBIRD_ACTION_HASH is missing in .env" 
            }, { status: 500 });
        }

        const rawResult = await fetchOsint({
            path: "/search",
            // ⚠️ PASTIKAN urutan ini sesuai dengan Request Body di web target
            payloadArray: ["leaks", leaks],
            // ⚠️ PASTIKAN hash ini khusus untuk fungsi search email
            actionHash: currentActionHash
        });
        // Filter error dari server target
        if (rawResult.error) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.error 
            }, { status: 404 });
        }

        if (rawResult.success === false) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.message || "Operation failed" 
            }, { status: 400 });
        }

        // Output bersih
        return NextResponse.json({
            status: "success",
            data: rawResult
        });

    } catch (error: any) {
        console.error("[API Cek Leaks] Crash:", error.message);
        return NextResponse.json({ 
            status: "error", 
            message: "Internal Server Error / Target Down" 
        }, { status: 500 });
    }
}

export async function POST(req: NextRequest) { 
    return withAuth(req, handler); 
}