// file: app/api/osiint/cekphone/route.ts (Contoh penamaan folder yang bener)
import { NextRequest, NextResponse } from 'next/server';
import { fetchOsint } from '@/lib/osint';
import { withAuth } from '@/lib/withAuth';

async function handler(req: NextRequest) {
    try {
        const { phone } = await req.json();

        // Validasi biar nggak error kalau payload kosong
        if (!phone) {
            return NextResponse.json({ 
                status: "error", 
                message: "Phone number is required" 
            }, { status: 400 });
        }

        // Panggil mesin tempur lu
        // Ambil hash dari env
        const currentActionHash = process.env.BLACKBIRD_ACTION_HASH;

        // Validasi jaga-jaga kalau env kosong atau lupa diisi
        if (!currentActionHash) {
            return NextResponse.json({ 
                status: "error", 
                message: "System Error: BLACKBIRD_ACTION_HASH is missing in .env" 
            }, { status: 500 });
        }

        // Panggil mesin tempur lu
        const rawResult = await fetchOsint({
            path: "/search", 
            payloadArray: ["phone", phone], 
            actionHash: currentActionHash // 👈 Sekarang ngambil dari variabel di atas
        });

        // Filter balikan dari Blackbird
        if (rawResult.error) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.error 
            }, { status: 404 });
        }

        if (rawResult.success === false) {
            return NextResponse.json({ 
                status: "error", 
                message: rawResult.message || "Operation failed" 
            }, { status: 400 });
        }

        // Output bersih
        return NextResponse.json({
            status: "success",
            data: rawResult
        });

    } catch (error: any) {
        console.error("[API Cek Phone] Crash:", error.message);
        return NextResponse.json({ 
            status: "error", 
            message: "Internal Server Error / Target Down" 
        }, { status: 500 });
    }
}

export async function POST(req: NextRequest) { 
    return withAuth(req, handler); 
}