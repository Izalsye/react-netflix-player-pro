// file: app/api/proxy/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ProxyAgent } from 'undici';

// 🚀 Tetep pakai engine Node.js (jangan pakai edge)
// export const runtime = 'edge'; 

// 👇 SWITCH PROXY MANUAL (Set 'false' pas di Localhost, set 'true' pas di VPS)
const USE_PROXY = true;

export async function OPTIONS() {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
            'Access-Control-Allow-Headers': 'Range, Origin, X-Requested-With, Content-Type, Accept, X-MB-Token',
            'Access-Control-Max-Age': '86400',
        },
    });
}

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;

    const url = searchParams.get('url');
    const provider = searchParams.get('provider');
    const type = searchParams.get('type') || 'stream';
    const source = searchParams.get('source') || 'wefeed';

    if (!url || !provider) {
        return new NextResponse("Missing required parameters", { status: 400 });
    }

    const allowedProviders = ['filmbox', 'dramovnime'];
    if (!allowedProviders.includes(provider)) {
        return new NextResponse("Provider Not Allowed", { status: 403 });
    }

    // ==========================================
    // 1. SETUP ORIGIN & REFERER DINAMIS
    // ==========================================
    let origin = '';
    let referer = '';

    if (type === 'sub') {
        if (provider === 'filmbox') {
            origin = 'https://movieboxhd.net';
            referer = 'https://movieboxhd.net/';
        } else if (provider === 'dramovnime') {
            try {
                const parsedUrl = new URL(url);
                origin = parsedUrl.origin;
                referer = parsedUrl.origin + '/';
            } catch (e) {
                origin = 'https://bcdn2.hakunaymatata.com';
                referer = 'https://bcdn2.hakunaymatata.com/';
            }
        }
    } else {
        if (source === 'filmbox' || provider === 'filmbox') {
            origin = 'https://movieboxhd.net';
            referer = `https://movieboxhd.net/`;
        } else {
            try {
                const parsedUrl = new URL(url);
                origin = parsedUrl.origin;
                referer = parsedUrl.origin + '/';
            } catch (e) {
                origin = '';
                referer = '';
            }
        }
    }

    const headers = new Headers();
    if (origin) headers.set('Origin', origin);
    if (referer) headers.set('Referer', referer);
    headers.set('User-Agent', req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36');

    // 🚀 INI KUNCI BIAR RAM GAK JEBOL: Terusin Range Header biar video diambil sepotong-sepotong!
    const range = req.headers.get('range');
    if (range) headers.set('Range', range);

    const xMbToken = req.headers.get('x-mb-token');
    if (xMbToken) headers.set('X-MB-Token', xMbToken);

    // ==========================================
    // 2. SETUP FETCH OPTIONS (KONDISIONAL PROXY MANUAL)
    // ==========================================
    const fetchOptions: RequestInit & { dispatcher?: any } = {
        method: 'GET',
        headers: headers,
    };

    let activeProxyUrl = "";
    if (USE_PROXY) {
        // Ambil dari .env, atau pakai default 127.0.0.1:8080 kalau lupa ngisi .env
        activeProxyUrl = process.env.PROXY_URL_FILMBOX || "http://127.0.0.1:8080";
        fetchOptions.dispatcher = new ProxyAgent(activeProxyUrl);
    }

    // ==========================================
    // 3. ROUTING LOGIC
    // ==========================================
    try {
        if (type === 'sub') {
            const upstreamRes = await fetch(url, fetchOptions);
            if (!upstreamRes.ok) return new NextResponse("Failed fetch", { status: upstreamRes.status });

            return new NextResponse(upstreamRes.body, {
                headers: {
                    'Content-Type': 'text/plain; charset=UTF-8',
                    'Cache-Control': 'public, max-age=86400',
                    'Access-Control-Allow-Origin': '*',
                }
            });
        } else {
            // 🚀 PROXY STREAMING (DASH / HLS / MP4)
            headers.set('Connection', 'keep-alive');
            headers.set('Accept', '*/*');
            headers.set('Accept-Language', 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7');
            headers.set('Sec-Fetch-Dest', 'video');
            headers.set('Sec-Fetch-Mode', 'no-cors');
            headers.set('Sec-Fetch-Site', 'cross-site');

            const upstreamResponse = await fetch(url, fetchOptions);

            if (!upstreamResponse.ok && upstreamResponse.status !== 206) {
                // 1. Ambil raw body dari upstream
                let errorBody = "";
                try {
                    errorBody = await upstreamResponse.text();
                } catch (e) {
                    errorBody = "[Gagal membaca body dari response upstream]";
                }

                // 2. Potong maksimal 1000 karakter
                const safeErrorBody = errorBody.substring(0, 1000);

                // 3. Print ke console server VPS
                console.error(`\n[🚨 PROXY UPSTREAM ERROR]`);
                console.error(`URL Request: ${url}`);
                console.error(`Status: ${upstreamResponse.status} ${upstreamResponse.statusText}`);
                console.error(`Via Proxy: ${USE_PROXY ? 'Yes (' + activeProxyUrl + ')' : 'No'}`);
                console.error(`Raw Response:\n${safeErrorBody}\n`);

                // 4. Balikin jadi JSON
                return new NextResponse(
                    JSON.stringify({
                        error: "Upstream Error",
                        status: upstreamResponse.status,
                        statusText: upstreamResponse.statusText,
                        via_proxy: USE_PROXY,
                        proxy_url: USE_PROXY ? activeProxyUrl : null,
                        raw_response: safeErrorBody
                    }),
                    {
                        status: upstreamResponse.status,
                        headers: {
                            'Content-Type': 'application/json',
                            'Cache-Control': 'no-store'
                        }
                    }
                );
            }

            const responseHeaders = new Headers();
            const headersToKeep = ['content-type', 'content-length', 'content-range', 'accept-ranges'];

            headersToKeep.forEach(key => {
                const value = upstreamResponse.headers.get(key);
                if (value) responseHeaders.set(key, value);
            });

            responseHeaders.set('access-control-allow-origin', '*');
            responseHeaders.set('access-control-expose-headers', 'Content-Length, Content-Range');
            responseHeaders.set('cache-control', 'no-store, no-cache, must-revalidate');

            return new Response(upstreamResponse.body, {
                status: upstreamResponse.status,
                statusText: upstreamResponse.statusText,
                headers: responseHeaders,
            });
        }
    } catch (error: any) {
        console.error("[PROXY FATAL ERROR]", error);
        return new NextResponse(
            JSON.stringify({
                error: "Proxy Server Error",
                message: error.message,
                via_proxy: USE_PROXY
            }),
            { status: 500, headers: { 'Content-Type': 'application/json' } }
        );
    }
}