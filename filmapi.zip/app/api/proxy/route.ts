// file: app/api/proxy/route.ts
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';

// 🚀 OPTIMASI: Tangani preflight request (OPTIONS) untuk semua jenis proxy
export async function OPTIONS() {
    return new NextResponse(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
            // 👈 WAJIB tambahin X-MB-Token di sini biar frontend gak kena block CORS!
            'Access-Control-Allow-Headers': 'Range, Origin, X-Requested-With, Content-Type, Accept, X-MB-Token',
            'Access-Control-Max-Age': '86400',
        },
    });
}

export async function GET(req: NextRequest) {
    const searchParams = req.nextUrl.searchParams;

    const url = searchParams.get('url');
    const provider = searchParams.get('provider');
    const type = searchParams.get('type') || 'stream'; // 'stream' atau 'sub'

    // Parameter khusus stream
    const dramaId = searchParams.get('dramaId');
    const source = searchParams.get('source') || 'wefeed';

    if (!url || !provider) {
        return new NextResponse("Missing required parameters (url/provider)", { status: 400 });
    }

    const allowedProviders = ['filmbox', 'dramovnime'];
    if (!allowedProviders.includes(provider)) {
        return new NextResponse("Provider Not Allowed", { status: 403 });
    }

    // ==========================================
    // 1. SETUP ORIGIN & REFERER DINAMIS
    // ==========================================
    let origin = '';
    let referer = '';

    if (type === 'sub') {
        // Logic Origin Subtitle
        if (provider === 'filmbox') {
            origin = 'https://movieboxhd.net'; // 👈 Update ke Web H5
            referer = 'https://movieboxhd.net/';
        } else if (provider === 'dramovnime') {
            try {
                const parsedUrl = new URL(url);
                origin = parsedUrl.origin;
                referer = parsedUrl.origin + '/';
            } catch (e) {
                origin = 'https://bcdn2.hakunaymatata.com';
                referer = 'https://bcdn2.hakunaymatata.com/';
            }
        }
    } else {
        // Logic Origin Stream (DASH/MP4/HLS)
        if (source === 'filmbox' || provider === 'filmbox') {
            origin = 'https://movieboxhd.net'; // 👈 Update ke Web H5
            // Gak perlu full path, root domain aja udah cukup buat ngibulin CDN
            referer = `https://movieboxhd.net/`;
        } else {
            try {
                const parsedUrl = new URL(url);
                origin = parsedUrl.origin;
                referer = parsedUrl.origin + '/';
            } catch (e) {
                origin = '';
                referer = '';
            }
        }
    }

    const headers = new Headers();
    if (origin) headers.set('Origin', origin);
    if (referer) headers.set('Referer', referer);
    headers.set('User-Agent', req.headers.get('user-agent') || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36');

    // 🚀 FORWARD HEADER KHUSUS DARI FRONTEND (DASH TOKEN DLL)
    const range = req.headers.get('range');
    if (range) headers.set('Range', range);

    const xMbToken = req.headers.get('x-mb-token');
    if (xMbToken) headers.set('X-MB-Token', xMbToken); // 👈 Trik lolos DASH CDN

    // ==========================================
    // 2. ROUTING LOGIC BERDASARKAN TIPE
    // ==========================================
    try {
        if (type === 'sub') {
            // ----------------------------------------
            // LOGIC SUBTITLE (SERVER SEKARANG HANYA BYPASS CORS)
            // ----------------------------------------
            const upstreamRes = await fetch(url, { headers });

            if (!upstreamRes.ok) {
                return new NextResponse("Failed to fetch subtitle", { status: upstreamRes.status });
            }

            // Langsung oper response stream/text mentah-mentah ke frontend
            return new NextResponse(upstreamRes.body, {
                headers: {
                    'Content-Type': 'text/plain; charset=UTF-8', // Biarkan jadi plain text dulu
                    'Cache-Control': 'public, max-age=86400',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, OPTIONS',
                }
            });
        } else {
            // ----------------------------------------
            // LOGIC STREAM (MP4 / HLS / DASH)
            // ----------------------------------------
            headers.set('Connection', 'keep-alive');

            const upstreamResponse = await fetch(url, {
                method: 'GET',
                headers: headers
            });

            if (!upstreamResponse.ok && upstreamResponse.status !== 206) {
                return new NextResponse(`Upstream error: ${upstreamResponse.statusText}`, { status: upstreamResponse.status });
            }

            const responseHeaders = new Headers();
            const headersToKeep = ['content-type', 'content-length', 'content-range', 'accept-ranges'];

            headersToKeep.forEach(key => {
                const value = upstreamResponse.headers.get(key);
                if (value) responseHeaders.set(key, value);
            });

            // Set CORS untuk Player DASH / HLS / MP4
            responseHeaders.set('access-control-allow-origin', '*');
            responseHeaders.set('access-control-expose-headers', 'Content-Length, Content-Range');
            responseHeaders.set('cache-control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

            return new Response(upstreamResponse.body, {
                status: upstreamResponse.status,
                statusText: upstreamResponse.statusText,
                headers: responseHeaders,
            });
        }
    } catch (error: any) {
        return new NextResponse(`Proxy Error: ${error.message}`, { status: 500 });
    }
}