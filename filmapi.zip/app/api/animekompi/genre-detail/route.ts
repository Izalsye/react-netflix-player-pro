import { NextRequest, NextResponse } from 'next/server';
import { proxyScrape } from '@/lib/proxyGlobal';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
        const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 👇 Ambil parameter 'genre' dari URL (contoh: romance, action, dll)
    const genre = req.nextUrl.searchParams.get('genre');

    // Ambil parameter page
    const pageParam = req.nextUrl.searchParams.get('page');
    const page = parseInt(pageParam || '1', 10);

    if (!genre) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'genre' wajib diisi. Contoh: ?genre=romance",
            data: null
        }, { status: 400 });
    }

    // Tentukan Target URL
    let targetUrl = `https://v9.animekompi.sbs/genres/${genre}/`;

    // Kalau page lebih dari 1, URL-nya berubah jadi /genres/{genre}/page/{page}/
    if (page > 1) {
        targetUrl = `https://v9.animekompi.sbs/genres/${genre}/page/${page}/`;
    }

    return proxyScrape(
        req,
        targetUrl,
        (html) => AnimekompiMapper.mapGenreDetail(html),
        {
            label: `animekompi-genre-${genre}-p${page}`,
        }
    );
}