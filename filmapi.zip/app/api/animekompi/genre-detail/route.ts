import { NextRequest, NextResponse } from 'next/server';
import { proxyScrapeRaw } from '@/lib/proxyGlobal'; // 👈 Pakai proxyScrapeRaw
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 👇 Ambil parameter 'genre' dari URL
    const genre = req.nextUrl.searchParams.get('genre');

    // Ambil parameter page
    const pageParam = req.nextUrl.searchParams.get('page');
    const page = parseInt(pageParam || '1', 10);

    if (!genre) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'genre' wajib diisi. Contoh: ?genre=romance",
            data: null
        }, { status: 400 });
    }

    // Tentukan Target URL
    let targetUrl = `https://v9.animekompi.sbs/genres/${genre}/`;

    // Kalau page lebih dari 1, URL-nya berubah
    if (page > 1) {
        targetUrl = `https://v9.animekompi.sbs/genres/${genre}/page/${page}/`;
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT GENRE DAN PAGE 🔥
        const cacheKey = `animekompi:genre-detail:${genre}:page:${page}`;
        const cacheTTL = 600; // 10 menit

        const mappedData = await getOrSetCache(cacheKey, async () => {
            // Panggil fungsi proxyScrapeRaw
            const data = await proxyScrapeRaw(
                targetUrl,
                (html) => AnimekompiMapper.mapGenreDetail(html),
                { label: `animekompi-genre-${genre}-p${page}` }
            );

            return data;
        }, cacheTTL);

        // Return Data dari Cache atau Upstream
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        // Ambil status asli dari error (404, 502, dll)
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}