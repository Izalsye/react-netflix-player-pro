import { NextRequest, NextResponse } from 'next/server';
import { proxyScrapeRaw } from '@/lib/proxyGlobal'; // 👈 Pakai proxyScrapeRaw
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // Target URL statis ke halaman list A-Z
    const targetUrl = 'https://v9.animekompi.sbs/anime/list-mode/';

    try {
        // 🔥 BIKIN CACHE KEY BUAT ANIMEKOMPI LIST A-Z 🔥
        const cacheKey = `animekompi:list`;
        const cacheTTL = 43200; // 12 Jam (Super aman karena jarang berubah)

        const mappedData = await getOrSetCache(cacheKey, async () => {
            // Panggil fungsi proxyScrapeRaw
            const data = await proxyScrapeRaw(
                targetUrl,
                (html) => AnimekompiMapper.mapList(html),
                { label: 'animekompi-list' }
            );

            return data;
        }, cacheTTL);

        // Return Data dari Cache atau Upstream
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}