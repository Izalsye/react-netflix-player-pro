import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
    const url = req.nextUrl.searchParams.get('url');

    if (!url) {
        return new NextResponse("URL video tidak ada", { status: 400 });
    }

    // 1. Siapkan header bawaan untuk ngecoh Google
    const fetchHeaders: Record<string, string> = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://www.blogger.com/',
    };

    // 2. 🔥 AMANIN HEADER RANGE 🔥
    // Cuma tambahin header Range kalau beneran ada dari request browser
    const range = req.headers.get('range');
    if (range) {
        fetchHeaders['Range'] = range;
    }

    try {
        // 3. Tembak ke server Google
        const response = await fetch(url, {
            headers: fetchHeaders
        });

        // 4. Teruskan data stream (body) dan header penting dari Google ke browser user
        const responseHeaders = new Headers();
        const headersToKeep = [
            'content-type',
            'content-length',
            'content-range',
            'accept-ranges'
        ];

        headersToKeep.forEach(key => {
            if (response.headers.has(key)) {
                responseHeaders.set(key, response.headers.get(key)!);
            }
        });

        // Set CORS biar bisa diputar di player manapun tanpa hambatan
        responseHeaders.set('Access-Control-Allow-Origin', '*');

        return new NextResponse(response.body, {
            status: response.status, // Bisa 200 (OK) atau 206 (Partial Content)
            statusText: response.statusText,
            headers: responseHeaders,
        });

    } catch (error: any) {
        return new NextResponse("Gagal proxy video: " + error.message, { status: 500 });
    }
}