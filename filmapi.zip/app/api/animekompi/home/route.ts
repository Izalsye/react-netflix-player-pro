// api/animekompi/home/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyScrapeRaw } from '@/lib/proxyGlobal'; // <-- Pakai yang Raw
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // <-- Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const pageParam = req.nextUrl.searchParams.get('page');
    const page = parseInt(pageParam || '1', 10);

    let targetUrl = 'https://v9.animekompi.sbs/';
    if (page > 1) {
        targetUrl = `https://v9.animekompi.sbs/page/${page}/`;
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT ANIMEKOMPI HOME 🔥
        const cacheKey = `animekompi:home:page:${page}`;
        const cacheTTL = 600; // 10 menit

        const mappedData = await getOrSetCache(cacheKey, async () => {
            // Panggil fungsi proxyScrapeRaw yang me-return JSON murni
            const data = await proxyScrapeRaw(
                targetUrl,
                (html) => AnimekompiMapper.mapHome(html),
                { label: `animekompi-home-page-${page}` }
            );

            return data;
        }, cacheTTL);

        // Return Data dari Cache atau Upstream
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData
        });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus, // Tetap kirim kode error asli di body JSON buat frontend
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus // Nginx cuma ngelihat 400, jadi JSON gak bakal ditimpa HTML
        });
    }
}