import { NextRequest, NextResponse } from 'next/server';
import { proxyScrape } from '@/lib/proxyGlobal';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 1. Ambil parameter 'page' dari URL query (contoh: /api/animekompi/home?page=2)
    const pageParam = req.nextUrl.searchParams.get('page');

    // Parse ke angka. Kalau kosong atau bukan angka, jadikan 1.
    const page = parseInt(pageParam || '1', 10);

    // 2. Tentukan target URL berdasarkan page
    let targetUrl = 'https://v9.animekompi.sbs/';

    // Kalau page lebih dari 1, ubah format URL-nya
    if (page > 1) {
        targetUrl = `https://v9.animekompi.sbs/page/${page}/`;
    }

    // 3. Panggil proxyScrape
    return proxyScrape(
        req,
        targetUrl,
        (html) => AnimekompiMapper.mapHome(html),
        {
            // Opsional: Bikin label stat-nya dinamis biar ketahuan page berapa yang di-hit
            label: `animekompi-home-page-${page}`,
        }
    );
}