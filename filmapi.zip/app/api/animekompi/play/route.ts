import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Import helper Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const episodeId = req.nextUrl.searchParams.get('episode_id');

    if (!episodeId) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'episode_id' wajib diisi. Contoh: ?episode_id=a-day-before-us-2-episode-01",
            data: null
        }, { status: 400 });
    }

    const targetUrl = `https://v9.animekompi.sbs/${episodeId}/`;

    try {
        // 🔥 BIKIN CACHE KEY KHUSUS UNTUK PLAY ANIMEKOMPI 🔥
        const cacheKey = `animekompi:play:${episodeId}`;
        const cacheTTL = 1800; // 30 Menit (Jangan kelamaan biar token gak expired)

        const mappedData = await getOrSetCache(cacheKey, async () => {
            try {
                const { data: html } = await axios.get(targetUrl, {
                    headers: { 'User-Agent': 'Mozilla/5.0' },
                    timeout: 15000 // 👈 Pasang batas tunggu 15 detik
                });

                // 🔥 HARUS PAKE AWAIT KARENA mapPlay SEKARANG ASYNC 🔥
                const result = await AnimekompiMapper.mapPlay(html);
                return result;

            } catch (err: any) {
                // Lempar error ke blok catch utama biar gak disimpen Redis
                if (err.response && err.response.status === 404) {
                    throw { status: 404, message: "Episode tidak ditemukan (404 dari sumber)" };
                }
                throw { status: 502, message: "Upstream error: " + err.message };
            }
        }, cacheTTL);

        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData // Sekarang datanya pasti utuh dan diambil dari Redis kalau udah ada
        });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}