import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const episodeId = req.nextUrl.searchParams.get('episode_id');

    if (!episodeId) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'episode_id' wajib diisi. Contoh: ?episode_id=a-day-before-us-2-episode-01",
            data: null
        }, { status: 400 });
    }

    const targetUrl = `https://v9.animekompi.sbs/${episodeId}/`;

    try {
        console.log(`🌐 [Route] Fetching: ${targetUrl}`);
        const { data: html } = await axios.get(targetUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        // 🔥 HARUS PAKE AWAIT KARENA mapPlay SEKARANG ASYNC 🔥
        const mappedData = await AnimekompiMapper.mapPlay(html);

        return NextResponse.json({
            code: 0,
            message: "ok",
            data: mappedData // Sekarang datanya pasti utuh, bukan Promise {} lagi
        });

    } catch (error: any) {
        // 1. Cek apakah ini error 404 dari Axios (Upstream)
        if (error.response && error.response.status === 404) {
            console.warn(`[Route 404] Episode not found: ${targetUrl}`);
            return NextResponse.json({ 
                code: 404, 
                message: "Episode tidak ditemukan (404 dari sumber)", 
                data: null 
            }, { status: 404 });
        }

        // 2. Jika error lain (Timeout, koneksi putus, web target down)
        console.error("💥 [Route] Error:", error.message);
        return NextResponse.json({ 
            code: 502, // Ubah 500 ke 502 (Bad Gateway) karena ini error dari pihak ke-3
            message: "Upstream error: " + error.message, 
            data: null 
        }, { status: 502 });
    }
}