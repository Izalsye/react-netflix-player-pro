import { NextRequest, NextResponse } from 'next/server';
import { proxyScrape } from '@/lib/proxyGlobal';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Target URL statis ke halaman Genres
    const targetUrl = 'https://v9.animekompi.sbs/genres/';

    // Panggil proxyScrape dan arahkan parser ke mapGenres
    return proxyScrape(
        req,
        targetUrl,
        (html) => AnimekompiMapper.mapGenres(html),
        {
            label: 'animekompi-genres',
        }
    );
}