import { NextRequest, NextResponse } from 'next/server';
import { proxyScrape } from '@/lib/proxyGlobal';
import { AnimekompiMapper } from '@/lib/animekompiMap';
import { validateApiKey } from '@/lib/apiKeyService';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'animekompi');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    
    // 1. Ambil parameter 'path' (wajib ada)
    const path = req.nextUrl.searchParams.get('path');

    if (!path) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'path' wajib diisi. Contoh: ?path=3d-kanojo-real-girl-season-2",
            data: null
        }, { status: 400 });
    }

    // 2. Susun target URL
    const targetUrl = `https://v9.animekompi.sbs/anime/${path}/`;

    // 3. Eksekusi proxyScrape tanpa mengirimkan cacheTtlSeconds
    return proxyScrape(
        req,
        targetUrl,
        (html) => AnimekompiMapper.mapDetail(html),
        {
            label: `animekompi-detail-${path}`
        }
    );
}