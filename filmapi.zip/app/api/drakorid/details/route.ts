// file: app/api/drakorid/nonton/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid'; // 👈 Eksekusi fetcher mentah
import { mapDetailDramaData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Tameng Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 1. Tangkap slug dari query: ?slug=fifties-professionals-2026
    const searchParams = req.nextUrl.searchParams;
    const slug = searchParams.get('slug');

    if (!slug) {
        return NextResponse.json({
            code: 400,
            message: "Slug drama wajib diisi!",
            data: null
        }, { status: 400 });
    }

    const targetPath = `/nonton/${slug}/`;

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT DETAIL DRAMA 🔥
        const cacheKey = `drakorid:detail:slug:${slug}`;
        const cacheTTL = 300; // 5 Menit (Biar episode baru cepet muncul)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak HTML ke target
            const html = await getDrakorHtml(targetPath);

            // Petakan HTML pakai fungsi mapDetailDramaData
            const cleanData = mapDetailDramaData(html, slug);

            // Langsung return objek datanya
            return cleanData;
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}