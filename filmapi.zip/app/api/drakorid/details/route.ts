// file: app/api/drakorid/nonton/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid'; // <-- Import proxy-nya
import { mapDetailDramaData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 1. Tangkap slug dari query: ?slug=fifties-professionals-2026
    const slug = req.nextUrl.searchParams.get('slug');

    if (!slug) {
        return NextResponse.json({
            code: 400,
            message: "Slug drama wajib diisi!",
            data: null
        }, { status: 400 });
    }

    const targetPath = `/nonton/${slug}/`;

    // 2. Langsung return fungsi proxyDrakorGet
    // Proxy ini otomatis ngecek API Key, catat stats, fetch HTML, dan mapping datanya
    return proxyDrakorGet(
        req,
        targetPath,
        (html) => mapDetailDramaData(html, slug) // <-- Fungsi scraper ditaruh di callback ini
    );
}