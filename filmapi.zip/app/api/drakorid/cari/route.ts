// file: app/api/drakorid/cari/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid';
import { mapSearchDramaData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const searchParams = req.nextUrl.searchParams;

    // 1. Tangkap parameter keyword pencarian 'q' dan halaman 'page' dari frontend
    const query = searchParams.get('q');
    const pageParam = searchParams.get('page') || searchParams.get('p'); // support 'page' atau 'p'
    const page = pageParam ? parseInt(pageParam, 10) : 1;

    // Validation: Jika frontend lupa ngirim keyword 'q', langsung cut biar gak mubazir request
    if (!query) {
        return NextResponse.json({
            success: false,
            message: "Parameter 'q' (keyword pencarian) wajib diisi."
        }, { status: 400 });
    }

    // 2. Rangkai URL target sesuai format asli drakorid: cari.html?q=keyword&p=halaman
    // EncodeURIComponent dipakai supaya kata kunci yang pakai spasi (misal: "perfect match") aman di URL
    const targetPath = `/cari.html?q=${encodeURIComponent(query)}&p=${page}`;

    // 3. Eksekusi via proxyDrakorGet
    return proxyDrakorGet(
        req,
        targetPath,
        (html) => {
            // 4. Petakan HTML hasil fetch menggunakan mapper yang sudah kita buat
            const parsedData = mapSearchDramaData(html);

            // 5. Susun format response JSON akhir untuk frontend-mu
            return {
                success: true,
                query: query,
                pagination: {
                    currentPage: parsedData.pagination.currentPage,
                    hasNextPage: parsedData.pagination.hasNextPage,
                    // Kita manipulasi url-nya agar mengarah ke endpoint API Next.js kamu sendiri, bukan web target
                    nextPageUrl: parsedData.pagination.hasNextPage
                        ? `/api/drakorid/cari?q=${encodeURIComponent(query)}&page=${page + 1}`
                        : null
                },
                total: parsedData.results.length,
                items: parsedData.results // Array dari list film/drama
            };
        }
    );
}