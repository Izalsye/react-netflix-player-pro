// file: app/api/drakorid/ongoing/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorPost } from '@/lib/drakorid';
import { mapOngoingData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 1. Tangkap parameter '?page=' dari URL lu
    const searchParams = req.nextUrl.searchParams;
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    // 2. Siapkan Payload untuk DrakorID
    const payloadParams: Record<string, string> = {};

    // Sesuai aturan lu: kalau page 1 gak usah dikirim, kalau > 1 baru dikirim
    if (page > 1) {
        payloadParams['page'] = page.toString();
    }

    // 3. Tembak menggunakan proxyDrakorPost
    return proxyDrakorPost(
        req,
        {
            path: '/ajax/drama/ongoing.php',
            payload: payloadParams
        },
        (rawHtml) => {
            // Cek kalau tiba-tiba response bukan string
            if (typeof rawHtml !== 'string') {
                throw new Error("Respon bukan HTML string.");
            }

            // 4. Petakan HTML pakai mapper lu
            // Di route.ts
            const cleanData = mapOngoingData(rawHtml);

            if (cleanData.length === 0) {
                console.warn("⚠️ Warning: Data ongoing kosong! Raw HTML:", rawHtml.substring(0, 500));
            }

            // 5. Return JSON dengan info current page
            return {
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }
    );
}