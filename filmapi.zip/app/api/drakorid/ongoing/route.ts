// file: app/api/drakorid/ongoing/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { postDrakor } from '@/lib/drakorid'; // 👈 Panggil engine core langsung
import { mapOngoingData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Tameng Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 1. Tangkap parameter '?page=' dari URL lu
    const searchParams = req.nextUrl.searchParams;
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    // 2. Siapkan Payload untuk DrakorID
    const payloadParams: Record<string, string> = {};
    if (page > 1) {
        payloadParams['page'] = page.toString();
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT ONGOING 🔥
        const cacheKey = `drakorid:ongoing:page:${page}`;
        const cacheTTL = 300; // 5 Menit (300 detik) - cocok buat pantau episode baru

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak menggunakan postDrakor
            const rawHtml = await postDrakor({
                path: '/ajax/drama/ongoing.php',
                payload: payloadParams
            });

            // Cek kalau tiba-tiba response bukan string
            if (typeof rawHtml !== 'string') {
                throw { status: 502, message: "Respon bukan HTML string." };
            }

            // Petakan HTML pakai mapper
            const cleanData = mapOngoingData(rawHtml);

            // 🔥 LOG AMAN: Gak ada lagi nge-print HTML mentah ke terminal!
            if (cleanData.length === 0) {
                console.warn(`[⚠️ DrakorID] Data ongoing kosong untuk page: ${page}`);
            }

            // Return JSON murni
            return {
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}