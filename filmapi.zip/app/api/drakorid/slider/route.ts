// file: app/api/drakorid/slider/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorPost } from '@/lib/drakorid';
import { mapSliderData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Gunakan proxyDrakorPost, otomatis handle API Key & Hit Stats
    return proxyDrakorPost(
        req,
        {
            path: '/ajax/index_slider.php'
            // Gak perlu kirim payload berdasarkan kode asli lu
        },
        (rawHtml) => {
            // Pastikan balasan berupa string HTML sebelum di-parse
            if (typeof rawHtml !== 'string') {
                throw new Error("Respon dari server bukan HTML string.");
            }

            // Petakan (Map) HTML mentah menjadi JSON yang rapi
            const cleanData = mapSliderData(rawHtml);

            // Return ini otomatis dimasukkan ke dalam properti "data"
            return {
                total: cleanData.length,
                items: cleanData
            };
        }
    );
}