// file: app/api/drakorid/slider/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { postDrakor } from '@/lib/drakorid'; // 👈 Eksekusi langsung POST
import { mapSliderData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Tameng Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT SLIDER 🔥
        const cacheKey = `drakorid:slider`;
        const cacheTTL = 3600; // 1 Jam

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak POST ke drakorid.co via postDrakor
            const rawHtml = await postDrakor({
                path: '/ajax/index_slider.php'
            });

            // Pastikan balasan berupa string HTML sebelum di-parse
            if (typeof rawHtml !== 'string') {
                throw { status: 502, message: "Respon dari server bukan HTML string." };
            }

            // Ekstrak HTML pakai mapper
            const cleanData = mapSliderData(rawHtml);

            return {
                total: cleanData.length,
                items: cleanData
            };
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}