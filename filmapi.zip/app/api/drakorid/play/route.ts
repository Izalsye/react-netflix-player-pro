// file: app/api/drakorid/play/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml, proxyDrakorCustom } from '@/lib/drakorid';
import { mapPlayData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Gunakan wrapper proxyDrakorCustom
    return proxyDrakorCustom(req, async () => {
        // --- SEMUA LOGIKA LU MASUK SINI ---

        const body = await req.json();
        const id = body.id;
        const episode = Number(body.episode);
        const quality = Number(body.quality) || 720;

        // Kalau error di sini, otomatis dilempar ke catch di wrapper
        if (!id || !episode) {
            throw new Error("ID (slug) dan Episode wajib diisi!");
        }

        // 1. Ambil HTML dari halaman watch-lite
        const watchPath = `/watch-lite/${id}/${episode}`;
        const watchHtml = await getDrakorHtml(watchPath);

        // 2. Cari URL iframe
        const regexIframe = new RegExp(`<div\\s+id="vidio${quality}"[^>]*>[\\s\\S]*?<iframe\\s+src=["']([^"']+)["']`, 'i');
        const iframeMatch = watchHtml.match(regexIframe);

        if (!iframeMatch || !iframeMatch[1]) {
            throw new Error(`Resolusi ${quality}p tidak ditemukan atau video belum tersedia.`);
        }

        const iframeUrl = iframeMatch[1];
        let streamUrl = "";

        // 3. JALAN PINTAS: Coba ekstrak parameter 'v'
        try {
            const urlObj = new URL(iframeUrl.startsWith('http') ? iframeUrl : `https://drakorid.co${iframeUrl}`);
            const encodedV = urlObj.searchParams.get('v');
            if (encodedV) {
                streamUrl = Buffer.from(encodedV, 'base64').toString('utf-8');
            }
        } catch (e) {
            console.log("[Route Info] Gagal decode base64, mencoba fetch step 2...");
        }

        // 4. FALLBACK: Fetch halaman player iframe
        if (!streamUrl) {
            const playerHtml = await getDrakorHtml(iframeUrl);
            const sourceMatch = playerHtml.match(/<source\s+src=["']([^"']+)["']/i);

            if (sourceMatch && sourceMatch[1]) {
                streamUrl = sourceMatch[1];
            } else {
                throw new Error("Gagal menemukan direct link video HLS dari player.");
            }
        }

        // 5. Kembalikan data yang udah dimap
        // Return ini otomatis jadi nilai 'data' di JSON response proxy lu
        return mapPlayData(id, episode, quality, streamUrl);
    });
}