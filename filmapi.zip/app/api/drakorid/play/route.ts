// file: app/api/drakorid/play/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid';
import { mapPlayData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Bawa masuk pasukan Redis

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        const body = await req.json();
        const id = body.id;
        const episode = Number(body.episode);
        const quality = Number(body.quality) || 720;

        if (!id || !episode) {
            return NextResponse.json({
                code: 400,
                message: "ID (slug) dan Episode wajib diisi!",
                data: null
            }, { status: 400 });
        }

        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT PLAY VIDEO 🔥
        const cacheKey = `drakorid:play:id:${id}:ep:${episode}:q:${quality}`;
        const cacheTTL = 1800; // 30 Menit (Biar link video gak basi)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // 1. Ambil HTML dari halaman watch-lite
            const watchPath = `/watch-lite/${id}/${episode}`;
            const watchHtml = await getDrakorHtml(watchPath);

            // 2. Cari URL iframe
            const regexIframe = new RegExp(`<div\\s+id="vidio${quality}"[^>]*>[\\s\\S]*?<iframe\\s+src=["']([^"']+)["']`, 'i');
            const iframeMatch = watchHtml.match(regexIframe);

            if (!iframeMatch || !iframeMatch[1]) {
                // Lempar sebagai object error biar ditangkap blocker Nginx
                throw { status: 404, message: `Resolusi ${quality}p tidak ditemukan atau video belum tersedia.` };
            }

            const iframeUrl = iframeMatch[1];
            let streamUrl = "";

            // 3. JALAN PINTAS: Coba ekstrak parameter 'v'
            try {
                const urlObj = new URL(iframeUrl.startsWith('http') ? iframeUrl : `https://drakorid.co${iframeUrl}`);
                const encodedV = urlObj.searchParams.get('v');
                if (encodedV) {
                    streamUrl = Buffer.from(encodedV, 'base64').toString('utf-8');
                }
            } catch (e) {
                console.log(`[DrakorID Play] Gagal decode base64, mencoba fetch step 2 untuk ID: ${id}`);
            }

            // 4. FALLBACK: Fetch halaman player iframe
            if (!streamUrl) {
                const playerHtml = await getDrakorHtml(iframeUrl);
                const sourceMatch = playerHtml.match(/<source\s+src=["']([^"']+)["']/i);

                if (sourceMatch && sourceMatch[1]) {
                    streamUrl = sourceMatch[1];
                } else {
                    throw { status: 404, message: "Gagal menemukan direct link video HLS dari player." };
                }
            }

            // 5. Kembalikan data yang udah dimap
            return mapPlayData(id, episode, quality, streamUrl);
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}