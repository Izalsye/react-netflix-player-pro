// file: app/api/drakorid/trending/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid';
import { mapAllTrendingData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Tinggal lempar req, path, dan fungsi mapper ke proxyDrakorGet
    // Otomatis di-handle API Key, Hit Stats, dan Try-Catch-nya
    return proxyDrakorGet(
        req,
        '/trending.html',
        (html) => mapAllTrendingData(html)
    );
}