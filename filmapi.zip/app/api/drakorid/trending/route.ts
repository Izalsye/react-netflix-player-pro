// file: app/api/drakorid/trending/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid'; // 👈 Eksekusi langsung
import { mapAllTrendingData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Pasukan Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT TRENDING 🔥
        const cacheKey = `drakorid:trending`;
        const cacheTTL = 3600; // 1 Jam, biar awet dan hemat CPU

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak HTML ke drakorid.co
            const html = await getDrakorHtml('/trending.html');

            // Ekstrak HTML pakai mapper
            const cleanData = mapAllTrendingData(html);

            return cleanData;
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}