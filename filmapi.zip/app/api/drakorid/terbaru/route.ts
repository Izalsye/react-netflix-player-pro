// file: app/api/drakorid/terbaru/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid'; // 👈 Langsung ambil core fetcher-nya
import { mapTerbaruData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Helper Redis andalan kita

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    // 1. Tangkap parameter '?page='
    const searchParams = req.nextUrl.searchParams;
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    const targetPath = `/list/${page}`;

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT HALAMAN TERBARU 🔥
        const cacheKey = `drakorid:terbaru:page:${page}`;
        // Set 5 Menit (300 detik) - cukup fresh buat list drakor update
        const cacheTTL = 300;

        // 2. Bungkus proses berat di dalam benteng Redis!
        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak langsung HTML ke drakorid.co
            const html = await getDrakorHtml(targetPath);

            // Ekstrak HTML pakai mapper Cheerio lu
            const cleanData = mapTerbaruData(html);

            // Return JSON mentah (Ini yang bakal disimpan otomatis di Redis)
            return {
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }, cacheTTL);

        // 3. Kembalikan response json yang super ringan
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}