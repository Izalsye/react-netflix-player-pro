// file: app/api/drakorid/terbaru/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid';
import { mapTerbaruData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // 1. Tangkap parameter '?page=' dari frontend lu (default ke 1 kalau kosong)
    const searchParams = req.nextUrl.searchParams;
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    // 2. Rangkai URL target (misal: /list/1 atau /list/2)
    const targetPath = `/list/${page}`;

    // 3. Eksekusi via proxyDrakorGet (Otomatis urus API Key, Stats, & Try-Catch)
    return proxyDrakorGet(
        req,
        targetPath,
        (html) => {
            // 4. Petakan HTML yang didapat pakai fungsi mapper lu
            const cleanData = mapTerbaruData(html);

            // 5. Susun data return supaya rapi dan informatif
            return {
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }
    );
}