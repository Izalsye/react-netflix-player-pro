// file: app/api/drakorid/kategori/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid'; // 👈 Tarik fungsi get mentahnya
import { mapKategoriData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Tameng baja Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT KATEGORI 🔥
        const cacheKey = `drakorid:kategori`;
        const cacheTTL = 86400; // 24 Jam (Super hemat CPU!)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak HTML target
            const html = await getDrakorHtml('/kategori.html');

            // Ekstrak data pakai Cheerio
            const cleanData = mapKategoriData(html);

            // Format ulang return-nya supaya info 'total' tetep ikut
            return {
                total: cleanData.length,
                items: cleanData
            };
        }, cacheTTL);

        // Kembalikan response JSON murni
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}