// file: app/api/drakorid/kategori/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid';
import { mapKategoriData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    // Tinggal return proxyDrakorGet aja, error handling & API key otomatis diurus
    return proxyDrakorGet(
        req,
        '/kategori.html',
        (html) => {
            const cleanData = mapKategoriData(html);

            // Format ulang return-nya supaya info 'total' tetep ikut
            return {
                total: cleanData.length,
                items: cleanData
            };
        }
    );
}