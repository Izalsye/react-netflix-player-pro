// file: app/api/drakorid/kategori/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getDrakorHtml } from '@/lib/drakorid'; // 👈 Eksekusi fetcher mentah
// 🔴 KITA RECYCLE MAPPER TERBARU KARENA HTML-NYA IDENTIK
import { mapTerbaruData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';
import { getOrSetCache } from '@/lib/redisClient'; // 👈 Tameng Redis

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }

    const searchParams = req.nextUrl.searchParams;

    // 1. Tangkap parameter 'slug' (contoh: film-korea, drama-china)
    const slug = searchParams.get('slug');
    if (!slug) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'slug' wajib diisi! Contoh: ?slug=film-korea",
            data: null
        }, { status: 400 });
    }

    // 2. Tangkap parameter 'page' (default 1)
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    // 3. Tembak URL Kategori DrakorID (misal: /kategori/film-korea/1)
    const targetPath = `/kategori/${slug}/${page}`;

    try {
        // 🔥 BIKIN CACHE KEY SPESIFIK BUAT DETAIL KATEGORI 🔥
        const cacheKey = `drakorid:kategori:detail:slug:${slug}:page:${page}`;
        const cacheTTL = 300; // 5 Menit (biar tetep fresh kalau ada drama baru di kategori ini)

        const rawData = await getOrSetCache(cacheKey, async () => {
            // Tembak HTML ke target
            const html = await getDrakorHtml(targetPath);

            // Petakan HTML pakai fungsi recycle mapTerbaruData
            const cleanData = mapTerbaruData(html);

            // Susun data kembalian beserta metadatanya
            return {
                kategori: slug,
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }, cacheTTL);

        // Kembalikan response json bersih dari memori
        return NextResponse.json({
            code: 0,
            message: "ok",
            data: rawData
        }, { status: 200 });

    } catch (error: any) {
        // Ambil status asli dari error
        const originalStatus = error.status || 502;

        // 🛡️ ANTI-NGINX HTML: Samarkan status krusial jadi 400
        let safeHttpStatus = originalStatus;
        if ([403, 404, 500, 502, 503, 504].includes(originalStatus)) {
            safeHttpStatus = 400;
        }

        return NextResponse.json({
            code: originalStatus,
            message: error.message || "Internal Server Error",
            data: null
        }, {
            status: safeHttpStatus
        });
    }
}