// file: app/api/drakorid/kategori/detail/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { proxyDrakorGet } from '@/lib/drakorid';
// 🔴 KITA RECYCLE MAPPER TERBARU KARENA HTML-NYA IDENTIK
import { mapTerbaruData } from '@/lib/drakoridMap';
import { validateApiKey } from '@/lib/apiKeyService';

export async function GET(req: NextRequest) {
    const auth = await validateApiKey(req, 'drakorid');

    // Kalau API Key ngasal atau limit abis, langsung tendang!
    if (!auth.isValid) {
        return NextResponse.json(
            { code: auth.status, message: auth.message, data: null },
            { status: auth.status }
        );
    }
    const searchParams = req.nextUrl.searchParams;

    // 1. Tangkap parameter 'slug' (contoh: film-korea, drama-china)
    const slug = searchParams.get('slug');
    if (!slug) {
        return NextResponse.json({
            code: 400,
            message: "Parameter 'slug' wajib diisi! Contoh: ?slug=film-korea",
            data: null
        }, { status: 400 });
    }

    // 2. Tangkap parameter 'page' (default 1)
    const pageParam = searchParams.get('page');
    const page = pageParam ? parseInt(pageParam) : 1;

    // 3. Tembak URL Kategori DrakorID (misal: /kategori/film-korea/1)
    const targetPath = `/kategori/${slug}/${page}`;

    // 4. Proses via proxyDrakorGet (Otomatis handle API Key, Stats, & Try-Catch)
    return proxyDrakorGet(
        req,
        targetPath,
        (html) => {
            // Petakan HTML pakai fungsi yang udah ada
            const cleanData = mapTerbaruData(html);

            // Susun data kembalian beserta metadatanya
            return {
                kategori: slug,
                page: page,
                total: cleanData.length,
                items: cleanData
            };
        }
    );
}