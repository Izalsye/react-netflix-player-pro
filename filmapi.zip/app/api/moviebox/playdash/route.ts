import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');
    const se = searchParams.get('se') || '1';
    const ep = searchParams.get('ep') || '1';

    if (!subjectId) {
        return NextResponse.json(
            { error: true, message: "Parameter 'subjectId' wajib diisi!" },
            { status: 400 }
        );
    }

    try {
        // Jangan di-cache, token CloudFront sangat sensitif waktu!
        return await movieboxGet(
            req,
            '/wefeed-mobile-bff/subject-api/play-info',
            { subjectId, se, ep },
            { label: 'mb-play-info', useProxy:true }
        );
    } catch (error: any) {
        return NextResponse.json(
            { error: true, message: "Gagal mengambil stream DASH: " + error.message },
            { status: 500 }
        );
    }
}