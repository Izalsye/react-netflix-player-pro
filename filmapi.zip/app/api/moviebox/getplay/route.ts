import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';
import { MovieboxMapper } from '@/lib/moviebox/mapping'; // Jangan lupa di-import bre

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');
    const se = searchParams.get('se') || '1';
    const ep = searchParams.get('ep') || '1';

    if (!subjectId) {
        return NextResponse.json(
            { error: true, message: "Parameter 'subjectId' wajib diisi bre!" },
            { status: 400 }
        );
    }

    try {
        // 1. HIT PERTAMA: Ambil data DASH
        const playInfoRes = await movieboxGet(
            req,
            '/wefeed-mobile-bff/subject-api/play-info',
            { subjectId, se, ep },
            { send: false, useProxy:true }
        );

        if (playInfoRes?.error) {
            return NextResponse.json(playInfoRes, { status: playInfoRes.http_status || 500 });
        }

        const streamId = playInfoRes?.data?.streams?.[0]?.id;

        // 2. HIT KEDUA & KETIGA: Ambil Captions dan Resource BERSAMAAN
        const [captionsRes, resourceRes] = await Promise.all([
            streamId ? movieboxGet(
                req,
                '/wefeed-mobile-bff/subject-api/get-stream-captions',
                { subjectId, streamId },
                { send: false, useProxy:true }
            ) : Promise.resolve(null),

            movieboxGet(
                req,
                '/wefeed-mobile-bff/subject-api/resource',
                {
                    subjectId, se, epFrom: ep, epTo: ep,
                    page: '1', perPage: '10', all: '0', resolution: '0'
                },
                { send: false, useProxy:true }
            )
        ]);

        // 3. GABUNGKAN DATA MENTAH
        const rawCombinedData = {
            code: 0,
            message: "ok",
            data: {
                playInfo: playInfoRes?.data || null,
                captions: captionsRes?.data || null,
                resource: resourceRes?.data || null
            }
        };

        // 🚀 4. PROSES MAPPING DATA JADI RAPI (Lempar parameter 'ep' untuk filter MP4)
        const mappedData = MovieboxMapper.mapPlayData(rawCombinedData, ep);

        const statusCode = mappedData.code === 0 ? 200 : 500;
        return NextResponse.json(mappedData, { status: statusCode });

    } catch (error: any) {
        return NextResponse.json(
            { code: 500, message: "Terjadi kesalahan saat memuat data play: " + error.message, data: null },
            { status: 500 }
        );
    }
}