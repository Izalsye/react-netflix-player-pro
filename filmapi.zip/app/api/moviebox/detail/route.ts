import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';
import { MovieboxMapper } from '@/lib/moviebox/mapping'; // Sesuaikan lokasi

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');

    if (!subjectId) {
        return NextResponse.json(
            { error: true, message: "Parameter 'subjectId' wajib diisi bre!" },
            { status: 400 }
        );
    }

    try {
        const [detailData, seasonData] = await Promise.all([
            movieboxGet(
                req,
                '/wefeed-mobile-bff/subject-api/get',
                { subjectId, se: '0' },
                { send: false, cacheTtlMs: 60_000, useProxy: true },
            ),
            movieboxGet(
                req,
                '/wefeed-mobile-bff/subject-api/season-info',
                { subjectId },
                { send: false, cacheTtlMs: 60_000, useProxy: true }
            )
        ]);

        if (detailData?.error) {
            return NextResponse.json(detailData, { status: detailData.http_status || 500 });
        }

        // Merge array seasons dari API kedua ke objek API pertama
        if (detailData?.data && seasonData?.data?.seasons) {
            detailData.data.seasons = seasonData.data.seasons;
        }
        // console.log("=== RAW SEASON DATA ===", JSON.stringify(seasonData, null, 2));
        // 🚀 PROSES MAPPING DATA
        const mappedData = MovieboxMapper.mapDetail(detailData);

        const statusCode = mappedData.code === 0 ? 200 : 500;
        return NextResponse.json(mappedData, { status: statusCode });

    } catch (error: any) {
        return NextResponse.json(
            { code: 500, message: "Terjadi kesalahan sistem: " + error.message, data: null },
            { status: 500 }
        );
    }
}