// app/api/moviebox/indocast/route.ts
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const targetUrl = searchParams.get('url');

    if (!targetUrl) {
        return NextResponse.json(
            { error: true, message: "Parameter 'url' wajib diisi bre!" },
            { status: 400 }
        );
    }

    try {
        // 1. Tangkap header 'Range' dari browser
        // Ini SANGAT PENTING untuk video player biar user bisa skip/dipercepat (forward/rewind)
        const range = req.headers.get('range');

        // 2. Siapkan header penyamaran (Spoofing)
        // Kita bohongi servernya biar ngira kita adalah aplikasi Android asli
        const fetchHeaders = new Headers({
            'User-Agent': 'com.community.oneroom/50020121 (Linux; U; Android 9; in_ID; SM-G955F; Build/PPR1.180610.011; Cronet/145.0.7582.0)',
            'Accept': '*/*',
            'Connection': 'keep-alive',
        });

        // Kalau browser minta potongan video tertentu, teruskan ke server asli
        if (range) {
            fetchHeaders.set('Range', range);
        }

        // 3. Lakukan Fetch ke server asli (CDN Hakuna Matata)
        const response = await fetch(targetUrl, {
            method: 'GET',
            headers: fetchHeaders,
            cache: 'no-store', // Jangan pernah di-cache karena ini aliran data besar (stream)
        });

        // 4. Tangani jika link sudah mati/expired
        if (!response.ok) {
            return NextResponse.json(
                { error: true, message: `Server asli menolak: ${response.status} ${response.statusText}` },
                { status: response.status }
            );
        }

        // 5. Susun Header balasan untuk Web Browser
        const responseHeaders = new Headers();

        // Pilih header bawaan server asli yang wajib diteruskan ke browser
        const headersToKeep = [
            'content-type',
            'content-length',
            'content-range',
            'accept-ranges'
        ];

        response.headers.forEach((value, key) => {
            if (headersToKeep.includes(key.toLowerCase())) {
                responseHeaders.set(key, value);
            }
        });

        // Tambahkan header anti-CORS supaya player di frontend kamu nggak rewel
        responseHeaders.set('Access-Control-Allow-Origin', '*');
        responseHeaders.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
        responseHeaders.set('Access-Control-Allow-Headers', 'Range');

        // 6. KEMBALIKAN STREAMING-NYA LANGSUNG KE BROWSER!
        return new NextResponse(response.body, {
            status: response.status,
            statusText: response.statusText,
            headers: responseHeaders,
        });

    } catch (error: any) {
        return NextResponse.json(
            { error: true, message: "Gagal memproses proxy stream: " + error.message },
            { status: 500 }
        );
    }
}