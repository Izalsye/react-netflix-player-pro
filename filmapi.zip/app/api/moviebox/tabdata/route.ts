// app/api/moviebox/tabdata/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';
import { MovieboxMapper } from '@/lib/moviebox/mapping'; // Panggil mapper-nya

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);

    const page = searchParams.get('page') || '1';
    const tabId = searchParams.get('tabId') || '0';
    const version = searchParams.get('version') || process.env.MOVIEBOX_TAB_VERSION || '6640c690e067dcda89f122568b26b11c';

    const endpointPath = '/wefeed-mobile-bff/tab-operating';
    const queryParams = { page, tabId, version };

    try {
        // Ambil raw data dari upstream (send: false wajib agar tidak langsung di-return)
        const rawResponse = await movieboxGet(
            req,
            endpointPath,
            queryParams,
            {
                label: 'mb-tabdata',
                cacheTtlMs: 60_000,
                send: false
            }
        );

        // Jika upstream nolak (403, 500, dll)
        if (rawResponse?.error) {
            return NextResponse.json(rawResponse, { status: rawResponse.http_status || 500 });
        }

        // 🚀 PROSES MAPPING DATA
        const mappedData = MovieboxMapper.mapTabData(rawResponse);

        const statusCode = mappedData.code === 0 ? 200 : 500;
        return NextResponse.json(mappedData, { status: statusCode });

    } catch (error: any) {
        return NextResponse.json({ code: 500, message: "Internal Server Error", data: null }, { status: 500 });
    }
}