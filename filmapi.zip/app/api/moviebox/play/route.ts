import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy'; // Sesuaikan path ini

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    // 1. Ambil semua query parameters dari URL
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');

    // Validasi parameter wajib
    if (!subjectId) {
        return NextResponse.json(
            { error: true, message: "Parameter 'subjectId' wajib diisi bre!" },
            { status: 400 }
        );
    }

    // 2. Ubah URLSearchParams menjadi Object agar mudah dikirim ke fungsi proxy
    // Ini bikin rute ini fleksibel, parameter apapun yang dikirim frontend bakal diteruskan
    const queryParams: Record<string, string> = {};
    searchParams.forEach((value, key) => {
        queryParams[key] = value;
    });

    // Berikan default value untuk parameter yang kosong agar behavior-nya mirip dengan aplikasi asli
    queryParams.page = queryParams.page || '1';
    queryParams.perPage = queryParams.perPage || '10';
    queryParams.all = queryParams.all || '0';
    queryParams.se = queryParams.se || '1';
    queryParams.resolution = queryParams.resolution || '0'; // 0 biasanya untuk default/auto

    // 3. Tentukan endpoint upstream
    const endpointPath = '/wefeed-mobile-bff/subject-api/resource';

    try {
        // 4. Hit server aslinya
        // ⚠️ PERHATIAN: Jangan gunakan cache lama-lama di sini! 
        // Link MP4 punya token (?sign=...) yang bisa expired. 
        // Kita set cacheTtlMs false/0 atau hapus opsinya agar selalu dapat link fresh.
        return await movieboxGet(
            req,
            endpointPath,
            queryParams,
            {
                label: 'mb-resource', useProxy:true
                // Nggak pakai cacheTtlMs agar link videonya selalu fresh dan nggak kadaluarsa
            }
        );
    } catch (error: any) {
        return NextResponse.json(
            { error: true, message: "Gagal mengambil link video: " + error.message },
            { status: 500 }
        );
    }
}