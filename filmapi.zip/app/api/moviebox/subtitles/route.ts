import { NextRequest, NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const subjectId = searchParams.get('subjectId');
    const streamId = searchParams.get('streamId');

    // Validasi parameter
    if (!subjectId || !streamId) {
        return NextResponse.json(
            { error: true, message: "Parameter 'subjectId' dan 'streamId' wajib diisi bre!" },
            { status: 400 }
        );
    }

    try {
        // Jangan pakai cacheTtlMs karena link AWS CloudFront ini punya waktu kadaluarsa (Policy & Signature)
        return await movieboxGet(
            req,
            '/wefeed-mobile-bff/subject-api/get-stream-captions',
            { subjectId, streamId },
            {
                label: 'mb-captions'
                // cacheTtlMs tidak digunakan agar selalu fresh
            }
        );
    } catch (error: any) {
        return NextResponse.json(
            { error: true, message: "Gagal mengambil subtitle: " + error.message },
            { status: 500 }
        );
    }
}