// app/api/moviebox/hometab/route.ts
import { NextResponse } from 'next/server';
import { movieboxGet } from '@/lib/moviebox/proxy';
import { MovieboxMapper } from '@/lib/moviebox/mapping'; // Sesuaikan path

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
    const endpointPath = '/wefeed-mobile-bff/subject-api/bottom-tab';

    try {
        // 1. Ambil data mentah (raw JSON) pakai opsi send: false
        const rawResponse = await movieboxGet(
            req,
            endpointPath,
            {},
            {
                label: 'mb-hometab',
                cacheTtlMs: 300_000, // Cache 5 menit
                send: false // PENTING: Supaya kita bisa olah datanya dulu
            }
        );

        // 2. Kalau ada error upstream (misal 500 / 403) yang kita handle di proxy
        if (rawResponse?.error) {
            return NextResponse.json(rawResponse, { status: rawResponse.http_status || 500 });
        }

        // 3. Masukkan ke mesin Mapper kita!
        const mappedData = MovieboxMapper.mapHomeTabs(rawResponse);

        // 4. Kirim hasilnya ke frontend
        // Jika di mapping error/null, kembalikan status 500, jika tidak 200
        const statusCode = mappedData.code === 0 ? 200 : 500;
        return NextResponse.json(mappedData, { status: statusCode });

    } catch (error: any) {
        return NextResponse.json(
            { code: 500, message: "Internal Server Error", data: null },
            { status: 500 }
        );
    }
}