import { NextResponse } from 'next/server';
import prisma from '@/prisma/prisma'; // Sesuaikan path prisma lu

export async function GET() {
    try {
        // Ini data paket VIP sesuai request lu bre
        const plans = [
            { code: '1_MONTH', name: '1 Bulan', price: 45000, durationDays: 30, limitPerDay: 1000000 },
            { code: '2_MONTHS', name: '2 Bulan', price: 80000, durationDays: 60, limitPerDay: 1000000 },
            { code: '3_MONTHS', name: '3 Bulan', price: 105000, durationDays: 90, limitPerDay: 1000000 },
            { code: '6_MONTHS', name: '6 Bulan', price: 180000, durationDays: 180, limitPerDay: 1000000 },
        ];

        // Kita pakai fungsi upsert (Update or Insert)
        // Jadi kalau datanya udah ada, dia bakal nge-update harganya. Kalau belum ada, dia bikin baru.
        for (const plan of plans) {
            await prisma.plan.upsert({
                where: { code: plan.code },
                update: {
                    price: plan.price,
                    name: plan.name,
                    durationDays: plan.durationDays
                },
                create: plan,
            });
        }

        return NextResponse.json({
            success: true,
            message: 'Mantap bre! Data Plan VIP berhasil ditambahkan ke Database.'
        });

    } catch (error) {
        console.error('SETUP PLAN ERROR:', error);
        return NextResponse.json({ error: 'Gagal insert data' }, { status: 500 });
    }
}