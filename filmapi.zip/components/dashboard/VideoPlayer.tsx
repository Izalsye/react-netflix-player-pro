'use client';

import { useEffect, useRef, useState } from 'react';
import Artplayer from 'artplayer';
import shaka from 'shaka-player';
import Hls from 'hls.js';

interface Subtitle {
    lang?: string;
    code?: string;
    label?: string;
    language?: string;
    subUrl?: string;
    url_proxy?: string;
    url?: string;
    format?: string;
}

interface VideoPlayerProps {
    src: string;
    qualities?: { html: string; url: string; default?: boolean }[];
    subtitles?: Subtitle[];
    licenseServers?: any;
    customData?: any;
    provider?: string;
    audioConf?: any;
}

if (typeof window !== 'undefined') {
    shaka.polyfill.installAll();
}

const getNiceLanguageName = (langCode?: string, originalLabel?: string) => {
    const rawCode = (langCode || '').toLowerCase().replace(/_/g, '-');
    const rawLabel = (originalLabel || '').toLowerCase();

    if (rawCode.includes('id') || rawCode === 'in' || rawLabel.includes('indo')) return 'Indonesia';
    if (rawCode.includes('en') || rawLabel.includes('eng')) return 'English';
    if (rawCode.includes('ms') || rawLabel.includes('malay')) return 'Melayu';

    if (originalLabel && originalLabel.length > 2 && !originalLabel.includes('_') && !originalLabel.startsWith('und')) {
        return originalLabel;
    }
    if (!langCode) return originalLabel || 'Unknown';
    try {
        const displayName = new Intl.DisplayNames(['id'], { type: 'language' });
        const cleanCode = rawCode.split('-')[0];
        const name = displayName.of(cleanCode);
        return name ? name.charAt(0).toUpperCase() + name.slice(1) : langCode.toUpperCase();
    } catch (e) {
        return langCode.toUpperCase();
    }
};

// ⭐ MAGIC AUTO-CONVERTER: SRT ke WebVTT secara Real-Time agar Native HTML5 Player / WeTV kebaca
const fetchToBlobUrl = async (url: string) => {
    try {
        const res = await fetch(url);
        if (!res.ok) return url;
        let text = await res.text();
        let type = 'text/vtt';

        text = text.trim();

        if (text.startsWith('WEBVTT')) {
            type = 'text/vtt';
        } else if (text.includes('<?xml') || text.includes('<tt')) {
            type = 'application/ttml+xml';
        } else if (text.includes('-->')) {
            // Ini Fix untuk Filmbox! Kalau format murni SRT, wajib diconvert ke VTT
            text = 'WEBVTT\n\n' + text.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
            type = 'text/vtt';
        }

        const blob = new Blob([text], { type });
        return URL.createObjectURL(blob);
    } catch (e) {
        return url;
    }
};

export default function VideoPlayer({ src, qualities, subtitles, licenseServers, customData, provider, audioConf }: VideoPlayerProps) {
    const artRef = useRef<HTMLDivElement>(null);
    const artInstance = useRef<Artplayer | null>(null);
    const shakaRef = useRef<any>(null);
    const [isVideoReady, setIsVideoReady] = useState(false);

    useEffect(() => {
        const container = artRef.current;
        if (!container) return;

        let isDestroyed = false;
        setIsVideoReady(false);
        let activeBlobUrls: string[] = [];
        // Deteksi File Murni MP4 (Filmbox) agar ngebut!
        const isMp4 = src.includes('.mp4') || provider?.includes('filmbox') || qualities?.some(q => q.url.includes('.mp4'));
        const isWeTv = provider?.includes('wetv');

        let activeEngineType = 'customShaka';
        if (isMp4) activeEngineType = ''; // Kosong = HTML5 Native
        else if (isWeTv) activeEngineType = 'customHls'; // WeTV pakai HLS

        const modernIcons = {
            play: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M6 4l15 8-15 8z"></path></svg>',
            pause: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M6 4h4v16H6zm8 0h4v16h-4z"></path></svg>',
            volume: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"></path></svg>',
            volumeClose: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"></path></svg>',
            setting: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.06-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.73,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.06,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.49-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"></path></svg>',
            fullscreen: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"></path></svg>',
            fullscreenWeb: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"></path></svg>',
            pip: '<svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M19 11h-8v6h8v-6zm4 8V4.98C23 3.88 22.1 3 21 3H3c-1.1 0-2 .88-2 1.98V19c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2zm-2 .02H3V4.97h18v14.05z"></path></svg>',
        };

        const seekBackIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M15 15l-6-6m0 0l6-6m-6 6h11.25M3.375 19.5h17.25c.621 0 1.125-.504 1.125-1.125v-9.75M3.375 19.5c-.621 0-1.125-.504-1.125-1.125v-9.75M3.375 19.5h11.25m-11.25 0V1.875c0-.621.504-1.125 1.125-1.125h9.75c.621 0 1.125.504 1.125 1.125v7.5"/></svg>';
        const seekForwardIcon = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 15l6-6m0 0l-6-6m6 6H3.375M20.625 19.5H3.375c-.621 0-1.125-.504-1.125-1.125v-9.75M20.625 19.5c.621 0 1.125-.504 1.125-1.125v-9.75M20.625 19.5H9m11.625 0V1.875c0-.621-.504-1.125-1.125-1.125h-9.75c-.621 0-1.125.504-1.125 1.125v7.5"/></svg>';

        const artConfig: any = {
            container: container,
            url: src,
            theme: '#E50914',
            volume: 1,
            autoplay: true,
            pip: true,
            setting: true,
            playbackRate: true,
            aspectRatio: true,
            fullscreen: true,
            fullscreenWeb: true,
            miniProgressBar: true,
            playsInline: true,
            autoPlayback: true,
            airplay: true,
            icons: modernIcons,
            // ⭐ PAKE NATIVE QUALITY ARTPLAYER, JANGAN INJECT MANUAL BIAR GA BENTROK/DUPLIKAT
            quality: qualities && qualities.length > 0 ? qualities : [],
            cssVar: {
                '--art-setting-width': '250px',
                '--art-volume-width': '100px',
            },
            customType: {
                customHls: function (video: any, url: any, art: any) {
                    if (Hls.isSupported()) {
                        if ((art as any).hls) (art as any).hls.destroy();

                        const hls = new Hls();
                        (art as any).hls = hls;

                        hls.loadSource(url);
                        hls.attachMedia(video);
                        art.on('destroy', () => hls.destroy());

                        hls.on(Hls.Events.MANIFEST_PARSED, () => {
                            const levels = hls.levels;
                            // Cegah bug menu "0p" (Cuma render internal HLS kalau list > 1 dan gak ada external qualities)
                            if (levels.length > 1 && (!qualities || qualities.length === 0)) {
                                art.setting.add({
                                    name: 'quality-hls-setting',
                                    html: 'Resolution',
                                    width: 250,
                                    selector: [
                                        { html: 'Auto', id: -1, default: true },
                                        ...levels.map((level, i) => ({ html: `${level.height}p`, id: i, default: false }))
                                    ],
                                    onSelect: function (item: any) {
                                        hls.currentLevel = item.id;
                                        return item.html;
                                    }
                                });
                            }
                        });
                    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                        video.src = url;
                    }
                },
                customShaka: async (video: any, url: any, art: any) => {
                    if (shaka.Player.isBrowserSupported()) {
                        if (shakaRef.current) await shakaRef.current.destroy().catch(() => { });

                        const player = new shaka.Player() as any;
                        await player.attach(video);
                        shakaRef.current = player;

                        let defaultAudioLang = 'id';
                        if (audioConf?.languageCode) defaultAudioLang = audioConf.languageCode.toLowerCase();

                        player.configure({
                            streaming: { bufferBehind: 30, bufferingGoal: 60 },
                            manifest: { hls: { ignoreTextStreamFailures: true, ignoreImageStreamFailures: true } },
                            preferredAudio: [{ language: defaultAudioLang }]
                        });

                        player.getNetworkingEngine()?.registerRequestFilter((type: any, request: any) => {
                            if (type === shaka.net.NetworkingEngine.RequestType.LICENSE) {
                                if (provider?.includes('vidio') && customData) {
                                    const pallyconToken = customData.widevine || customData.playready;
                                    if (pallyconToken) request.headers['pallycon-customdata-v2'] = pallyconToken;
                                } else if (customData?.token) {
                                    request.headers['authorization'] = customData.token.trim();
                                }
                            }
                        });

                        if (provider?.includes('hbo') && licenseServers?.licenseUrl) {
                            player.configure({ drm: { servers: { 'com.widevine.alpha': licenseServers.licenseUrl, 'com.microsoft.playready': licenseServers.licenseUrl } } });
                        } else if (provider?.includes('vidio') && licenseServers?.drm_license_url) {
                            const drmProxyUrl = `/api/vidio/drm-proxy?url=${encodeURIComponent(licenseServers.drm_license_url)}`;
                            player.configure({ drm: { servers: { 'com.widevine.alpha': drmProxyUrl, 'com.microsoft.playready': drmProxyUrl } } });
                        } else if ((provider?.includes('prime') || licenseServers?.certificate_base64) && licenseServers?.drm_license_url) {
                            player.configure({ drm: { servers: { 'com.widevine.alpha': licenseServers.drm_license_url }, advanced: { 'com.widevine.alpha': { audioRobustness: ['SW_SECURE_CRYPTO'], videoRobustness: ['SW_SECURE_CRYPTO'] } } }, manifest: { ignoreDrmInfo: true } });
                        } else if (provider?.includes('viu') && licenseServers?.drm_license_url) {
                            const drmProxyUrl = `/api/viu/drm-proxy?url=${encodeURIComponent(licenseServers.drm_license_url)}`;
                            player.configure({ drm: { servers: { 'com.widevine.alpha': drmProxyUrl } } });
                        }

                        let forceMimeType = undefined;
                        if (provider?.includes('idlix') || provider?.includes('iqiyi') || src.includes('.json') || src.includes('.m3u8')) forceMimeType = 'application/x-mpegurl';

                        await player.load(url, null, forceMimeType);

                        const variantTracks = player.getVariantTracks();
                        const uniqueHeights = Array.from(new Set(variantTracks.map((t: any) => t.height).filter(Boolean))).sort((a: any, b: any) => b - a);

                        if (uniqueHeights.length > 1 && (!qualities || qualities.length === 0)) {
                            art.setting.add({
                                name: 'quality-shaka-setting',
                                html: 'Resolution',
                                width: 250,
                                selector: [
                                    { html: 'Auto', id: 'auto', default: true },
                                    ...uniqueHeights.map(h => ({ html: `${h}p`, id: h, default: false }))
                                ],
                                onSelect: (item: any) => {
                                    if (item.id === 'auto') player.configure({ abr: { enabled: true } });
                                    else {
                                        player.configure({ abr: { enabled: false } });
                                        const tracks = player.getVariantTracks();
                                        const targetTrack = tracks.find((t: any) => t.height === item.id);
                                        if (targetTrack) player.selectVariantTrack(targetTrack, true);
                                    }
                                    return item.html;
                                }
                            });
                        }

                        const uniqueAudioLangs = Array.from(new Set(variantTracks.map((t: any) => t.language).filter(Boolean)));
                        if (uniqueAudioLangs.length > 1) {
                            const activeTrack = variantTracks.find((t: any) => t.active);
                            const activeLang = activeTrack ? activeTrack.language : uniqueAudioLangs[0];
                            art.setting.add({
                                name: 'audio-setting',
                                html: 'Audio',
                                width: 250,
                                selector: uniqueAudioLangs.map((lang: any) => ({
                                    html: getNiceLanguageName(lang, variantTracks.find((t: any) => t.language === lang)?.label),
                                    lang: lang,
                                    default: lang === activeLang
                                })),
                                onSelect: function (item: any) {
                                    try {
                                        const targetTrack = variantTracks.find((t: any) => t.language === item.lang);
                                        if (targetTrack) player.selectVariantTrack(targetTrack, true, true);
                                    } catch (e) { }
                                    return item.html;
                                }
                            });
                        }

                        if (subtitles && subtitles.length > 0) {
                            const injectPromises = subtitles.map(async (sub) => {
                                try {
                                    const trackUrl = sub.subUrl || sub.url_proxy || sub.url || '';
                                    if (!trackUrl) return;
                                    const blobUrl = await fetchToBlobUrl(trackUrl);
                                    // Default ke VTT karena fetchToBlobUrl udah ngerjain tugasnya
                                    await player.addTextTrackAsync(blobUrl, sub.lang || sub.code || 'id', 'subtitles', 'text/vtt', undefined, sub.label || sub.language || 'Subtitle');
                                } catch (err) { }
                            });
                            await Promise.all(injectPromises);
                        }

                        if (isDestroyed) return;
                        const textTracks = player.getTextTracks();
                        if (textTracks.length > 0) {
                            const indoTrack = textTracks.find((t: any) => t?.language?.toLowerCase().startsWith('id') || t?.label?.toLowerCase().includes('indo'));
                            const activeTrack = indoTrack || textTracks[0];

                            player.selectTextTrack(activeTrack);
                            if (typeof player.setTextTrackVisibility === 'function') player.setTextTrackVisibility(true);

                            art.setting.add({
                                name: 'subtitle-shaka-setting',
                                html: 'Subtitles',
                                width: 250,
                                selector: [
                                    { html: 'Off', track: null, default: !activeTrack },
                                    ...textTracks.map((t: any) => ({
                                        html: getNiceLanguageName(t.language, t.label),
                                        track: t,
                                        default: t.id === activeTrack.id
                                    }))
                                ],
                                onSelect: function (item: any) {
                                    if (item.track === null) player.setTextTrackVisibility(false);
                                    else {
                                        player.setTextTrackVisibility(true);
                                        player.selectTextTrack(item.track);
                                    }
                                    return item.html;
                                }
                            });
                        }
                    }
                }
            }
        };

        if (activeEngineType !== '') artConfig.type = activeEngineType;

        artInstance.current = new Artplayer(artConfig);

        artInstance.current.on('ready', () => {
            const art = artInstance.current!;
            const video = art.video;

            // ⭐ INJECT SUBTITLE NATIVE HTML5 & HLS
            if (activeEngineType !== 'customShaka' && subtitles && subtitles.length > 0) {

                // 1. Kunci SATU index subtitle default sebelum di-fetch (Prioritas Indo)
                let defaultSubIndex = subtitles.findIndex(s =>
                    (s.lang && s.lang.toLowerCase().includes('id')) ||
                    (s.label && s.label.toLowerCase().includes('indo'))
                );
                // Kalau nggak ada Indo, default ke urutan pertama aja
                if (defaultSubIndex === -1) defaultSubIndex = 0;
                const trackElements: HTMLTrackElement[] = [];

                const promises = subtitles.map(async (sub, index) => {
                    const trackUrl = sub.subUrl || sub.url_proxy || sub.url || '';
                    if (!trackUrl) return;

                    const blobUrl = await fetchToBlobUrl(trackUrl);

                    // Kalau modal udah ditutup pas lagi fetch, langsung hapus blob-nya biar nggak bocor
                    if (isDestroyed) {
                        URL.revokeObjectURL(blobUrl);
                        return;
                    }

                    activeBlobUrls.push(blobUrl); // Simpan blob url ke array

                    const track = document.createElement('track');
                    track.kind = 'subtitles';
                    track.srclang = sub.lang || sub.code || 'id';
                    track.label = getNiceLanguageName(track.srclang, sub.label || sub.language);
                    track.src = blobUrl;

                    // Beri izin 'default' murni HANYA ke 1 track yang terpilih
                    const isDefault = (index === defaultSubIndex);
                    if (isDefault) track.default = true;

                    video.appendChild(track);
                    // MAGIC FIX: Listen saat file VTT selesai diparsing
                    track.addEventListener('load', () => {
                        if (track.track) {
                            track.track.mode = isDefault ? 'showing' : 'disabled';
                        }
                    });

                    trackElements.push(track);
                });

                Promise.all(promises).then(() => {
                    if (isDestroyed || trackElements.length === 0) return;

                    art.setting.add({
                        name: 'subtitle-html5-setting',
                        html: 'Subtitles',
                        width: 250,
                        selector: [
                            { html: 'Off', track: null, default: false },
                            ...trackElements.map((t, i) => ({
                                html: t.label,
                                track: t,
                                default: i === defaultSubIndex // Centang rapi sesuai pilihan awal
                            }))
                        ],
                        onSelect: function (item: any) {
                            // Saat menu diganti, eksekusi pembersihan total
                            Array.from(video.textTracks).forEach((t: any) => t.mode = 'disabled');
                            if (item.track) {
                                const selected = Array.from(video.textTracks).find((t: any) => t.label === item.track.label);
                                if (selected) (selected as any).mode = 'showing';
                            }
                            return item.html;
                        }
                    });
                });
            }

            // ⭐ SMART DOUBLE CLICK ZONES (Tetap dipakai)
            const showSeekAnim = (dir: 'back' | 'forward') => {
                const anim = document.createElement('div');
                anim.className = 'seek-anim-custom';
                anim.innerHTML = dir === 'back' ? `${seekBackIcon}<span>-10</span>` : `${seekForwardIcon}<span>+10</span>`;
                anim.style.left = dir === 'back' ? '25%' : '75%';
                art.template.$player.appendChild(anim);
                setTimeout(() => anim.remove(), 800);
            };

            const createClickZone = (direction: 'back' | 'forward') => {
                const zone = document.createElement('div');
                zone.style.cssText = `position: absolute; top: 0; bottom: 60px; width: 30%; z-index: 20; cursor: pointer;`;
                zone.style[direction === 'back' ? 'left' : 'right'] = '0';

                let clickTimeout: any;
                zone.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (clickTimeout) {
                        clearTimeout(clickTimeout);
                        clickTimeout = null;

                        const duration = video.duration || 0;
                        let newTime = video.currentTime + (direction === 'back' ? -10 : 10);
                        video.currentTime = Math.max(0, Math.min(newTime, duration));
                        showSeekAnim(direction);
                    } else {
                        clickTimeout = setTimeout(() => {
                            clickTimeout = null;
                            art.toggle();
                        }, 250);
                    }
                });

                zone.addEventListener('dblclick', (e) => e.stopPropagation());
                return zone;
            };

            art.template.$player.appendChild(createClickZone('back'));
            art.template.$player.appendChild(createClickZone('forward'));
        });

        artInstance.current.on('video:loadedmetadata', () => setIsVideoReady(true));
        artInstance.current.on('video:canplay', () => setIsVideoReady(true));

        // 🔥 MAGIC CLEANUP BARU: Eksekusi saat pindah episode atau tutup modal
        return () => {
            isDestroyed = true;

            // 1. Hapus SEMUA Blob Subtitle dari memori browser!
            if (activeBlobUrls && activeBlobUrls.length > 0) {
                activeBlobUrls.forEach(url => URL.revokeObjectURL(url));
            }

            // 2. Destroy Shaka Player
            if (shakaRef.current) {
                shakaRef.current.destroy().catch(() => { });
            }

            // 3. Kosongkan Buffer Video & Destroy Artplayer sepenuhnya
            if (artInstance.current) {
                const videoElement = artInstance.current.video;
                if (videoElement) {
                    videoElement.pause();
                    videoElement.removeAttribute('src'); // Buang buffer dari memori!
                    videoElement.load();
                }

                // Ubah false jadi true agar elemen DOM Artplayer dibersihkan total
                artInstance.current.destroy(true);
            }
        };
    }, [src, qualities, licenseServers, customData, subtitles, provider, audioConf]);

    return (
        <div className="w-full relative aspect-video bg-black rounded-lg overflow-hidden shadow-2xl group animate-in fade-in duration-500">
            <div className="absolute top-4 right-4 z-50 pointer-events-none opacity-80 group-hover:opacity-100 transition-opacity">
                <style>{`
                    .art-control-icon svg { margin: 0 auto; transition: transform 0.2s; }
                    .art-control-icon:hover svg { transform: scale(1.15); }
                    @keyframes watermark-pulse { 0%, 100% { opacity: 0.6; text-shadow: 0 0 5px rgba(229,9,20,0.3); } 50% { opacity: 1; text-shadow: 0 0 15px rgba(229,9,20,0.8); } }
                    .watermark-text { animation: watermark-pulse 3s infinite ease-in-out; }
                    .seek-anim-custom { position: absolute; top: 50%; transform: translate(-50%, -50%); display: flex; flex-direction: column; align-items: center; justify-content: center; background: rgba(0,0,0,0.6); border-radius: 50%; width: 90px; height: 90px; color: white; font-size: 18px; font-weight: bold; pointer-events: none; animation: seek-fade 0.8s cubic-bezier(0.4, 0, 0.2, 1) forwards; z-index: 50; }
                    .seek-anim-custom svg { margin-bottom: 2px; }
                    @keyframes seek-fade { 0% { opacity: 0; transform: translate(-50%, -50%) scale(0.5); } 20% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); } 40% { transform: translate(-50%, -50%) scale(1); } 100% { opacity: 0; transform: translate(-50%, -50%) scale(1); } }
                `}</style>
                <h2 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-[#E50914] to-[#83050C] tracking-[0.1em] watermark-text select-none">
                    INDOCAST
                </h2>
            </div>
            <div ref={artRef} className="w-full h-full" />
        </div>
    );
}